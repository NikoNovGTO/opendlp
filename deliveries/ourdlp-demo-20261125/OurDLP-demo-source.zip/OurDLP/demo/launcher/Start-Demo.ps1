﻿#Requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference='Stop'
try {
. (Join-Path $PSScriptRoot 'DemoCommon.ps1')
. (Join-Path $PSScriptRoot 'DemoProcesses.ps1')
} catch {[Windows.Forms.MessageBox]::Show('Комплект распакован не полностью или его описание повреждено. Распакуйте архив заново.','OurDLP')|Out-Null;exit 1}
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=[Security.Principal.WindowsPrincipal]::new($identity)
if($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    [Windows.Forms.MessageBox]::Show('Откройте ЗАПУСТИТЬ.cmd обычным пользователем. Повышение прав будет запрошено только для подготовки и установки службы.','OurDLP')|Out-Null;exit
}
$created=$false;$single=[Threading.Mutex]::new($true,'Local\OurDLP.DemoLauncher',[ref]$created)
if(-not $created){[Windows.Forms.MessageBox]::Show('Окно демонстрации уже открыто.','OurDLP')|Out-Null;$single.Dispose();exit}
try{
    Initialize-DemoData
    if(-not [Environment]::Is64BitOperatingSystem -or -not [Environment]::Is64BitProcess){throw 'Требуется Windows x64 и 64-разрядный PowerShell.'}
    $form=[Windows.Forms.Form]::new();$form.Text='OurDLP — Демонстрация на одном ПК';$form.Size=[Drawing.Size]::new(850,730);$form.MinimumSize=[Drawing.Size]::new(800,680)
    $form.StartPosition='CenterScreen';$form.Font=[Drawing.Font]::new('Segoe UI',10);$form.AutoScaleMode='Dpi';$form.BackColor=[Drawing.Color]::FromArgb(243,245,248)
    $panel=[Windows.Forms.FlowLayoutPanel]::new();$panel.Dock='Fill';$panel.Padding=[Windows.Forms.Padding]::new(24);$panel.FlowDirection='TopDown';$panel.WrapContents=$false;$panel.AutoScroll=$true;$form.Controls.Add($panel)
    function Add-DemoLabel([string]$Text,[int]$Height,[int]$Size){$label=[Windows.Forms.Label]::new();$label.Text=$Text;$label.Width=740;$label.Height=$Height;$label.Font=[Drawing.Font]::new('Segoe UI',$Size);$panel.Controls.Add($label);return $label}
    $null=Add-DemoLabel 'OurDLP — показ на одном Windows-ПК' 42 19
    $null=Add-DemoLabel 'Один комплект: сервер, консоль, агент и тестовые материалы. .NET включён. PostgreSQL должен быть установлен и запущен. Перед запуском закройте прежний сервер в Visual Studio.' 70 10
    $status=Add-DemoLabel 'Начните с проверки готовности. Если база и сертификат уже настроены, первичную подготовку можно пропустить.' 66 10
    $script:DemoBusy=$false;$script:DemoButtons=@();$script:DemoChildProcess=$null
    function Run-DemoAction([scriptblock]$Action){
        if($script:DemoBusy){return};$script:DemoBusy=$true;foreach($b in $script:DemoButtons){$b.Enabled=$false};$status.Text='Выполняется действие…';$form.Refresh()
        try{& $Action}catch{$status.Text=$_.Exception.Message}
        finally{$script:DemoBusy=$false;foreach($b in $script:DemoButtons){$b.Enabled=$true}}
    }
    function Add-DemoButton([string]$Text,[scriptblock]$Action){
        $button=[Windows.Forms.Button]::new();$button.Text=$Text;$button.Width=740;$button.Height=42;$button.Margin=[Windows.Forms.Padding]::new(0,0,0,8)
        $button.Tag=$Action;$button.Add_Click({param($sender,$eventArgs) Run-DemoAction $sender.Tag});$panel.Controls.Add($button);$script:DemoButtons+=,$button
    }
    function Start-DemoElevated([string]$Name){
        if($null -ne $script:DemoChildProcess -and -not $script:DemoChildProcess.HasExited){throw 'Сначала завершите открытое окно подготовки или установки агента.'}
        $file=Join-Path $PSScriptRoot $Name
        $script:DemoChildProcess=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$file+'"'),'-ExpectedSid',$identity.User.Value) -PassThru
        $status.Text='Открылось окно подготовки. Завершите шаги в нём, затем вернитесь сюда.'
    }
    Add-DemoButton 'Проверить готовность' {
        $setup=Get-DemoLocalSetup
        $text=switch($setup.DatabaseStatus){'ready'{if($setup.AdministratorExists){'База готова, администратор уже создан.'}else{'База готова; нужно создать администратора.'}}'not-configured'{'Подключение к базе ещё не настроено.'}'migration-required'{'Нужно обновить структуру базы.'}default{'PostgreSQL недоступен. Проверьте его службу и настройки.'}}
        try{$cert=Get-DemoCertificate;$cert.Dispose();$text+=' Сертификат найден.'}catch{$text+=' Сертификат требует подготовки.'}
        $service=Get-Service OurDLP.Agent -ErrorAction SilentlyContinue;$text+=if($null -eq $service){' Агент пока не установлен.'}else{' Служба агента найдена.'};$status.Text=$text
    }
    Add-DemoButton '1. Первичная подготовка базы и сертификата' {Start-DemoElevated 'Prepare-Demo.ps1'}
    Add-DemoButton '2. Запустить сервер и консоль' {Start-DemoServer;Start-DemoDesktop;$status.Text='Сервер готов. Войдите в консоль прежними данными. Для первого агента: «Компьютеры» → добавить ПК → получить код.'}
    Add-DemoButton '3. Агент на этом ПК: установить или обновить' {Start-DemoElevated 'Install-DemoAgent.ps1'}
    Add-DemoButton '4. Открыть тестовый текст и компонент буфера' {
        Start-DemoSession;$sample=Join-Path $script:DemoData 'Тест буфера OurDLP.txt'
        [IO.File]::WriteAllText($sample,"OURDLP-TEST-1234`r`nOURDLP-TEST-5678`r`n",[Text.UTF8Encoding]::new($true));Start-Process notepad.exe -ArgumentList ('"'+$sample+'"')|Out-Null
        $status.Text='В консоли создайте и назначьте политику буфера. Дождитесь «Наблюдение включено», выделите первую строку в Блокноте и нажмите Ctrl+C. Результат — в журнале событий.'
    }
    Add-DemoButton 'Открыть сценарий показа' {Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $script:BundleRoot 'ПОКАЗ.txt')+'"')|Out-Null;$status.Text='Сценарий открыт в Блокноте.'}
    Add-DemoButton 'Остановить мой сервер для проверки офлайн' {Stop-OwnedDemoServer;$status.Text='Сервер этого комплекта остановлен. Служба и пользовательский компонент продолжают работу. Скопируйте второй маркер, затем снова запустите сервер.'}
    Add-DemoButton 'Диагностика: открыть папку журналов' {Start-Process explorer.exe -ArgumentList ('"'+$script:DemoData+'"')|Out-Null;$status.Text='Журналы сервера находятся в открывшейся папке. Не отправляйте пароли и файлы User Secrets.'}
    $null=Add-DemoLabel 'Режим наблюдения: копирование и вставка разрешены. Содержимое буфера не сохраняется. Закрытие этого окна оставляет сервер и агент работающими.' 56 10
    $form.Add_FormClosing({param($sender,$eventArgs) if($script:DemoBusy){$eventArgs.Cancel=$true}})
    $form.Add_Shown({Run-DemoAction {Initialize-DemoApplications;$status.Text='Комплект подготовлен. Нажмите «Проверить готовность» или запустите сервер и консоль.'}})
    [Windows.Forms.Application]::Run($form)
}catch{[Windows.Forms.MessageBox]::Show($_.Exception.Message,'OurDLP — Не удалось запустить комплект')|Out-Null}
finally{$single.ReleaseMutex();$single.Dispose()}
