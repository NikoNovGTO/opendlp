using System.Collections.ObjectModel;
using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed class ClipboardLists : ObservableObject
{
    private string _deviceQuery = "", _eventQuery = ""; private bool _attention;
    public ObservableCollection<ClipboardDeviceRow> Devices { get; } = [];
    public ObservableCollection<ClipboardEventView> Events { get; } = [];
    public ObservableCollection<ClipboardDeviceRow> VisibleDevices { get; } = [];
    public ObservableCollection<ClipboardEventView> VisibleEvents { get; } = [];
    public event Action? DeviceFilterChanged;
    public string DeviceQuery { get => _deviceQuery; set { if (SetProperty(ref _deviceQuery, value)) FilterDevices(); } }
    public string EventQuery { get => _eventQuery; set { if (SetProperty(ref _eventQuery, value)) FilterEvents(); } }
    public bool OnlyAttention { get => _attention; set { if (SetProperty(ref _attention, value)) FilterDevices(); } }
    public bool NoDevices => VisibleDevices.Count == 0;
    public bool NoEvents => VisibleEvents.Count == 0;
    public string DeviceCount => $"Показано компьютеров: {VisibleDevices.Count} из {Devices.Count}";
    public string EventCount => $"Показано событий: {VisibleEvents.Count} из {Events.Count}. Загружены до 200 последних событий.";
    public void Replace(IEnumerable<ClipboardDeviceRow> devices, IEnumerable<ClipboardEventView> events)
    {
        Devices.Clear(); foreach (var row in devices) Devices.Add(row);
        Events.Clear(); foreach (var row in events) Events.Add(row);
        FilterDevices(); FilterEvents();
    }
    private void FilterDevices()
    {
        var query = DeviceQuery.Trim(); VisibleDevices.Clear();
        foreach (var row in Devices.Where(row => (!OnlyAttention || row.Status.RequiresAttention) &&
            (query.Length == 0 || row.Name.Contains(query, StringComparison.OrdinalIgnoreCase)))) VisibleDevices.Add(row);
        OnPropertyChanged(nameof(NoDevices)); OnPropertyChanged(nameof(DeviceCount)); DeviceFilterChanged?.Invoke();
    }
    private void FilterEvents()
    {
        var query = EventQuery.Trim(); VisibleEvents.Clear();
        foreach (var row in Events.Where(row => query.Length == 0 || new[] { row.Device, row.User, row.Process, row.Policy, row.Matches }
            .Any(text => text.Contains(query, StringComparison.OrdinalIgnoreCase)))) VisibleEvents.Add(row);
        OnPropertyChanged(nameof(NoEvents)); OnPropertyChanged(nameof(EventCount));
    }
}
