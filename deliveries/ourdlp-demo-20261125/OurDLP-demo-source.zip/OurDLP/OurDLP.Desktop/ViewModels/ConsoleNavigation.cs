using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels;
public sealed class ConsoleNavigation : ObservableObject
{
    private int _section;
    public int Section { get => _section; set => SetProperty(ref _section, value); }
    public RelayCommand Devices { get; }
    public RelayCommand Clipboard { get; }
    public RelayCommand Scans { get; }
    public ConsoleNavigation() { Devices = new(() => Section = 1); Clipboard = new(() => Section = 2); Scans = new(() => Section = 3); }
}
