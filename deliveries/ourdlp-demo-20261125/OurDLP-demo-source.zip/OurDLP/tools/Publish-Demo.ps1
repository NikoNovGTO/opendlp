﻿#Requires -Version 5.1
[CmdletBinding()]
param([string]$OutputPath='')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
if(-not $OutputPath){$OutputPath=Join-Path $root 'artifacts/OurDLP-Demo'}
$OutputPath=[IO.Path]::GetFullPath($OutputPath)
if(Test-Path -LiteralPath $OutputPath){throw 'Папка результата уже существует. Выберите новую папку через -OutputPath.'}
if(-not (Get-Command dotnet -ErrorAction SilentlyContinue)){throw 'Для сборки исходников требуется .NET SDK 10. Готовый комплект запускается без SDK.'}
$work=Join-Path ([IO.Path]::GetTempPath()) ('ourdlp-publish-'+[Guid]::NewGuid().ToString('N'))
$store=Join-Path $OutputPath 'payload/content';[IO.Directory]::CreateDirectory($store)|Out-Null
$groups=@{Agent=@{};Server=@{};Desktop=@{}}
try {
    foreach($project in @('OurDLP.Agent','OurDLP.Session','OurDLP.Server','OurDLP.Desktop')){
        $published=Join-Path $work $project
        & dotnet publish (Join-Path $root ($project+'/'+$project+'.csproj')) -c Release -r win-x64 --self-contained true '-p:EnableWindowsTargeting=true' '-p:SatelliteResourceLanguages=ru' -o $published
        if($LASTEXITCODE -ne 0){throw ('Не удалось собрать '+$project)}
        $group=if($project -in @('OurDLP.Agent','OurDLP.Session')){'Agent'}elseif($project -eq 'OurDLP.Server'){'Server'}else{'Desktop'}
        $prefix=[IO.Path]::GetFullPath($published).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
        foreach($file in Get-ChildItem -LiteralPath $published -File -Recurse){
            $relative=$file.FullName.Substring($prefix.Length).Replace('\','/')
            $hash=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($groups[$group].ContainsKey($relative) -and $groups[$group][$relative] -ne $hash){throw ('Несовместимые файлы Agent/Session: '+$relative)}
            $groups[$group][$relative]=$hash
            $target=Join-Path $store ($hash+'.bin')
            if(-not (Test-Path -LiteralPath $target)){Copy-Item -LiteralPath $file.FullName -Destination $target}
        }
    }
    $apps=@{}
    foreach($group in $groups.Keys){$apps[$group]=@($groups[$group].Keys|Sort-Object|ForEach-Object{@{Path=$_;Sha256=$groups[$group][$_]}})}
    @{Version='0.8.2';Apps=$apps}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $OutputPath 'payload/apps.json') -Encoding UTF8
    Copy-Item -LiteralPath (Join-Path $root 'demo/launcher') -Destination (Join-Path $OutputPath 'launcher') -Recurse
    Copy-Item -LiteralPath (Join-Path $root 'tools') -Destination (Join-Path $OutputPath 'tools') -Recurse
    foreach($file in Get-ChildItem -LiteralPath $root -Filter '*.md'){Copy-Item -LiteralPath $file.FullName -Destination $OutputPath}
    foreach($name in @('ЗАПУСТИТЬ.cmd','ЧИТАТЬ.txt','ПОКАЗ.txt')){Copy-Item -LiteralPath (Join-Path $root ('demo/'+$name)) -Destination $OutputPath}
    Write-Host ('Комплект готов: '+$OutputPath)
    Write-Host 'На Windows откройте ЗАПУСТИТЬ.cmd обычным пользователем. PostgreSQL должен быть установлен.'
} finally {if(Test-Path -LiteralPath $work){Remove-Item -LiteralPath $work -Recurse -Force}}
