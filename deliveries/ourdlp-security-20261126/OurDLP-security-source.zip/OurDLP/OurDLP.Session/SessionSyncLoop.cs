using System.Security.Cryptography;
using System.Text.Json;

namespace OurDLP.Session;

public sealed class SessionSyncLoop(SessionCoordinator coordinator, TimeSpan? interval = null)
{
    public async Task RunAsync(CancellationToken stop)
    {
        try
        {
            while (!stop.IsCancellationRequested)
            {
                try { await coordinator.SyncOnceAsync(stop); }
                catch (Exception error) when (error is IOException or InvalidDataException
                    or UnauthorizedAccessException or CryptographicException or ArgumentException or JsonException)
                {
                    // Retain the last applied policy and pending metadata; retry without logging their contents.
                }
                await Task.Delay(interval ?? TimeSpan.FromSeconds(5), stop);
            }
        }
        catch (OperationCanceledException) when (stop.IsCancellationRequested) { }
    }
}
