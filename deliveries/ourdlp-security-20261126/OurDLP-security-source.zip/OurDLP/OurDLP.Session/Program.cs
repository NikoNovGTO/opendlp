using System.Diagnostics;
using System.Runtime.Versioning;
using OurDLP.Session;
using OurDLP.Session.Native;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (!OperatingSystem.IsWindows()) return 1;
        return RunWindows(args);
    }
    [SupportedOSPlatform("windows")]
    private static int RunWindows(string[] args)
    {
        if (args.Length != 0 || Process.GetCurrentProcess().SessionId == 0) return 1;
        using var single = new Mutex(true, @"Local\OurDLP.Clipboard.Session.v1", out var created);
        if (!created)
        { var existing = ClipboardNative.FindWindowW(ClipboardWindow.ClassName, null); if (existing != 0) ClipboardNative.PostMessageW(existing, 0x8002, 0, 0); return 0; }
        using var stop = new CancellationTokenSource();
        try
        {
            var coordinator = new SessionCoordinator(new WindowsSessionStore(), new WindowsSessionPipeClient());
            coordinator.InitializeAsync(stop.Token).GetAwaiter().GetResult();
            var processing = new ClipboardProcessing(coordinator);
            var work = Task.Run(() => processing.RunAsync(stop.Token));
            var sync = Task.Run(() => new SessionSyncLoop(coordinator).RunAsync(stop.Token));
            try { new ClipboardWindow(coordinator, processing, Process.GetCurrentProcess().SessionId, stop.Token, () => !work.IsCompleted && !sync.IsCompleted).Run(); }
            finally
            {
                coordinator.SetListenerReady(false); processing.Complete(); stop.Cancel();
                try { Task.WhenAll(work, sync).Wait(TimeSpan.FromSeconds(5)); } catch { }
            }
            return 0;
        }
        catch (Exception e)
        { Trace.TraceError(e.GetType().Name); ClipboardNative.MessageBoxW(0, SessionErrorText.Describe(e), "OurDLP — Не удалось запустить компонент", 0x10); return 1; }
        finally { single.ReleaseMutex(); }
    }
}
