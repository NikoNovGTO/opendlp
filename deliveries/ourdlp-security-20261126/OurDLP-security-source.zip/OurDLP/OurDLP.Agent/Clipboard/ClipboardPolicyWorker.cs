using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace OurDLP.Agent.Clipboard;

public sealed class ClipboardPolicyWorker(IAgentStateStore registration, ClipboardAgentCoordinator coordinator,
    IClipboardAgentClient client, ILogger<ClipboardPolicyWorker> logger, IHostApplicationLifetime lifetime) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            var state = await registration.ReadAsync(stoppingToken); if (state?.DeviceId is null) return;
            var exchange = new ClipboardAgentExchangeCycle(coordinator, client);
            while (!stoppingToken.IsCancellationRequested)
            {
                var outcome = await exchange.RunAsync(state, stoppingToken);
                if (outcome == ClipboardExchangeOutcome.Revoked) { logger.LogError("Обмен буфером отозван. Локальная очередь сохранена."); lifetime.StopApplication(); return; }
                if (outcome == ClipboardExchangeOutcome.InvalidReply) logger.LogWarning("Ответ сервера буфера отклонён. Политика и очередь сохранены; обмен будет повторён.");
                await Task.Delay(TimeSpan.FromSeconds(15), stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
        catch (Exception e) { logger.LogError("Обмен политикой буфера остановлен ({Type}).", e.GetType().Name); lifetime.StopApplication(); }
    }
}
