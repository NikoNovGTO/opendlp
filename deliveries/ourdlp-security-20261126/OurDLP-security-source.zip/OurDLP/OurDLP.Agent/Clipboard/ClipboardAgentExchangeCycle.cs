using OurDLP.Contracts;

namespace OurDLP.Agent.Clipboard;

public enum ClipboardExchangeOutcome { Completed, Unavailable, InvalidReply, Revoked }

public sealed class ClipboardAgentExchangeCycle(ClipboardAgentCoordinator coordinator, IClipboardAgentClient client)
{
    public async Task<ClipboardExchangeOutcome> RunAsync(AgentState registration, CancellationToken token)
    {
        var snapshot = await coordinator.SnapshotAsync(token);
        var response = await client.SyncAsync(registration, snapshot, token);
        if (response.AccessDenied) return ClipboardExchangeOutcome.Revoked;
        if (response.Value is null) return ClipboardExchangeOutcome.Unavailable;
        try
        {
            await coordinator.ApplyAsync(response.Value, snapshot.Events.Select(row => row.Detection.Id).ToArray(), token);
            return ClipboardExchangeOutcome.Completed;
        }
        catch (ClipboardProtocolException)
        {
            // Protocol errors are retried. Storage/permission failures still propagate to the service supervisor.
            return ClipboardExchangeOutcome.InvalidReply;
        }
    }
}
