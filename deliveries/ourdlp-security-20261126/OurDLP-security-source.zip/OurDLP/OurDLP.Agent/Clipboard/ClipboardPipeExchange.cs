using OurDLP.Contracts;

namespace OurDLP.Agent.Clipboard;

public sealed class ClipboardPipeExchange(ClipboardAgentCoordinator coordinator)
{
    public async Task ExchangeAsync(Stream pipe, Func<ClipboardPeer> authenticatePeer, CancellationToken token)
    {
        // ImpersonateNamedPipeClient uses the security context of the last message read.
        // Read only the bounded header first, authenticate the peer, then allocate/read/parse its payload.
        ClipboardPeer? peer = null;
        var request = await ClipboardFrames.ReadAsync<ClipboardSessionRequest>(pipe, token,
            () => peer = authenticatePeer());
        var response = await coordinator.SessionAsync(peer ?? throw new UnauthorizedAccessException(), request, token);
        await ClipboardFrames.WriteAsync(pipe, response, token);
    }
}
