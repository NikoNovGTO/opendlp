namespace OurDLP.Server.Security;

public sealed class ApiRequestOriginGuard(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var request = context.Request;
        if (request.Path.StartsWithSegments("/api") && !HttpMethods.IsGet(request.Method)
            && !HttpMethods.IsHead(request.Method) && !HttpMethods.IsOptions(request.Method)
            && !Allowed(request))
        {
            context.Response.StatusCode = StatusCodes.Status403Forbidden;
            await context.Response.WriteAsJsonAsync(new OurDLP.Contracts.AuthMessage("Запрос с другого источника не разрешён."));
            return;
        }
        await next(context);
    }

    private static bool Allowed(HttpRequest request)
    {
        // The native console/agent omit browser headers. Browser-supplied headers are checked independently of cookies.
        var site = request.Headers["Sec-Fetch-Site"];
        if (site.Count != 0 && (site.Count != 1 || site[0] != "same-origin")) return false;
        var values = request.Headers.Origin;
        if (values.Count == 0) return true;
        if (values.Count != 1 || !Uri.TryCreate(values[0], UriKind.Absolute, out var origin)
            || origin.Scheme is not ("http" or "https") || origin.UserInfo.Length != 0
            || origin.AbsolutePath != "/" || origin.Query.Length != 0 || origin.Fragment.Length != 0
            || !Uri.TryCreate(request.Scheme + "://" + request.Host.ToUriComponent(), UriKind.Absolute, out var target)) return false;
        try
        {
            return origin.Scheme.Equals(target.Scheme, StringComparison.OrdinalIgnoreCase)
                && origin.IdnHost.Equals(target.IdnHost, StringComparison.OrdinalIgnoreCase) && origin.Port == target.Port;
        }
        catch (UriFormatException) { return false; }
    }
}
