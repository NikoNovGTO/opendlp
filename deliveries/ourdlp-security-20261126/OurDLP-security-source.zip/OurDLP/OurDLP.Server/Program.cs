using OurDLP.Server.Agents;
using OurDLP.Server.Authentication;
using OurDLP.Server.Data;
using OurDLP.Server.Endpoints;
using OurDLP.Server.Security;

var checkSetup = args.Contains("--check-local-setup", StringComparer.Ordinal);
var migrate = args.Contains("--migrate-database", StringComparer.Ordinal);
var bootstrap = args.Contains("--create-administrator", StringComparer.Ordinal);
var builder = WebApplication.CreateBuilder(args.Where(argument => argument is not "--migrate-database" and not "--create-administrator" and not "--check-local-setup").ToArray());
builder.Logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", migrate ? LogLevel.Critical : LogLevel.Warning);
if (checkSetup) builder.Logging.ClearProviders();
builder.Services.AddProblemDetails();
builder.Services.AddOurDlpDatabase(builder.Configuration);
builder.Services.AddOurDlpAuthentication(builder.Configuration);
builder.Services.AddOurDlpAgents();

var app = builder.Build();
if (migrate || bootstrap || checkSetup)
{
    try
    {
        if (checkSetup)
        {
            Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(await LocalSetupProbe.CheckAsync(app.Services, default)));
            return;
        }
        Environment.ExitCode = migrate ? await DatabaseMigrationRunner.RunAsync(app.Services)
            : await AdministratorBootstrap.RunAsync(app.Services);
    }
    catch (Exception exception)
    {
        Console.Error.WriteLine($"Локальная команда не выполнена ({exception.GetType().Name}). Проверьте PostgreSQL и конфигурацию.");
        Environment.ExitCode = 1;
    }
    return;
}
app.UseExceptionHandler();
app.UseMiddleware<ApiResponsePrivacy>();
app.UseMiddleware<AuthenticationRequestLimits>();
app.UseMiddleware<ApiRequestOriginGuard>();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.MapServerStatusEndpoints();
app.MapDatabaseHealthEndpoints();
app.MapAuthenticationEndpoints();
app.MapDeviceEndpoints();
app.MapAgentEndpoints();
app.MapScanEndpoints();
app.MapClipboardEndpoints();
app.Run();

public partial class Program { }
