namespace OurDLP.Contracts;

public static class ClipboardAcknowledgements
{
    public static void Validate(IReadOnlyList<Guid>? accepted, IReadOnlyList<ClipboardEventRejection>? rejected,
        IReadOnlyCollection<Guid> sent)
    {
        if (accepted is null || rejected is null || sent.Count > ClipboardWire.MaxBatch
            || accepted.Count > ClipboardWire.MaxBatch || rejected.Count > ClipboardWire.MaxBatch
            || accepted.Count + rejected.Count > ClipboardWire.MaxBatch
            || rejected.Any(row => row is null || string.IsNullOrWhiteSpace(row.Reason)
                || row.Reason.Length > 64 || row.Reason.Any(char.IsControl)))
            throw new ClipboardProtocolException("Некорректное подтверждение событий.");
        var ids = accepted.Concat(rejected.Select(row => row.Id)).ToArray();
        if (ids.Any(id => id == Guid.Empty || !sent.Contains(id)) || ids.Distinct().Count() != ids.Length)
            throw new ClipboardProtocolException("Подтверждение содержит повторные, противоречивые или чужие события.");
    }
}
