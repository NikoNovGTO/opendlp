using System.Buffers.Binary;
using System.Text.Json;

namespace OurDLP.Contracts;

public static class ClipboardFrames
{
    public static Task<T> ReadAsync<T>(Stream stream, CancellationToken token) => ReadAsync<T>(stream, token, null);

    public static async Task<T> ReadAsync<T>(Stream stream, CancellationToken token, Action? authenticate)
    {
        var header = new byte[4]; await stream.ReadExactlyAsync(header, token);
        var length = BinaryPrimitives.ReadInt32LittleEndian(header);
        if (length < 1 || length > ClipboardWire.MaxFrameBytes) throw new InvalidDataException("Неверный размер сообщения.");
        authenticate?.Invoke();
        var data = new byte[length]; await stream.ReadExactlyAsync(data, token);
        return JsonSerializer.Deserialize<T>(data, ScanWire.Json) ?? throw new InvalidDataException("Пустое сообщение.");
    }
    public static async Task WriteAsync<T>(Stream stream, T value, CancellationToken token)
    {
        var data = JsonSerializer.SerializeToUtf8Bytes(value, ScanWire.Json);
        if (data.Length > ClipboardWire.MaxFrameBytes) throw new InvalidDataException("Сообщение превышает предел.");
        var header = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(header, data.Length);
        await stream.WriteAsync(header, token); await stream.WriteAsync(data, token); await stream.FlushAsync(token);
    }
}
