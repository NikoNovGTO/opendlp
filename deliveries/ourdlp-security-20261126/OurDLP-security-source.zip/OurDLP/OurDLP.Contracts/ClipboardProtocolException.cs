namespace OurDLP.Contracts;

public sealed class ClipboardProtocolException(string message) : IOException(message);
