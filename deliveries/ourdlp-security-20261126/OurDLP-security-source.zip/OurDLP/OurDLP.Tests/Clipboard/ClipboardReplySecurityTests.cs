using OurDLP.Contracts;
using OurDLP.Session;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class ClipboardReplySecurityTests
{
    [Theory]
    [InlineData(0)][InlineData(1)][InlineData(2)][InlineData(3)][InlineData(4)]
    [InlineData(5)][InlineData(6)][InlineData(7)][InlineData(8)]
    public async Task InvalidAcknowledgementsNeverChangeEitherDurableQueue(int kind)
    {
        var p = ClipboardSamples.Policy(); var (_, service, agent) = await ClipboardSamples.AgentAsync(p);
        var detection = ClipboardSamples.Detection(p);
        await service.SessionAsync(ClipboardSamples.Peer, ClipboardSamples.Request(agent.State!.RegistrationKey, detection), default);
        IReadOnlyList<Guid> accepted = []; IReadOnlyList<ClipboardEventRejection> rejected = [];
        switch (kind)
        {
            case 0: accepted = [detection.Id, detection.Id]; break;
            case 1: accepted = [detection.Id]; rejected = [new(detection.Id, "invalid")]; break;
            case 2: accepted = [Guid.NewGuid()]; break;
            case 3: accepted = [Guid.Empty]; break;
            case 4: rejected = [new(detection.Id, "bad\nreason")]; break;
            case 5: rejected = [null!]; break;
            case 6: accepted = Enumerable.Repeat(detection.Id, 33).ToArray(); break;
            case 7: accepted = null!; break;
            case 8: rejected = null!; break;
        }
        var before = ScanWire.Serialize(agent.State);
        await Assert.ThrowsAsync<ClipboardProtocolException>(() => service.ApplyAsync(new(p, accepted, rejected), [detection.Id], default));
        Assert.Equal(before, ScanWire.Serialize(agent.State));
        var user = new TestSessionStore { State = new() { RegistrationKey = agent.State.RegistrationKey, Policy = p, Pending = [detection] } };
        var session = new SessionCoordinator(user, new TestSessionClient { Exchange = _ => Task.FromResult<ClipboardSessionResponse?>(new(agent.State.RegistrationKey, p, accepted, rejected, false)) });
        await session.InitializeAsync(default); var prepared = session.CurrentPolicy; before = ScanWire.Serialize(user.State);
        await Assert.ThrowsAsync<ClipboardProtocolException>(() => session.SyncOnceAsync(default));
        Assert.Equal(before, ScanWire.Serialize(user.State)); Assert.Same(prepared, session.CurrentPolicy);
        Assert.Contains("нет связи", session.Describe());
    }

    [Fact] public void ValidMixedPartialAcknowledgementsAllowUnacknowledgedEventsToRemainPending()
    {
        var ids = Enumerable.Range(0, 32).Select(_ => Guid.NewGuid()).ToArray();
        ClipboardAcknowledgements.Validate(ids.Take(10).ToArray(), ids.Skip(10).Take(10).Select(id => new ClipboardEventRejection(id, "invalid-metadata")).ToArray(), ids);
        ClipboardAcknowledgements.Validate([], [], []);
    }

    [Fact] public async Task AChangedRegistrationCannotAcknowledgeEventsFromTheOldRegistration()
    {
        var p = ClipboardSamples.Policy(); var detection = ClipboardSamples.Detection(p);
        var user = new TestSessionStore { State = new() { RegistrationKey = new('A', 64), Policy = p, Pending = [detection] } };
        var session = new SessionCoordinator(user, new TestSessionClient { Exchange = _ => Task.FromResult<ClipboardSessionResponse?>(new(new('B', 64), null, [detection.Id], [], false)) });
        await session.InitializeAsync(default);
        await Assert.ThrowsAsync<ClipboardProtocolException>(() => session.SyncOnceAsync(default));
        Assert.Equal(new string('A', 64), user.State.RegistrationKey); Assert.Single(user.State.Pending);
    }
}
