using System.Buffers.Binary;
using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class ClipboardPipeExchangeTests
{
    [Fact] public async Task HeaderIsReadBeforePeerAuthenticationAndPayloadIsReadOnlyAfterAuthentication()
    {
        var (_, service, store) = await ClipboardSamples.AgentAsync(ClipboardSamples.Policy());
        using var stream = new MemoryStream();
        await ClipboardFrames.WriteAsync(stream, ClipboardSamples.Request(store.State!.RegistrationKey), default);
        var end = stream.Length; stream.Position = 0; var called = false;
        await new ClipboardPipeExchange(service).ExchangeAsync(stream, () =>
        {
            Assert.Equal(4, stream.Position); called = true; return ClipboardSamples.Peer;
        }, default);
        Assert.True(called); stream.Position = end;
        Assert.Equal(store.State.RegistrationKey, (await ClipboardFrames.ReadAsync<ClipboardSessionResponse>(stream, default)).RegistrationKey);
        Assert.Single((await service.SnapshotAsync(default)).Helpers);
    }

    [Fact] public async Task FailedAuthenticationDoesNotReadPayloadOrChangeCoordinatorState()
    {
        var (_, service, store) = await ClipboardSamples.AgentAsync(ClipboardSamples.Policy());
        using var stream = new MemoryStream(); await ClipboardFrames.WriteAsync(stream, ClipboardSamples.Request(store.State!.RegistrationKey), default);
        stream.Position = 0; var before = ScanWire.Serialize(store.State);
        await Assert.ThrowsAsync<UnauthorizedAccessException>(() => new ClipboardPipeExchange(service).ExchangeAsync(stream,
            () => throw new UnauthorizedAccessException(), default));
        Assert.Equal(4, stream.Position); Assert.Equal(before, ScanWire.Serialize(store.State));
        Assert.Empty((await service.SnapshotAsync(default)).Helpers);
    }

    [Theory][InlineData(0)][InlineData(-1)][InlineData(262145)]
    public async Task InvalidFrameLengthIsRejectedBeforePeerCallbacksAndAllocatingPayload(int length)
    {
        var (_, service, _) = await ClipboardSamples.AgentAsync(null); var bytes = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(bytes, length);
        using var stream = new MemoryStream(bytes); var called = false;
        await Assert.ThrowsAsync<InvalidDataException>(() => new ClipboardPipeExchange(service).ExchangeAsync(stream,
            () => { called = true; return ClipboardSamples.Peer; }, default));
        Assert.False(called);
    }
}
