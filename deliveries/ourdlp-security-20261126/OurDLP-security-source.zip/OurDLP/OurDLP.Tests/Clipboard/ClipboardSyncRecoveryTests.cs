using OurDLP.Agent;
using OurDLP.Agent.Clipboard;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;
using OurDLP.Session;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class ClipboardSyncRecoveryTests
{
    [Fact] public async Task UserLoopSurvivesBadFramesAndContradictoryRepliesThenAppliesAValidReply()
    {
        var p = ClipboardSamples.Policy(); var detection = ClipboardSamples.Detection(p); var key = new string('A', 64);
        var user = new TestSessionStore { State = new() { RegistrationKey = key, Policy = p, Pending = [detection] } };
        using var stop = new CancellationTokenSource(); var calls = 0;
        var client = new TestSessionClient { Exchange = _ =>
        {
            calls++;
            if (calls == 1) throw new InvalidDataException("Malformed frame");
            if (calls == 2) return Task.FromResult<ClipboardSessionResponse?>(new(key, p, [detection.Id], [new(detection.Id, "invalid")], false));
            if (calls == 3)
            {
                Assert.Single(user.State.Pending); Assert.Equal(1, user.State.Policy!.Version);
                return Task.FromResult<ClipboardSessionResponse?>(new(key, p with { Version = 2 }, [detection.Id], [], false));
            }
            stop.Cancel(); stop.Token.ThrowIfCancellationRequested(); throw new InvalidOperationException();
        } };
        var session = new SessionCoordinator(user, client); await session.InitializeAsync(default);
        await new SessionSyncLoop(session, TimeSpan.Zero).RunAsync(stop.Token).WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal(4, calls); Assert.Empty(user.State.Pending); Assert.Equal(2, session.CurrentPolicy!.Compiled.Definition.Version);
    }

    [Fact] public async Task AgentRetriesProtocolErrorsButDoesNotHideStorageFailures()
    {
        var p = ClipboardSamples.Policy(); var (registration, service, store) = await ClipboardSamples.AgentAsync(p);
        var detection = ClipboardSamples.Detection(p);
        await service.SessionAsync(ClipboardSamples.Peer, ClipboardSamples.Request(store.State!.RegistrationKey, detection), default);
        var client = new Client { Reply = new(p, [detection.Id], [new(detection.Id, "invalid")]) };
        var cycle = new ClipboardAgentExchangeCycle(service, client);
        Assert.Equal(ClipboardExchangeOutcome.InvalidReply, await cycle.RunAsync(registration.State!, default));
        Assert.Single(store.State!.Pending); Assert.Equal(1, store.State.Policy!.Version);
        client.Reply = new(p with { Version = 2, Rules = [p.Rules[0] with { Pattern = "(" }] }, [detection.Id], []);
        Assert.Equal(ClipboardExchangeOutcome.InvalidReply, await cycle.RunAsync(registration.State!, default));
        Assert.Single(store.State.Pending);
        client.Reply = new(p with { Version = 2 }, [detection.Id], []); store.FailSave = true;
        await Assert.ThrowsAsync<IOException>(() => cycle.RunAsync(registration.State!, default));
        Assert.Single(store.State.Pending); store.FailSave = false;
        var invalidStorage = new ClipboardAgentCoordinator(registration, new InvalidStorage(store));
        await Assert.ThrowsAsync<InvalidDataException>(() => new ClipboardAgentExchangeCycle(invalidStorage, client).RunAsync(registration.State!, default));
        Assert.Single(store.State.Pending);
        Assert.Equal(ClipboardExchangeOutcome.Completed, await cycle.RunAsync(registration.State!, default));
        Assert.Empty(store.State.Pending); Assert.Equal(2, store.State.Policy!.Version);
        client.Status = 401; Assert.Equal(ClipboardExchangeOutcome.Revoked, await cycle.RunAsync(registration.State!, default));
    }

    private sealed class Client : IClipboardAgentClient
    {
        public ClipboardAgentResponse Reply { get; set; } = null!;
        public int Status { get; set; } = 200;
        public Task<AgentScanReply<ClipboardAgentResponse>> SyncAsync(AgentState state, ClipboardAgentSync request, CancellationToken token)
            => Task.FromResult(new AgentScanReply<ClipboardAgentResponse>(Reply, Status));
    }

    private sealed class InvalidStorage(TestAgentStore inner) : IClipboardAgentStore
    {
        public Task<ClipboardAgentState?> ReadAsync(CancellationToken token) => inner.ReadAsync(token);
        public Task SaveAsync(ClipboardAgentState value, CancellationToken token) => throw new InvalidDataException("Storage failure");
        public Task ArchiveAsync(CancellationToken token) => inner.ArchiveAsync(token);
    }
}
