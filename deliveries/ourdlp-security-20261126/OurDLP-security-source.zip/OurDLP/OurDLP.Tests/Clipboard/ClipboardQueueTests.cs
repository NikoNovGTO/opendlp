using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Session;
using Xunit;
namespace OurDLP.Tests.Clipboard;
public sealed class ClipboardQueueTests
{
    [Fact] public async Task OfflineSessionRestartAndLostPipeAckKeepOneDurableMetadataEvent()
    {
        var p=ClipboardSamples.Policy();var (_,service,agentStore)=await ClipboardSamples.AgentAsync(p);var userStore=new TestSessionStore();var pipe=new TestSessionClient();pipe.Connect(service);
        var session=new SessionCoordinator(userStore,pipe);await session.InitializeAsync(default);await session.SyncOnceAsync(default);
        Assert.Null((await service.SnapshotAsync(default)).Helpers.Single().AppliedVersion);
        session.SetListenerReady(true);await session.SyncOnceAsync(default);Assert.Equal(1,(await service.SnapshotAsync(default)).Helpers.Single().AppliedVersion);
        pipe.Exchange=_=>Task.FromResult<ClipboardSessionResponse?>(null);
        var chars="private OURDLP-TEST-7788 marker".ToCharArray();using(var capture=new CapturedClipboard(new(chars,chars.Length),session.CurrentPolicy!,false,"notepad",3,DateTimeOffset.UtcNow))await session.EnqueueAsync(capture,default);
        await session.SyncOnceAsync(default);Assert.Single(userStore.State.Pending);Assert.Empty(agentStore.State!.Pending);Assert.All(chars,c=>Assert.Equal('\0',c));
        Assert.DoesNotContain("7788",ScanWire.Serialize(userStore.State));
        var restarted=new SessionCoordinator(userStore,pipe);await restarted.InitializeAsync(default);
        pipe.Exchange=async request=>{await service.SessionAsync(ClipboardSamples.Peer,request,default);return null;};await restarted.SyncOnceAsync(default);
        Assert.Single(userStore.State.Pending);Assert.Single(agentStore.State.Pending);
        pipe.Connect(service);await restarted.SyncOnceAsync(default);Assert.Empty(userStore.State.Pending);Assert.Single(agentStore.State.Pending);
        var restartedService=new ClipboardAgentCoordinator((await ClipboardSamples.AgentAsync(null)).Registration,agentStore);
        // A new registration archives the previous queue instead of submitting it as another device.
        await restartedService.SnapshotAsync(default);Assert.Equal(1,agentStore.Archives);
    }
    [Fact] public async Task ServiceDoesNotAcknowledgeBeforeDurableSaveAndRetryIsIdempotent()
    {
        var p=ClipboardSamples.Policy();var (_,service,store)=await ClipboardSamples.AgentAsync(p);var request=ClipboardSamples.Request(store.State!.RegistrationKey,ClipboardSamples.Detection(p));
        store.FailSave=true;await Assert.ThrowsAsync<IOException>(()=>service.SessionAsync(ClipboardSamples.Peer,request,default));Assert.Empty((await service.SnapshotAsync(default)).Events);
        store.FailSave=false;var one=await service.SessionAsync(ClipboardSamples.Peer,request,default);var two=await service.SessionAsync(ClipboardSamples.Peer,request,default);
        Assert.Equal(one.Accepted,two.Accepted);Assert.Single(store.State!.Pending);
        Assert.Equal(ClipboardSamples.Peer.UserSid,store.State.Pending[0].UserSid);
        var altered=request with{Events=[request.Events[0] with{TextCharacters=20}]};Assert.Equal("event-conflict",Assert.Single((await service.SessionAsync(ClipboardSamples.Peer,altered,default)).Rejected).Reason);
    }
    [Fact] public async Task WrongRegistrationAndForgedPeerCannotSubmitMetadata()
    {
        var p=ClipboardSamples.Policy();var (_,service,store)=await ClipboardSamples.AgentAsync(p);
        var response=await service.SessionAsync(ClipboardSamples.Peer,ClipboardSamples.Request(new('B',64),ClipboardSamples.Detection(p)),default);Assert.Empty(response.Accepted);Assert.Empty(store.State!.Pending);
        await Assert.ThrowsAsync<InvalidDataException>(()=>service.SessionAsync(ClipboardSamples.Peer with{SessionId=0},ClipboardSamples.Request(store.State.RegistrationKey),default));
    }
    [Fact] public async Task ServiceAndUserQueuesAreBoundedAndReportDrops()
    {
        var p=ClipboardSamples.Policy();var (_,service,store)=await ClipboardSamples.AgentAsync(p);var key=store.State!.RegistrationKey;
        for(var batch=0;batch<16;batch++)await service.SessionAsync(ClipboardSamples.Peer,ClipboardSamples.Request(key,Enumerable.Range(0,32).Select(_=>ClipboardSamples.Detection(p)).ToArray()),default);
        var full=await service.SessionAsync(ClipboardSamples.Peer,ClipboardSamples.Request(key,ClipboardSamples.Detection(p)),default);Assert.True(full.QueueFull);Assert.Empty(full.Accepted);Assert.Equal(512,store.State!.Pending.Count);
        var user=new TestSessionStore{State=new(){RegistrationKey=key,Policy=p,Pending=Enumerable.Range(0,128).Select(_=>ClipboardSamples.Detection(p)).ToArray()}};var session=new SessionCoordinator(user,new TestSessionClient());await session.InitializeAsync(default);
        var text="OURDLP-TEST-1234".ToCharArray();using var captured=new CapturedClipboard(new(text,text.Length),session.CurrentPolicy!,false,"notepad",3,DateTimeOffset.UtcNow);await session.EnqueueAsync(captured,default);
        Assert.Equal(128,user.State.Pending.Count);Assert.Equal(1,user.State.DroppedCaptures);
    }
    [Fact] public async Task WrongBatchAcksNeverDeleteOtherEventsAndRejectionsAreCounted()
    {
        var p=ClipboardSamples.Policy();var (_,service,store)=await ClipboardSamples.AgentAsync(p);var detection=ClipboardSamples.Detection(p);
        await service.SessionAsync(ClipboardSamples.Peer,ClipboardSamples.Request(store.State!.RegistrationKey,detection),default);
        await Assert.ThrowsAsync<ClipboardProtocolException>(()=>service.ApplyAsync(new(p,[Guid.NewGuid()],[]),[detection.Id],default));Assert.Single(store.State!.Pending);
        await service.ApplyAsync(new(p,[],[new(detection.Id,"invalid")]),[detection.Id],default);Assert.Empty(store.State.Pending);Assert.Equal(1,store.State.RejectedEvents);
        var user=new TestSessionStore{State=new(){RegistrationKey=store.State.RegistrationKey,Policy=p,Pending=[detection]}};
        var pipe=new TestSessionClient{Exchange=_=>Task.FromResult<ClipboardSessionResponse?>(new(store.State.RegistrationKey,p,[Guid.NewGuid()],[],false))};var session=new SessionCoordinator(user,pipe);await session.InitializeAsync(default);
        await Assert.ThrowsAsync<ClipboardProtocolException>(()=>session.SyncOnceAsync(default));Assert.Single(user.State.Pending);
    }
    [Fact] public async Task StaleOtherSessionResponseCannotRollBackSharedRegistration()
    {
        var p=ClipboardSamples.Policy();var oldKey=new string('A',64);var newKey=new string('B',64);var user=new TestSessionStore{State=new(){RegistrationKey=oldKey,Policy=p}};
        var pipe=new TestSessionClient{Exchange=_=>{user.State=new(){RegistrationKey=newKey};return Task.FromResult<ClipboardSessionResponse?>(new(oldKey,p,[],[],false));}};
        var session=new SessionCoordinator(user,pipe);await session.InitializeAsync(default);await session.SyncOnceAsync(default);Assert.Equal(newKey,user.State.RegistrationKey);Assert.Null(session.CurrentPolicy);
    }
    [Fact] public async Task DisabledPolicyDeliveredAfterOfflineStopsNewDetections()
    {
        var p=ClipboardSamples.Policy();var (_,service,store)=await ClipboardSamples.AgentAsync(p);var user=new TestSessionStore();var pipe=new TestSessionClient();pipe.Connect(service);var session=new SessionCoordinator(user,pipe);await session.InitializeAsync(default);await session.SyncOnceAsync(default);
        await service.ApplyAsync(new(p with{Version=2,Enabled=false},[],[]),[],default);await session.SyncOnceAsync(default);
        var text="OURDLP-TEST-1234".ToCharArray();using var capture=new CapturedClipboard(new(text,text.Length),session.CurrentPolicy!,false,"notepad",3,DateTimeOffset.UtcNow);await session.EnqueueAsync(capture,default);Assert.Empty(user.State.Pending);Assert.False(session.CurrentPolicy!.Compiled.Definition.Enabled);
    }
}
