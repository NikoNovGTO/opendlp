using Microsoft.AspNetCore.Http;
using OurDLP.Server.Security;
using Xunit;

namespace OurDLP.Tests.Security;

public sealed class ApiOriginGuardTests
{
    [Theory]
    [InlineData(null, null, true)]
    [InlineData("https://localhost:7443", null, true)]
    [InlineData("https://LOCALHOST:7443", "same-origin", true)]
    [InlineData("https://localhost:7444", null, false)]
    [InlineData("http://localhost:7443", null, false)]
    [InlineData("https://evil.example", null, false)]
    [InlineData("https://localhost:7443.evil.example", null, false)]
    [InlineData("https://localhost:7443/path", null, false)]
    [InlineData("https://localhost:7443?x=1", null, false)]
    [InlineData("https://localhost:7443#fragment", null, false)]
    [InlineData("https://user@localhost:7443", null, false)]
    [InlineData("null", null, false)]
    [InlineData("", null, false)]
    [InlineData(null, "cross-site", false)]
    [InlineData(null, "same-site", false)]
    [InlineData(null, "none", false)]
    [InlineData(null, "unexpected", false)]
    [InlineData("https://localhost:7443", "cross-site", false)]
    public async Task UnsafeApiRequestsCheckBrowserOriginWithoutBreakingNativeClients(string? origin, string? site, bool allowed)
    {
        var context = Context(); if (origin is not null) context.Request.Headers.Origin = origin;
        if (site is not null) context.Request.Headers["Sec-Fetch-Site"] = site;
        var called = false; await new ApiRequestOriginGuard(_ => { called = true; return Task.CompletedTask; }).InvokeAsync(context);
        Assert.Equal(allowed, called); Assert.Equal(allowed ? 200 : 403, context.Response.StatusCode);
    }

    [Fact] public async Task MultipleOriginsAndForgedForwardedHostDoNotAuthorizeBrowserRequests()
    {
        var context = Context(); context.Request.Headers.Origin = new[] { "https://localhost:7443", "https://evil.example" };
        await new ApiRequestOriginGuard(_ => throw new InvalidOperationException()).InvokeAsync(context); Assert.Equal(403, context.Response.StatusCode);
        context = Context(); context.Request.Headers.Origin = "https://evil.example";
        context.Request.Headers["X-Forwarded-Host"] = "evil.example"; context.Request.Headers["X-Forwarded-Proto"] = "https";
        await new ApiRequestOriginGuard(_ => throw new InvalidOperationException()).InvokeAsync(context); Assert.Equal(403, context.Response.StatusCode);
    }

    [Theory][InlineData("localhost", "https://localhost:443")][InlineData("[::1]:7443", "https://[::1]:7443")]
    public async Task DefaultPortAndIpv6AreComparedAsOrigins(string host, string origin)
    {
        var context = Context(); context.Request.Host = new(host); context.Request.Headers.Origin = origin; var called = false;
        await new ApiRequestOriginGuard(_ => { called = true; return Task.CompletedTask; }).InvokeAsync(context); Assert.True(called);
    }

    [Theory][InlineData("GET")][InlineData("HEAD")][InlineData("OPTIONS")]
    public async Task SafeMethodsKeepTheirExistingAuthorizationAndRouting(string method)
    {
        var context = Context(); context.Request.Method = method; context.Request.Headers.Origin = "https://evil.example";
        var called = false; await new ApiRequestOriginGuard(_ => { called = true; return Task.CompletedTask; }).InvokeAsync(context); Assert.True(called);
    }

    private static DefaultHttpContext Context()
    {
        var context = new DefaultHttpContext(); context.Request.Path = "/api/auth/logout"; context.Request.Method = "POST";
        context.Request.Scheme = "https"; context.Request.Host = new("localhost:7443"); context.Response.Body = new MemoryStream(); return context;
    }
}
