using System.Net;
using System.Net.Http.Json;
using OurDLP.Contracts;
using OurDLP.Tests.Clipboard;
using Xunit;

namespace OurDLP.Tests.Security;

public sealed class ApiSecurityIntegrationTests
{
    [PostgresFact][Trait("Category", "Postgres")]
    public async Task BrowserRequestCannotRevokeAgentOrLogoutAdministratorAndApiResponsesAreNotCacheable()
    {
        await using var f = await ClipboardFixture.CreateAsync();
        using var forged = new HttpRequestMessage(HttpMethod.Post, $"/api/devices/{f.State.DeviceId}/revoke");
        forged.Headers.Add("Origin", "https://localhost:9999"); forged.Headers.Add("Sec-Fetch-Site", "same-site");
        using var denied = await f.Context.Admin.SendAsync(forged);
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode); Assert.True(denied.Headers.CacheControl!.NoStore);
        await f.ExchangeAsync();
        using var logout = new HttpRequestMessage(HttpMethod.Post, "/api/auth/logout"); logout.Headers.Add("Origin", "https://untrusted.example");
        Assert.Equal(HttpStatusCode.Forbidden, (await f.Context.Admin.SendAsync(logout)).StatusCode);
        using var current = await f.Context.Admin.GetAsync("/api/auth/me"); Assert.Equal(HttpStatusCode.OK, current.StatusCode);
        Assert.True(current.Headers.CacheControl!.NoStore);
        foreach (var path in new[] { "/api/devices", "/api/clipboard/policies", "/api/clipboard/events", "/api/status" })
        {
            using var response = await f.Context.Admin.GetAsync(path); Assert.True(response.IsSuccessStatusCode); Assert.True(response.Headers.CacheControl!.NoStore);
        }
        using var valid = new HttpRequestMessage(HttpMethod.Post, "/api/auth/logout"); valid.Headers.Add("Origin", "https://localhost");
        valid.Headers.Add("Sec-Fetch-Site", "same-origin"); Assert.Equal(HttpStatusCode.NoContent, (await f.Context.Admin.SendAsync(valid)).StatusCode);
        using var after = await f.Context.Admin.GetAsync("/api/auth/me"); Assert.Equal(HttpStatusCode.Unauthorized, after.StatusCode); Assert.True(after.Headers.CacheControl!.NoStore);
    }

    [Fact] public async Task CrossOriginLoginIsRejectedBeforeDatabaseAccessWhileNativeClientsKeepExistingReadinessResult()
    {
        await using var server = new DatabaseTestServer(""); using var client = server.CreateClient(new() { BaseAddress = new("https://localhost") });
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/auth/login")
        { Content = JsonContent.Create(new LoginRequest { UserName = "admin", Password = "ExampleTestPassword123!" }) };
        request.Headers.Add("Origin", "https://elsewhere.example"); using var denied = await client.SendAsync(request);
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode); Assert.True(denied.Headers.CacheControl!.NoStore);
        using var native = await client.PostAsJsonAsync("/api/auth/login", new LoginRequest { UserName = "admin", Password = "ExampleTestPassword123!" });
        Assert.Equal(HttpStatusCode.ServiceUnavailable, native.StatusCode); Assert.True(native.Headers.CacheControl!.NoStore);
    }
}
