using System.Text.Json;
using OurDLP.Core.Scanning;

namespace OurDLP.Contracts;

public sealed record CreateScanJobRequest(Guid DeviceId, ScanRequest Request);
public sealed record ScanJobResponse(Guid Id, Guid DeviceId, string DeviceName, string RootPath,
    string Status, DateTimeOffset CreatedAtUtc, DateTimeOffset? CompletedAtUtc, int? FilesScanned, int? Findings);
public sealed record ScanJobListResponse(IReadOnlyList<ScanJobResponse> Jobs);
public sealed record ScanJobReportResponse(Guid JobId, ScanReport Report);
public sealed record ScanWorkRequest(int ProtocolVersion, string ScanRoot);
public sealed record ScanWork(Guid Id, ScanRequest Request);
public sealed record ScanWorkResponse(int ProtocolVersion, ScanWork? Job);
public sealed record ScanJobStateResponse(Guid JobId, string Status);
public sealed record ScanResultAcknowledgement(Guid JobId, string Outcome);

public static class ScanWire
{
    public const int Version = 1;
    public const int MaxReportBytes = 2 * 1024 * 1024;
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    public static string Serialize<T>(T value) => JsonSerializer.Serialize(value, Json);
    public static T Read<T>(string value) => JsonSerializer.Deserialize<T>(value, Json) ?? throw new InvalidDataException("Пустой пакет.");
}
