namespace OurDLP.Contracts;

public static class RemoteScanPaths
{
    private static string Normalize(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.Contains('\0')) throw new ArgumentException("Некорректный путь проверки.");
        var normalized = path.Replace('\\', '/');
        var windows = normalized.Length > 2 && char.IsAsciiLetter(normalized[0]) && normalized[1] == ':' && normalized[2] == '/';
        if (!windows && !normalized.StartsWith('/')) throw new ArgumentException("Нужен абсолютный путь на компьютере агента.");
        if (normalized.Split('/').Any(part => part is "." or "..")) throw new ArgumentException("Переходы . и .. в пути не разрешены.");
        return normalized.Length == 1 ? normalized : normalized.TrimEnd('/');
    }
    public static bool IsInside(string path, string root)
    {
        try
        {
            var normalized = Normalize(path); var parent = Normalize(root);
            var comparison = parent.Length > 1 && parent[1] == ':' ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            return normalized.Equals(parent, comparison) || normalized.StartsWith(parent.TrimEnd('/') + "/", comparison);
        }
        catch (ArgumentException) { return false; }
    }
    public static bool Equivalent(string first, string second) => IsInside(first, second) && IsInside(second, first);
    public static bool RelativeMatches(string path, string root, string relative)
    {
        if (!IsInside(path, root) || relative is null) return false;
        var parent = Normalize(root).TrimEnd('/') + "/"; var normalized = Normalize(path);
        return normalized.Length > parent.Length && normalized[parent.Length..].Equals(relative.Replace('\\', '/'),
            parent.Length > 1 && parent[1] == ':' ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
    }
}
