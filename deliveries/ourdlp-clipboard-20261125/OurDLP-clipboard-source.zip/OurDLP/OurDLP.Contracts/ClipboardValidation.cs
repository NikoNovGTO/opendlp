using System.Text.RegularExpressions;
using OurDLP.Core.Clipboard;

namespace OurDLP.Contracts;

public static class ClipboardValidation
{
    public static bool Detection(ClipboardSessionEvent item) => item is not null && item.Id != Guid.Empty
        && item.PolicyId != Guid.Empty && item.PolicyVersion > 0 && item.OccurredAtUtc != default
        && item.SourceProcess is { Length: <= 128 } && !item.SourceProcess.Any(char.IsControl)
        && item.OriginSessionId is >= 0 and <= 65535 && item.TextCharacters is >= 0 and <= 65536 && item.Hits is { Count: <= 20 } && item.TimedOutRules is { Count: <= 20 }
        && (item.Hits.Count > 0 || item.Truncated || item.TimedOutRules.Count > 0)
        && item.Hits.All(hit => hit is not null && hit.RuleId != Guid.Empty && hit.Count is >= 1 and <= 100)
        && item.Hits.Select(hit => hit.RuleId).Distinct().Count() == item.Hits.Count
        && item.TimedOutRules.All(id => id != Guid.Empty) && item.TimedOutRules.Distinct().Count() == item.TimedOutRules.Count;
    public static bool Peer(string sid, string name, int session) => sid is { Length: <= 128 } && name is { Length: <= 256 }
        && !name.Any(char.IsControl) && session is > 0 and <= 65535
        && Regex.IsMatch(sid, @"^S-\d{1,2}(-\d{1,12}){1,16}$", RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(20));
    public static bool Against(ClipboardSessionEvent item, ClipboardPolicy policy) => Detection(item)
        && item.PolicyId == policy.Id && item.PolicyVersion == policy.Version && policy.Enabled
        && item.TextCharacters <= policy.MaxTextCharacters
        && item.Hits.All(hit => policy.Rules.Any(rule => rule.Id == hit.RuleId))
        && item.TimedOutRules.All(id => policy.Rules.Any(rule => rule.Id == id));
}
