using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace OurDLP.Session.Native;

[SupportedOSPlatform("windows")]
internal static class ClipboardReader
{
    public static bool TryRead(nint window, SessionPolicy policy, int session, out CapturedClipboard? captured)
    {
        captured = null;
        if (!ClipboardNative.IsClipboardFormatAvailable(13)) return true;
        if (!ClipboardNative.OpenClipboard(window)) return false;
        try
        {
            var memory = ClipboardNative.GetClipboardData(13); if (memory == 0) return false;
            var available = (ulong)ClipboardNative.GlobalSize(memory) / 2;
            if (available == 0) return true;
            var count = (int)Math.Min(available, (ulong)policy.Compiled.Definition.MaxTextCharacters + 1);
            var pointer = ClipboardNative.GlobalLock(memory); if (pointer == 0) return false;
            var characters = new char[count];
            try { Marshal.Copy(pointer, characters, 0, count); }
            catch { Array.Clear(characters); throw; }
            finally { ClipboardNative.GlobalUnlock(memory); }
            var terminator = Array.IndexOf(characters, '\0');
            var length = terminator >= 0 ? terminator : count;
            var truncated = length > policy.Compiled.Definition.MaxTextCharacters || terminator < 0;
            length = Math.Min(length, policy.Compiled.Definition.MaxTextCharacters);
            captured = new(new(characters, length), policy, truncated, SourceProcess(), session, DateTimeOffset.UtcNow);
            return true;
        }
        finally { ClipboardNative.CloseClipboard(); }
    }
    private static string SourceProcess()
    {
        try
        {
            ClipboardNative.GetWindowThreadProcessId(ClipboardNative.GetClipboardOwner(), out var pid);
            if (pid == 0) return "неизвестно";
            using var process = Process.GetProcessById(checked((int)pid));
            return new string(process.ProcessName.Where(c => !char.IsControl(c)).Take(128).ToArray());
        }
        catch { return "неизвестно"; }
    }
}
