using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace OurDLP.Session.Native;

[SupportedOSPlatform("windows")]
internal static class ClipboardNative
{
    public const uint Update = 0x031D, Timer = 0x0113, Close = 0x0010, Destroy = 0x0002, Tray = 0x8001;
    [UnmanagedFunctionPointer(CallingConvention.Winapi)] public delegate nint WindowProcedure(nint window, uint message, nuint wParam, nint lParam);
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct WindowClass
    {
        public uint Size, Style; public nint Procedure; public int ClassExtra, WindowExtra;
        public nint Instance, Icon, Cursor, Background; public string? Menu; public string ClassName; public nint SmallIcon;
    }
    [StructLayout(LayoutKind.Sequential)] public struct Point { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct Message { public nint Window; public uint Id; public nuint WParam; public nint LParam; public uint Time; public Point Position; public uint Private; }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern nint GetModuleHandleW(string? name);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern ushort RegisterClassExW(ref WindowClass value);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern nint CreateWindowExW(uint exStyle, string className, string title, uint style, int x, int y, int width, int height, nint parent, nint menu, nint instance, nint parameter);
    [DllImport("user32.dll")] public static extern nint DefWindowProcW(nint window, uint message, nuint wParam, nint lParam);
    [DllImport("user32.dll")] public static extern bool DestroyWindow(nint window);
    [DllImport("user32.dll")] public static extern void PostQuitMessage(int code);
    [DllImport("user32.dll")] public static extern int GetMessageW(out Message message, nint window, uint min, uint max);
    [DllImport("user32.dll")] public static extern bool TranslateMessage(ref Message message);
    [DllImport("user32.dll")] public static extern nint DispatchMessageW(ref Message message);
    [DllImport("user32.dll")] public static extern bool AddClipboardFormatListener(nint window);
    [DllImport("user32.dll")] public static extern bool RemoveClipboardFormatListener(nint window);
    [DllImport("user32.dll")] public static extern uint GetClipboardSequenceNumber();
    [DllImport("user32.dll")] public static extern bool IsClipboardFormatAvailable(uint format);
    [DllImport("user32.dll")] public static extern bool OpenClipboard(nint window);
    [DllImport("user32.dll")] public static extern bool CloseClipboard();
    [DllImport("user32.dll")] public static extern nint GetClipboardData(uint format);
    [DllImport("user32.dll")] public static extern nint GetClipboardOwner();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(nint window, out uint process);
    [DllImport("kernel32.dll")] public static extern nuint GlobalSize(nint memory);
    [DllImport("kernel32.dll")] public static extern nint GlobalLock(nint memory);
    [DllImport("kernel32.dll")] public static extern bool GlobalUnlock(nint memory);
    [DllImport("user32.dll")] public static extern nuint SetTimer(nint window, nuint id, uint milliseconds, nint callback);
    [DllImport("user32.dll")] public static extern bool KillTimer(nint window, nuint id);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int MessageBoxW(nint window, string text, string title, uint type);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern uint RegisterWindowMessageW(string value);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern nint FindWindowW(string className, string? title);
    [DllImport("user32.dll")] public static extern bool PostMessageW(nint window, uint message, nuint wParam, nint lParam);
}
