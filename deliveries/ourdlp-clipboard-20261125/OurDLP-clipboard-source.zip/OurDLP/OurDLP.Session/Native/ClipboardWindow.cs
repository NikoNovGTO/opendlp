using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace OurDLP.Session.Native;

[SupportedOSPlatform("windows")]
internal sealed class ClipboardWindow(SessionCoordinator coordinator, ClipboardProcessing processing, int session, CancellationToken token, Func<bool> healthy)
{
    public const string ClassName = "OurDLP.Clipboard.Session.v1";
    private SessionTray? _tray;
    private uint _lastSequence = ClipboardNative.GetClipboardSequenceNumber();
    private int _attempts;
    private uint _taskbar;
    public void Run()
    {
        // Keep the managed delegate alive for the entire native message loop.
        ClipboardNative.WindowProcedure procedure = Procedure;
        var definition = new ClipboardNative.WindowClass { Size = (uint)Marshal.SizeOf<ClipboardNative.WindowClass>(),
            Procedure = Marshal.GetFunctionPointerForDelegate(procedure), Instance = ClipboardNative.GetModuleHandleW(null), ClassName = ClassName };
        if (ClipboardNative.RegisterClassExW(ref definition) == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
        var window = ClipboardNative.CreateWindowExW(0, ClassName, "OurDLP", 0, 0, 0, 0, 0, 0, 0, definition.Instance, 0);
        if (window == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
        try
        {
            if (!ClipboardNative.AddClipboardFormatListener(window)) throw new Win32Exception(Marshal.GetLastWin32Error());
            _tray = new(window); _tray.Add(); _taskbar = ClipboardNative.RegisterWindowMessageW("TaskbarCreated");
            coordinator.SetListenerReady(true); ClipboardNative.SetTimer(window, 2, 1000, 0);
            int result;
            while ((result = ClipboardNative.GetMessageW(out var message, 0, 0, 0)) > 0)
            { ClipboardNative.TranslateMessage(ref message); ClipboardNative.DispatchMessageW(ref message); }
            if (result < 0) throw new Win32Exception(Marshal.GetLastWin32Error());
        }
        finally
        {
            coordinator.SetListenerReady(false); ClipboardNative.RemoveClipboardFormatListener(window);
            _tray?.Dispose(); ClipboardNative.DestroyWindow(window); GC.KeepAlive(procedure);
        }
    }
    private nint Procedure(nint window, uint message, nuint wParam, nint lParam)
    {
        try
        {
            if (message == ClipboardNative.Update) { _attempts = 0; Capture(window); return 0; }
            if (message == ClipboardNative.Timer && wParam == 2)
            {
                if (!healthy()) { coordinator.SetListenerReady(false); ClipboardNative.MessageBoxW(window, "Обработка буфера остановилась. Перезапустите пользовательский компонент OurDLP.", "OurDLP", 0x10); ClipboardNative.DestroyWindow(window); }
                return 0;
            }
            if (message == ClipboardNative.Timer && wParam == 1) { Capture(window); return 0; }
            if (message == ClipboardNative.Tray)
            {
                if ((uint)lParam == 0x0203) Show(window);
                if ((uint)lParam == 0x0205) { var action = _tray!.Menu(); if (action == 1) Show(window); else if (action == 2) ClipboardNative.DestroyWindow(window); }
                return 0;
            }
            if (message == 0x8002) { Show(window); return 0; }
            if (_taskbar != 0 && message == _taskbar) { _tray?.Add(); return 0; }
            if (message == ClipboardNative.Destroy) { ClipboardNative.PostQuitMessage(0); return 0; }
            if (message == 0x0011) return 1;
        }
        catch { _ = coordinator.DroppedAsync(token).ContinueWith(_ => { }, TaskScheduler.Default); }
        return ClipboardNative.DefWindowProcW(window, message, wParam, lParam);
    }
    private void Capture(nint window)
    {
        var sequence = ClipboardNative.GetClipboardSequenceNumber(); var policy = coordinator.CurrentPolicy;
        if (sequence == _lastSequence || policy?.Compiled.Definition.Enabled != true)
        { _lastSequence = sequence; ClipboardNative.KillTimer(window, 1); return; }
        if (!ClipboardReader.TryRead(window, policy, session, out var captured))
        {
            if (++_attempts < 5) { ClipboardNative.SetTimer(window, 1, 100, 0); return; }
            _ = coordinator.DroppedAsync(token).ContinueWith(_ => { }, TaskScheduler.Default);
        }
        _lastSequence = sequence; ClipboardNative.KillTimer(window, 1);
        if (captured is not null && !processing.Post(captured)) _ = coordinator.DroppedAsync(token).ContinueWith(_ => { }, TaskScheduler.Default);
    }
    private void Show(nint window) => ClipboardNative.MessageBoxW(window, coordinator.Describe(), "OurDLP — состояние", 0x40);
}
