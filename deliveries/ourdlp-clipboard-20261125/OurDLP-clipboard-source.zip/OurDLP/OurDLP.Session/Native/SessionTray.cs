using System.Runtime.InteropServices;
using System.Runtime.Versioning;

namespace OurDLP.Session.Native;

[SupportedOSPlatform("windows")]
internal sealed class SessionTray(nint window) : IDisposable
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct Data
    {
        public uint Size; public nint Window; public uint Id, Flags, Callback; public nint Icon;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string Tip;
        public uint State, StateMask;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Info;
        public uint Version;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string InfoTitle;
        public uint InfoFlags; public Guid Guid; public nint Balloon;
    }
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern bool Shell_NotifyIconW(uint message, ref Data data);
    [DllImport("user32.dll")] private static extern nint LoadIconW(nint instance, nint name);
    [DllImport("user32.dll")] private static extern nint CreatePopupMenu();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool AppendMenuW(nint menu, uint flags, nuint item, string text);
    [DllImport("user32.dll")] private static extern bool DestroyMenu(nint menu);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out ClipboardNative.Point point);
    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(nint window);
    [DllImport("user32.dll")] private static extern uint TrackPopupMenu(nint menu, uint flags, int x, int y, int reserved, nint window, nint rectangle);
    private Data Value() => new() { Size = (uint)Marshal.SizeOf<Data>(), Window = window, Id = 1, Flags = 7,
        Callback = ClipboardNative.Tray, Icon = LoadIconW(0, 32516), Tip = "OurDLP — наблюдение буфера обмена", Info = "", InfoTitle = "" };
    public void Add() { var data = Value(); if (!Shell_NotifyIconW(0, ref data)) throw new InvalidOperationException("Не удалось показать значок OurDLP."); }
    public uint Menu()
    {
        var menu = CreatePopupMenu();
        try
        {
            AppendMenuW(menu, 0, 1, "Состояние OurDLP"); AppendMenuW(menu, 0, 2, "Выход из пользовательского компонента");
            GetCursorPos(out var point); SetForegroundWindow(window);
            var command = TrackPopupMenu(menu, 0x0100 | 0x0002, point.X, point.Y, 0, window, 0);
            ClipboardNative.PostMessageW(window, 0, 0, 0); return command;
        }
        finally { DestroyMenu(menu); }
    }
    public void Dispose() { var data = Value(); Shell_NotifyIconW(2, ref data); }
}
