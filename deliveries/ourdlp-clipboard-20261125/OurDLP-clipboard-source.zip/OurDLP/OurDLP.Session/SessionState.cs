using OurDLP.Contracts;
using OurDLP.Core.Clipboard;

namespace OurDLP.Session;

public sealed record SessionState
{
    public int SchemaVersion { get; init; } = 1;
    public string? RegistrationKey { get; init; }
    public ClipboardPolicy? Policy { get; init; }
    public IReadOnlyList<ClipboardSessionEvent> Pending { get; init; } = [];
    public long DroppedCaptures { get; init; }
    public long RejectedEvents { get; init; }
}
public interface ISessionStateStore
{
    Task<SessionState> ReadAsync(CancellationToken token);
    Task<SessionState> UpdateAsync(Func<SessionState, SessionState> update, CancellationToken token);
}
public interface IClipboardSessionClient
{
    Task<ClipboardSessionResponse?> SyncAsync(ClipboardSessionRequest request, CancellationToken token);
}
public sealed record SessionPolicy(string RegistrationKey, CompiledClipboardPolicy Compiled);
