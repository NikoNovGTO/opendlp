using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
using OurDLP.Contracts;

namespace OurDLP.Session;

[SupportedOSPlatform("windows")]
public sealed class WindowsSessionPipeClient : IClipboardSessionClient
{
    [DllImport("kernel32.dll", SetLastError = true)] private static extern bool GetNamedPipeServerSessionId(SafePipeHandle pipe, out uint session);
    public async Task<ClipboardSessionResponse?> SyncAsync(ClipboardSessionRequest request, CancellationToken token)
    {
        try
        {
            using var budget = CancellationTokenSource.CreateLinkedTokenSource(token); budget.CancelAfter(TimeSpan.FromSeconds(3));
            using var pipe = new NamedPipeClientStream(".", ClipboardWire.PipeName,
                PipeAccessRights.ReadData | PipeAccessRights.WriteData | PipeAccessRights.ReadAttributes | PipeAccessRights.ReadPermissions | PipeAccessRights.Synchronize,
                PipeOptions.Asynchronous, TokenImpersonationLevel.Impersonation, HandleInheritability.None);
            await pipe.ConnectAsync(budget.Token);
            if (!GetNamedPipeServerSessionId(pipe.SafePipeHandle, out var session) || session != 0) return null;
            // Pin the protected pipe owner to the service's virtual account. Unlike
            // opening the service process, reading this ACL needs no elevation.
            var expected = new NTAccount("NT SERVICE", "OurDLP.Agent").Translate(typeof(SecurityIdentifier));
            if (!Equals(pipe.GetAccessControl().GetOwner(typeof(SecurityIdentifier)), expected)) return null;
            await ClipboardFrames.WriteAsync(pipe, request, budget.Token);
            return await ClipboardFrames.ReadAsync<ClipboardSessionResponse>(pipe, budget.Token);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return null; }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or System.ComponentModel.Win32Exception or System.Text.Json.JsonException or ArgumentException) { return null; }
    }
}
