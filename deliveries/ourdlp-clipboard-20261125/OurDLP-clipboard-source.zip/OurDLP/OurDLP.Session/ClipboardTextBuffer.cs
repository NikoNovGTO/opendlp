using OurDLP.Core.Clipboard;

namespace OurDLP.Session;

public sealed class ClipboardTextBuffer(char[] characters, int length) : IDisposable
{
    public ReadOnlySpan<char> Text => characters.AsSpan(0, length);
    public void Dispose() => Array.Clear(characters);
}
public sealed record CapturedClipboard(ClipboardTextBuffer Buffer, SessionPolicy Policy, bool Truncated,
    string SourceProcess, int SessionId, DateTimeOffset OccurredAtUtc) : IDisposable
{ public void Dispose() => Buffer.Dispose(); }
