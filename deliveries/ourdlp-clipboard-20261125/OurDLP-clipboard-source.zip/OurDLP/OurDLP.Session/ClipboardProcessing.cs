using System.Threading.Channels;

namespace OurDLP.Session;

public sealed class ClipboardProcessing(SessionCoordinator coordinator)
{
    private readonly Channel<CapturedClipboard> _captures = Channel.CreateBounded<CapturedClipboard>(new BoundedChannelOptions(16) { FullMode = BoundedChannelFullMode.Wait, SingleReader = true });
    public bool Post(CapturedClipboard captured)
    { if (_captures.Writer.TryWrite(captured)) return true; captured.Dispose(); return false; }
    public async Task RunAsync(CancellationToken token)
    {
        try
        {
            await foreach (var captured in _captures.Reader.ReadAllAsync(token))
                using (captured) await coordinator.EnqueueAsync(captured, token);
        }
        finally { while (_captures.Reader.TryRead(out var pending)) pending.Dispose(); }
    }
    public void Complete() => _captures.Writer.TryComplete();
}
