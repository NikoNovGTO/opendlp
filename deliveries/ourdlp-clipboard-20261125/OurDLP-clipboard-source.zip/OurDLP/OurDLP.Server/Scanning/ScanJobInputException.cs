namespace OurDLP.Server.Scanning;

public sealed class ScanJobInputException(string message) : Exception(message);
