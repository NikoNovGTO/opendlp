namespace OurDLP.Server.Scanning;

public sealed class ScanJobConflictException(string message) : Exception(message);
