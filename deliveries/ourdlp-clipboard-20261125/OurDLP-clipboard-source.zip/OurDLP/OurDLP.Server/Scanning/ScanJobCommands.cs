using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Scanning;

public sealed class ScanJobCommands(OurDlpDbContext db, DeviceRegistry audit, TimeProvider time)
{
    public async Task<Guid> CreateAsync(CreateScanJobRequest request, Guid administrator, CancellationToken token)
    {
        ScanRequest definition;
        try { definition = ScanRequestValidator.NormalizeDefinition(request.Request); }
        catch (ArgumentException error) { throw new ScanJobInputException(error.Message); }
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, request.DeviceId, token);
        var device = await db.Devices.FindAsync([request.DeviceId], token);
        if (device is null || device.IsAccessRevoked || device.RegisteredAtUtc is null || device.ScanRoot is null)
            throw new ScanJobInputException("Нужен зарегистрированный агент 0.6 с объявленной областью проверки.");
        if (!RemoteScanPaths.IsInside(definition.RootPath, device.ScanRoot))
            throw new ScanJobInputException("Папка должна находиться внутри разрешённой области на компьютере агента.");
        if (await db.ScanJobs.AnyAsync(row => row.DeviceId == device.Id && (row.Status == "queued" || row.Status == "running"), token))
            throw new ScanJobConflictException("У устройства уже есть незавершённое задание. Дождитесь результата или отмените его.");
        var job = new ScanJob { Id = Guid.NewGuid(), DeviceId = device.Id, AdministratorId = administrator,
            RootPath = definition.RootPath, RequestJson = ScanWire.Serialize(definition), CreatedAtUtc = time.GetUtcNow() };
        db.ScanJobs.Add(job); audit.AddAudit(device.Id, administrator, "scan.created");
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token); return job.Id;
    }
    public async Task<ScanJobStateResponse?> CancelAsync(Guid id, Guid administrator, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        var device = await db.ScanJobs.Where(row => row.Id == id).Select(row => (Guid?)row.DeviceId).SingleOrDefaultAsync(token);
        if (device is null) return null;
        await AgentDatabaseLock.AcquireAsync(db, device.Value, token);
        var job = await db.ScanJobs.SingleAsync(row => row.Id == id, token);
        if (job.Status is "queued" or "running")
        {
            job.Status = "cancelled"; job.CompletedAtUtc = time.GetUtcNow();
            audit.AddAudit(job.DeviceId, administrator, "scan.cancelled"); await db.SaveChangesAsync(token);
        }
        await transaction.CommitAsync(token); return new(id, job.Status);
    }
}
