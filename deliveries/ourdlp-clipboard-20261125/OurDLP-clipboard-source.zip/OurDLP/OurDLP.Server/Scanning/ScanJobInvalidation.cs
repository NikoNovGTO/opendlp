using Microsoft.EntityFrameworkCore;
using OurDLP.Server.Data;

namespace OurDLP.Server.Scanning;

public static class ScanJobInvalidation
{
    public static Task<int> CancelAsync(OurDlpDbContext db, Guid device, DateTimeOffset now, CancellationToken token) =>
        db.ScanJobs.Where(row => row.DeviceId == device && (row.Status == "queued" || row.Status == "running"))
            .ExecuteUpdateAsync(update => update.SetProperty(row => row.Status, "cancelled")
                .SetProperty(row => row.CompletedAtUtc, now), token);
}
