using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;

namespace OurDLP.Server.Scanning;

public sealed class ScanWorkDelivery(OurDlpDbContext db, DeviceRegistry audit, TimeProvider time)
{
    public async Task<ScanWorkResponse> NextAsync(Guid deviceId, string credential, ScanWorkRequest request, CancellationToken token)
    {
        if (request.ProtocolVersion != ScanWire.Version || string.IsNullOrWhiteSpace(request.ScanRoot) || request.ScanRoot.Length > 1024
            || !RemoteScanPaths.IsInside(request.ScanRoot, request.ScanRoot)) throw new ScanJobInputException("Неверная версия протокола или область проверки.");
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, deviceId, token);
        if (!await db.DeviceCredentials.AnyAsync(row => row.DeviceId == deviceId && row.TokenHash == credential && row.RevokedAtUtc == null, token)) throw new UnauthorizedAccessException();
        var device = await db.Devices.SingleAsync(row => row.Id == deviceId, token);
        if (device.IsAccessRevoked || device.RegisteredAtUtc is null) throw new UnauthorizedAccessException();
        device.ScanRoot = request.ScanRoot;
        var job = await db.ScanJobs.Where(row => row.DeviceId == deviceId && (row.Status == "queued" || row.Status == "running"))
            .OrderBy(row => row.CreatedAtUtc).FirstOrDefaultAsync(token);
        if (job?.Status == "queued")
        {
            job.Status = "running"; job.StartedAtUtc = time.GetUtcNow(); audit.AddAudit(deviceId, null, "scan.started");
        }
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token);
        return new(ScanWire.Version, job is null ? null : new(job.Id, ScanWire.Read<ScanRequest>(job.RequestJson)));
    }
    public async Task<ScanJobStateResponse?> StateAsync(Guid device, Guid id, CancellationToken token)
    {
        var status = await db.ScanJobs.AsNoTracking().Where(row => row.Id == id && row.DeviceId == device).Select(row => row.Status).SingleOrDefaultAsync(token);
        return status is null ? null : new(id, status);
    }
}
