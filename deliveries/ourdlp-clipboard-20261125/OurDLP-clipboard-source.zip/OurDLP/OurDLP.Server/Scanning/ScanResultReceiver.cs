using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;

namespace OurDLP.Server.Scanning;

public sealed class ScanResultReceiver(OurDlpDbContext db, DeviceRegistry audit, TimeProvider time)
{
    public async Task<ScanResultAcknowledgement?> ReceiveAsync(Guid device, string credential, Guid id, ScanReport report, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, device, token);
        if (!await db.DeviceCredentials.AnyAsync(row => row.DeviceId == device && row.TokenHash == credential && row.RevokedAtUtc == null, token)) throw new UnauthorizedAccessException();
        if (await db.Devices.AnyAsync(row => row.Id == device && row.IsAccessRevoked, token)) throw new UnauthorizedAccessException();
        var job = await db.ScanJobs.SingleOrDefaultAsync(row => row.Id == id && row.DeviceId == device, token);
        if (job is null) return null;
        if (job.Status == "cancelled") return new(id, "cancelled");
        var normalized = ScanReportValidation.Normalize(id, ScanWire.Read<ScanRequest>(job.RequestJson), report);
        var json = ScanWire.Serialize(normalized); var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)));
        if (job.ReportHash is not null)
        {
            if (job.ReportHash != hash) throw new ScanJobConflictException("Результат этого задания уже принят и не может быть заменён.");
            return new(id, "duplicate");
        }
        if (job.Status != "running") throw new ScanJobConflictException("Задание не было получено агентом.");
        job.ReportJson = json; job.ReportHash = hash; job.FilesScanned = normalized.FilesScanned; job.Findings = normalized.Findings.Count;
        job.Status = normalized.Completion switch { ScanCompletion.Completed => "completed", ScanCompletion.Cancelled => "cancelled", ScanCompletion.LimitReached => "partial", _ => "failed" };
        job.CompletedAtUtc = time.GetUtcNow(); audit.AddAudit(device, null, "scan.result.accepted");
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token); return new(id, "accepted");
    }
}
