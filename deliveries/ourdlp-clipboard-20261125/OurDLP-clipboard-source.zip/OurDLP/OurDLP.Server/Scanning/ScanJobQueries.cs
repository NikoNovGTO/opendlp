using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Server.Data;

namespace OurDLP.Server.Scanning;

public sealed class ScanJobQueries(OurDlpDbContext db)
{
    public async Task<ScanJobListResponse> ListAsync(CancellationToken token) => new(await (
        from job in db.ScanJobs.AsNoTracking() join device in db.Devices.AsNoTracking() on job.DeviceId equals device.Id
        orderby job.CreatedAtUtc descending
        select new ScanJobResponse(job.Id, job.DeviceId, device.Name, job.RootPath, job.Status,
            job.CreatedAtUtc, job.CompletedAtUtc, job.FilesScanned, job.Findings)).Take(100).ToListAsync(token));
    public async Task<ScanJobReportResponse?> ReportAsync(Guid id, CancellationToken token)
    {
        var row = await db.ScanJobs.AsNoTracking().SingleOrDefaultAsync(row => row.Id == id, token);
        return row?.ReportJson is null ? null : new(id, ScanWire.Read<ScanReport>(row.ReportJson));
    }
}
