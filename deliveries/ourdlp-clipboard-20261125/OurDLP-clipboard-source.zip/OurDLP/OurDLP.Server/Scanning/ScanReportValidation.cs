using System.Text;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;

namespace OurDLP.Server.Scanning;

public static class ScanReportValidation
{
    public static ScanReport Normalize(Guid id, ScanRequest request, ScanReport report)
    {
        if (report is null || report.SchemaVersion != 1 || report.Id != id || !Enum.IsDefined(report.Completion)
            || !RemoteScanPaths.Equivalent(report.RootPath, request.RootPath) || report.StartedAtUtc == default || report.CompletedAtUtc == default || report.CompletedAtUtc < report.StartedAtUtc
            || report.Findings is null || report.Issues is null || report.Message is null || report.Message.Length > 512
            || report.Findings.Count > request.Limits.MaxFindings || report.Issues.Count > request.Limits.MaxIssues
            || report.FilesScanned < 0 || report.FilesScanned > request.Limits.MaxFiles || report.FilesSkipped < 0
            || report.FilesSkipped > request.Limits.MaxEntries || report.EntriesVisited < 0 || report.EntriesVisited > request.Limits.MaxEntries
            || report.IssueCount < report.Issues.Count || report.IssueCount > 50_000)
            throw new ScanJobInputException("Некорректный отчёт проверки.");
        var rules = request.Rules.ToDictionary(rule => rule.Id);
        if (report.Findings.Any(row => row is null || row.Id == Guid.Empty || row.Matches is < 1 or > 1000
            || row.Matches > request.Limits.MaxMatchesPerFile || !rules.ContainsKey(row.RuleId)
            || row.FilePath?.Length > 32768 || !RemoteScanPaths.RelativeMatches(row.FilePath!, request.RootPath, row.RelativePath))
            || report.Findings.Select(row => row.Id).Distinct().Count() != report.Findings.Count
            || report.Issues.Any(row => row is null || row.Path is null || row.Path.Length > 32768 || row.Code is null || row.Code.Length > 64
                || row.Message is null || row.Message.Length > 512 || !RemoteScanPaths.IsInside(row.Path, request.RootPath)))
            throw new ScanJobInputException("Состав обнаружений или замечаний не соответствует заданию.");
        var normalized = report with { RootPath = request.RootPath, Rules = request.Rules, Limits = request.Limits,
            ExcludedDirectories = request.ExcludedDirectories, Findings = report.Findings.Select(row => row with { RuleName = rules[row.RuleId].Name }).ToArray() };
        if (Encoding.UTF8.GetByteCount(ScanWire.Serialize(normalized)) > ScanWire.MaxReportBytes) throw new ScanJobInputException("Отчёт превышает предел передачи.");
        return normalized;
    }
}
