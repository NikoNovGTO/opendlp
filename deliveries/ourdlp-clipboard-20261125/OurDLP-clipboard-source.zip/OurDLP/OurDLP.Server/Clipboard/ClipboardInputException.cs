namespace OurDLP.Server.Clipboard;
public sealed class ClipboardInputException(string message) : Exception(message);
public sealed class ClipboardConflictException(string message) : Exception(message);
