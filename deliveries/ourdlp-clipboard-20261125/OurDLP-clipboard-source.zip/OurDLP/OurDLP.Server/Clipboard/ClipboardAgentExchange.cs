using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Clipboard;

public sealed class ClipboardAgentExchange(OurDlpDbContext db, ClipboardEventReceiver receiver, TimeProvider time)
{
    public async Task<ClipboardAgentResponse> SyncAsync(Guid deviceId, string credential, ClipboardAgentSync request, CancellationToken token)
    {
        if (request.ProtocolVersion != ClipboardWire.Version || request.Events is null || request.Events.Count > ClipboardWire.MaxBatch
            || request.Helpers is null || request.Helpers.Count > 16)
            throw new ClipboardInputException("Неверная версия или размер пакета буфера обмена.");
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, deviceId, token);
        if (!await db.DeviceCredentials.AnyAsync(row => row.DeviceId == deviceId && row.TokenHash == credential && row.RevokedAtUtc == null, token)) throw new UnauthorizedAccessException();
        var device = await db.Devices.SingleAsync(row => row.Id == deviceId, token);
        if (device.IsAccessRevoked || device.RegisteredAtUtc is null) throw new UnauthorizedAccessException();
        var config = await db.ClipboardDevices.FindAsync([deviceId], token);
        if (config is null) { config = new() { DeviceId = deviceId }; db.ClipboardDevices.Add(config); }
        config.Capable = true;
        var delivered = request.CachedPolicyId is { } cached && request.CachedVersion is { } version
            && await db.ClipboardDeliveries.AnyAsync(row => row.DeviceId == deviceId && row.CredentialHash == credential && row.PolicyId == cached && row.Version == version, token);
        config.CachedPolicyId = delivered ? request.CachedPolicyId : null; config.CachedVersion = delivered ? request.CachedVersion : null;
        var helpers = new List<ClipboardHelperStatus>();
        foreach (var helper in request.Helpers)
        {
            if (helper is null || !ClipboardValidation.Peer(helper.UserSid, helper.UserName, helper.SessionId) || helper.DroppedCaptures < 0
                || helper.LastSeenAtUtc == default || helper.LastSeenAtUtc > time.GetUtcNow().AddMinutes(1)) throw new ClipboardInputException("Некорректный статус пользовательского компонента.");
            var applied = helper.AppliedPolicyId is { } p && helper.AppliedVersion is { } v && await db.ClipboardDeliveries.AnyAsync(row => row.DeviceId == deviceId && row.CredentialHash == credential && row.PolicyId == p && row.Version == v, token);
            helpers.Add(helper with { AppliedPolicyId = applied ? helper.AppliedPolicyId : null, AppliedVersion = applied ? helper.AppliedVersion : null });
        }
        config.HelpersJson = ScanWire.Serialize(helpers);
        var result = await receiver.ReceiveAsync(deviceId, credential, request.Events, token);
        ClipboardPolicy? definition = null;
        if (config.AssignedPolicyId is { } id)
        {
            var policy = await db.ClipboardPolicies.SingleAsync(row => row.Id == id, token);
            var revision = await db.ClipboardPolicyRevisions.FindAsync([id, policy.CurrentVersion], token);
            definition = ScanWire.Read<ClipboardPolicy>(revision!.DefinitionJson);
            if (!await db.ClipboardDeliveries.AnyAsync(row => row.DeviceId == deviceId && row.CredentialHash == credential && row.PolicyId == id && row.Version == policy.CurrentVersion, token))
                db.ClipboardDeliveries.Add(new() { DeviceId = deviceId, CredentialHash = credential, PolicyId = id, Version = policy.CurrentVersion, DeliveredAtUtc = time.GetUtcNow() });
        }
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token);
        return new(definition, result.Accepted, result.Rejected);
    }
}
