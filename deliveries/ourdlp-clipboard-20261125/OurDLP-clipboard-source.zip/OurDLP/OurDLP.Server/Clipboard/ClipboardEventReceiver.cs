using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Clipboard;

public sealed class ClipboardEventReceiver(OurDlpDbContext db, TimeProvider time)
{
    // Called inside the device transaction/lock acquired by ClipboardAgentExchange.
    public async Task<(List<Guid> Accepted, List<ClipboardEventRejection> Rejected)> ReceiveAsync(Guid device, string credential,
        IReadOnlyList<ClipboardEvent> events, CancellationToken token)
    {
        var accepted = new List<Guid>(); var rejected = new List<ClipboardEventRejection>();
        foreach (var item in events)
        {
            if (item is null || !ClipboardValidation.Detection(item.Detection) || !ClipboardValidation.Peer(item.UserSid, item.UserName, item.SessionId))
            { rejected.Add(new(item?.Detection?.Id ?? Guid.Empty, "invalid-metadata")); continue; }
            var normalized = item with { Detection = item.Detection with { OccurredAtUtc = item.Detection.OccurredAtUtc.ToUniversalTime() } };
            var detection = normalized.Detection;
            var grant = await db.ClipboardDeliveries.AnyAsync(row => row.DeviceId == device && row.CredentialHash == credential
                && row.PolicyId == detection.PolicyId && row.Version == detection.PolicyVersion, token);
            var revision = grant ? await db.ClipboardPolicyRevisions.FindAsync([detection.PolicyId, detection.PolicyVersion], token) : null;
            if (revision is null || !ClipboardValidation.Against(detection, ScanWire.Read<ClipboardPolicy>(revision.DefinitionJson)))
            { rejected.Add(new(detection.Id, "policy-not-delivered")); continue; }
            var json = ScanWire.Serialize(normalized); var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(json)));
            var existing = await db.ClipboardEvents.FindAsync([detection.Id], token);
            if (existing is not null)
            {
                if (existing.DeviceId == device && existing.CredentialHash == credential && existing.PayloadHash == hash) accepted.Add(detection.Id);
                else rejected.Add(new(detection.Id, "event-conflict"));
                continue;
            }
            db.ClipboardEvents.Add(new() { Id = detection.Id, DeviceId = device, PolicyId = detection.PolicyId,
                PolicyVersion = detection.PolicyVersion, CredentialHash = credential, MetadataJson = json, PayloadHash = hash,
                OccurredAtUtc = detection.OccurredAtUtc, ReceivedAtUtc = time.GetUtcNow() });
            accepted.Add(detection.Id);
        }
        return (accepted, rejected);
    }
}
