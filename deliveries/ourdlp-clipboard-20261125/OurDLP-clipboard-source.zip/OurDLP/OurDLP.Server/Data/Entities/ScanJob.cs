namespace OurDLP.Server.Data.Entities;

public sealed class ScanJob
{
    public Guid Id { get; set; }
    public Guid DeviceId { get; set; }
    public Guid AdministratorId { get; set; }
    public string RootPath { get; set; } = string.Empty;
    public string RequestJson { get; set; } = string.Empty;
    public string Status { get; set; } = "queued";
    public DateTimeOffset CreatedAtUtc { get; set; }
    public DateTimeOffset? StartedAtUtc { get; set; }
    public DateTimeOffset? CompletedAtUtc { get; set; }
    public string? ReportJson { get; set; }
    public string? ReportHash { get; set; }
    public int? FilesScanned { get; set; }
    public int? Findings { get; set; }
}
