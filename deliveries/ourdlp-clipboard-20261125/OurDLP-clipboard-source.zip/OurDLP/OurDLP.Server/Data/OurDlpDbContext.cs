using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data;

public sealed class OurDlpDbContext(DbContextOptions<OurDlpDbContext> options)
    : IdentityDbContext<Administrator, IdentityRole<Guid>, Guid>(options)
{
    public DbSet<ClipboardPolicyRecord> ClipboardPolicies => Set<ClipboardPolicyRecord>();
    public DbSet<ClipboardPolicyRevision> ClipboardPolicyRevisions => Set<ClipboardPolicyRevision>();
    public DbSet<ClipboardDeviceConfiguration> ClipboardDevices => Set<ClipboardDeviceConfiguration>();
    public DbSet<ClipboardPolicyDelivery> ClipboardDeliveries => Set<ClipboardPolicyDelivery>();
    public DbSet<ClipboardEventRecord> ClipboardEvents => Set<ClipboardEventRecord>();
    public DbSet<ScanJob> ScanJobs => Set<ScanJob>();
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<AuthenticationAudit> AuthenticationAudit => Set<AuthenticationAudit>();

    public DbSet<DeviceEnrollment> DeviceEnrollments => Set<DeviceEnrollment>();
    public DbSet<DeviceCredential> DeviceCredentials => Set<DeviceCredential>();
    public DbSet<DeviceAudit> DeviceAudit => Set<DeviceAudit>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OurDlpDbContext).Assembly);
    }
}
