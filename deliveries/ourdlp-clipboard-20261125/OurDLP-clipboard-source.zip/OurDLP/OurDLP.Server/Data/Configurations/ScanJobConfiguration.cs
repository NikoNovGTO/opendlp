using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data.Configurations;

public sealed class ScanJobConfiguration : IEntityTypeConfiguration<ScanJob>
{
    public void Configure(EntityTypeBuilder<ScanJob> builder)
    {
        builder.ToTable("scan_jobs"); builder.HasKey(row => row.Id);
        builder.Property(row => row.RootPath).HasMaxLength(1024);
        builder.Property(row => row.RequestJson).HasColumnType("jsonb").IsRequired();
        builder.Property(row => row.ReportJson).HasColumnType("jsonb");
        builder.Property(row => row.ReportHash).HasMaxLength(64);
        builder.Property(row => row.Status).HasMaxLength(32).IsRequired();
        builder.HasOne<Device>().WithMany().HasForeignKey(row => row.DeviceId);
        builder.HasIndex(row => row.CreatedAtUtc);
        builder.HasIndex(row => row.DeviceId).IsUnique().HasFilter("\"Status\" IN ('queued', 'running')");
    }
}
