﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OurDLP.Server.Data.Migrations
{
    /// <inheritdoc />
    public partial class RemoteScans : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ScanRoot",
                table: "devices",
                type: "character varying(1024)",
                maxLength: 1024,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "scan_jobs",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    DeviceId = table.Column<Guid>(type: "uuid", nullable: false),
                    AdministratorId = table.Column<Guid>(type: "uuid", nullable: false),
                    RootPath = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: false),
                    RequestJson = table.Column<string>(type: "jsonb", nullable: false),
                    Status = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    StartedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    CompletedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    ReportJson = table.Column<string>(type: "jsonb", nullable: true),
                    ReportHash = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                    FilesScanned = table.Column<int>(type: "integer", nullable: true),
                    Findings = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_scan_jobs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_scan_jobs_devices_DeviceId",
                        column: x => x.DeviceId,
                        principalTable: "devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_scan_jobs_CreatedAtUtc",
                table: "scan_jobs",
                column: "CreatedAtUtc");

            migrationBuilder.CreateIndex(
                name: "IX_scan_jobs_DeviceId",
                table: "scan_jobs",
                column: "DeviceId",
                unique: true,
                filter: "\"Status\" IN ('queued', 'running')");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "scan_jobs");

            migrationBuilder.DropColumn(
                name: "ScanRoot",
                table: "devices");
        }
    }
}
