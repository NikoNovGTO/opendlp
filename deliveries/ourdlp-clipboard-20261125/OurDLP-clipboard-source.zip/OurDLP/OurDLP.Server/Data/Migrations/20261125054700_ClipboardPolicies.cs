﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OurDLP.Server.Data.Migrations
{
    /// <inheritdoc />
    public partial class ClipboardPolicies : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "clipboard_policies",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    CurrentVersion = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clipboard_policies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "clipboard_device_configuration",
                columns: table => new
                {
                    DeviceId = table.Column<Guid>(type: "uuid", nullable: false),
                    Capable = table.Column<bool>(type: "boolean", nullable: false),
                    AssignedPolicyId = table.Column<Guid>(type: "uuid", nullable: true),
                    CachedPolicyId = table.Column<Guid>(type: "uuid", nullable: true),
                    CachedVersion = table.Column<int>(type: "integer", nullable: true),
                    HelpersJson = table.Column<string>(type: "jsonb", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clipboard_device_configuration", x => x.DeviceId);
                    table.ForeignKey(
                        name: "FK_clipboard_device_configuration_clipboard_policies_AssignedP~",
                        column: x => x.AssignedPolicyId,
                        principalTable: "clipboard_policies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_clipboard_device_configuration_devices_DeviceId",
                        column: x => x.DeviceId,
                        principalTable: "devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "clipboard_policy_revisions",
                columns: table => new
                {
                    PolicyId = table.Column<Guid>(type: "uuid", nullable: false),
                    Version = table.Column<int>(type: "integer", nullable: false),
                    DefinitionJson = table.Column<string>(type: "jsonb", nullable: false),
                    AdministratorId = table.Column<Guid>(type: "uuid", nullable: false),
                    CreatedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clipboard_policy_revisions", x => new { x.PolicyId, x.Version });
                    table.ForeignKey(
                        name: "FK_clipboard_policy_revisions_clipboard_policies_PolicyId",
                        column: x => x.PolicyId,
                        principalTable: "clipboard_policies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "clipboard_events",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    DeviceId = table.Column<Guid>(type: "uuid", nullable: false),
                    PolicyId = table.Column<Guid>(type: "uuid", nullable: false),
                    PolicyVersion = table.Column<int>(type: "integer", nullable: false),
                    CredentialHash = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    MetadataJson = table.Column<string>(type: "jsonb", nullable: false),
                    PayloadHash = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    OccurredAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    ReceivedAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clipboard_events", x => x.Id);
                    table.ForeignKey(
                        name: "FK_clipboard_events_clipboard_policy_revisions_PolicyId_Policy~",
                        columns: x => new { x.PolicyId, x.PolicyVersion },
                        principalTable: "clipboard_policy_revisions",
                        principalColumns: new[] { "PolicyId", "Version" },
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_clipboard_events_devices_DeviceId",
                        column: x => x.DeviceId,
                        principalTable: "devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "clipboard_policy_deliveries",
                columns: table => new
                {
                    DeviceId = table.Column<Guid>(type: "uuid", nullable: false),
                    CredentialHash = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    PolicyId = table.Column<Guid>(type: "uuid", nullable: false),
                    Version = table.Column<int>(type: "integer", nullable: false),
                    DeliveredAtUtc = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_clipboard_policy_deliveries", x => new { x.DeviceId, x.CredentialHash, x.PolicyId, x.Version });
                    table.ForeignKey(
                        name: "FK_clipboard_policy_deliveries_clipboard_policy_revisions_Poli~",
                        columns: x => new { x.PolicyId, x.Version },
                        principalTable: "clipboard_policy_revisions",
                        principalColumns: new[] { "PolicyId", "Version" },
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_clipboard_policy_deliveries_devices_DeviceId",
                        column: x => x.DeviceId,
                        principalTable: "devices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_clipboard_device_configuration_AssignedPolicyId",
                table: "clipboard_device_configuration",
                column: "AssignedPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_clipboard_events_DeviceId_ReceivedAtUtc",
                table: "clipboard_events",
                columns: new[] { "DeviceId", "ReceivedAtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_clipboard_events_PolicyId_PolicyVersion",
                table: "clipboard_events",
                columns: new[] { "PolicyId", "PolicyVersion" });

            migrationBuilder.CreateIndex(
                name: "IX_clipboard_events_ReceivedAtUtc",
                table: "clipboard_events",
                column: "ReceivedAtUtc");

            migrationBuilder.CreateIndex(
                name: "IX_clipboard_policy_deliveries_PolicyId_Version",
                table: "clipboard_policy_deliveries",
                columns: new[] { "PolicyId", "Version" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "clipboard_device_configuration");

            migrationBuilder.DropTable(
                name: "clipboard_events");

            migrationBuilder.DropTable(
                name: "clipboard_policy_deliveries");

            migrationBuilder.DropTable(
                name: "clipboard_policy_revisions");

            migrationBuilder.DropTable(
                name: "clipboard_policies");
        }
    }
}
