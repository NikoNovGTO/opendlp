using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;

namespace OurDLP.Server.Data;

public sealed class DatabaseReadiness(DatabaseSettings settings,
    IDbContextFactory<OurDlpDbContext> factory, ILogger<DatabaseReadiness> logger)
{
    public async Task<DatabaseStatusResponse> CheckAsync(CancellationToken cancellationToken)
    {
        if (!settings.IsConfigured)
            return new("not-configured", "Подключение к PostgreSQL ещё не настроено на сервере.");

        using var budget = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        budget.CancelAfter(TimeSpan.FromSeconds(3));
        try
        {
            await using var db = await factory.CreateDbContextAsync(budget.Token);
            if (!await db.Database.CanConnectAsync(budget.Token))
                return Unavailable();
            if ((await db.Database.GetPendingMigrationsAsync(budget.Token)).Any())
                return new("migration-required", "База доступна, но требуется применить миграции локальной командой настройки.");

            // Read the real table; no writes or schema changes during an HTTP probe.
            await db.Devices.AsNoTracking().OrderBy(device => device.Id).Select(device => device.Id).Take(1).ToListAsync(budget.Token);
            await db.Users.AsNoTracking().OrderBy(user => user.Id).Select(user => user.Id).Take(1).ToListAsync(budget.Token);
            await db.DeviceCredentials.AsNoTracking().OrderBy(row => row.DeviceId).Select(row => row.DeviceId).Take(1).ToListAsync(budget.Token);
            await db.DeviceEnrollments.AsNoTracking().OrderBy(row => row.DeviceId).Select(row => row.DeviceId).Take(1).ToListAsync(budget.Token);
            await db.ScanJobs.AsNoTracking().Select(row => row.Id).Take(1).ToListAsync(budget.Token);
            await db.ClipboardPolicies.AsNoTracking().Select(row => row.Id).Take(1).ToListAsync(budget.Token);
            await db.ClipboardEvents.AsNoTracking().Select(row => row.Id).Take(1).ToListAsync(budget.Token);
            return new("ready", "PostgreSQL доступен. Миграции применены, чтение таблицы устройств выполнено.");
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception exception)
        {
            // Never send connection strings, credentials or driver exception text to clients.
            logger.LogWarning("Database readiness failed ({ExceptionType}).", exception.GetType().Name);
            return Unavailable();
        }
    }

    private static DatabaseStatusResponse Unavailable() => new("unavailable",
        "База не готова. Проверьте службу PostgreSQL, параметры подключения, права и схему базы.");
}
