using System.Security.Claims;
using OurDLP.Contracts;
using OurDLP.Server.Agents;
using OurDLP.Server.Authentication;
using OurDLP.Server.Clipboard;

namespace OurDLP.Server.Endpoints;

public static class ClipboardEndpoints
{
    public static IEndpointRouteBuilder MapClipboardEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var admin = endpoints.MapGroup("/api/clipboard").RequireAuthorization(AuthDefaults.AdministratorPolicy);
        admin.MapGet("/policies", (ClipboardPolicies policies, CancellationToken token) => policies.ListAsync(token));
        admin.MapPost("/policies", async (ClipboardPolicyDraft draft, ClipboardPolicies policies, HttpContext context, CancellationToken token) => await Execute(async () => Results.Ok(await policies.SaveAsync(null, draft, Actor(context), token))));
        admin.MapPost("/policies/{id:guid}", async (Guid id, ClipboardPolicyDraft draft, ClipboardPolicies policies, HttpContext context, CancellationToken token) => await Execute(async () => Results.Ok(await policies.SaveAsync(id, draft, Actor(context), token))));
        admin.MapGet("/devices", (ClipboardQueries queries, CancellationToken token) => queries.DevicesAsync(token));
        admin.MapPost("/devices/{id:guid}/policy", async (Guid id, ClipboardAssignment request, ClipboardPolicies policies, HttpContext context, CancellationToken token) => await Execute(async () => { await policies.AssignAsync(id, request.PolicyId, Actor(context), token); return Results.Ok(new DeviceOperationResponse("Назначение сохранено. Дождитесь подтверждения применения.")); }));
        admin.MapGet("/events", async (ClipboardQueries queries, HttpContext context, CancellationToken token) => { context.Response.Headers.CacheControl = "no-store"; return await queries.EventsAsync(token); });
        endpoints.MapPost("/api/agent/clipboard/sync", async (ClipboardAgentSync request, ClipboardAgentExchange exchange, HttpContext context, CancellationToken token) =>
            await Execute(async () => Results.Ok(await exchange.SyncAsync(Guid.Parse(context.User.FindFirst("device_id")!.Value), context.User.FindFirst("agent_credential_hash")!.Value, request, token))))
            .RequireAuthorization(AgentAuthenticationHandler.PolicyName);
        return endpoints;
    }
    private static Guid Actor(HttpContext context) => Guid.Parse(context.User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private static async Task<IResult> Execute(Func<Task<IResult>> action)
    {
        try { return await action(); }
        catch (ClipboardInputException e) { return Results.BadRequest(new DeviceOperationResponse(e.Message)); }
        catch (ClipboardConflictException e) { return Results.Conflict(new DeviceOperationResponse(e.Message)); }
        catch (UnauthorizedAccessException) { return Results.Unauthorized(); }
    }
}
