using System.Security.Claims;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Server.Agents;
using OurDLP.Server.Authentication;
using OurDLP.Server.Scanning;

namespace OurDLP.Server.Endpoints;

public static class ScanEndpoints
{
    public static IEndpointRouteBuilder MapScanEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var admin = endpoints.MapGroup("/api/scans").RequireAuthorization(AuthDefaults.AdministratorPolicy);
        admin.MapGet("", (ScanJobQueries queries, CancellationToken token) => queries.ListAsync(token));
        admin.MapPost("", async (CreateScanJobRequest request, ScanJobCommands commands, HttpContext context, CancellationToken token) =>
            await Execute(async () => Results.Ok(new ScanJobStateResponse(await commands.CreateAsync(request, Admin(context), token), "queued"))));
        admin.MapPost("/{id:guid}/cancel", async (Guid id, ScanJobCommands commands, HttpContext context, CancellationToken token) =>
        { var result = await commands.CancelAsync(id, Admin(context), token); return result is null ? Results.NotFound() : Results.Ok(result); });
        admin.MapGet("/{id:guid}/report", async (Guid id, ScanJobQueries queries, HttpContext context, CancellationToken token) =>
        { context.Response.Headers.CacheControl = "no-store"; var result = await queries.ReportAsync(id, token); return result is null ? Results.NotFound() : Results.Ok(result); });
        var agent = endpoints.MapGroup("/api/agent/scans").RequireAuthorization(AgentAuthenticationHandler.PolicyName);
        agent.MapPost("/next", async (ScanWorkRequest request, ScanWorkDelivery delivery, HttpContext context, CancellationToken token) =>
        { context.Response.Headers.CacheControl = "no-store"; return await Execute(async () => Results.Ok(await delivery.NextAsync(Device(context), Credential(context), request, token))); });
        agent.MapGet("/{id:guid}", async (Guid id, ScanWorkDelivery delivery, HttpContext context, CancellationToken token) =>
        { var result = await delivery.StateAsync(Device(context), id, token); return result is null ? Results.NotFound() : Results.Ok(result); });
        agent.MapPost("/{id:guid}/result", async (Guid id, ScanReport report, ScanResultReceiver receiver, HttpContext context, CancellationToken token) =>
            await Execute(async () => { var result = await receiver.ReceiveAsync(Device(context), Credential(context), id, report, token); return result is null ? Results.NotFound() : Results.Ok(result); }));
        return endpoints;
    }
    private static string Credential(HttpContext context) => context.User.FindFirst("agent_credential_hash")!.Value;
    private static Guid Device(HttpContext context) => Guid.Parse(context.User.FindFirst("device_id")!.Value);
    private static Guid Admin(HttpContext context) => Guid.Parse(context.User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private static async Task<IResult> Execute(Func<Task<IResult>> action)
    {
        try { return await action(); }
        catch (ScanJobInputException error) { return Results.BadRequest(new DeviceOperationResponse(error.Message)); }
        catch (ScanJobConflictException error) { return Results.Conflict(new DeviceOperationResponse(error.Message)); }
        catch (UnauthorizedAccessException) { return Results.Unauthorized(); }
    }
}
