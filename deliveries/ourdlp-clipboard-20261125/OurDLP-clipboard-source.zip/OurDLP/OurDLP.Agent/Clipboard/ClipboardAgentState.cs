using OurDLP.Contracts;
using OurDLP.Core.Clipboard;

namespace OurDLP.Agent.Clipboard;

public sealed record ClipboardAgentState
{
    public int SchemaVersion { get; init; } = 1;
    public string RegistrationKey { get; init; } = string.Empty;
    public ClipboardPolicy? Policy { get; init; }
    public IReadOnlyList<ClipboardEvent> Pending { get; init; } = [];
    public long RejectedEvents { get; init; }
}
public interface IClipboardAgentStore
{
    Task<ClipboardAgentState?> ReadAsync(CancellationToken token);
    Task SaveAsync(ClipboardAgentState value, CancellationToken token);
    Task ArchiveAsync(CancellationToken token);
}
public interface IClipboardAgentClient
{
    Task<OurDLP.Agent.Scanning.AgentScanReply<ClipboardAgentResponse>> SyncAsync(AgentState state, ClipboardAgentSync request, CancellationToken token);
}
