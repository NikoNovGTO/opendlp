using System.ComponentModel;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
using OurDLP.Contracts;

namespace OurDLP.Agent.Clipboard;

[SupportedOSPlatform("windows")]
public static class WindowsClipboardPipe
{
    [StructLayout(LayoutKind.Sequential)]
    private struct SecurityAttributes { public int Length; public IntPtr Descriptor; [MarshalAs(UnmanagedType.Bool)] public bool Inherit; }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern SafePipeHandle CreateNamedPipeW(string name, uint openMode, uint pipeMode, uint maximumInstances,
        uint outSize, uint inSize, uint timeout, ref SecurityAttributes security);
    public static NamedPipeServerStream Create()
    {
        var security = new PipeSecurity(); security.SetAccessRuleProtection(true, false);
        var service = WindowsIdentity.GetCurrent().User!; security.SetOwner(service);
        foreach (var sid in new[] { service, new SecurityIdentifier("S-1-5-18"), new SecurityIdentifier("S-1-5-32-544") })
            security.AddAccessRule(new PipeAccessRule(sid, PipeAccessRights.FullControl, AccessControlType.Allow));
        // Exact data rights, deliberately excluding FILE_CREATE_PIPE_INSTANCE (bit 4).
        var clientRights = PipeAccessRights.ReadData | PipeAccessRights.WriteData | PipeAccessRights.ReadAttributes | PipeAccessRights.ReadPermissions | PipeAccessRights.Synchronize;
        security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier("S-1-5-11"), clientRights, AccessControlType.Allow));
        var descriptor = security.GetSecurityDescriptorBinaryForm(); var pinned = GCHandle.Alloc(descriptor, GCHandleType.Pinned);
        try
        {
            var attributes = new SecurityAttributes { Length = Marshal.SizeOf<SecurityAttributes>(), Descriptor = pinned.AddrOfPinnedObject() };
            // Duplex + overlapped + first instance; byte mode + reject remote clients.
            var handle = CreateNamedPipeW(@"\\.\pipe\" + ClipboardWire.PipeName, 3u | 0x40000000u | 0x00080000u,
                0x00000008u, 1, ClipboardWire.MaxFrameBytes, ClipboardWire.MaxFrameBytes, 2000, ref attributes);
            if (handle.IsInvalid) { var error = Marshal.GetLastWin32Error(); handle.Dispose(); throw new Win32Exception(error); }
            try { return new(PipeDirection.InOut, true, false, handle); } catch { handle.Dispose(); throw; }
        }
        finally { pinned.Free(); }
    }
}
