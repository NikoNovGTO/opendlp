using System.Runtime.Versioning;
using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OurDLP.Contracts;

namespace OurDLP.Agent.Clipboard;

[SupportedOSPlatform("windows")]
public sealed class ClipboardPipeWorker(ClipboardAgentCoordinator coordinator, ILogger<ClipboardPipeWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var pipe = WindowsClipboardPipe.Create();
                await pipe.WaitForConnectionAsync(stoppingToken);
                using var budget = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken); budget.CancelAfter(TimeSpan.FromSeconds(3));
                try
                {
                    var peer = WindowsClipboardPeer.Read(pipe);
                    var request = await ClipboardFrames.ReadAsync<ClipboardSessionRequest>(pipe, budget.Token);
                    var response = await coordinator.SessionAsync(peer, request, budget.Token);
                    await ClipboardFrames.WriteAsync(pipe, response, budget.Token);
                }
                catch (Exception e) when (e is IOException or UnauthorizedAccessException or JsonException or OperationCanceledException or System.ComponentModel.Win32Exception or ArgumentException)
                { logger.LogDebug("Пользовательский канал завершён ({Type}).", e.GetType().Name); }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { return; }
            catch (Exception e)
            { logger.LogWarning("Канал буфера недоступен ({Type}); повтор через 5 секунд.", e.GetType().Name); await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken); }
        }
    }
}
