using System.Runtime.Versioning;

namespace OurDLP.Agent.Clipboard;

[SupportedOSPlatform("windows")]
public sealed class WindowsClipboardAgentStore : IClipboardAgentStore
{
    private readonly WindowsAgentFiles _files = new();
    private const string FileName = "clipboard-state.bin", Purpose = "OurDLP.Agent.Clipboard.v1";
    public Task<ClipboardAgentState?> ReadAsync(CancellationToken token) => _files.ReadAsync<ClipboardAgentState>(FileName, Purpose, 2 * 1024 * 1024, token);
    public Task SaveAsync(ClipboardAgentState value, CancellationToken token) => _files.SaveAsync(FileName, Purpose, 2 * 1024 * 1024, value, token);
    public Task ArchiveAsync(CancellationToken token) { token.ThrowIfCancellationRequested(); _files.Archive(FileName, "clipboard-archive-"); return Task.CompletedTask; }
}
