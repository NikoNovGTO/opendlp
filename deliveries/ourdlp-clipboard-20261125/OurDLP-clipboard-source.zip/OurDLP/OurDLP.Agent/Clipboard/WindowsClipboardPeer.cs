using System.ComponentModel;
using System.Diagnostics;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
using OurDLP.Contracts;

namespace OurDLP.Agent.Clipboard;

[SupportedOSPlatform("windows")]
public static class WindowsClipboardPeer
{
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetNamedPipeClientProcessId(SafePipeHandle pipe, out uint process);
    public static ClipboardPeer Read(NamedPipeServerStream pipe)
    {
        if (!GetNamedPipeClientProcessId(pipe.SafePipeHandle, out var pid)) throw new Win32Exception(Marshal.GetLastWin32Error());
        string? sid = null, name = null; var session = 0;
        // Inspect the client while impersonating it: the service account need not have
        // cross-user process-query rights. The pipe supplies the peer PID.
        pipe.RunAsClient(() =>
        {
            using var identity = WindowsIdentity.GetCurrent(); if (!identity.IsAuthenticated) return;
            using var process = Process.GetProcessById(checked((int)pid));
            var expected = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "OurDLP", "Agent", "OurDLP.Session.exe");
            session = process.SessionId;
            if (session == 0 || !WindowsProcessPath.Read(pid).Equals(expected, StringComparison.OrdinalIgnoreCase)) throw new UnauthorizedAccessException("Неизвестный клиент канала.");
            sid = identity.User?.Value; try { name = identity.Name; } catch { name = sid; }
        });
        if (!ClipboardValidation.Peer(sid!, name!, session)) throw new UnauthorizedAccessException("Не удалось подтвердить пользовательский сеанс.");
        return new(sid!, name!, session);
    }
}
