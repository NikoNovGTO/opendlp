using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace OurDLP.Agent.Clipboard;

[SupportedOSPlatform("windows")]
public static class WindowsProcessPath
{
    [DllImport("kernel32.dll", SetLastError = true)] private static extern SafeProcessHandle OpenProcess(uint access, bool inherit, uint process);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool QueryFullProcessImageNameW(SafeProcessHandle process, uint flags, StringBuilder path, ref uint size);
    public static string Read(uint process)
    {
        using var handle = OpenProcess(0x1000, false, process);
        if (handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error());
        var output = new StringBuilder(32768); uint length = 32768;
        if (!QueryFullProcessImageNameW(handle, 0, output, ref length)) throw new Win32Exception(Marshal.GetLastWin32Error());
        return Path.GetFullPath(output.ToString());
    }
}
