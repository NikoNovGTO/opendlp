using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;

namespace OurDLP.Agent.Clipboard;

public sealed class ClipboardAgentClient(HttpClient http) : IClipboardAgentClient
{
    public async Task<AgentScanReply<ClipboardAgentResponse>> SyncAsync(AgentState state, ClipboardAgentSync body, CancellationToken token)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, AgentAddress.Normalize(state.ServerAddress) + "/api/agent/clipboard/sync")
        { Content = JsonContent.Create(body, options: ScanWire.Json) };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", state.Token);
        try
        {
            using var response = await http.SendAsync(request, token);
            if (!response.IsSuccessStatusCode) return new(null, (int)response.StatusCode);
            return new(await response.Content.ReadFromJsonAsync<ClipboardAgentResponse>(ScanWire.Json, token), (int)response.StatusCode);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return new(null, 504); }
        catch (Exception e) when (e is HttpRequestException or IOException or JsonException or NotSupportedException) { return new(null, 503); }
    }
}
