using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace OurDLP.Agent.Clipboard;

public sealed class ClipboardPolicyWorker(IAgentStateStore registration, ClipboardAgentCoordinator coordinator,
    IClipboardAgentClient client, ILogger<ClipboardPolicyWorker> logger, IHostApplicationLifetime lifetime) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            var state = await registration.ReadAsync(stoppingToken); if (state?.DeviceId is null) return;
            while (!stoppingToken.IsCancellationRequested)
            {
                var snapshot = await coordinator.SnapshotAsync(stoppingToken);
                var response = await client.SyncAsync(state, snapshot, stoppingToken);
                if (response.AccessDenied) { logger.LogError("Обмен буфером отозван. Локальная очередь сохранена."); lifetime.StopApplication(); return; }
                if (response.Value is not null) await coordinator.ApplyAsync(response.Value, snapshot.Events.Select(row => row.Detection.Id).ToArray(), stoppingToken);
                await Task.Delay(TimeSpan.FromSeconds(15), stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
        catch (Exception e) { logger.LogError("Обмен политикой буфера остановлен ({Type}).", e.GetType().Name); lifetime.StopApplication(); }
    }
}
