using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;

namespace OurDLP.Agent.Scanning;

public sealed class AgentScanClient(HttpClient http) : IAgentScanClient
{
    public Task<AgentScanReply<ScanWorkResponse>> NextAsync(AgentState state, string root, CancellationToken token) =>
        SendAsync<ScanWorkResponse>(state, HttpMethod.Post, "/next", new ScanWorkRequest(ScanWire.Version, root), token);
    public Task<AgentScanReply<ScanJobStateResponse>> StateAsync(AgentState state, Guid job, CancellationToken token) =>
        SendAsync<ScanJobStateResponse>(state, HttpMethod.Get, $"/{job}", null, token);
    public Task<AgentScanReply<ScanResultAcknowledgement>> SubmitAsync(AgentState state, Guid job, ScanReport report, CancellationToken token) =>
        SendAsync<ScanResultAcknowledgement>(state, HttpMethod.Post, $"/{job}/result", report, token);
    private async Task<AgentScanReply<T>> SendAsync<T>(AgentState state, HttpMethod method, string path, object? body, CancellationToken token)
    {
        using var request = new HttpRequestMessage(method, AgentAddress.Normalize(state.ServerAddress) + "/api/agent/scans" + path);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", state.Token);
        if (body is not null) request.Content = JsonContent.Create(body, options: ScanWire.Json);
        try
        {
            using var response = await http.SendAsync(request, token);
            if (!response.IsSuccessStatusCode) return new(default, (int)response.StatusCode);
            var value = await response.Content.ReadFromJsonAsync<T>(ScanWire.Json, token);
            return new(value, value is null ? 502 : (int)response.StatusCode);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return new(default, 504); }
        catch (Exception error) when (error is HttpRequestException or JsonException or NotSupportedException or IOException) { return new(default, 503); }
    }
}
