using System.Runtime.Versioning;

namespace OurDLP.Agent.Scanning;

[SupportedOSPlatform("windows")]
public sealed class WindowsAgentScanQueue : IAgentScanQueue
{
    private readonly WindowsAgentFiles _files = new();
    private const string FileName = "pending-scan.bin", Purpose = "OurDLP.Agent.PendingScan.v1";
    public Task<PendingAgentScan?> ReadAsync(CancellationToken token) => _files.ReadAsync<PendingAgentScan>(FileName, Purpose, 3 * 1024 * 1024, token);
    public Task SaveAsync(PendingAgentScan pending, CancellationToken token) => _files.SaveAsync(FileName, Purpose, 3 * 1024 * 1024, pending, token);
    public Task ClearAsync(CancellationToken token) { token.ThrowIfCancellationRequested(); _files.Delete(FileName); return Task.CompletedTask; }
    public Task ArchiveAsync(CancellationToken token) { token.ThrowIfCancellationRequested(); _files.Archive(FileName); return Task.CompletedTask; }
}
