using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace OurDLP.Agent.Scanning;

public sealed class AgentScanWorker(IAgentStateStore states, AgentScanCycle cycle,
    ILogger<AgentScanWorker> logger, IHostApplicationLifetime lifetime) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            var state = await states.ReadAsync(stoppingToken);
            if (state?.DeviceId is null) return;
            while (!stoppingToken.IsCancellationRequested)
            {
                try { await cycle.RunOnceAsync(state, stoppingToken); }
                catch (Exception error) when (error is IOException or UnauthorizedAccessException)
                { logger.LogWarning("Очередь проверки недоступна ({Type}); повтор через 15 секунд.", error.GetType().Name); }
                await Task.Delay(TimeSpan.FromSeconds(15), stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
        catch (AgentAccessRevokedException) { logger.LogError("Доступ агента отозван. Результат сохранён локально."); lifetime.StopApplication(); }
        catch (Exception error)
        { logger.LogError("Обработка заданий остановлена ({Type}). Проверьте локальную установку.", error.GetType().Name); lifetime.StopApplication(); }
    }
}
