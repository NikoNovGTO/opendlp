using OurDLP.Contracts;

namespace OurDLP.Agent.Scanning;

public sealed class AgentScanCycle(IAgentScanQueue queue, IAgentScanClient client, AgentScanProcessing processing, string scanRoot)
{
    public async Task RunOnceAsync(AgentState state, CancellationToken stop)
    {
        if (state.DeviceId is null) throw new InvalidOperationException("Агент не зарегистрирован.");
        var pending = await queue.ReadAsync(stop);
        if (pending is not null && (pending.DeviceId != state.DeviceId || pending.ServerAddress != state.ServerAddress))
            throw new InvalidDataException("Очередь относится к другой регистрации. Нужна локальная перерегистрация с архивированием очереди.");
        if (pending is null)
        {
            var work = await client.NextAsync(state, scanRoot, stop);
            if (work.AccessDenied) throw new AgentAccessRevokedException();
            if (work.Value is not { ProtocolVersion: ScanWire.Version, Job: { } job } || job.Id == Guid.Empty || job.Request is null) return;
            pending = new(state.ServerAddress, state.DeviceId.Value, job, null);
            await queue.SaveAsync(pending, stop); // A reboot can safely resume this read-only job.
        }
        if (pending.Report is null)
        {
            var result = await processing.ExecuteAsync(state, pending.Job, stop);
            pending = pending with { Report = result.Report };
            // Preserve partial results during an orderly service stop as well.
            using var saveBudget = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            await queue.SaveAsync(pending, saveBudget.Token);
            if (result.Revoked) throw new AgentAccessRevokedException();
        }
        if (stop.IsCancellationRequested) return;
        var response = await client.SubmitAsync(state, pending.Job.Id, pending.Report, stop);
        if (response.AccessDenied) throw new AgentAccessRevokedException();
        if (response.Value is { } acknowledgement && acknowledgement.JobId == pending.Job.Id
            && acknowledgement.Outcome is "accepted" or "duplicate" or "cancelled") await queue.ClearAsync(stop);
        // Any network error or unexpected acknowledgement leaves the exact result pending.
    }
}
