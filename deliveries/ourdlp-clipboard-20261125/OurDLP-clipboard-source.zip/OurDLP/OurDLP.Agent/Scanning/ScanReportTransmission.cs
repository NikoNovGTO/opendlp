using System.Text;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;

namespace OurDLP.Agent.Scanning;

public static class ScanReportTransmission
{
    public static ScanReport Bound(ScanReport report)
    {
        while (Encoding.UTF8.GetByteCount(ScanWire.Serialize(report)) > ScanWire.MaxReportBytes)
        {
            if (report.Findings.Count == 0 && report.Issues.Count == 0) throw new InvalidDataException("Параметры отчёта превышают предел передачи.");
            report = report with
            {
                Findings = report.Findings.Take(report.Findings.Count / 2).ToArray(),
                Issues = report.Issues.Take(report.Issues.Count / 2).ToArray(),
                Completion = report.Completion == ScanCompletion.Cancelled ? ScanCompletion.Cancelled : ScanCompletion.LimitReached,
                Message = "Достигнут предел размера пакета; часть обнаружений и замечаний не включена. Результат неполный."
            };
        }
        return report;
    }
}
