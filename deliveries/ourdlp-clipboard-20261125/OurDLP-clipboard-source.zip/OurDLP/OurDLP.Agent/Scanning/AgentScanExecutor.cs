using OurDLP.Contracts;
using OurDLP.Core.Scanning;

namespace OurDLP.Agent.Scanning;

public sealed class AgentScanExecutor(IFileScanner scanner, string allowedRoot)
{
    public async Task<ScanReport> ExecuteAsync(ScanWork job, CancellationToken token)
    {
        var started = DateTimeOffset.UtcNow;
        try
        {
            var root = Path.GetFullPath(job.Request.RootPath);
            if (!RemoteScanPaths.IsInside(root, Path.GetFullPath(allowedRoot))) throw new ArgumentException();
            var report = await scanner.ScanAsync(job.Request, null, token);
            return report with { Id = job.Id };
        }
        catch (Exception error) when (error is ArgumentException or IOException or UnauthorizedAccessException or System.Security.SecurityException)
        {
            return new()
            {
                Id = job.Id, RootPath = job.Request.RootPath, Rules = job.Request.Rules,
                ExcludedDirectories = job.Request.ExcludedDirectories, Limits = job.Request.Limits,
                StartedAtUtc = started, CompletedAtUtc = DateTimeOffset.UtcNow, Completion = ScanCompletion.Failed,
                Message = "Проверка не выполнена. Проверьте разрешённую область, существование каталога, ссылки и права агента.",
                IssueCount = 1, Issues = [new(job.Request.RootPath, "scope", "Каталог недоступен для разрешённой проверки агента.")]
            };
        }
    }
}
