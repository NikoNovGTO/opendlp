using OurDLP.Contracts;
using OurDLP.Core.Scanning;

namespace OurDLP.Agent.Scanning;

public sealed class AgentScanProcessing(AgentScanExecutor executor, IAgentScanClient client, TimeSpan? pollInterval = null)
{
    public async Task<(ScanReport Report, bool Revoked)> ExecuteAsync(AgentState state, ScanWork job, CancellationToken stop)
    {
        using var cancel = CancellationTokenSource.CreateLinkedTokenSource(stop);
        var running = executor.ExecuteAsync(job, cancel.Token);
        var revoked = false;
        try
        {
            while (!running.IsCompleted)
            {
                if (await Task.WhenAny(running, Task.Delay(pollInterval ?? TimeSpan.FromSeconds(5), stop)) == running) break;
                stop.ThrowIfCancellationRequested();
                var status = await client.StateAsync(state, job.Id, stop);
                if (status.AccessDenied) { revoked = true; cancel.Cancel(); break; }
                if (status.Value is { Status: "cancelled" } value && value.JobId == job.Id) { cancel.Cancel(); break; }
            }
        }
        catch (OperationCanceledException) when (stop.IsCancellationRequested) { cancel.Cancel(); }
        return (ScanReportTransmission.Bound(await running), revoked);
    }
}
