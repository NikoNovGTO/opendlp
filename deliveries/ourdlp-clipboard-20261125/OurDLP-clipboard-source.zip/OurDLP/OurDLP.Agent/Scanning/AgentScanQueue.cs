using OurDLP.Contracts;
using OurDLP.Core.Scanning;

namespace OurDLP.Agent.Scanning;

public sealed record PendingAgentScan(string ServerAddress, Guid DeviceId, ScanWork Job, ScanReport? Report);
public interface IAgentScanQueue
{
    Task<PendingAgentScan?> ReadAsync(CancellationToken token);
    Task SaveAsync(PendingAgentScan pending, CancellationToken token);
    Task ClearAsync(CancellationToken token);
    Task ArchiveAsync(CancellationToken token);
}
public sealed class AgentAccessRevokedException : Exception;
public sealed record AgentScanReply<T>(T? Value, int StatusCode)
{
    public bool Succeeded => Value is not null;
    public bool AccessDenied => StatusCode is 401 or 403;
}
public interface IAgentScanClient
{
    Task<AgentScanReply<ScanWorkResponse>> NextAsync(AgentState state, string root, CancellationToken token);
    Task<AgentScanReply<ScanJobStateResponse>> StateAsync(AgentState state, Guid job, CancellationToken token);
    Task<AgentScanReply<ScanResultAcknowledgement>> SubmitAsync(AgentState state, Guid job, ScanReport report, CancellationToken token);
}
