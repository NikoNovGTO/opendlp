namespace OurDLP.Agent;

public sealed class AgentState
{
    public int FormatVersion { get; init; } = 1;
    public string ServerAddress { get; init; } = string.Empty;
    public string? EnrollmentCodeHash { get; init; }
    public string Token { get; init; } = string.Empty;
    public DateTimeOffset? ServiceContactConfirmedAtUtc { get; init; }
    public Guid? DeviceId { get; init; }
    public AgentState WithDevice(Guid id) => new() { ServerAddress = ServerAddress, Token = Token, EnrollmentCodeHash = EnrollmentCodeHash, DeviceId = id };
    public AgentState WithServiceContact() => new() { ServerAddress = ServerAddress, Token = Token, EnrollmentCodeHash = EnrollmentCodeHash, DeviceId = DeviceId, ServiceContactConfirmedAtUtc = DateTimeOffset.UtcNow };
}
