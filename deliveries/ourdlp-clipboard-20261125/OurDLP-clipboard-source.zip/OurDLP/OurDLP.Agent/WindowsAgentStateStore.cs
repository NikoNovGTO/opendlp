using System.Runtime.Versioning;

namespace OurDLP.Agent;

[SupportedOSPlatform("windows")]
public sealed class WindowsAgentStateStore : IAgentStateStore
{
    private readonly WindowsAgentFiles _files = new();
    public async Task<AgentState?> ReadAsync(CancellationToken token)
    {
        var state = await _files.ReadAsync<AgentState>("state.bin", "OurDLP.Agent.State.v1", 64 * 1024, token);
        if (state is null) return null;
        if (state.FormatVersion != 1 || state.Token?.Length != 43) throw new InvalidDataException("Некорректное состояние агента.");
        _ = AgentAddress.Normalize(state.ServerAddress); return state;
    }
    public Task SaveAsync(AgentState state, CancellationToken token) =>
        _files.SaveAsync("state.bin", "OurDLP.Agent.State.v1", 64 * 1024, state, token);
}
