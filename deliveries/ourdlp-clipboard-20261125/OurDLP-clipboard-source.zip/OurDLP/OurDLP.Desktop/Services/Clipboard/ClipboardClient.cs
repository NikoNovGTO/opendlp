using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Models;
namespace OurDLP.Desktop.Services.Clipboard;
public sealed class ClipboardClient(HttpClient http, string address) : IClipboardClient
{
    public Task<DeviceApiResult<ClipboardPolicyList>> PoliciesAsync(CancellationToken token) => Send<ClipboardPolicyList>(HttpMethod.Get, "/policies", null, token);
    public Task<DeviceApiResult<ClipboardPolicy>> SaveAsync(Guid? id, ClipboardPolicyDraft draft, CancellationToken token) => Send<ClipboardPolicy>(HttpMethod.Post, "/policies" + (id is null ? "" : "/" + id), draft, token);
    public Task<DeviceApiResult<ClipboardDeviceList>> DevicesAsync(CancellationToken token) => Send<ClipboardDeviceList>(HttpMethod.Get, "/devices", null, token);
    public Task<DeviceApiResult<DeviceOperationResponse>> AssignAsync(Guid device, Guid? policy, CancellationToken token) => Send<DeviceOperationResponse>(HttpMethod.Post, $"/devices/{device}/policy", new ClipboardAssignment(policy), token);
    public Task<DeviceApiResult<ClipboardEventList>> EventsAsync(CancellationToken token) => Send<ClipboardEventList>(HttpMethod.Get, "/events", null, token);
    private async Task<DeviceApiResult<T>> Send<T>(HttpMethod method, string path, object? body, CancellationToken token)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var root)) return new(default, "Неверный адрес сервера.");
        using var request = new HttpRequestMessage(method, root + "/api/clipboard" + path);
        if (body is not null) request.Content = JsonContent.Create(body);
        try
        {
            using var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token);
            await response.Content.LoadIntoBufferAsync(32 * 1024 * 1024, token);
            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden) return new(default, "Сеанс завершён.", true);
            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode is HttpStatusCode.BadRequest or HttpStatusCode.Conflict)
                    return new(default, (await response.Content.ReadFromJsonAsync<DeviceOperationResponse>(token))?.Message ?? "Операция не принята.");
                return new(default, "Не удалось выполнить операцию. Проверьте сервер.");
            }
            var value = await response.Content.ReadFromJsonAsync<T>(token); return value is null ? new(default, "Пустой ответ сервера.") : new(value);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return new(default, "Сервер не ответил вовремя."); }
        catch (Exception e) when (e is HttpRequestException or JsonException or NotSupportedException) { return new(default, "Защищённый обмен с сервером не выполнен."); }
    }
}
