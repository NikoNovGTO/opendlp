using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Models;
namespace OurDLP.Desktop.Services.Clipboard;
public interface IClipboardClient
{
    Task<DeviceApiResult<ClipboardPolicyList>> PoliciesAsync(CancellationToken token);
    Task<DeviceApiResult<ClipboardPolicy>> SaveAsync(Guid? id, ClipboardPolicyDraft draft, CancellationToken token);
    Task<DeviceApiResult<ClipboardDeviceList>> DevicesAsync(CancellationToken token);
    Task<DeviceApiResult<DeviceOperationResponse>> AssignAsync(Guid device, Guid? policy, CancellationToken token);
    Task<DeviceApiResult<ClipboardEventList>> EventsAsync(CancellationToken token);
}
