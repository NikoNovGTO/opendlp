using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services.RemoteScanning;

public sealed class ScanJobsClient(HttpClient http, string address) : IScanJobsClient
{
    public Task<DeviceApiResult<ScanJobListResponse>> ListAsync(CancellationToken token) => SendAsync<ScanJobListResponse>(HttpMethod.Get, "", null, token);
    public Task<DeviceApiResult<ScanJobStateResponse>> CreateAsync(CreateScanJobRequest body, CancellationToken token) => SendAsync<ScanJobStateResponse>(HttpMethod.Post, "", body, token);
    public Task<DeviceApiResult<ScanJobStateResponse>> CancelAsync(Guid id, CancellationToken token) => SendAsync<ScanJobStateResponse>(HttpMethod.Post, $"/{id}/cancel", null, token);
    public async Task<DeviceApiResult<ScanJobReportResponse>> ReportAsync(Guid id, CancellationToken token)
    {
        var result = await SendAsync<ScanJobReportResponse>(HttpMethod.Get, $"/{id}/report", null, token);
        return result.Value is { } value && (value.JobId != id || value.Report?.Id != id)
            ? new(default, "Отчёт не соответствует выбранному заданию.") : result;
    }
    private async Task<DeviceApiResult<T>> SendAsync<T>(HttpMethod method, string path, object? body, CancellationToken token)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized)) return new(default, "Некорректный адрес сервера.");
        using var request = new HttpRequestMessage(method, normalized + "/api/scans" + path);
        if (body is not null) request.Content = JsonContent.Create(body);
        try
        {
            using var response = await http.SendAsync(request, token);
            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden) return new(default, "Сеанс завершён. Войдите повторно.", true);
            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode is HttpStatusCode.BadRequest or HttpStatusCode.Conflict)
                {
                    var error = await response.Content.ReadFromJsonAsync<DeviceOperationResponse>(token);
                    return new(default, error?.Message ?? "Задание не принято.");
                }
                return new(default, response.StatusCode == HttpStatusCode.NotFound ? "Отчёт пока отсутствует. Обновите список." : "Операция не выполнена. Проверьте состояние сервера.");
            }
            var value = await response.Content.ReadFromJsonAsync<T>(token);
            return value is null ? new(default, "Сервер вернул пустой ответ.") : new(value);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return new(default, "Сервер не ответил вовремя."); }
        catch (Exception error) when (error is HttpRequestException or JsonException or NotSupportedException) { return new(default, "Не удалось выполнить защищённый обмен с сервером."); }
    }
}
