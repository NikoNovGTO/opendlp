using OurDLP.Contracts;
using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services.RemoteScanning;

public interface IScanJobsClient
{
    Task<DeviceApiResult<ScanJobListResponse>> ListAsync(CancellationToken token);
    Task<DeviceApiResult<ScanJobStateResponse>> CreateAsync(CreateScanJobRequest request, CancellationToken token);
    Task<DeviceApiResult<ScanJobStateResponse>> CancelAsync(Guid id, CancellationToken token);
    Task<DeviceApiResult<ScanJobReportResponse>> ReportAsync(Guid id, CancellationToken token);
}
