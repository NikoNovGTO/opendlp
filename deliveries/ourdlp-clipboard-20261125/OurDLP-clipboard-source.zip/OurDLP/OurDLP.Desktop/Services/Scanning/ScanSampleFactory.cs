using OurDLP.Core.Samples;
using System.IO;
using System.Text;

namespace OurDLP.Desktop.Services.Scanning;

public sealed class ScanSampleFactory(string? parent = null)
{
    public string Create()
    {
        var directory = Path.Combine(parent ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "OurDLP", "Samples"), "OurDLP-Test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Path.Combine(directory, "excluded"));
        File.WriteAllText(Path.Combine(directory, "sample.txt"), "Тестовые строки: OURDLP-TEST-0001 и OURDLP-TEST-0002.", Encoding.UTF8);
        File.WriteAllText(Path.Combine(directory, "list.csv"), "id;marker\n1;OURDLP-TEST-0003", Encoding.UTF8);
        File.WriteAllText(Path.Combine(directory, "clean.log"), "Здесь нет тестовых маркеров.", Encoding.UTF8);
        File.WriteAllText(Path.Combine(directory, "excluded", "ignored.txt"), "OURDLP-TEST-9999", Encoding.UTF8);
        File.WriteAllText(Path.Combine(directory, "unsupported.pdf"), "OURDLP-TEST-8888", Encoding.UTF8);
        OfficeSampleDocuments.Create(directory);
        return directory;
    }
}
