using System.Windows.Controls;
using System.Windows.Threading;
using OurDLP.Desktop.ViewModels.RemoteScanning;

namespace OurDLP.Desktop.Views;

public partial class RemoteScansView : UserControl
{
    private readonly DispatcherTimer _refresh = new() { Interval = TimeSpan.FromSeconds(10) };
    public RemoteScansView()
    {
        InitializeComponent(); _refresh.Tick += (_, _) => Refresh();
        Loaded += (_, _) => { Refresh(); _refresh.Start(); }; Unloaded += (_, _) => _refresh.Stop();
    }
    private void Refresh()
    { if (DataContext is RemoteScansViewModel model && model.RefreshCommand.CanExecute(null)) model.RefreshCommand.Execute(null); }
}
