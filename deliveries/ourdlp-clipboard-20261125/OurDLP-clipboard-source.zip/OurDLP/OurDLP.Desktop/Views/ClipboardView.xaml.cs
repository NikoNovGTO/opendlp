using System.Windows.Controls;
using System.Windows.Threading;
using OurDLP.Desktop.ViewModels.Clipboard;
namespace OurDLP.Desktop.Views;
public partial class ClipboardView : UserControl
{
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(10) };
    public ClipboardView() { InitializeComponent(); _timer.Tick += (_, _) => Refresh(); Loaded += (_, _) => { Refresh(); _timer.Start(); }; Unloaded += (_, _) => _timer.Stop(); }
    private void Refresh() { if (DataContext is ClipboardWorkspace model && model.RefreshCommand.CanExecute(null)) model.RefreshCommand.Execute(null); }
}
