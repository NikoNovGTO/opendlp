using System.Collections.ObjectModel;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services.Clipboard;
namespace OurDLP.Desktop.ViewModels.Clipboard;
public sealed class ClipboardWorkspace : ObservableObject, IDisposable
{
    private readonly IClipboardClient _client; private readonly Func<string, bool> _confirm; private readonly Action _expired;
    private readonly CancellationTokenSource _lifetime = new(); private bool _busy, _disposed, _refreshing;
    private ClipboardPolicy? _policy; private ClipboardDeviceRow? _device; private string _message = "";
    public ObservableCollection<ClipboardPolicy> Policies { get; } = [];
    public ObservableCollection<ClipboardDeviceRow> Devices { get; } = [];
    public ObservableCollection<ClipboardEventView> Events { get; } = [];
    public ClipboardPolicyEditor Editor { get; } = new();
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public bool CanEdit => !_busy && !_disposed;
    public ClipboardPolicy? SelectedPolicy { get => _policy; set { if (SetProperty(ref _policy, value)) { if (!_refreshing && value is not null) Editor.Load(value); RefreshCommands(); } } }
    public ClipboardDeviceRow? SelectedDevice { get => _device; set { if (SetProperty(ref _device, value)) RefreshCommands(); } }
    public AsyncRelayCommand RefreshCommand { get; }
    public AsyncRelayCommand NewCommand { get; }
    public AsyncRelayCommand SaveCommand { get; }
    public AsyncRelayCommand AssignCommand { get; }
    public AsyncRelayCommand UnassignCommand { get; }
    public ClipboardWorkspace(IClipboardClient client, Func<string, bool> confirm, Action expired)
    {
        _client = client; _confirm = confirm; _expired = expired;
        RefreshCommand = Command(RefreshAsync); NewCommand = Command(() => { SelectedPolicy = null; Editor.Load(null); return Task.CompletedTask; });
        SaveCommand = Command(SaveAsync);
        AssignCommand = Command(() => AssignAsync(SelectedPolicy?.Id), () => SelectedDevice?.Capable == true && SelectedPolicy is not null);
        UnassignCommand = Command(() => AssignAsync(null), () => SelectedDevice?.PolicyId is not null);
    }
    private AsyncRelayCommand Command(Func<Task> operation, Func<bool>? allowed = null) => new(() => RunAsync(operation), Unexpected, () => CanEdit && (allowed?.Invoke() ?? true));
    private async Task RunAsync(Func<Task> operation)
    {
        if (!CanEdit) return; _busy = true; Message = ""; RefreshCommands();
        try { await operation(); }
        catch (OperationCanceledException) when (_disposed) { }
        catch (ArgumentException e) { if (!_disposed) Message = e.Message; }
        finally { _busy = false; if (_disposed) _lifetime.Dispose(); else RefreshCommands(); }
    }
    private async Task RefreshAsync()
    {
        var policies = await _client.PoliciesAsync(_lifetime.Token); if (!Accept(policies)) return;
        var devices = await _client.DevicesAsync(_lifetime.Token); if (!Accept(devices)) return;
        var events = await _client.EventsAsync(_lifetime.Token); if (!Accept(events)) return;
        var policyId = SelectedPolicy?.Id; var deviceId = SelectedDevice?.Id; _refreshing = true;
        try
        {
            Policies.Clear(); foreach (var policy in policies.Value!.Policies) Policies.Add(policy);
            SelectedPolicy = Policies.FirstOrDefault(row => row.Id == policyId);
            Devices.Clear(); foreach (var device in devices.Value!.Devices) Devices.Add(new(device));
            SelectedDevice = Devices.FirstOrDefault(row => row.Id == deviceId) ?? Devices.FirstOrDefault();
            Events.Clear(); foreach (var item in events.Value!.Events) Events.Add(new(item));
        }
        finally { _refreshing = false; }
    }
    private async Task SaveAsync()
    {
        var draft = Editor.Draft();
        // This editor deliberately supports a single rule; do not silently erase a multi-rule policy created through the API.
        if (SelectedPolicy?.Rules.Count > 1) { Message = "Эта политика содержит несколько правил. Изменяйте её через API или создайте новую в редакторе."; return; }
        var result = await _client.SaveAsync(Editor.Id, draft, _lifetime.Token); if (!Accept(result)) return;
        Editor.Load(result.Value); await RefreshAsync(); if (!_disposed) { SelectedPolicy = Policies.FirstOrDefault(row => row.Id == result.Value!.Id); Message = "Версия сохранена. Назначенные агенты получат её автоматически."; }
    }
    private async Task AssignAsync(Guid? policy)
    {
        if (SelectedDevice is not { } device || !_confirm(policy is null
            ? "Снять назначение? Наблюдение остановится после получения изменения агентом и пользовательским компонентом."
            : "Назначить политику? При включённой политике начнётся фоновый анализ текстового буфера пользователей. Содержимое на сервер не отправляется, вставка не блокируется.")) return;
        if (Accept(await _client.AssignAsync(device.Id, policy, _lifetime.Token))) { await RefreshAsync(); if (!_disposed) Message = "Назначение сохранено. Смотрите подтверждение в столбце применения."; }
    }
    private bool Accept<T>(DeviceApiResult<T> result)
    {
        if (_disposed) return false;
        if (result.SessionExpired) { Events.Clear(); _expired(); return false; }
        if (result.Value is not null) return true; Message = result.Error ?? "Операция не выполнена."; return false;
    }
    private void RefreshCommands() { OnPropertyChanged(nameof(CanEdit)); foreach (var c in new[] { RefreshCommand, NewCommand, SaveCommand, AssignCommand, UnassignCommand }) c.Refresh(); }
    private void Unexpected(Exception e) { System.Diagnostics.Trace.TraceError(e.GetType().Name); if (!_disposed) Message = "Операция не завершена. Проверьте состояние сервера."; }
    public void Dispose() { if (_disposed) return; _disposed = true; _lifetime.Cancel(); if (!_busy) _lifetime.Dispose(); }
}
