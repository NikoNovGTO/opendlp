using OurDLP.Contracts;
namespace OurDLP.Desktop.ViewModels.Clipboard;
public sealed class ClipboardDeviceRow(ClipboardDeviceState state)
{
    public Guid Id => state.Id;
    public string Name => state.Name;
    public bool Capable => state.Capable;
    public Guid? PolicyId => state.AssignedPolicyId;
    public string Desired => state.DesiredVersion is { } version ? "v" + version : "—";
    public string Cached => state.CachedVersion is { } version ? "v" + version : "—";
    public string Applied
    {
        get
        {
            if (state.Status == "offline") return "Нет связи; показано последнее состояние";
            if (!state.Capable) return "Нужен агент 0.8";
            if (state.AssignedPolicyId is null) return "Политика не назначена";
            if (state.CachedPolicyId != state.AssignedPolicyId || state.CachedVersion != state.DesiredVersion) return "Ожидает получения агентом";
            var fresh = state.Helpers.Where(row => row.LastSeenAtUtc >= DateTimeOffset.UtcNow.AddSeconds(-45)).ToArray();
            var ready = fresh.Count(row => row.AppliedPolicyId == state.AssignedPolicyId && row.AppliedVersion == state.DesiredVersion);
            return ready == 0 ? "Кэш готов; нет подтверждения сеанса" : $"Применена: {ready} из {fresh.Length} сеансов";
        }
    }
    public string Sessions => string.Join("; ", state.Helpers.Select(row => $"{row.UserName} (сеанс {row.SessionId}, v{row.AppliedVersion?.ToString() ?? "—"}, пропуски {row.DroppedCaptures})"));
}
public sealed class ClipboardEventView(ClipboardEventRow data)
{
    public Guid DeviceId => data.DeviceId;
    public string Device => data.DeviceName;
    public string User => data.UserName;
    public string Process => data.SourceProcess;
    public string Time => TimeZoneInfo.ConvertTime(data.OccurredAtUtc, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss") + " МСК";
    public string Policy => data.PolicyName + " v" + data.PolicyVersion;
    public string Matches => string.Join("; ", data.Hits.Select(hit => (data.Rules.FirstOrDefault(rule => rule.Id == hit.RuleId)?.Name ?? "Правило") + ": " + hit.Count + (hit.CountLimited ? "+" : "")));
    public string Details => $"Символов проверено: {data.TextCharacters}; сеанс {data.SessionId}" + (data.Truncated ? "; превышен размер текста" : "") + (data.TimedOutRules.Count > 0 ? "; тайм-аут правила" : "");
}
