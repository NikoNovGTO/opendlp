using System.Collections.ObjectModel;
using System.IO;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.Services.RemoteScanning;
using OurDLP.Desktop.Services.Scanning;
using OurDLP.Desktop.ViewModels.Scanning;

namespace OurDLP.Desktop.ViewModels.RemoteScanning;

public sealed class RemoteScansViewModel : ObservableObject, IDisposable
{
    private readonly IDevicesClient _devices;
    private readonly IScanJobsClient _client;
    private readonly Func<string, bool> _confirm;
    private readonly Action _sessionExpired;
    private readonly Func<string?> _chooseExport;
    private readonly CancellationTokenSource _lifetime = new();
    private DeviceResponse? _device;
    private ScanJobRow? _job;
    private bool _busy, _disposed, _updatingDevices, _updatingJobs;
    private Guid? _openedReport;
    private string _message = string.Empty;
    public ObservableCollection<DeviceResponse> Devices { get; } = [];
    public ObservableCollection<ScanJobRow> Jobs { get; } = [];
    public ScanOptionsViewModel Options { get; } = new();
    public ScanResultsViewModel Results { get; } = new();
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public bool CanEdit => !_busy && !_disposed;
    public string AllowedRoot => SelectedDevice?.ScanRoot ?? "Агент ещё не объявил область. Установите или обновите его до 0.6 и дождитесь связи.";
    public string FormatSupportHint => Version.TryParse(SelectedDevice?.AgentVersion, out var version) && version >= new Version(0, 7)
        ? "Агент " + SelectedDevice!.AgentVersion + ": TXT, CSV, LOG, DOCX, XLSX."
        : "DOCX/XLSX требуют агента 0.7 или новее. Текущая версия: " + (SelectedDevice?.AgentVersion ?? "неизвестна");
    public DeviceResponse? SelectedDevice
    {
        get => _device;
        set
        {
            var changed = _device?.Id != value?.Id;
            if (!SetProperty(ref _device, value)) return;
            if (changed && !_updatingDevices) Options.Folder = value?.ScanRoot is { } root ? Path.Combine(root, "Demo") : string.Empty;
            OnPropertyChanged(nameof(AllowedRoot)); OnPropertyChanged(nameof(FormatSupportHint)); RefreshCommands();
        }
    }
    public ScanJobRow? SelectedJob
    {
        get => _job;
        set { if (SetProperty(ref _job, value)) { if (!_updatingJobs && value?.Id != _openedReport) { _openedReport = null; Results.Show(null); } RefreshCommands(); } }
    }
    public AsyncRelayCommand RefreshCommand { get; }
    public AsyncRelayCommand CreateCommand { get; }
    public AsyncRelayCommand CancelCommand { get; }
    public AsyncRelayCommand OpenReportCommand { get; }
    public AsyncRelayCommand ExportCommand { get; }
    public RemoteScansViewModel(IDevicesClient devices, IScanJobsClient client, Func<string, bool> confirm,
        Action sessionExpired, Func<string?> chooseExport)
    {
        _devices = devices; _client = client; _confirm = confirm; _sessionExpired = sessionExpired; _chooseExport = chooseExport;
        RefreshCommand = Command(RefreshAsync);
        CreateCommand = Command(CreateAsync, () => SelectedDevice?.ScanRoot is not null);
        CancelCommand = Command(CancelAsync, () => SelectedJob?.CanCancel == true);
        OpenReportCommand = Command(OpenReportAsync, () => SelectedJob?.HasReport == true);
        ExportCommand = Command(ExportAsync, () => Results.Report is not null);
    }
    private AsyncRelayCommand Command(Func<Task> action, Func<bool>? allowed = null) => new(() => RunAsync(action), Unexpected, () => CanEdit && (allowed?.Invoke() ?? true));
    private async Task RunAsync(Func<Task> operation)
    {
        if (!CanEdit) return; _busy = true; Message = string.Empty; RefreshCommands();
        try { await operation(); }
        catch (OperationCanceledException) when (_disposed) { }
        catch (ArgumentException error) { if (!_disposed) Message = error.Message; }
        finally { _busy = false; if (_disposed) _lifetime.Dispose(); else RefreshCommands(); }
    }
    private async Task RefreshAsync()
    {
        var devices = await _devices.ListAsync(_lifetime.Token); if (!Accept(devices)) return;
        var deviceId = SelectedDevice?.Id; var folder = Options.Folder; _updatingDevices = true;
        try
        {
            Devices.Clear(); foreach (var device in devices.Value!.Devices.Where(row => row.Status is "active" or "offline")) Devices.Add(device);
            SelectedDevice = Devices.FirstOrDefault(row => row.Id == deviceId) ?? Devices.FirstOrDefault();
        }
        finally { _updatingDevices = false; }
        Options.Folder = SelectedDevice?.Id == deviceId ? folder : SelectedDevice?.ScanRoot is { } root ? Path.Combine(root, "Demo") : string.Empty;
        var jobs = await _client.ListAsync(_lifetime.Token); if (!Accept(jobs)) return;
        var jobId = SelectedJob?.Id; _updatingJobs = true;
        try { Jobs.Clear(); foreach (var job in jobs.Value!.Jobs) Jobs.Add(new(job)); SelectedJob = Jobs.FirstOrDefault(row => row.Id == jobId) ?? Jobs.FirstOrDefault(); }
        finally { _updatingJobs = false; }
        if (_openedReport is not null && SelectedJob?.Id != _openedReport) { _openedReport = null; Results.Show(null); }
    }
    private async Task CreateAsync()
    {
        if (SelectedDevice is not { } device) return;
        var request = ScanRequestValidator.NormalizeDefinition(Options.BuildRequest());
        if (!RemoteScanPaths.IsInside(request.RootPath, device.ScanRoot!)) { Message = "Выберите путь внутри разрешённой области агента."; return; }
        var result = await _client.CreateAsync(new(device.Id, request), _lifetime.Token); if (!Accept(result)) return;
        await RefreshAsync(); if (!_disposed) { SelectedJob = Jobs.FirstOrDefault(row => row.Id == result.Value!.JobId); Message = "Задание сохранено на сервере. Агент получит его при следующем подключении."; }
    }
    private async Task CancelAsync()
    {
        if (SelectedJob is not { } job || !_confirm("Отменить задание? Агент получит отмену при наличии связи; уже выполняемая операция чтения может завершиться позже.")) return;
        if (Accept(await _client.CancelAsync(job.Id, _lifetime.Token))) await RefreshAsync();
    }
    private async Task OpenReportAsync()
    {
        if (SelectedJob is not { } job) return;
        var result = await _client.ReportAsync(job.Id, _lifetime.Token); if (Accept(result)) { Results.Show(result.Value!.Report); _openedReport = result.Value.JobId; }
    }
    private async Task ExportAsync()
    {
        if (Results.Report is not { } report || _chooseExport() is not { } path) return;
        await ScanCsvExporter.ExportAsync(report, path, _lifetime.Token); if (!_disposed) Message = "CSV сохранён: метаданные обнаружений без найденных строк.";
    }
    private bool Accept<T>(DeviceApiResult<T> result)
    {
        if (_disposed) return false;
        if (result.SessionExpired) { Results.Show(null); _sessionExpired(); return false; }
        if (result.Value is not null) return true; Message = result.Error ?? "Операция не выполнена."; return false;
    }
    private void RefreshCommands()
    { OnPropertyChanged(nameof(CanEdit)); foreach (var command in new[] { RefreshCommand, CreateCommand, CancelCommand, OpenReportCommand, ExportCommand }) command.Refresh(); }
    private void Unexpected(Exception error)
    { System.Diagnostics.Trace.TraceError(error.GetType().Name); if (!_disposed) Message = "Не удалось выполнить операцию. Проверьте сервер и доступ к файлу отчёта."; }
    public void Dispose() { if (_disposed) return; _disposed = true; _lifetime.Cancel(); if (!_busy) _lifetime.Dispose(); }
}
