using OurDLP.Contracts;

namespace OurDLP.Desktop.ViewModels.RemoteScanning;

public sealed class ScanJobRow(ScanJobResponse job)
{
    public Guid Id => job.Id;
    public string DeviceName => job.DeviceName;
    public string RootPath => job.RootPath;
    public bool CanCancel => job.Status is "queued" or "running";
    public bool HasReport => job.FilesScanned is not null;
    public string Status => job.Status switch
    { "queued" => "Ожидает агента", "running" => "Выполняется", "completed" => "Завершено", "partial" => "Неполный результат", "cancelled" => "Отменено", "failed" => "Ошибка проверки", _ => "Неизвестно" };
    public string Created => TimeZoneInfo.ConvertTime(job.CreatedAtUtc, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss") + " МСК";
    public string Counts => job.FilesScanned is null ? "—" : $"Файлов: {job.FilesScanned}, обнаружений: {job.Findings}";
}
