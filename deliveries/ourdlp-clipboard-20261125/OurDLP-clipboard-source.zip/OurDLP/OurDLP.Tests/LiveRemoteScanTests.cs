using System.Text;
using System.Text.Json;
using OurDLP.Agent;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.Services.RemoteScanning;
using OurDLP.Desktop.Services.Scanning;
using OurDLP.Tests.Scanning;
using Xunit;

namespace OurDLP.Tests;

[Collection("Live server")]
public sealed class LiveRemoteScanTests
{
    [LiveAuthenticationFact][Trait("Category","Integration")]
    public async Task RealTlsAgentJobAndLargeMetadataReportRoundTrip()
    {
        var address=Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var expected=Environment.GetEnvironmentVariable("OURDLP_EXPECT_LOGIN_SUCCESS")=="1";
        var loginData=ScanWire.Read<LoginRequest>(await File.ReadAllTextAsync(Environment.GetEnvironmentVariable("OURDLP_LIVE_LOGIN_FILE")!));
        using var adminHttp=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false,UseCookies=true,CookieContainer=new()}){Timeout=TimeSpan.FromSeconds(10),MaxResponseContentBufferSize=4*1024*1024};
        var auth=new AuthenticationClient(adminHttp);var login=await auth.LoginAsync(address,loginData.UserName,loginData.Password,default);
        Assert.Equal(expected,login.Succeeded);if(!expected)return;
        using var files=new ScanFiles();var sample=new ScanSampleFactory(files.Root).Create();
        for(var i=0;i<90;i++)File.WriteAllText(Path.Combine(sample,"Длинное_тестовое_имя_документа_"+i+".txt"),"OURDLP-TEST-1234");
        var devices=new DevicesClient(adminHttp,address);var enrollment=(await devices.CreateAsync("LIVE-SCAN-"+Guid.NewGuid().ToString("N")[..8],default)).Value!;
        try
        {
            using var agentHttp=new HttpClient(new HttpClientHandler{UseCookies=false,AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(10),MaxResponseContentBufferSize=64*1024};
            var states=new MemoryAgentState();Assert.True((await new AgentEnrollment(states,new(agentHttp)).EnrollAsync(address,enrollment.Code,false,default)).Succeeded);
            var state=states.State!;var agent=new AgentScanClient(agentHttp);Assert.True((await agent.NextAsync(state,files.Root,default)).Succeeded);
            var jobs=new ScanJobsClient(adminHttp,address);var created=(await jobs.CreateAsync(new(enrollment.DeviceId,files.Request() with{RootPath=sample}),default)).Value!;
            var queue=new RemoteScanning.TestScanQueue(Path.Combine(files.Root,"pending.json"));
            await new AgentScanCycle(queue,agent,new(new(new OurDLP.Core.Scanning.FileScanner(),files.Root),agent),files.Root).RunOnceAsync(state,default);
            Assert.Null(await queue.ReadAsync(default));var report=(await jobs.ReportAsync(created.JobId,default)).Value!.Report;
            Assert.Equal(94,report.Findings.Count);Assert.Equal(97,report.Findings.Sum(row=>row.Matches));
            Assert.True(Encoding.UTF8.GetByteCount(ScanWire.Serialize(report))>16*1024);
            Assert.Equal("completed",(await jobs.ListAsync(default)).Value!.Jobs.Single(row=>row.Id==created.JobId).Status);
        }
        finally{await devices.RevokeAsync(enrollment.DeviceId,default);await auth.LogoutAsync(address,default);}
    }
}
