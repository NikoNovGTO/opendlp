using OurDLP.Core.Scanning;
using OurDLP.Desktop.Services.Scanning;
using OurDLP.Desktop.ViewModels.Scanning;
using Xunit;

namespace OurDLP.Tests.Scanning;

public sealed class ScanWorkspaceTests
{
    [Fact]
    public async Task DemoResetsRuleAndRunsActualEngineAndHistoryOnOneComputer()
    {
        using var files=new ScanFiles();var store=new JsonScanReportStore(Path.Combine(files.Root,"reports"));
        using var model=new ScanWorkspaceViewModel(new FileScanner(),store,()=>null,()=>null,new ScanSampleFactory(files.Root).Create);
        model.Options.Pattern="invalid(";
        await model.CreateSampleCommand.ExecuteAsync();await model.StartCommand.ExecuteAsync();
        Assert.NotNull(model.Results.Report);Assert.Equal(7,model.Results.Report.Findings.Sum(row=>row.Matches));
        Assert.Single(model.History.Items);Assert.Equal(string.Empty,model.ProgressText);
        await model.OpenHistoryCommand.ExecuteAsync();Assert.Equal(4,model.Results.Findings.Count);
    }
    [Fact]
    public async Task CancelDisablesOtherActionsAndSavesPartialReport()
    {
        using var files=new ScanFiles();var scanner=new WaitingScanner();var store=new MemoryReports();
        using var model=new ScanWorkspaceViewModel(scanner,store,()=>null,()=>null,()=>files.Root);model.Options.Folder=files.Root;
        var running=model.StartCommand.ExecuteAsync();await scanner.Started.Task;
        Assert.False(model.StartCommand.CanExecute(null));Assert.False(model.OpenHistoryCommand.CanExecute(null));
        Assert.False(model.CanEdit);await model.CancelCommand.ExecuteAsync();await running;
        Assert.Equal(ScanCompletion.Cancelled,model.Results.Report!.Completion);Assert.NotNull(store.Saved);Assert.True(model.CanEdit);
    }
    [Fact]
    public async Task StorageFailureDoesNotDiscardResults()
    {
        using var files=new ScanFiles();files.Write("a.txt","OURDLP-TEST-0001");
        using var model=new ScanWorkspaceViewModel(new FileScanner(),new MemoryReports{FailSave=true},()=>null,()=>null,()=>files.Root);
        model.Options.Folder=files.Root;await model.StartCommand.ExecuteAsync();
        Assert.Single(model.Results.Findings);Assert.Contains("сохранить не удалось",model.Message);Assert.True(model.CanEdit);
    }
    [Fact]
    public async Task InvalidInputDoesNotWriteAReportOrLeaveBusyState()
    {
        using var files=new ScanFiles();var store=new MemoryReports();
        using var model=new ScanWorkspaceViewModel(new FileScanner(),store,()=>null,()=>null,()=>files.Root);
        model.Options.Folder=files.Root;model.Options.Pattern="(";await model.StartCommand.ExecuteAsync();
        Assert.Null(store.Saved);Assert.Contains("выражение",model.Message);Assert.True(model.CanEdit);Assert.False(model.CancelCommand.CanExecute(null));
    }
    [Fact]
    public async Task ClosingWorkspaceCancelsWorkAndIgnoresLateResults()
    {
        using var files=new ScanFiles();var scanner=new WaitingScanner();var store=new MemoryReports();
        var model=new ScanWorkspaceViewModel(scanner,store,()=>null,()=>null,()=>files.Root);model.Options.Folder=files.Root;
        var run=model.StartCommand.ExecuteAsync();await scanner.Started.Task;model.Dispose();await run;
        Assert.Null(model.Results.Report);Assert.Null(store.Saved);Assert.False(model.StartCommand.CanExecute(null));
    }
    private sealed class WaitingScanner:IFileScanner
    {
        public TaskCompletionSource Started {get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
        public async Task<ScanReport> ScanAsync(ScanRequest request,IProgress<ScanProgress>? progress,CancellationToken token)
        {
            Started.TrySetResult();try{await Task.Delay(Timeout.Infinite,token);}catch(OperationCanceledException){}
            return new(){RootPath=request.RootPath,Completion=ScanCompletion.Cancelled};
        }
    }
    private sealed class MemoryReports:IScanReportStore
    {
        public ScanReport? Saved {get;private set;}public bool FailSave{get;init;}
        public Task SaveAsync(ScanReport report,CancellationToken token){if(FailSave)throw new IOException();Saved=report;return Task.CompletedTask;}
        public Task<ScanReport> LoadAsync(Guid id,CancellationToken token)=>Task.FromResult(Saved!);
        public Task<ScanHistoryList> ListAsync(CancellationToken token)=>Task.FromResult(new ScanHistoryList([],0));
    }
}
