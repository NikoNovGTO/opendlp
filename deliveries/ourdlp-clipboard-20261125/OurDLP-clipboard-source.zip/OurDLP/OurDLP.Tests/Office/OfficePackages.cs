using System.IO.Compression;
using System.Text;

namespace OurDLP.Tests.Office;

internal static class OfficePackages
{
    public const string W="http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    public const string S="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    public const string R="http://schemas.openxmlformats.org/officeDocument/2006/relationships/";
    public const string P="http://schemas.openxmlformats.org/package/2006/relationships";
    public static Dictionary<string,string> Word(string body) => new()
    {
        ["[Content_Types].xml"]="<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'><Default Extension='xml' ContentType='application/xml'/><Override PartName='/word/document.xml' ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml'/></Types>",
        ["_rels/.rels"]=$"<Relationships xmlns='{P}'><Relationship Id='main' Type='{R}officeDocument' Target='word/document.xml'/></Relationships>",
        ["word/document.xml"]=$"<w:document xmlns:w='{W}' xmlns:r='{R.TrimEnd('/')}'><w:body>{body}</w:body></w:document>"
    };
    public static Dictionary<string,string> Excel(string cells,string? shared=null)
    {
        var result=new Dictionary<string,string>
        {
            ["[Content_Types].xml"]="<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'><Default Extension='xml' ContentType='application/xml'/><Override PartName='/xl/workbook.xml' ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml'/></Types>",
            ["_rels/.rels"]=$"<Relationships xmlns='{P}'><Relationship Id='main' Type='{R}officeDocument' Target='xl/workbook.xml'/></Relationships>",
            ["xl/workbook.xml"]=$"<workbook xmlns='{S}' xmlns:r='{R.TrimEnd('/')}'><sheets><sheet name='Test' sheetId='1' r:id='sheet'/></sheets></workbook>",
            ["xl/_rels/workbook.xml.rels"]=$"<Relationships xmlns='{P}'><Relationship Id='sheet' Type='{R}worksheet' Target='worksheets/sheet1.xml'/>{(shared is null?"":$"<Relationship Id='strings' Type='{R}sharedStrings' Target='sharedStrings.xml'/>")}</Relationships>",
            ["xl/worksheets/sheet1.xml"]=$"<worksheet xmlns='{S}'><sheetData><row r='1'>{cells}</row></sheetData></worksheet>"
        };
        if(shared is not null)result["xl/sharedStrings.xml"]=$"<sst xmlns='{S}'>{shared}</sst>";
        return result;
    }
    public static string Write(string folder,string name,IDictionary<string,string> parts,CompressionLevel compression=CompressionLevel.Optimal)
    {
        var path=Path.Combine(folder,name);
        using var file=File.Create(path);using var zip=new ZipArchive(file,ZipArchiveMode.Create);
        foreach(var part in parts){using var text=new StreamWriter(zip.CreateEntry(part.Key,compression).Open(),new UTF8Encoding(false));text.Write(part.Value);}
        return path;
    }
}
