using System.IO.Compression;
using System.Text.Json;
using OurDLP.Core.Samples;
using OurDLP.Core.Scanning;
using OurDLP.Tests.Scanning;
using Xunit;

namespace OurDLP.Tests.Office;

public sealed class OfficeBoundaryTests
{
    [Fact]
    public async Task BadZipAndXmlDoNotAbortOtherFilesOrExposeParserText()
    {
        using var files=new ScanFiles();files.Write("not-a-zip.xlsx","OURDLP-TEST-7000");var parts=OfficePackages.Word("<w:p><w:r><w:t>OURDLP-TEST-7001");
        OfficePackages.Write(files.Root,"bad-xml.docx",parts);files.Write("good.txt","OURDLP-TEST-7002");
        var gap=OfficePackages.Write(files.Root,"directory-gap.docx",OfficePackages.Word("<w:p/>"));
        using(var zip=new FileStream(gap,FileMode.Open,FileAccess.Write))
        {zip.Position=zip.Length-22+12;using var writer=new BinaryWriter(zip);writer.Write((uint)1);}
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);Assert.Single(report.Findings);Assert.Equal(3,report.FilesSkipped);Assert.Equal(3,report.Issues.Count);
        Assert.All(report.Issues,issue=>Assert.Equal("office-invalid",issue.Code));Assert.DoesNotContain("OURDLP-TEST-7001",JsonSerializer.Serialize(report));
    }
    [Fact]
    public async Task ExternalEntitiesAreForbiddenAndOutsideFileIsNotIncluded()
    {
        using var files=new ScanFiles();using var outside=new ScanFiles();var path=outside.Write("secret.txt","OURDLP-TEST-7777");
        var parts=OfficePackages.Word("<w:p><w:r><w:t>&external;</w:t></w:r></w:p>");
        parts["word/document.xml"]=$"<!DOCTYPE w:document [<!ENTITY external SYSTEM '{new Uri(path).AbsoluteUri}'>]>"+parts["word/document.xml"];
        OfficePackages.Write(files.Root,"entities.docx",parts);var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Empty(report.Findings);Assert.Equal("office-invalid",Assert.Single(report.Issues).Code);
    }
    [Fact]
    public async Task ReferencedExternalPartsAreNotFetched()
    {
        using var files=new ScanFiles();var parts=OfficePackages.Word("<w:sectPr><w:headerReference r:id='outside'/></w:sectPr>");
        parts["word/_rels/document.xml.rels"]=$"<Relationships xmlns='{OfficePackages.P}'><Relationship Id='outside' Type='{OfficePackages.R}header' Target='https://example.invalid/private.xml' TargetMode='External'/></Relationships>";
        OfficePackages.Write(files.Root,"external.docx",parts);var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Empty(report.Findings);Assert.Equal("office-external",Assert.Single(report.Issues).Code);
    }
    [Theory][InlineData("traversal")][InlineData("duplicate")]
    public async Task RejectsTraversalAndEquivalentDuplicateArchiveParts(string kind)
    {
        using var files=new ScanFiles();var parts=OfficePackages.Word("<w:p/>");
        parts[kind=="traversal"?"../escape.xml":"WORD/DOCUMENT.XML"]="<test/>";
        OfficePackages.Write(files.Root,"names.docx",parts);var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Equal("office-invalid",Assert.Single(report.Issues).Code);
    }
    [Fact]
    public async Task PasswordContainerAndRenamedMacroPackageAreExplicitSkips()
    {
        using var files=new ScanFiles();File.WriteAllBytes(Path.Combine(files.Root,"protected.docx"),[0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1,0,0]);
        var parts=OfficePackages.Word("<w:p/>");parts["[Content_Types].xml"]=parts["[Content_Types].xml"].Replace("application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml","application/vnd.ms-word.document.macroEnabled.main+xml");
        OfficePackages.Write(files.Root,"macro-renamed.docx",parts);var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Contains(report.Issues,row=>row.Code=="office-protected");Assert.Contains(report.Issues,row=>row.Code=="office-invalid");Assert.Equal(2,report.FilesSkipped);
    }
    [Theory][InlineData("ratio")][InlineData("parts")][InlineData("text")][InlineData("xml")][InlineData("expanded")][InlineData("nodes")][InlineData("depth")][InlineData("lying-count")]
    public async Task BoundsArchiveAndTextResources(string kind)
    {
        using var files=new ScanFiles();var parts=OfficePackages.Word("<w:p/>");var compression=CompressionLevel.NoCompression;
        switch(kind)
        {
            case "ratio":parts=OfficePackages.Word("<w:p><w:r><w:t>"+new string('x',500_000)+"</w:t></w:r></w:p>");compression=CompressionLevel.Optimal;break;
            case "lying-count":for(var i=0;i<3000;i++)parts["extra/"+i+".xml"]="<x/>";break;
            case "parts":for(var i=0;i<2048;i++)parts["extra/"+i+".xml"]="<x/>";break;
            case "text":parts=OfficePackages.Word("<w:p><w:r><w:t>"+new string('x',2_000_001)+"</w:t></w:r></w:p>");break;
            case "xml":parts=OfficePackages.Word(new string('x',8*1024*1024));break;
            case "expanded":parts["media/unread.bin"]=new string('x',33*1024*1024);compression=CompressionLevel.Optimal;break;
            case "depth":parts=OfficePackages.Word(string.Concat(Enumerable.Repeat("<w:p>",256))+string.Concat(Enumerable.Repeat("</w:p>",256)));break;
            case "nodes":parts=OfficePackages.Word(string.Concat(Enumerable.Repeat("<w:p/>",500_001)));break;
        }
        var archivePath=OfficePackages.Write(files.Root,"limit.docx",parts,compression);
        if(kind=="lying-count")
        {
            using var file=new FileStream(archivePath,FileMode.Open,FileAccess.Write);file.Position=file.Length-22+8;
            using var writer=new BinaryWriter(file);writer.Write((ushort)1);writer.Write((ushort)1);
        }
        var report=await new FileScanner().ScanAsync(files.Request(limits:new(){MaxFileBytes=20*1024*1024}),null,default).WaitAsync(TimeSpan.FromSeconds(15));
        Assert.Empty(report.Findings);Assert.Equal("office-limit",Assert.Single(report.Issues).Code);Assert.Equal(1,report.FilesSkipped);
    }
    [Fact]
    public void DemoCreationPreservesExistingFilesAndRejectsLinkedDirectories()
    {
        using var files=new ScanFiles();OfficeSampleDocuments.Create(files.Root);var path=Path.Combine(files.Root,"sample-document.docx");
        var original=File.ReadAllBytes(path);OfficeSampleDocuments.Create(files.Root);Assert.Equal(original,File.ReadAllBytes(path));
        using var outside=new ScanFiles();var link=Path.Combine(files.Root,"link");Directory.CreateSymbolicLink(link,outside.Root);
        Assert.Throws<UnauthorizedAccessException>(()=>OfficeSampleDocuments.Create(link));Assert.Empty(Directory.GetFiles(outside.Root));
    }
}
