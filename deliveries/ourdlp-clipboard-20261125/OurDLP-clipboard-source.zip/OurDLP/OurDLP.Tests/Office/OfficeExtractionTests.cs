using System.Text.Json;
using OurDLP.Core.Scanning;
using OurDLP.Tests.Scanning;
using Xunit;

namespace OurDLP.Tests.Office;

public sealed class OfficeExtractionTests
{
    [Theory][InlineData("reference-word.docx",4)][InlineData("reference-excel.xlsx",3)]
    public async Task ReadsDocumentsProducedByIndependentLibrariesWithoutStoringMatchedText(string name,int count)
    {
        using var files=new ScanFiles();File.Copy(Path.Combine(AppContext.BaseDirectory,"Fixtures",name),Path.Combine(files.Root,name));
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Empty(report.Issues);Assert.Equal(count,Assert.Single(report.Findings).Matches);
        var json=JsonSerializer.Serialize(report);
        foreach(var marker in new[]{"OURDLP-TEST-1010","OURDLP-TEST-1011","OURDLP-TEST-2010","OURDLP-TEST-2011"})Assert.DoesNotContain(marker,json);
    }
    [Fact]
    public async Task WordReadsReferencedPartsAndJoinsRunsButKeepsParagraphsApart()
    {
        using var files=new ScanFiles();
        var parts=OfficePackages.Word("<w:p><w:r><w:t>OURDLP-</w:t></w:r><w:r><w:t>TEST-3000</w:t></w:r></w:p><w:p><w:r><w:t>OURDLP-</w:t></w:r></w:p><w:p><w:r><w:t>TEST-3999</w:t></w:r></w:p><w:p><w:r><w:footnoteReference w:id='1'/><w:endnoteReference w:id='2'/><w:commentReference w:id='0'/></w:r></w:p><w:p><w:r><w:t>OURDLP-</w:t></w:r><w:r><w:t> </w:t></w:r><w:r><w:t>TEST-3996</w:t></w:r></w:p><w:sectPr><w:headerReference r:id='h'/><w:headerReference r:id='h2'/><w:footerReference r:id='f'/></w:sectPr>");
        parts["word/_rels/document.xml.rels"]=$"<Relationships xmlns='{OfficePackages.P}'><Relationship Id='h' Type='{OfficePackages.R}header' Target='header.xml'/><Relationship Id='h2' Type='{OfficePackages.R}header' Target='header.xml'/><Relationship Id='f' Type='{OfficePackages.R}footer' Target='footer.xml'/><Relationship Id='n' Type='{OfficePackages.R}footnotes' Target='footnotes.xml'/><Relationship Id='e' Type='{OfficePackages.R}endnotes' Target='endnotes.xml'/><Relationship Id='c' Type='{OfficePackages.R}comments' Target='comments.xml'/></Relationships>";
        parts["word/header.xml"]=$"<w:hdr xmlns:w='{OfficePackages.W}'><w:p><w:r><w:t>OURDLP-TEST-3001</w:t></w:r></w:p></w:hdr>";
        parts["word/footer.xml"]=$"<w:ftr xmlns:w='{OfficePackages.W}'><w:p><w:r><w:t>OURDLP-TEST-3002</w:t></w:r></w:p></w:ftr>";
        parts["word/footnotes.xml"]=$"<w:footnotes xmlns:w='{OfficePackages.W}'><w:footnote w:id='1'><w:p><w:r><w:t>OURDLP-TEST-3003</w:t></w:r></w:p></w:footnote><w:footnote w:id='9'><w:p><w:r><w:t>OURDLP-TEST-3998</w:t></w:r></w:p></w:footnote></w:footnotes>";
        parts["word/endnotes.xml"]=$"<w:endnotes xmlns:w='{OfficePackages.W}'><w:endnote w:id='2'><w:p><w:r><w:t>OURDLP-TEST-3004</w:t></w:r></w:p></w:endnote></w:endnotes>";
        parts["word/comments.xml"]=$"<w:comments xmlns:w='{OfficePackages.W}'><w:comment w:id='0'><w:p><w:r><w:t>OURDLP-TEST-3005</w:t></w:r></w:p></w:comment></w:comments>";
        parts["word/orphan.xml"]=$"<w:hdr xmlns:w='{OfficePackages.W}'><w:p><w:r><w:t>OURDLP-TEST-3997</w:t></w:r></w:p></w:hdr>";
        OfficePackages.Write(files.Root,"parts.docx",parts);
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);Assert.Empty(report.Issues);Assert.Equal(6,Assert.Single(report.Findings).Matches);
    }
    [Theory][InlineData(false)][InlineData(true)]
    public async Task WordSupportsTransitionalAndStrictNamespacesAndRetainedDeletedText(bool strict)
    {
        using var files=new ScanFiles();var parts=OfficePackages.Word("<w:p><w:del><w:r><w:delText>OURDLP-TEST-3100</w:delText></w:r></w:del></w:p>");
        if(strict)foreach(var key in parts.Keys.ToArray())parts[key]=parts[key].Replace(OfficePackages.W,"http://purl.oclc.org/ooxml/wordprocessingml/main").Replace(OfficePackages.R.TrimEnd('/'),"http://purl.oclc.org/ooxml/officeDocument/relationships");
        OfficePackages.Write(files.Root,"strict.DOCX",parts);var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Empty(report.Issues);Assert.Equal(1,Assert.Single(report.Findings).Matches);
    }
    [Fact]
    public async Task ExcelCountsUsedRichStringsAndCachedValuesWithoutJoiningCellsOrEvaluatingFormulas()
    {
        using var files=new ScanFiles();
        var shared="<si><r><t>OURDLP-</t></r><r><t>TEST-3200</t></r><rPh sb='0' eb='1'><t>OURDLP-TEST-3998</t></rPh></si><si><t>OURDLP-TEST-3999</t></si>";
        var cells="<c r='A1' t='s'><v> 0 </v></c><c r='B1' t='s'><v>0</v></c><c r='C1' t='inlineStr'><is><r><t>OURDLP-</t></r><r><t>TEST-3201</t></r></is></c><c r='D1' t='str'><f>FAKE_FORMULA()</f><v>OURDLP-TEST-3202</v></c><c r='E1' t='str'><f>&quot;OURDLP-TEST-3997&quot;</f></c><c r='F1' t='inlineStr'><is><t>OURDLP-</t></is></c><c r='G1' t='inlineStr'><is><t>TEST-3996</t></is></c><c r='H1' t='inlineStr'><is><r><t>OURDLP-</t></r><r><t> </t></r><r><t>TEST-3995</t></r></is></c>";
        OfficePackages.Write(files.Root,"rich.xlsx",OfficePackages.Excel(cells,shared));
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);Assert.Empty(report.Issues);Assert.Equal(4,Assert.Single(report.Findings).Matches);
    }
    [Fact]
    public async Task BadSharedStringIndexIsReportedInsteadOfSilentlyReturningAnEmptyCell()
    {
        using var files=new ScanFiles();OfficePackages.Write(files.Root,"bad.xlsx",OfficePackages.Excel("<c t='s'><v>99</v></c>","<si><t>value</t></si>"));
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);Assert.Empty(report.Findings);Assert.Equal("office-invalid",Assert.Single(report.Issues).Code);
    }
}
