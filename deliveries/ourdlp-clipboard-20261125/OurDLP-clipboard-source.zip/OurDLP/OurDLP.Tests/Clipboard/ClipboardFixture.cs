using OurDLP.Agent;
using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Services.Clipboard;
using Xunit;
namespace OurDLP.Tests.Clipboard;
public sealed class ClipboardFixture:IAsyncDisposable
{
    public AgentTestContext Context {get;private set;}=null!;
    public HttpClient Http {get;private set;}=null!;
    public MemoryAgentState Registration {get;}=new();
    public AgentState State=>Registration.State!;
    public TestAgentStore Store {get;}=new();
    public ClipboardAgentCoordinator Service {get;private set;}=null!;
    public ClipboardAgentClient Agent=>new(Http);
    public ClipboardClient Admin=>new(Context.Admin,"https://localhost");
    public static async Task<ClipboardFixture> CreateAsync()
    {
        var f=new ClipboardFixture{Context=await AgentTestContext.CreateAsync()};f.Http=f.Context.Agent();var code=await f.Context.AddAsync();
        Assert.True((await new AgentEnrollment(f.Registration,new(f.Http)).EnrollAsync("https://localhost",code.Code,false,default)).Succeeded);
        f.Service=new(f.Registration,f.Store);await f.ExchangeAsync();return f;
    }
    public async Task<ClipboardAgentResponse> ExchangeAsync()
    {var packet=await Service.SnapshotAsync(default);var reply=await Agent.SyncAsync(State,packet,default);Assert.NotNull(reply.Value);await Service.ApplyAsync(reply.Value,packet.Events.Select(row=>row.Detection.Id).ToArray(),default);return reply.Value;}
    public async Task<ClipboardPolicy> AssignAsync()
    {
        var policy=ClipboardSamples.Policy();var created=(await Admin.SaveAsync(null,new(policy.Name,true,policy.MaxTextCharacters,policy.Rules),default)).Value!;Assert.NotNull(created);
        Assert.NotNull((await Admin.AssignAsync(State.DeviceId!.Value,created.Id,default)).Value);await ExchangeAsync();return created;
    }
    public async ValueTask DisposeAsync(){Http.Dispose();await Context.DisposeAsync();}
}
