using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Agent;
using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Server.Data;
using OurDLP.Session;
using Xunit;
namespace OurDLP.Tests.Clipboard;
public sealed class ClipboardIntegrationTests
{
    [PostgresFact][Trait("Category","Postgres")]
    public async Task OfflineMetadataSurvivesBothRestartsAndLostServerAckWithoutContentOrDuplicates()
    {
        await using var f=await ClipboardFixture.CreateAsync();var policy=await f.AssignAsync();var user=new TestSessionStore();var pipe=new TestSessionClient();pipe.Connect(f.Service);
        var session=new SessionCoordinator(user,pipe);await session.InitializeAsync(default);await session.SyncOnceAsync(default);session.SetListenerReady(true);await session.SyncOnceAsync(default);await f.ExchangeAsync();
        var device=Assert.Single((await f.Admin.DevicesAsync(default)).Value!.Devices);Assert.Equal(1,device.CachedVersion);Assert.Equal(1,Assert.Single(device.Helpers).AppliedVersion);
        pipe.Exchange=_=>Task.FromResult<ClipboardSessionResponse?>(null);
        var secret="private-prefix-"+Guid.NewGuid().ToString("N")+" OURDLP-TEST-7719";var chars=secret.ToCharArray();
        using(var captured=new CapturedClipboard(new(chars,chars.Length),session.CurrentPolicy!,false,"notepad",3,DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(3))))await session.EnqueueAsync(captured,default);
        await session.SyncOnceAsync(default);Assert.Single(user.State.Pending);Assert.DoesNotContain(secret,ScanWire.Serialize(user.State));
        session=new(user,pipe);await session.InitializeAsync(default);pipe.Connect(f.Service);await session.SyncOnceAsync(default);Assert.Empty(user.State.Pending);
        var restarted=new ClipboardAgentCoordinator(f.Registration,f.Store);var packet=await restarted.SnapshotAsync(default);Assert.Single(packet.Events);
        var first=await f.Agent.SyncAsync(f.State,packet,default);Assert.Single(first.Value!.Accepted); // Drop response before saving the acknowledgement.
        var retry=await f.Agent.SyncAsync(f.State,packet,default);Assert.Single(retry.Value!.Accepted);
        await restarted.ApplyAsync(retry.Value,packet.Events.Select(row=>row.Detection.Id).ToArray(),default);Assert.Empty(f.Store.State!.Pending);
        var events=(await f.Admin.EventsAsync(default)).Value!.Events;var row=Assert.Single(events);Assert.Equal(1,row.PolicyVersion);Assert.Equal(ClipboardSamples.Peer.UserSid,row.UserSid);Assert.Equal(3,row.SessionId);Assert.Single(row.Hits);
        Assert.DoesNotContain(secret,ScanWire.Serialize(events));Assert.DoesNotContain("7719",ScanWire.Serialize(events));
        await using var scope=f.Context.Server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();var stored=Assert.Single(await db.ClipboardEvents.ToListAsync());Assert.DoesNotContain("7719",stored.MetadataJson);Assert.Equal(TimeSpan.Zero,stored.OccurredAtUtc.Offset);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task RevisionsAreImmutableConflictsDetectedAndDeliveredHistoricalEventsAccepted()
    {
        await using var f=await ClipboardFixture.CreateAsync();var v1=await f.AssignAsync();var event1=ClipboardSamples.Detection(v1);
        var v2=(await f.Admin.SaveAsync(v1.Id,new(v1.Name,false,v1.MaxTextCharacters,v1.Rules,1),default)).Value!;Assert.Equal(2,v2.Version);
        Assert.Contains("изменена",(await f.Admin.SaveAsync(v1.Id,new("Stale",true,16384,v1.Rules,1),default)).Error!);
        var packet=new ClipboardAgentSync(1,v1.Id,1,[],[new(event1,ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3)]);
        var response=(await f.Agent.SyncAsync(f.State,packet,default)).Value!;Assert.Single(response.Accepted);Assert.Equal(2,response.Policy!.Version);Assert.False(response.Policy.Enabled);
        var forbidden=ClipboardSamples.Detection(v2);var rejected=(await f.Agent.SyncAsync(f.State,packet with{Events=[new(forbidden,ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3)]},default)).Value!;Assert.Equal("policy-not-delivered",Assert.Single(rejected.Rejected).Reason);
        var changed=event1 with{TextCharacters=20};var conflict=(await f.Agent.SyncAsync(f.State,packet with{Events=[new(changed,ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3)]},default)).Value!;Assert.Equal("event-conflict",Assert.Single(conflict.Rejected).Reason);
        await using var scope=f.Context.Server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();Assert.Equal(2,await db.ClipboardPolicyRevisions.CountAsync());var old=ScanWire.Read<ClipboardPolicy>((await db.ClipboardPolicyRevisions.SingleAsync(row=>row.Version==1)).DefinitionJson);Assert.True(old.Enabled);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task DedicatedAgentAuthenticationAndPerDeviceDeliveryAreEnforced()
    {
        await using var f=await ClipboardFixture.CreateAsync();var p=await f.AssignAsync();using var anonymous=f.Context.Agent();
        Assert.Equal(HttpStatusCode.Unauthorized,(await anonymous.GetAsync("/api/clipboard/events")).StatusCode);
        f.Http.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",f.State.Token);
        Assert.Equal(HttpStatusCode.Unauthorized,(await f.Http.GetAsync("/api/clipboard/policies")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await f.Context.Admin.PostAsJsonAsync("/api/agent/clipboard/sync",new ClipboardAgentSync(1,null,null,[],[]))).StatusCode);
        var other=await f.Context.AddAsync("OTHER");var store=new MemoryAgentState();using var second=f.Context.Agent();Assert.True((await new AgentEnrollment(store,new(second)).EnrollAsync("https://localhost",other.Code,false,default)).Succeeded);
        var detection=ClipboardSamples.Detection(p);var response=await new ClipboardAgentClient(second).SyncAsync(store.State!,new(1,p.Id,1,[],[new(detection,ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3)]),default);
        Assert.Equal("policy-not-delivered",Assert.Single(response.Value!.Rejected).Reason);Assert.Null(response.Value.Policy);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task ReenrollmentClearsAssignmentAndOldDeliveryCannotBeReusedByNewCredential()
    {
        await using var f=await ClipboardFixture.CreateAsync();var p=await f.AssignAsync();var next=(await (await f.Context.Admin.PostAsync($"/api/devices/{f.State.DeviceId}/enrollment",null)).Content.ReadFromJsonAsync<EnrollmentResponse>())!;
        Assert.True((await f.Agent.SyncAsync(f.State,new(1,null,null,[],[]),default)).AccessDenied);
        var reg=new MemoryAgentState();Assert.True((await new AgentEnrollment(reg,new(f.Http)).EnrollAsync("https://localhost",next.Code,false,default)).Succeeded);
        var item=new ClipboardEvent(ClipboardSamples.Detection(p),ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3);
        var response=(await f.Agent.SyncAsync(reg.State!,new(1,p.Id,1,[],[item]),default)).Value!;Assert.Null(response.Policy);Assert.Equal("policy-not-delivered",Assert.Single(response.Rejected).Reason);
        var device=Assert.Single((await f.Admin.DevicesAsync(default)).Value!.Devices);Assert.Null(device.AssignedPolicyId);Assert.Null(device.CachedVersion);Assert.Empty(device.Helpers);
        Assert.True((await f.Context.Admin.PostAsync($"/api/devices/{f.State.DeviceId}/revoke",null)).IsSuccessStatusCode);Assert.True((await f.Agent.SyncAsync(reg.State!,new(1,null,null,[],[]),default)).AccessDenied);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task InvalidBatchesPoliciesAndUndeliveredAcknowledgementsAreRejected()
    {
        await using var f=await ClipboardFixture.CreateAsync();var p=await f.AssignAsync();
        Assert.Equal(400,(await f.Agent.SyncAsync(f.State,new(99,null,null,[],[]),default)).StatusCode);
        Assert.Equal(400,(await f.Agent.SyncAsync(f.State,new(1,null,null,[],Enumerable.Range(0,33).Select(_=>new ClipboardEvent(ClipboardSamples.Detection(p),ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3)).ToArray()),default)).StatusCode);
        Assert.Null((await f.Admin.SaveAsync(null,new("Bad",true,16384,[p.Rules[0] with{Pattern="("}]),default)).Value);
        var forged=p.Id;await f.Agent.SyncAsync(f.State,new(1,forged,900,[new(ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3,forged,900,DateTimeOffset.UtcNow,0)],[]),default);
        var state=Assert.Single((await f.Admin.DevicesAsync(default)).Value!.Devices);Assert.Null(state.CachedVersion);Assert.Null(Assert.Single(state.Helpers).AppliedVersion);
        var invalid=ClipboardSamples.Detection(p) with{Hits=[new(Guid.NewGuid(),1,false)]};var response=(await f.Agent.SyncAsync(f.State,new(1,p.Id,1,[],[new(invalid,ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3)]),default)).Value!;Assert.Single(response.Rejected);
        Assert.NotNull((await f.Admin.AssignAsync(f.State.DeviceId!.Value,null,default)).Value);Assert.Null((await f.ExchangeAsync()).Policy);
    }
}
