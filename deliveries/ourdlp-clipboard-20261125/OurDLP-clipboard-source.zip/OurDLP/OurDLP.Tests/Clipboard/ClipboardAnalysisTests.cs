using System.Buffers.Binary;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Session;
using Xunit;
namespace OurDLP.Tests.Clipboard;
public sealed class ClipboardAnalysisTests
{
    [Fact] public void DetectorCountsWithoutReturningTextAndBufferIsCleared()
    {
        var chars="OURDLP-TEST-1234 and OURDLP-TEST-9876".ToCharArray();ClipboardAnalysis result;
        using(var buffer=new ClipboardTextBuffer(chars,chars.Length))result=new CompiledClipboardPolicy(ClipboardSamples.Policy()).Analyze(buffer.Text);
        Assert.All(chars,c=>Assert.Equal('\0',c));Assert.Equal(2,Assert.Single(result.Hits).Count);
        Assert.DoesNotContain("OURDLP-TEST",ScanWire.Serialize(result));
    }
    [Fact] public void DisabledPolicyDoesNotInspectOrGenerateEvents()
    {var result=new CompiledClipboardPolicy(ClipboardSamples.Policy(false)).Analyze("OURDLP-TEST-1234");Assert.False(result.HasEvent);Assert.Equal(0,result.TextCharacters);}
    [Fact] public void LongTextInspectsOnlyBoundedPrefixAndReportsTruncation()
    {var policy=ClipboardSamples.Policy() with{MaxTextCharacters=1024};var result=new CompiledClipboardPolicy(policy).Analyze(new string('a',1024)+"OURDLP-TEST-1234");Assert.Empty(result.Hits);Assert.True(result.Truncated);Assert.Equal(1024,result.TextCharacters);Assert.True(result.HasEvent);}
    [Fact] public void MatchLimitAndTimeoutAreExplicitMetadata()
    {
        var policy=ClipboardSamples.Policy();var many=new CompiledClipboardPolicy(policy).Analyze(string.Join(" ",Enumerable.Repeat("OURDLP-TEST-1234",110)));
        Assert.Equal(100,Assert.Single(many.Hits).Count);Assert.True(many.Hits[0].CountLimited);
        policy=policy with{Rules=[policy.Rules[0] with{Pattern="(a+)+$"}]};
        var timed=new CompiledClipboardPolicy(policy).Analyze(new string('a',16000)+"!");Assert.Equal(policy.Rules[0].Id,Assert.Single(timed.TimedOutRules));
    }
    [Fact] public void InvalidExpressionsDuplicateIdsAndOversizedPoliciesAreRejected()
    {
        var p=ClipboardSamples.Policy();Assert.Throws<ArgumentException>(()=>new CompiledClipboardPolicy(p with{Rules=[p.Rules[0] with{Pattern="("}]}));
        Assert.Throws<ArgumentException>(()=>new CompiledClipboardPolicy(p with{Rules=[p.Rules[0],p.Rules[0]]}));
        Assert.Throws<ArgumentException>(()=>new CompiledClipboardPolicy(p with{MaxTextCharacters=1000000}));
        Assert.Throws<ArgumentException>(()=>new CompiledClipboardPolicy(p with{Rules=Enumerable.Range(0,20).Select(_=>p.Rules[0] with{Id=Guid.NewGuid(),Pattern=new string('Я',2000)}).ToArray()}));
    }
    [Fact] public async Task FramingRejectsOversizedTruncatedAndNegativeLengths()
    {
        foreach(var length in new[]{-1,ClipboardWire.MaxFrameBytes+1}){using var stream=new MemoryStream();var header=new byte[4];BinaryPrimitives.WriteInt32LittleEndian(header,length);stream.Write(header);stream.Position=0;await Assert.ThrowsAsync<InvalidDataException>(()=>ClipboardFrames.ReadAsync<ClipboardSessionRequest>(stream,default));}
        using var shortStream=new MemoryStream(new byte[]{5,0,0,0,123});await Assert.ThrowsAsync<EndOfStreamException>(()=>ClipboardFrames.ReadAsync<ClipboardSessionRequest>(shortStream,default));
    }
    [Fact] public async Task FramesRoundTripMetadataOnly()
    {
        var p=ClipboardSamples.Policy();var request=ClipboardSamples.Request(new('A',64),ClipboardSamples.Detection(p));using var stream=new MemoryStream();
        await ClipboardFrames.WriteAsync(stream,request,default);stream.Position=0;var copy=await ClipboardFrames.ReadAsync<ClipboardSessionRequest>(stream,default);
        Assert.Equal(ScanWire.Serialize(request),ScanWire.Serialize(copy));Assert.DoesNotContain("content",ScanWire.Serialize(copy),StringComparison.OrdinalIgnoreCase);
    }
}
