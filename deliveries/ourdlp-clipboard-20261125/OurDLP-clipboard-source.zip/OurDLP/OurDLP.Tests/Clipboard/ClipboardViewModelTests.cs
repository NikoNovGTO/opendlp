using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services.Clipboard;
using OurDLP.Desktop.ViewModels.Clipboard;
using Xunit;
namespace OurDLP.Tests.Clipboard;
public sealed class ClipboardViewModelTests
{
    [Fact] public async Task AutoRefreshPreservesDraftAndOptimisticVersionAcrossSelectionReset()
    {
        var client=new Client();using var vm=new ClipboardWorkspace(client,_=>true,()=>{});
        vm.Policies.CollectionChanged+=(_,_)=>{if(vm.Policies.Count==0)vm.SelectedPolicy=null;};
        await vm.RefreshCommand.ExecuteAsync();vm.SelectedPolicy=vm.Policies[0];var rule=vm.Editor.Draft().Rules[0].Id;vm.Editor.Name="Несохранённое имя";
        client.Policy=client.Policy with{Version=2};await vm.RefreshCommand.ExecuteAsync();Assert.Equal("Несохранённое имя",vm.Editor.Name);Assert.Equal(1,vm.Editor.Draft().ExpectedVersion);Assert.Equal(rule,vm.Editor.Draft().Rules[0].Id);
    }
    [Fact] public async Task DeclinedAssignmentAndInvalidDraftDoNotMutateServer()
    {
        var client=new Client();using var vm=new ClipboardWorkspace(client,_=>false,()=>{});await vm.RefreshCommand.ExecuteAsync();vm.SelectedPolicy=vm.Policies[0];await vm.AssignCommand.ExecuteAsync();Assert.Equal(0,client.Assignments);
        vm.Editor.Pattern="(";await vm.SaveCommand.ExecuteAsync();Assert.Equal(0,client.Saves);Assert.Contains("выражение",vm.Message);
    }
    [Fact] public void CachedPolicyIsNotReportedAsAppliedUntilFreshSessionAcknowledges()
    {
        var id=Guid.NewGuid();var device=new ClipboardDeviceState(Guid.NewGuid(),"PC",true,"active",id,2,id,2,[]);
        Assert.Contains("нет подтверждения",new ClipboardDeviceRow(device).Applied);
        var helper=new ClipboardHelperStatus(ClipboardSamples.Peer.UserSid,ClipboardSamples.Peer.UserName,3,id,2,DateTimeOffset.UtcNow,0);
        Assert.Contains("Применена: 1",new ClipboardDeviceRow(device with{Helpers=[helper]}).Applied);
        Assert.Contains("нет подтверждения",new ClipboardDeviceRow(device with{Helpers=[helper with{LastSeenAtUtc=DateTimeOffset.UtcNow.AddMinutes(-1)}]}).Applied);
        Assert.Contains("Нет связи",new ClipboardDeviceRow(device with{Status="offline",Helpers=[helper]}).Applied);
    }
    [Fact] public async Task SessionExpiryRequestsLoginAndClearsVisibleEvents()
    {var client=new Client();var expired=0;using var vm=new ClipboardWorkspace(client,_=>true,()=>expired++);client.Expired=true;await vm.RefreshCommand.ExecuteAsync();Assert.Equal(1,expired);Assert.Empty(vm.Events);}
    private sealed class Client:IClipboardClient
    {
        public ClipboardPolicy Policy{get;set;}=ClipboardSamples.Policy();public int Saves{get;private set;}public int Assignments{get;private set;}public bool Expired{get;set;}
        public Task<DeviceApiResult<ClipboardPolicyList>> PoliciesAsync(CancellationToken t)=>Task.FromResult(Expired?new DeviceApiResult<ClipboardPolicyList>(null,"expired",true):new(new([Policy])));
        public Task<DeviceApiResult<ClipboardDeviceList>> DevicesAsync(CancellationToken t)=>Task.FromResult(new DeviceApiResult<ClipboardDeviceList>(new([new(Guid.NewGuid(),"PC",true,"active",null,null,null,null,[])])));
        public Task<DeviceApiResult<ClipboardEventList>> EventsAsync(CancellationToken t)=>Task.FromResult(new DeviceApiResult<ClipboardEventList>(new([])));
        public Task<DeviceApiResult<ClipboardPolicy>> SaveAsync(Guid? id,ClipboardPolicyDraft draft,CancellationToken t){Saves++;return Task.FromResult(new DeviceApiResult<ClipboardPolicy>(Policy));}
        public Task<DeviceApiResult<DeviceOperationResponse>> AssignAsync(Guid device,Guid? policy,CancellationToken t){Assignments++;return Task.FromResult(new DeviceApiResult<DeviceOperationResponse>(new("OK")));}
    }
}
