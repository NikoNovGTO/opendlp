using System.Net;
using System.Net.Http.Headers;
using OurDLP.Agent;
using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.Services.Clipboard;
using OurDLP.Session;
using Xunit;
namespace OurDLP.Tests.Clipboard;
[Collection("Live server")]
public sealed class LiveClipboardTests
{
    [LiveAuthenticationFact][Trait("Category","Integration")]
    public async Task RealTlsPolicySessionMetadataAndReconnectUseProductionClients()
    {
        var address=Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var expected=Environment.GetEnvironmentVariable("OURDLP_EXPECT_LOGIN_SUCCESS")=="1";
        var loginData=ScanWire.Read<LoginRequest>(await File.ReadAllTextAsync(Environment.GetEnvironmentVariable("OURDLP_LIVE_LOGIN_FILE")!));
        using var adminHttp=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false,UseCookies=true,CookieContainer=new()}){Timeout=TimeSpan.FromSeconds(10),MaxResponseContentBufferSize=4*1024*1024};
        var auth=new AuthenticationClient(adminHttp);Assert.Equal(expected,(await auth.LoginAsync(address,loginData.UserName,loginData.Password,default)).Succeeded);if(!expected)return;
        var devices=new DevicesClient(adminHttp,address);var enrollment=(await devices.CreateAsync("LIVE-CLIP-"+Guid.NewGuid().ToString("N")[..8],default)).Value!;
        try
        {
            using var agentHttp=new HttpClient(new HttpClientHandler{UseCookies=false,AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(10),MaxResponseContentBufferSize=256*1024};
            var registration=new MemoryAgentState();Assert.True((await new AgentEnrollment(registration,new(agentHttp)).EnrollAsync(address,enrollment.Code,false,default)).Succeeded);
            var state=registration.State!;var store=new TestAgentStore();var service=new ClipboardAgentCoordinator(registration,store);var agent=new ClipboardAgentClient(agentHttp);var admin=new ClipboardClient(adminHttp,address);
            async Task Exchange(){var packet=await service.SnapshotAsync(default);var reply=await agent.SyncAsync(state,packet,default);Assert.NotNull(reply.Value);await service.ApplyAsync(reply.Value,packet.Events.Select(row=>row.Detection.Id).ToArray(),default);}
            await Exchange();var p=ClipboardSamples.Policy();p=(await admin.SaveAsync(null,new(p.Name,true,p.MaxTextCharacters,p.Rules),default)).Value!;Assert.NotNull(p);Assert.NotNull((await admin.AssignAsync(enrollment.DeviceId,p.Id,default)).Value);await Exchange();
            // Synthetic clipboard input exercises the portable detector, not Win32 capture.
            var user=new TestSessionStore();var pipe=new TestSessionClient();pipe.Connect(service);var session=new SessionCoordinator(user,pipe);await session.InitializeAsync(default);await session.SyncOnceAsync(default);session.SetListenerReady(true);await session.SyncOnceAsync(default);await Exchange();
            Assert.Equal(1,(await admin.DevicesAsync(default)).Value!.Devices.Single(row=>row.Id==enrollment.DeviceId).Helpers.Single().AppliedVersion);
            pipe.Exchange=_=>Task.FromResult<ClipboardSessionResponse?>(null);var chars="OURDLP-TEST-5487".ToCharArray();
            using(var captured=new CapturedClipboard(new(chars,chars.Length),session.CurrentPolicy!,false,"test-input",3,DateTimeOffset.UtcNow))await session.EnqueueAsync(captured,default);
            await session.SyncOnceAsync(default);Assert.Single(user.State.Pending);pipe.Connect(service);await session.SyncOnceAsync(default);
            var pending=await service.SnapshotAsync(default);var reply1=await agent.SyncAsync(state,pending,default);var reply2=await agent.SyncAsync(state,pending,default);Assert.Single(reply1.Value!.Accepted);Assert.Single(reply2.Value!.Accepted);
            await service.ApplyAsync(reply2.Value,pending.Events.Select(row=>row.Detection.Id).ToArray(),default);Assert.Empty(store.State!.Pending);
            var events=(await admin.EventsAsync(default)).Value!.Events.Where(row=>row.DeviceId==enrollment.DeviceId).ToArray();Assert.Single(events);Assert.DoesNotContain("5487",ScanWire.Serialize(events));
            agentHttp.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",state.Token);
            using var oversized=await agentHttp.PostAsync(address+"/api/agent/clipboard/sync",new StringContent(new string(' ',ClipboardWire.MaxFrameBytes+10),System.Text.Encoding.UTF8,"application/json"));Assert.Equal(HttpStatusCode.RequestEntityTooLarge,oversized.StatusCode);
        }
        finally{await devices.RevokeAsync(enrollment.DeviceId,default);await auth.LogoutAsync(address,default);}
    }
}
