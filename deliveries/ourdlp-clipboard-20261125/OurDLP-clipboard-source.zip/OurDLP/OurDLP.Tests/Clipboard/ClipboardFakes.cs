using OurDLP.Agent;
using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Scanning;
using OurDLP.Session;
namespace OurDLP.Tests.Clipboard;
// Portable test doubles only. Production stores use Windows DPAPI, not JSON files.
public static class ClipboardSamples
{
    public static ClipboardPolicy Policy(bool enabled=true) => new(Guid.NewGuid(),1,"Маркер",enabled,16384,[new ScanRule(Guid.NewGuid(),"Тест","OURDLP-TEST-[0-9]{4}")]);
    public static ClipboardSessionEvent Detection(ClipboardPolicy policy) => new(Guid.NewGuid(),policy.Id,policy.Version,DateTimeOffset.UtcNow,"notepad",16,false,[new(policy.Rules[0].Id,1,false)],[],3);
    public static readonly ClipboardPeer Peer = new("S-1-5-21-100-200-300-1001","TEST\\User",3);
    public static ClipboardSessionRequest Request(string? key, params ClipboardSessionEvent[] events) => new(1,key,null,null,events,0);
    public static async Task<(MemoryAgentState Registration, ClipboardAgentCoordinator Service, TestAgentStore Store)> AgentAsync(ClipboardPolicy? policy)
    {
        var registration=new MemoryAgentState();await registration.SaveAsync(new(){ServerAddress="https://localhost",DeviceId=Guid.NewGuid(),Token=new('A',43)},default);
        var store=new TestAgentStore();var service=new ClipboardAgentCoordinator(registration,store);
        await service.ApplyAsync(new(policy,[],[]),[],default);return(registration,service,store);
    }
}
public sealed class TestAgentStore : IClipboardAgentStore
{
    public ClipboardAgentState? State { get; set; } public bool FailSave { get; set; } public int Archives { get; private set; }
    public Task<ClipboardAgentState?> ReadAsync(CancellationToken token)=>Task.FromResult(State is null?null:ScanWire.Read<ClipboardAgentState>(ScanWire.Serialize(State)));
    public Task SaveAsync(ClipboardAgentState value,CancellationToken token){if(FailSave)throw new IOException("Test disk unavailable");State=ScanWire.Read<ClipboardAgentState>(ScanWire.Serialize(value));return Task.CompletedTask;}
    public Task ArchiveAsync(CancellationToken token){Archives++;State=null;return Task.CompletedTask;}
}
public sealed class TestSessionStore : ISessionStateStore
{
    public SessionState State { get; set; }=new();
    public Task<SessionState> ReadAsync(CancellationToken token)=>Task.FromResult(State);
    public Task<SessionState> UpdateAsync(Func<SessionState,SessionState> update,CancellationToken token){State=ScanWire.Read<SessionState>(ScanWire.Serialize(update(State)));return Task.FromResult(State);}
}
public sealed class TestSessionClient : IClipboardSessionClient
{
    public Func<ClipboardSessionRequest,Task<ClipboardSessionResponse?>> Exchange { get; set; }=_=>Task.FromResult<ClipboardSessionResponse?>(null);
    public ClipboardSessionRequest? LastRequest { get; private set; }
    public Task<ClipboardSessionResponse?> SyncAsync(ClipboardSessionRequest request,CancellationToken token){LastRequest=request;return Exchange(request);}
    public void Connect(ClipboardAgentCoordinator service)=>Exchange=async request=>await service.SessionAsync(ClipboardSamples.Peer,request,default);
}
