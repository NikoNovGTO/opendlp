using System.Text;
using OurDLP.Agent;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Tests.Scanning;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class RemoteScanLogicTests
{
    [Theory]
    [InlineData(@"C:\ProgramData\OurDLP\ScanTargets\Demo",@"C:\ProgramData\OurDLP\ScanTargets",true)]
    [InlineData(@"c:\ProgramData\OurDLP\ScanTargets\Demo",@"C:\ProgramData\OurDLP\ScanTargets",true)]
    [InlineData(@"C:\ProgramData\OurDLP\ScanTargets-other",@"C:\ProgramData\OurDLP\ScanTargets",false)]
    [InlineData(@"C:\ProgramData\OurDLP\ScanTargets\..\secret",@"C:\ProgramData\OurDLP\ScanTargets",false)]
    [InlineData("/scope/demo","/scope",true)][InlineData("/scope-other/demo","/scope",false)]
    public void ScopeComparisonIsPlatformIndependent(string path,string root,bool expected)=>Assert.Equal(expected,RemoteScanPaths.IsInside(path,root));
    [Fact]
    public async Task LocalScopeGuardRejectsJobBeforeReadingOutsideFiles()
    {
        using var allowed=new ScanFiles();using var outside=new ScanFiles();outside.Write("private.txt","OURDLP-TEST-0001");
        var scanner=new CountingScanner();var result=await new AgentScanExecutor(scanner,allowed.Root).ExecuteAsync(new(Guid.NewGuid(),outside.Request()),default);
        Assert.Equal(ScanCompletion.Failed,result.Completion);Assert.Equal(0,scanner.Calls);Assert.Empty(result.Findings);
    }
    [Fact]
    public void OversizedMetadataIsExplicitlyReducedBeforeItEntersTheQueue()
    {
        var text=new string('Ж',20_000);var findings=Enumerable.Range(0,100).Select(_=>new ScanFinding(Guid.NewGuid(),text,text,Guid.NewGuid(),"rule",1,false,DateTimeOffset.UtcNow)).ToArray();
        var report=ScanReportTransmission.Bound(new(){Findings=findings});
        Assert.Equal(ScanCompletion.LimitReached,report.Completion);Assert.True(report.Findings.Count<100);
        Assert.True(Encoding.UTF8.GetByteCount(ScanWire.Serialize(report))<=ScanWire.MaxReportBytes);
    }
    [Fact]
    public async Task WrongAcknowledgementDoesNotDiscardPendingReport()
    {
        using var files=new ScanFiles();var job=new ScanWork(Guid.NewGuid(),files.Request());
        var report=new ScanReport{Id=job.Id};var queue=new TestScanQueue(Path.Combine(files.Root,"pending.json"));
        var state=new AgentState{DeviceId=Guid.NewGuid(),ServerAddress="https://localhost",Token="test"};await queue.SaveAsync(new(state.ServerAddress,state.DeviceId.Value,job,report),default);
        var client=new WrongAcknowledgement();var cycle=new AgentScanCycle(queue,client,new(new(new FileScanner(),files.Root),client),files.Root);
        await cycle.RunOnceAsync(state,default);Assert.NotNull(await queue.ReadAsync(default));
    }
    private sealed class WrongAcknowledgement:IAgentScanClient
    {
        public Task<AgentScanReply<ScanWorkResponse>> NextAsync(AgentState state,string root,CancellationToken token)=>throw new Exception("Must not claim while a report is pending");
        public Task<AgentScanReply<ScanJobStateResponse>> StateAsync(AgentState state,Guid job,CancellationToken token)=>throw new Exception();
        public Task<AgentScanReply<ScanResultAcknowledgement>> SubmitAsync(AgentState state,Guid job,ScanReport report,CancellationToken token)=>Task.FromResult(new AgentScanReply<ScanResultAcknowledgement>(new(Guid.NewGuid(),"accepted"),200));
    }
}
