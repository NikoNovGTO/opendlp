using System.Net.Http.Json;
using OurDLP.Agent;
using OurDLP.Contracts;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class ReEnrollmentRecoveryTests
{
    [PostgresFact][Trait("Category","Postgres")]
    public async Task LostExplicitReEnrollmentResponseCanRetryTheSameCodeWithoutReplacingTheAcceptedToken()
    {
        await using var context=await AgentTestContext.CreateAsync();var first=await context.AddAsync();using var original=context.Agent();var store=new MemoryAgentState();
        Assert.False((await new AgentEnrollment(store,new(original)).EnrollAsync("https://localhost",OurDLP.Server.Agents.AgentSecrets.Create(),false,default)).Succeeded);
        var pendingToken=store.State!.Token;
        Assert.True((await new AgentEnrollment(store,new(original)).EnrollAsync("https://localhost",first.Code,false,default)).Succeeded);var oldToken=store.State!.Token;
        Assert.Equal(pendingToken,oldToken);
        Assert.Equal(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(first.Code))),store.State.EnrollmentCodeHash);
        var next=(await (await context.Admin.PostAsync($"/api/devices/{first.DeviceId}/enrollment",null)).Content.ReadFromJsonAsync<EnrollmentResponse>())!;
        var handler=new DropOnce{InnerHandler=context.Server.Server.CreateHandler()};using var http=new HttpClient(handler);
        Assert.False((await new AgentEnrollment(store,new(http)).EnrollAsync("https://localhost",next.Code,true,default)).Succeeded);
        var acceptedToken=store.State!.Token;Assert.NotEqual(oldToken,acceptedToken);Assert.Null(store.State.DeviceId);
        Assert.True((await new AgentEnrollment(store,new(http)).EnrollAsync("https://localhost",next.Code,true,default)).Succeeded);
        Assert.Equal(acceptedToken,store.State.Token);Assert.Equal(first.DeviceId,store.State.DeviceId);Assert.Equal(1,handler.Enrollments);
        Assert.DoesNotContain(next.Code,ScanWire.Serialize(store.State));
    }
    private sealed class DropOnce:DelegatingHandler
    {
        public int Enrollments{get;private set;}
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)
        {
            var response=await base.SendAsync(request,token);
            if(request.RequestUri!.AbsolutePath.EndsWith("/enroll")&&Enrollments++==0){response.Dispose();throw new HttpRequestException("lost reply");}
            return response;
        }
    }
}
