using System.Net;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Agent;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Server.Data;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class RemoteScanIntegrationTests
{
    [PostgresFact][Trait("Category","Postgres")]
    public async Task AdminJobActualAgentScannerAndPersistentServerReportWorkEndToEnd()
    {
        await using var f=await RemoteScanFixture.CreateAsync(); var id=await f.CreateJobAsync();
        var queue=new TestScanQueue(Path.Combine(f.Files.Root,"pending.json")); await f.Cycle(queue).RunOnceAsync(f.State,default);
        Assert.Null(await queue.ReadAsync(default));
        var report=(await f.Admin.ReportAsync(id,default)).Value!.Report;
        Assert.Equal(id,report.Id);Assert.Equal(5,report.FilesScanned);Assert.Equal(4,report.Findings.Count);Assert.Equal(7,report.Findings.Sum(row=>row.Matches));
        Assert.Equal("completed",(await f.Admin.ListAsync(default)).Value!.Jobs.Single().Status);
        await using var scope=f.Context.Server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        var stored=await db.ScanJobs.SingleAsync();Assert.NotNull(stored.ReportHash);Assert.Equal(1,await db.DeviceAudit.CountAsync(row=>row.Action=="scan.result.accepted"));
        foreach(var marker in new[]{"OURDLP-TEST-0001","OURDLP-TEST-0002","OURDLP-TEST-0003","OURDLP-TEST-0004","OURDLP-TEST-0005","OURDLP-TEST-0006","OURDLP-TEST-0007"})Assert.DoesNotContain(marker,stored.ReportJson!);
        var cancel=(await f.Admin.CancelAsync(id,default)).Value!;Assert.Equal("completed",cancel.Status);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task LostResultResponseRetainsExactOutboxAndRetriesWithoutRescanningOrDuplicateAudit()
    {
        await using var f=await RemoteScanFixture.CreateAsync();var id=await f.CreateJobAsync();
        var handler=new InterruptingHandler{InnerHandler=f.Context.Server.Server.CreateHandler(),DropResult=true};using var http=new HttpClient(handler);
        var client=new AgentScanClient(http);var scanner=new CountingScanner();var path=Path.Combine(f.Files.Root,"pending.json");
        await f.Cycle(new TestScanQueue(path),client,scanner).RunOnceAsync(f.State,default);
        var saved=(await new TestScanQueue(path).ReadAsync(default))!;Assert.NotNull(saved.Report);Assert.Equal(1,scanner.Calls);
        Assert.Equal("completed",(await f.Admin.ListAsync(default)).Value!.Jobs.Single().Status);
        await f.Cycle(new TestScanQueue(path),client,scanner).RunOnceAsync(f.State,default);
        Assert.Null(await new TestScanQueue(path).ReadAsync(default));Assert.Equal(1,scanner.Calls);
        await using var scope=f.Context.Server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        Assert.Equal(1,await db.DeviceAudit.CountAsync(row=>row.Action=="scan.result.accepted"));
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task CachedJobRunsOfflineThenARecreatedAgentUploadsCachedResult()
    {
        await using var f=await RemoteScanFixture.CreateAsync();await f.CreateJobAsync();
        var actual=new AgentScanClient(f.Http);var work=(await actual.NextAsync(f.State,f.Files.Root,default)).Value!.Job!;
        var path=Path.Combine(f.Files.Root,"pending.json");var queue=new TestScanQueue(path);await queue.SaveAsync(new(f.State.ServerAddress,f.State.DeviceId!.Value,work,null),default);
        var handler=new InterruptingHandler{InnerHandler=f.Context.Server.Server.CreateHandler(),Offline=true};using var http=new HttpClient(handler);
        var client=new AgentScanClient(http);var scanner=new CountingScanner();
        await f.Cycle(queue,client,scanner).RunOnceAsync(f.State,default);
        Assert.NotNull((await queue.ReadAsync(default))!.Report);Assert.Equal(1,scanner.Calls);
        handler.Offline=false;await f.Cycle(new TestScanQueue(path),client,scanner).RunOnceAsync(f.State,default);
        Assert.Null(await queue.ReadAsync(default));Assert.Equal(1,scanner.Calls);
        Assert.Equal("completed",(await f.Admin.ListAsync(default)).Value!.Jobs.Single().Status);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task LostWorkResponseIsRedeliveredWithSameId()
    {
        await using var f=await RemoteScanFixture.CreateAsync();var id=await f.CreateJobAsync();
        var handler=new InterruptingHandler{InnerHandler=f.Context.Server.Server.CreateHandler(),DropWork=true};using var http=new HttpClient(handler);
        var client=new AgentScanClient(http);var queue=new TestScanQueue(Path.Combine(f.Files.Root,"pending.json"));
        await f.Cycle(queue,client).RunOnceAsync(f.State,default);Assert.Null(await queue.ReadAsync(default));
        Assert.Equal("running",(await f.Admin.ListAsync(default)).Value!.Jobs.Single().Status);
        await f.Cycle(queue,client).RunOnceAsync(f.State,default);
        Assert.Equal(id,(await f.Admin.ReportAsync(id,default)).Value!.Report.Id);
        await using var scope=f.Context.Server.Services.CreateAsyncScope();Assert.Equal(1,await scope.ServiceProvider.GetRequiredService<OurDlpDbContext>().DeviceAudit.CountAsync(row=>row.Action=="scan.started"));
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task ConcurrentCreatesAllowOneActiveJobAndCancellationFreesTheDevice()
    {
        await using var f=await RemoteScanFixture.CreateAsync();var request=new CreateScanJobRequest(f.State.DeviceId!.Value,f.Request());
        var responses=await Task.WhenAll(f.Context.Admin.PostAsJsonAsync("/api/scans",request),f.Context.Admin.PostAsJsonAsync("/api/scans",request));
        Assert.Single(responses,row=>row.StatusCode==HttpStatusCode.OK);Assert.Single(responses,row=>row.StatusCode==HttpStatusCode.Conflict);
        var id=(await f.Admin.ListAsync(default)).Value!.Jobs.Single().Id;Assert.Equal("cancelled",(await f.Admin.CancelAsync(id,default)).Value!.Status);
        Assert.NotEqual(id,await f.CreateJobAsync());foreach(var response in responses)response.Dispose();
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task DeviceIsolationAdminRoleAndImmutableResultAreEnforced()
    {
        await using var f=await RemoteScanFixture.CreateAsync();var id=await f.CreateJobAsync();
        var own=new AgentScanClient(f.Http);var work=(await own.NextAsync(f.State,f.Files.Root,default)).Value!.Job!;
        var report=(await new FileScanner().ScanAsync(work.Request,null,default)) with{Id=id};
        var other=await f.Context.AddAsync("OTHER");var store=new MemoryAgentState();using var otherHttp=f.Context.Agent();
        Assert.True((await new AgentEnrollment(store,new(otherHttp)).EnrollAsync("https://localhost",other.Code,false,default)).Succeeded);
        var otherClient=new AgentScanClient(otherHttp);Assert.Equal(404,(await otherClient.SubmitAsync(store.State!,id,report,default)).StatusCode);
        using var auth=f.AuthenticatedHttp();Assert.Equal(HttpStatusCode.Unauthorized,(await auth.GetAsync("/api/scans")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await f.Context.Admin.PostAsJsonAsync("/api/agent/scans/next",new ScanWorkRequest(1,f.Files.Root))).StatusCode);
        Assert.Equal(400,(await own.SubmitAsync(f.State,id,report with{Findings=[report.Findings[0] with{FilePath="/outside/secret.txt"}]},default)).StatusCode);
        Assert.Equal("accepted",(await own.SubmitAsync(f.State,id,report,default)).Value!.Outcome);
        Assert.Equal("duplicate",(await own.SubmitAsync(f.State,id,report,default)).Value!.Outcome);
        Assert.Equal(409,(await own.SubmitAsync(f.State,id,report with{Message="replaced"},default)).StatusCode);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task AdminCancelAndCredentialRevocationDoNotAcceptLateResults()
    {
        await using var f=await RemoteScanFixture.CreateAsync();var id=await f.CreateJobAsync();var client=new AgentScanClient(f.Http);
        var work=(await client.NextAsync(f.State,f.Files.Root,default)).Value!.Job!;
        var report=(await new FileScanner().ScanAsync(work.Request,null,default)) with{Id=id};
        await f.Admin.CancelAsync(id,default);Assert.Equal("cancelled",(await client.SubmitAsync(f.State,id,report,default)).Value!.Outcome);
        Assert.Null((await f.Admin.ReportAsync(id,default)).Value);
        var next=await f.CreateJobAsync();Assert.True((await f.Context.Admin.PostAsync($"/api/devices/{f.State.DeviceId}/revoke",null)).IsSuccessStatusCode);
        Assert.Equal(401,(await client.NextAsync(f.State,f.Files.Root,default)).StatusCode);
        Assert.Equal("cancelled",(await f.Admin.ListAsync(default)).Value!.Jobs.Single(row=>row.Id==next).Status);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task ServerRejectsScopeEscapeAndOldAgentWithoutCapability()
    {
        await using var f=await RemoteScanFixture.CreateAsync();
        var outside=await f.Admin.CreateAsync(new(f.State.DeviceId!.Value,f.Request() with{RootPath=Path.GetTempPath()}),default);Assert.Null(outside.Value);
        var old=await f.Context.AddAsync("OLD");using var http=f.Context.Agent();var state=new MemoryAgentState();
        await new AgentEnrollment(state,new(http)).EnrollAsync("https://localhost",old.Code,false,default);
        Assert.Null((await f.Admin.CreateAsync(new(old.DeviceId,f.Request()),default)).Value);
    }
    private sealed class InterruptingHandler:DelegatingHandler
    {
        public bool Offline{get;set;}public bool DropResult{get;set;}public bool DropWork{get;set;}
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)
        {
            if(Offline)return new(HttpStatusCode.ServiceUnavailable);
            var response=await base.SendAsync(request,token);var path=request.RequestUri!.AbsolutePath;
            if((DropResult&&path.EndsWith("/result"))||(DropWork&&path.EndsWith("/next")))
            {DropResult=false;DropWork=false;response.Dispose();throw new HttpRequestException("simulated lost response");}
            return response;
        }
    }
}
