using System.Net.Http.Headers;
using System.Net.Http.Json;
using OurDLP.Agent;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Services.RemoteScanning;
using OurDLP.Desktop.Services.Scanning;
using OurDLP.Tests.Scanning;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class RemoteScanFixture : IAsyncDisposable
{
    public AgentTestContext Context { get; private set; } = null!;
    public ScanFiles Files { get; } = new();
    public AgentState State { get; private set; } = null!;
    public HttpClient Http { get; private set; } = null!;
    public string Sample { get; private set; } = string.Empty;
    public ScanJobsClient Admin => new(Context.Admin, "https://localhost");
    public static async Task<RemoteScanFixture> CreateAsync()
    {
        var fixture = new RemoteScanFixture { Context = await AgentTestContext.CreateAsync() };
        fixture.Sample = new ScanSampleFactory(fixture.Files.Root).Create();
        var enrollment = await fixture.Context.AddAsync(); fixture.Http = fixture.Context.Agent();
        var store = new MemoryAgentState();
        Assert.True((await new AgentEnrollment(store, new(fixture.Http)).EnrollAsync("https://localhost", enrollment.Code, false, default)).Succeeded);
        fixture.State = store.State!;
        Assert.True((await new AgentScanClient(fixture.Http).NextAsync(fixture.State, fixture.Files.Root, default)).Succeeded);
        return fixture;
    }
    public ScanRequest Request() => Files.Request() with { RootPath = Sample };
    public async Task<Guid> CreateJobAsync()
    {
        var result = await Admin.CreateAsync(new(State.DeviceId!.Value, Request()), default);
        Assert.NotNull(result.Value); return result.Value.JobId;
    }
    public AgentScanCycle Cycle(IAgentScanQueue queue, IAgentScanClient? client = null, IFileScanner? scanner = null)
    {
        client ??= new AgentScanClient(Http);
        return new(queue, client, new(new(scanner ?? new FileScanner(), Files.Root), client), Files.Root);
    }
    public HttpClient AuthenticatedHttp()
    { var http = Context.Agent(); http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", State.Token); return http; }
    public async ValueTask DisposeAsync() { Http.Dispose(); await Context.DisposeAsync(); Files.Dispose(); }
}

// Portable test storage only: production uses WindowsAgentScanQueue with DPAPI and ACL.
public sealed class TestScanQueue(string path) : IAgentScanQueue
{
    public async Task<PendingAgentScan?> ReadAsync(CancellationToken token) => !File.Exists(path) ? null : ScanWire.Read<PendingAgentScan>(await File.ReadAllTextAsync(path, token));
    public Task SaveAsync(PendingAgentScan pending, CancellationToken token) => File.WriteAllTextAsync(path, ScanWire.Serialize(pending), token);
    public Task ClearAsync(CancellationToken token) { File.Delete(path); return Task.CompletedTask; }
    public Task ArchiveAsync(CancellationToken token) { if (File.Exists(path)) File.Move(path, path + ".archive", true); return Task.CompletedTask; }
}
public sealed class CountingScanner : IFileScanner
{
    public int Calls { get; private set; }
    public Task<ScanReport> ScanAsync(ScanRequest request, IProgress<ScanProgress>? progress, CancellationToken token)
    { Calls++; return new FileScanner().ScanAsync(request, progress, token); }
}
