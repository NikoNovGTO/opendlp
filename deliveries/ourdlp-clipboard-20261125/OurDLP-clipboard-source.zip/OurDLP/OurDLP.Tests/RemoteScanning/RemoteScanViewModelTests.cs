using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.Services.RemoteScanning;
using OurDLP.Desktop.ViewModels.RemoteScanning;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class RemoteScanViewModelTests
{
    [Fact]
    public async Task RefreshPreservesTypedRemotePathAndOpenedReportDespiteSelectionReset()
    {
        var devices=new Devices();var jobs=new Jobs();using var model=new RemoteScansViewModel(devices,jobs,_=>true,()=>{},()=>null);
        model.Devices.CollectionChanged+=(_,_)=>{if(model.Devices.Count==0)model.SelectedDevice=null;};
        model.Jobs.CollectionChanged+=(_,_)=>{if(model.Jobs.Count==0)model.SelectedJob=null;};
        await model.RefreshCommand.ExecuteAsync();model.Options.Folder="/allowed/custom";await model.OpenReportCommand.ExecuteAsync();
        await model.RefreshCommand.ExecuteAsync();
        Assert.Equal("/allowed/custom",model.Options.Folder);Assert.NotNull(model.Results.Report);
        Assert.Equal(jobs.Report.Id,model.Results.Report.Id);
    }
    [Fact]
    public async Task CancellingConfirmationSendsNoMutation()
    {
        var jobs=new Jobs{Status="running"};using var model=new RemoteScansViewModel(new Devices(),jobs,_=>false,()=>{},()=>null);
        await model.RefreshCommand.ExecuteAsync();await model.CancelCommand.ExecuteAsync();Assert.Equal(0,jobs.Cancels);
    }
    [Fact]
    public async Task InvalidRegexAndScopeNeverCreateServerJobs()
    {
        var jobs=new Jobs();using var model=new RemoteScansViewModel(new Devices(),jobs,_=>true,()=>{},()=>null);
        await model.RefreshCommand.ExecuteAsync();model.Options.Pattern="(";await model.CreateCommand.ExecuteAsync();Assert.Contains("выражение",model.Message);
        model.Options.Pattern="x";model.Options.Folder="/outside";await model.CreateCommand.ExecuteAsync();Assert.Equal(0,jobs.Creates);
    }
    [Fact]
    public async Task SessionExpiryClearsReportAndRequestsLogin()
    {
        var jobs=new Jobs();var expired=0;using var model=new RemoteScansViewModel(new Devices(),jobs,_=>true,()=>expired++,()=>null);
        await model.RefreshCommand.ExecuteAsync();await model.OpenReportCommand.ExecuteAsync();jobs.Expired=true;
        await model.RefreshCommand.ExecuteAsync();Assert.Equal(1,expired);Assert.Null(model.Results.Report);
    }
    private sealed class Devices:IDevicesClient
    {
        private readonly Guid _id=Guid.NewGuid();
        public Task<DeviceApiResult<DeviceListResponse>> ListAsync(CancellationToken token)=>Task.FromResult(new DeviceApiResult<DeviceListResponse>(new([new(_id,"Agent","PC","Windows","0.6.0","127.0.0.1","active",DateTimeOffset.UtcNow,"/allowed")])));
        public Task<DeviceApiResult<EnrollmentResponse>> CreateAsync(string name,CancellationToken token)=>throw new NotImplementedException();
        public Task<DeviceApiResult<EnrollmentResponse>> ReissueAsync(Guid id,CancellationToken token)=>throw new NotImplementedException();
        public Task<DeviceApiResult<DeviceOperationResponse>> RevokeAsync(Guid id,CancellationToken token)=>throw new NotImplementedException();
    }
    private sealed class Jobs:IScanJobsClient
    {
        private readonly Guid _id=Guid.NewGuid();public string Status{get;init;}="completed";
        public bool Expired{get;set;}public int Cancels{get;private set;}public int Creates{get;private set;}
        public ScanReport Report{get;}=new();
        public Task<DeviceApiResult<ScanJobListResponse>> ListAsync(CancellationToken token)=>Task.FromResult(Expired?new DeviceApiResult<ScanJobListResponse>(null,"expired",true):new(new([new(_id,Guid.NewGuid(),"PC","/allowed/Demo",Status,DateTimeOffset.UtcNow,null,1,0)])));
        public Task<DeviceApiResult<ScanJobReportResponse>> ReportAsync(Guid id,CancellationToken token)=>Task.FromResult(new DeviceApiResult<ScanJobReportResponse>(new(id,Report)));
        public Task<DeviceApiResult<ScanJobStateResponse>> CreateAsync(CreateScanJobRequest request,CancellationToken token){Creates++;return Task.FromResult(new DeviceApiResult<ScanJobStateResponse>(new(_id,"queued")));}
        public Task<DeviceApiResult<ScanJobStateResponse>> CancelAsync(Guid id,CancellationToken token){Cancels++;return Task.FromResult(new DeviceApiResult<ScanJobStateResponse>(new(id,"cancelled")));}
    }
}
