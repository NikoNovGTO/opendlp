using OurDLP.Agent;
using OurDLP.Agent.Scanning;
using OurDLP.Contracts;
using OurDLP.Core.Scanning;
using OurDLP.Tests.Scanning;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class AgentScanCancellationTests
{
    [Theory][InlineData(false)][InlineData(true)]
    public async Task RemoteCancellationOrRevocationStopsTheRunningScanner(bool revoked)
    {
        using var files=new ScanFiles();var job=new ScanWork(Guid.NewGuid(),files.Request());var client=new CancellationClient(revoked);
        var processing=new AgentScanProcessing(new(new WaitingScanner(),files.Root),client,TimeSpan.FromMilliseconds(1));
        var result=await processing.ExecuteAsync(new(),job,default).WaitAsync(TimeSpan.FromSeconds(3));
        Assert.Equal(ScanCompletion.Cancelled,result.Report.Completion);Assert.Equal(revoked,result.Revoked);
    }
    private sealed class WaitingScanner:IFileScanner
    {
        public async Task<ScanReport> ScanAsync(ScanRequest request,IProgress<ScanProgress>? progress,CancellationToken token)
        {try{await Task.Delay(Timeout.Infinite,token);}catch(OperationCanceledException){}return new(){Completion=ScanCompletion.Cancelled};}
    }
    private sealed class CancellationClient(bool revoked):IAgentScanClient
    {
        public Task<AgentScanReply<ScanJobStateResponse>> StateAsync(AgentState state,Guid job,CancellationToken token)=>Task.FromResult(revoked?new AgentScanReply<ScanJobStateResponse>(null,401):new(new(job,"cancelled"),200));
        public Task<AgentScanReply<ScanWorkResponse>> NextAsync(AgentState state,string root,CancellationToken token)=>throw new NotImplementedException();
        public Task<AgentScanReply<ScanResultAcknowledgement>> SubmitAsync(AgentState state,Guid job,ScanReport report,CancellationToken token)=>throw new NotImplementedException();
    }
}
