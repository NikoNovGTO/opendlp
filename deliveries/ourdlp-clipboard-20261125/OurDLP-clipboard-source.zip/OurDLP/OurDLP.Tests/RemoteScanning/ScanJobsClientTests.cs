using System.Net;
using System.Net.Http.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Services.RemoteScanning;
using Xunit;

namespace OurDLP.Tests.RemoteScanning;

public sealed class ScanJobsClientTests
{
    [Fact]
    public async Task MismatchedReportIdentityIsNotDisplayedAsTheRequestedJob()
    {
        using var http=new HttpClient(new Handler());var client=new ScanJobsClient(http,"https://localhost");
        var result=await client.ReportAsync(Guid.NewGuid(),default);Assert.Null(result.Value);Assert.Contains("соответствует",result.Error);
    }
    private sealed class Handler:HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)=>
            Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=JsonContent.Create(new ScanJobReportResponse(Guid.NewGuid(),new()))});
    }
}
