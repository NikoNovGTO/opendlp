using System.IO.Compression;
using System.Text;

namespace OurDLP.Core.Samples;

public static class OfficeSampleDocuments
{
    private const string Rel = "http://schemas.openxmlformats.org/package/2006/relationships";
    private const string OfficeRel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/";
    private const string Types = "http://schemas.openxmlformats.org/package/2006/content-types";
    public static void Create(string folder)
    {
        if (!Directory.Exists(folder)) throw new ArgumentException("Сначала создайте тестовый каталог.");
        for (var current = new DirectoryInfo(folder); current is not null; current = current.Parent)
            if ((current.Attributes & FileAttributes.ReparsePoint) != 0) throw new UnauthorizedAccessException("Тестовый каталог не должен проходить через ссылку.");
        Word(Path.Combine(folder, "sample-document.docx"));
        Excel(Path.Combine(folder, "sample-table.xlsx"));
    }
    private static void Word(string path) => Write(path, new Dictionary<string, string>
    {
        ["[Content_Types].xml"] = $"<Types xmlns='{Types}'><Default Extension='rels' ContentType='application/vnd.openxmlformats-package.relationships+xml'/><Default Extension='xml' ContentType='application/xml'/><Override PartName='/word/document.xml' ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml'/><Override PartName='/word/header1.xml' ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml'/></Types>",
        ["_rels/.rels"] = $"<Relationships xmlns='{Rel}'><Relationship Id='main' Type='{OfficeRel}officeDocument' Target='word/document.xml'/></Relationships>",
        ["word/document.xml"] = "<w:document xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships'><w:body><w:p><w:r><w:t>OURDLP-</w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>TEST-0004</w:t></w:r></w:p><w:sectPr><w:headerReference w:type='default' r:id='header'/></w:sectPr></w:body></w:document>",
        ["word/_rels/document.xml.rels"] = $"<Relationships xmlns='{Rel}'><Relationship Id='header' Type='{OfficeRel}header' Target='header1.xml'/></Relationships>",
        ["word/header1.xml"] = "<w:hdr xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'><w:p><w:r><w:t>OURDLP-TEST-0005</w:t></w:r></w:p></w:hdr>"
    });
    private static void Excel(string path) => Write(path, new Dictionary<string, string>
    {
        ["[Content_Types].xml"] = $"<Types xmlns='{Types}'><Default Extension='rels' ContentType='application/vnd.openxmlformats-package.relationships+xml'/><Default Extension='xml' ContentType='application/xml'/><Override PartName='/xl/workbook.xml' ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml'/><Override PartName='/xl/worksheets/sheet1.xml' ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'/><Override PartName='/xl/sharedStrings.xml' ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml'/></Types>",
        ["_rels/.rels"] = $"<Relationships xmlns='{Rel}'><Relationship Id='main' Type='{OfficeRel}officeDocument' Target='xl/workbook.xml'/></Relationships>",
        ["xl/workbook.xml"] = "<workbook xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships'><sheets><sheet name='Demo' sheetId='1' r:id='sheet'/></sheets></workbook>",
        ["xl/_rels/workbook.xml.rels"] = $"<Relationships xmlns='{Rel}'><Relationship Id='sheet' Type='{OfficeRel}worksheet' Target='worksheets/sheet1.xml'/><Relationship Id='strings' Type='{OfficeRel}sharedStrings' Target='sharedStrings.xml'/></Relationships>",
        ["xl/sharedStrings.xml"] = "<sst xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main' count='1' uniqueCount='1'><si><t>OURDLP-TEST-0006</t></si></sst>",
        ["xl/worksheets/sheet1.xml"] = "<worksheet xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'><sheetData><row r='1'><c r='A1' t='s'><v>0</v></c><c r='B1' t='inlineStr'><is><r><t>OURDLP-</t></r><r><t>TEST-0007</t></r></is></c></row></sheetData></worksheet>"
    });
    private static void Write(string path, IReadOnlyDictionary<string, string> parts)
    {
        if (File.Exists(path)) return;
        var temporary = Path.Combine(Path.GetDirectoryName(path)!, Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write))
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Create))
                foreach (var pair in parts)
                { using var writer = new StreamWriter(archive.CreateEntry(pair.Key, CompressionLevel.Optimal).Open(), new UTF8Encoding(false)); writer.Write(pair.Value); }
            try { File.Move(temporary, path, false); } catch (IOException) when (File.Exists(path)) { }
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
}
