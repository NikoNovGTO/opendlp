using OurDLP.Core.Scanning;

namespace OurDLP.Core.Clipboard;

public sealed record ClipboardPolicy(Guid Id, int Version, string Name, bool Enabled,
    int MaxTextCharacters, IReadOnlyList<ScanRule> Rules);
public sealed record ClipboardRuleHit(Guid RuleId, int Count, bool CountLimited);
public sealed record ClipboardAnalysis(int TextCharacters, bool Truncated,
    IReadOnlyList<ClipboardRuleHit> Hits, IReadOnlyList<Guid> TimedOutRules)
{
    public bool HasEvent => Hits.Count != 0 || TimedOutRules.Count != 0 || Truncated;
}
