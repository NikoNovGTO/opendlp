using System.Text.RegularExpressions;

namespace OurDLP.Core.Clipboard;

public sealed class CompiledClipboardPolicy
{
    public ClipboardPolicy Definition { get; }
    private readonly IReadOnlyList<(Guid Id, Regex Expression)> _rules;
    public CompiledClipboardPolicy(ClipboardPolicy definition)
    {
        if (definition is null || definition.Id == Guid.Empty || definition.Version < 1
            || string.IsNullOrWhiteSpace(definition.Name) || definition.Name.Length > 100
            || definition.MaxTextCharacters is < 1024 or > 65536 || definition.Rules is null
            || definition.Rules.Count is < 1 or > 20 || definition.Rules.Any(rule => rule is null)
            || definition.Rules.Select(rule => rule.Id).Distinct().Count() != definition.Rules.Count)
            throw new ArgumentException("Некорректная политика буфера обмена.");
        if (System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(definition).Length > 128 * 1024) throw new ArgumentException("Политика превышает 128 КиБ.");
        var rules = new List<(Guid, Regex)>();
        foreach (var rule in definition.Rules)
        {
            if (rule.Id == Guid.Empty || string.IsNullOrWhiteSpace(rule.Name) || rule.Name.Length > 100
                || string.IsNullOrWhiteSpace(rule.Pattern) || rule.Pattern.Length > 2000)
                throw new ArgumentException("Задайте название правила и выражение до 2000 символов.");
            try { rules.Add((rule.Id, new(rule.Pattern, RegexOptions.Multiline | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100)))); }
            catch (ArgumentException) { throw new ArgumentException("Некорректное регулярное выражение политики."); }
        }
        Definition = definition with { Rules = definition.Rules.ToArray() }; _rules = rules;
    }
    public ClipboardAnalysis Analyze(ReadOnlySpan<char> text, bool truncated = false)
    {
        if (!Definition.Enabled) return new(0, false, [], []);
        if (text.Length > Definition.MaxTextCharacters) { text = text[..Definition.MaxTextCharacters]; truncated = true; }
        var hits = new List<ClipboardRuleHit>(); var timeouts = new List<Guid>();
        foreach (var rule in _rules)
        {
            var count = 0; var limited = false;
            try
            {
                foreach (var match in rule.Expression.EnumerateMatches(text))
                { if (count == 100) { limited = true; break; } count++; }
            }
            catch (RegexMatchTimeoutException) { timeouts.Add(rule.Id); limited = true; }
            if (count != 0) hits.Add(new(rule.Id, count, limited));
        }
        return new(text.Length, truncated, hits, timeouts);
    }
}
