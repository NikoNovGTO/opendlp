using System.Text;

namespace OurDLP.Core.Content;

internal sealed class OfficeText
{
    private readonly StringBuilder _text = new();
    public void Append(string value)
    { if (value.Length > OfficeBudget.MaxTextCharacters - _text.Length) throw OfficeBudget.Limit(); _text.Append(value); }
    public void Boundary() => Append("\n");
    public override string ToString() => _text.ToString();
}
