using System.Xml;

namespace OurDLP.Core.Content;

internal static class SpreadsheetStrings
{
    public static IReadOnlyList<string> Read(OfficePackage package, string workbook, IReadOnlyDictionary<string, OfficeRelationship> relationships)
    {
        var parts = relationships.Values.Where(row => OfficeNames.Relationship(row.Type, "sharedStrings")).ToArray();
        if (parts.Length == 0) return [];
        if (parts.Length != 1) throw OfficeBudget.Invalid();
        var values = new List<string>(); var characters = 0; SpreadsheetRichText? current = null;
        using var xml = package.Xml(package.Target(workbook, parts[0]), "sst", OfficeNames.Sheet);
        while (xml.Read())
        {
            var r = xml.Reader;
            if (r.NodeType == XmlNodeType.Element && r.LocalName == "si" && OfficeNames.Sheet(r.NamespaceURI))
            { if (current is not null) throw OfficeBudget.Invalid(); current = new(); if (r.IsEmptyElement) { Add(""); current = null; } }
            else if (r.NodeType == XmlNodeType.EndElement && r.LocalName == "si" && OfficeNames.Sheet(r.NamespaceURI))
            { if (current is null) throw OfficeBudget.Invalid(); Add(current.ToString()); current = null; }
            else current?.Read(r);
        }
        return values;
        void Add(string value)
        {
            if (values.Count >= 100_000 || value.Length > OfficeBudget.MaxTextCharacters - characters) throw OfficeBudget.Limit();
            characters += value.Length; values.Add(value);
        }
    }
}
