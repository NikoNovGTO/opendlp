namespace OurDLP.Core.Content;

internal static class OfficeNames
{
    public const string PackageRelationships = "http://schemas.openxmlformats.org/package/2006/relationships";
    public const string ContentTypes = "http://schemas.openxmlformats.org/package/2006/content-types";
    public const string WordMain = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";
    public const string SheetMain = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml";
    public static bool Word(string ns) => ns is "http://schemas.openxmlformats.org/wordprocessingml/2006/main" or "http://purl.oclc.org/ooxml/wordprocessingml/main";
    public static bool Sheet(string ns) => ns is "http://schemas.openxmlformats.org/spreadsheetml/2006/main" or "http://purl.oclc.org/ooxml/spreadsheetml/main";
    public static bool Relationship(string type, string name) => type == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/" + name
        || type == "http://purl.oclc.org/ooxml/officeDocument/relationships/" + name;
    public static string? RelationshipId(System.Xml.XmlReader reader) => reader.GetAttribute("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")
        ?? reader.GetAttribute("id", "http://purl.oclc.org/ooxml/officeDocument/relationships");
}
