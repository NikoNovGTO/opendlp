namespace OurDLP.Core.Content;

internal static class ScannableFile
{
    public static FileStream Open(string path, long maximum)
    {
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) throw new ScanContentException("link", "Ссылка пропущена.");
        var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        if (stream.Length <= maximum) return stream;
        stream.Dispose(); throw new ScanContentException("size", "Размер файла превышает выбранный предел.");
    }
}
