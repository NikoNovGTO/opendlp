namespace OurDLP.Core.Content;

internal static class OfficePartPath
{
    public static string Entry(string value)
    {
        var decoded = Uri.UnescapeDataString(value).TrimEnd('/');
        if (decoded.Length == 0 || decoded.Length > 2048 || decoded[0] == '/' || decoded.Contains('\\')
            || decoded.Contains(':') || decoded.Contains('%') || decoded.Contains('?') || decoded.Contains('#')
            || decoded.Any(char.IsControl) || decoded.Split('/').Any(part => part is ".." or "." or "")) throw OfficeBudget.Invalid();
        return decoded;
    }
    public static string Resolve(string source, string target)
    {
        if (target.Length > 2048 || target.Contains('\\') || target.Contains(':') || target.Contains('#') || target.Contains('?') || target.StartsWith("//", StringComparison.Ordinal))
            throw OfficeBudget.Invalid();
        var decoded = Uri.UnescapeDataString(target);
        var parts = target.StartsWith('/') || source.Length == 0 ? new List<string>() : source.Split('/').SkipLast(1).ToList();
        foreach (var part in decoded.Split('/'))
        {
            if (part is "" or ".") continue;
            if (part == "..") { if (parts.Count == 0) throw OfficeBudget.Invalid(); parts.RemoveAt(parts.Count - 1); }
            else parts.Add(part);
        }
        return Entry(string.Join('/', parts));
    }
    public static string Relationships(string source)
    {
        var slash = source.LastIndexOf('/');
        return slash < 0 ? "_rels/" + source + ".rels" : source[..(slash + 1)] + "_rels/" + source[(slash + 1)..] + ".rels";
    }
}
