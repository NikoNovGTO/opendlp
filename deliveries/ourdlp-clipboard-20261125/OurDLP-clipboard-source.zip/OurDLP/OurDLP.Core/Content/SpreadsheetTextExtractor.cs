using System.Xml;

namespace OurDLP.Core.Content;

internal sealed class SpreadsheetTextExtractor(OfficePackage package)
{
    public string Read()
    {
        var workbook = package.MainPart(OfficeNames.SheetMain); var relationships = package.Relationships(workbook);
        var sheets = new List<string>();
        using (var xml = package.Xml(workbook, "workbook", OfficeNames.Sheet))
        {
            while (xml.Read())
            {
                var r = xml.Reader;
                if (r.NodeType != XmlNodeType.Element || r.LocalName != "sheet" || !OfficeNames.Sheet(r.NamespaceURI)) continue;
                var id = OfficeNames.RelationshipId(r);
                if (id is null || !relationships.TryGetValue(id, out var relation)) throw OfficeBudget.Invalid();
                if (!OfficeNames.Relationship(relation.Type, "worksheet")) continue;
                if (sheets.Count >= 64) throw OfficeBudget.Limit();
                sheets.Add(package.Target(workbook, relation));
            }
        }
        if (sheets.Count != sheets.Distinct(StringComparer.OrdinalIgnoreCase).Count()) throw OfficeBudget.Invalid();
        var strings = SpreadsheetStrings.Read(package, workbook, relationships); var text = new OfficeText();
        foreach (var path in sheets) WorksheetText.Read(package, path, strings, text);
        return text.ToString();
    }
}
