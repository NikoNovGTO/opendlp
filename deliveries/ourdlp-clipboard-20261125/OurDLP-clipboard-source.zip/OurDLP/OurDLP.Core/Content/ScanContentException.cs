namespace OurDLP.Core.Content;

internal sealed class ScanContentException(string code, string message) : IOException(message)
{ public string Code { get; } = code; }
