using System.Xml;

namespace OurDLP.Core.Content;

internal sealed class WordTextExtractor(OfficePackage package)
{
    private readonly OfficeText _text = new();
    private readonly HashSet<string> _readReferences = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _headers = [], _footers = [], _footnotes = [], _endnotes = [], _comments = [];
    public string Read()
    {
        var main = package.MainPart(OfficeNames.WordMain);
        ReadPart(main, "document", null, null, collectReferences: true);
        var relationships = package.Relationships(main);
        foreach (var id in _headers) ReadReference(main, relationships, id, "header", "hdr");
        foreach (var id in _footers) ReadReference(main, relationships, id, "footer", "ftr");
        ReadNotes(main, relationships, "footnotes", "footnote", _footnotes);
        ReadNotes(main, relationships, "endnotes", "endnote", _endnotes);
        ReadNotes(main, relationships, "comments", "comment", _comments);
        return _text.ToString();
    }
    private void ReadReference(string main, IReadOnlyDictionary<string, OfficeRelationship> relationships, string id, string type, string root)
    {
        if (!relationships.TryGetValue(id, out var relation) || !OfficeNames.Relationship(relation.Type, type)) throw OfficeBudget.Invalid();
        var target = package.Target(main, relation);
        if (!_readReferences.Add(type + "/" + target)) return;
        _text.Boundary(); ReadPart(target, root, null, null, false);
    }
    private void ReadNotes(string main, IReadOnlyDictionary<string, OfficeRelationship> relationships, string type, string element, HashSet<string> used)
    {
        if (used.Count == 0) return;
        var matches = relationships.Values.Where(row => OfficeNames.Relationship(row.Type, type)).ToArray();
        if (matches.Length != 1) throw OfficeBudget.Invalid();
        _text.Boundary(); ReadPart(package.Target(main, matches[0]), type, element, used, false);
    }
    private void ReadPart(string path, string root, string? item, HashSet<string>? used, bool collectReferences)
    {
        using var xml = package.Xml(path, root, OfficeNames.Word); var active = item is null; var textDepth = -1; var body = root != "document";
        while (xml.Read())
        {
            var r = xml.Reader;
            if (r.NodeType == XmlNodeType.Element && OfficeNames.Word(r.NamespaceURI))
            {
                if (item is not null && r.LocalName == item)
                { var id = r.GetAttribute("id", r.NamespaceURI); active = id is not null && used!.Contains(id); if (active) _text.Boundary(); }
                if (!active) continue;
                if (r.LocalName == "body") body = true;
                if (collectReferences) Collect(r);
                if (r.LocalName is "t" or "delText") { if (!r.IsEmptyElement) textDepth = r.Depth; }
                else if (r.LocalName == "tab") _text.Append("\t");
                else if (r.LocalName is "br" or "cr") _text.Boundary();
                else if (r.LocalName == "altChunk") throw new ScanContentException("office-embedded", "DOCX содержит внедрённый текстовый документ altChunk. Его анализ пока не поддерживается; файл пропущен.");
            }
            else if (r.NodeType == XmlNodeType.EndElement && OfficeNames.Word(r.NamespaceURI))
            {
                if (r.Depth == textDepth) textDepth = -1;
                if (active && r.LocalName is "p" or "tc") _text.Boundary();
                if (r.LocalName == item) active = false;
            }
            else if (active && textDepth >= 0 && r.NodeType is XmlNodeType.Text or XmlNodeType.CDATA or XmlNodeType.SignificantWhitespace or XmlNodeType.Whitespace) _text.Append(r.Value);
        }
        if (!body) throw OfficeBudget.Invalid();
    }
    private void Collect(XmlReader r)
    {
        var relation = OfficeNames.RelationshipId(r); var id = r.GetAttribute("id", r.NamespaceURI);
        if (r.LocalName == "headerReference" && relation is not null) _headers.Add(relation);
        if (r.LocalName == "footerReference" && relation is not null) _footers.Add(relation);
        if (r.LocalName == "footnoteReference" && id is not null) _footnotes.Add(id);
        if (r.LocalName == "endnoteReference" && id is not null) _endnotes.Add(id);
        if (r.LocalName is "commentReference" or "commentRangeStart" && id is not null) _comments.Add(id);
    }
}
