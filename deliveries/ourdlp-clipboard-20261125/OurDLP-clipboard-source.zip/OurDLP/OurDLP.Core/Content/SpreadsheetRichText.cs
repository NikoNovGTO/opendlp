using System.Xml;

namespace OurDLP.Core.Content;

internal sealed class SpreadsheetRichText
{
    private readonly OfficeText _text = new();
    private int _textDepth = -1, _phoneticDepth = -1;
    public void Read(XmlReader r)
    {
        if (r.NodeType == XmlNodeType.Element && OfficeNames.Sheet(r.NamespaceURI))
        {
            if (r.LocalName == "rPh" && !r.IsEmptyElement) _phoneticDepth = r.Depth;
            if (r.LocalName == "t" && !r.IsEmptyElement && _phoneticDepth < 0) _textDepth = r.Depth;
        }
        else if (r.NodeType == XmlNodeType.EndElement)
        { if (r.Depth == _textDepth) _textDepth = -1; if (r.Depth == _phoneticDepth) _phoneticDepth = -1; }
        else if (_textDepth >= 0 && _phoneticDepth < 0 && r.NodeType is XmlNodeType.Text or XmlNodeType.CDATA or XmlNodeType.SignificantWhitespace or XmlNodeType.Whitespace) _text.Append(r.Value);
    }
    public override string ToString() => _text.ToString();
}
