using System.Xml;
using OurDLP.Core.Scanning;

namespace OurDLP.Core.Content;

internal static class DocumentTextReader
{
    public static string Read(string path, long maximum, CancellationToken token)
    {
        var extension = Path.GetExtension(path).ToLowerInvariant();
        if (extension is not (".docx" or ".xlsx")) return TextFileReader.Read(path, maximum, token);
        using var stream = ScannableFile.Open(path, maximum);
        try
        {
            token.ThrowIfCancellationRequested(); Span<byte> signature = stackalloc byte[8]; var read = stream.Read(signature); stream.Position = 0;
            if (read >= 8 && signature.SequenceEqual(new byte[] { 0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1 }))
                throw new ScanContentException("office-protected", "Файл Office в контейнере OLE: возможна защита паролем или старый формат. Файл пропущен.");
            var budget = new OfficeBudget(token); using var package = new OfficePackage(stream, budget);
            return extension == ".docx" ? new WordTextExtractor(package).Read() : new SpreadsheetTextExtractor(package).Read();
        }
        catch (XmlException error)
        {
            if (token.IsCancellationRequested) throw new OperationCanceledException(token);
            for (Exception? inner = error.InnerException; inner is not null; inner = inner.InnerException)
                if (inner is ScanContentException content) throw new ScanContentException(content.Code, content.Message);
            throw OfficeBudget.Invalid();
        }
        catch (InvalidDataException) { throw OfficeBudget.Invalid(); }
        catch (NotSupportedException) { throw OfficeBudget.Invalid(); }
        catch (UriFormatException) { throw OfficeBudget.Invalid(); }
    }
}
