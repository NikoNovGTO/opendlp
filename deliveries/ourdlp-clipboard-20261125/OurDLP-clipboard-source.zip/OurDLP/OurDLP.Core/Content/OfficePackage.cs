using System.IO.Compression;
using System.Xml;

namespace OurDLP.Core.Content;

internal sealed record OfficeRelationship(string Id, string Type, string Target, bool External);
internal sealed class OfficePackage : IDisposable
{
    private readonly ZipArchive _archive;
    private readonly OfficeBudget _budget;
    private readonly Dictionary<string, ZipArchiveEntry> _parts = new(StringComparer.OrdinalIgnoreCase);
    public OfficePackage(Stream stream, OfficeBudget budget)
    {
        _budget = budget; OfficeZipDirectory.Check(stream, budget); _archive = new(stream, ZipArchiveMode.Read, leaveOpen: true);
        try
        {
            if (_archive.Entries.Count > OfficeBudget.MaxEntries) throw OfficeBudget.Limit();
            long expanded = 0;
            foreach (var entry in _archive.Entries)
            {
                budget.Check(); var name = OfficePartPath.Entry(entry.FullName);
                if (entry.Length > OfficeBudget.MaxExpandedBytes - expanded) throw OfficeBudget.Limit();
                expanded += entry.Length;
                if (entry.Length > 64 * 1024 && entry.Length / (double)Math.Max(1, entry.CompressedLength) > 200) throw OfficeBudget.Limit();
                if (!_parts.TryAdd(name, entry)) throw OfficeBudget.Invalid();
            }
        }
        catch { _archive.Dispose(); throw; }
    }
    public OfficeXmlPart Xml(string path, string root, Func<string, bool> ns)
    {
        _budget.Check();
        if (!_parts.TryGetValue(OfficePartPath.Entry(path), out var entry)) throw OfficeBudget.Invalid();
        if (entry.Length > OfficeBudget.MaxPartBytes) throw OfficeBudget.Limit();
        var stream = new OfficeReadStream(entry.Open(), _budget);
        try { return new(stream, _budget, root, ns); } catch { stream.Dispose(); throw; }
    }
    public IReadOnlyDictionary<string, OfficeRelationship> Relationships(string source)
    {
        var name = source.Length == 0 ? "_rels/.rels" : OfficePartPath.Relationships(source);
        var result = new Dictionary<string, OfficeRelationship>(StringComparer.Ordinal);
        if (!_parts.ContainsKey(name)) return result;
        using var xml = Xml(name, "Relationships", ns => ns == OfficeNames.PackageRelationships);
        while (xml.Read())
        {
            var r = xml.Reader;
            if (r.NodeType != XmlNodeType.Element || r.LocalName != "Relationship" || r.NamespaceURI != OfficeNames.PackageRelationships) continue;
            var id = r.GetAttribute("Id"); var type = r.GetAttribute("Type"); var target = r.GetAttribute("Target");
            if (string.IsNullOrEmpty(id) || id.Length > 256 || type is null || type.Length > 512 || target is null || target.Length > 2048) throw OfficeBudget.Invalid();
            var mode = r.GetAttribute("TargetMode");
            if (mode is not null and not "External" and not "Internal") throw OfficeBudget.Invalid();
            if (!result.TryAdd(id, new(id, type, target, mode == "External"))) throw OfficeBudget.Invalid();
        }
        return result;
    }
    public string Target(string source, OfficeRelationship relation)
    {
        if (relation.External) throw new ScanContentException("office-external", "Часть документа ссылается на внешний ресурс. Сетевые и внешние файлы не открываются.");
        return OfficePartPath.Resolve(source, relation.Target);
    }
    public string MainPart(string expectedContentType)
    {
        var roots = Relationships("").Values.Where(row => OfficeNames.Relationship(row.Type, "officeDocument")).ToArray();
        if (roots.Length != 1) throw OfficeBudget.Invalid();
        var main = Target("", roots[0]); var found = false;
        using var xml = Xml("[Content_Types].xml", "Types", ns => ns == OfficeNames.ContentTypes);
        while (xml.Read())
        {
            var r = xml.Reader;
            if (r.NodeType != XmlNodeType.Element || r.LocalName != "Override" || r.NamespaceURI != OfficeNames.ContentTypes) continue;
            var name = r.GetAttribute("PartName"); if (name is null) throw OfficeBudget.Invalid();
            if (!OfficePartPath.Resolve("", name).Equals(main, StringComparison.OrdinalIgnoreCase)) continue;
            if (found || r.GetAttribute("ContentType") != expectedContentType) throw OfficeBudget.Invalid(); found = true;
        }
        if (!found) throw OfficeBudget.Invalid(); return main;
    }
    public void Dispose() => _archive.Dispose();
}
