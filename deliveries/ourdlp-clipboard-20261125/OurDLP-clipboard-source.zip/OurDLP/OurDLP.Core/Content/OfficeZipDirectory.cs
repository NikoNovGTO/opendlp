using System.Buffers.Binary;

namespace OurDLP.Core.Content;

internal static class OfficeZipDirectory
{
    // Check the real central-directory record count before ZipArchive allocates entry objects.
    public static void Check(Stream stream, OfficeBudget budget)
    {
        budget.Check(); var length = stream.Length;
        if (length < 22) throw OfficeBudget.Invalid();
        var tail = new byte[(int)Math.Min(length, 65_557)]; stream.Position = length - tail.Length; stream.ReadExactly(tail);
        var end = -1;
        for (var i = tail.Length - 22; i >= 0; i--)
            if (BinaryPrimitives.ReadUInt32LittleEndian(tail.AsSpan(i)) == 0x06054b50
                && i + 22 + BinaryPrimitives.ReadUInt16LittleEndian(tail.AsSpan(i + 20)) == tail.Length) { end = i; break; }
        if (end < 0) throw OfficeBudget.Invalid();
        var record = tail.AsSpan(end);
        var disk = BinaryPrimitives.ReadUInt16LittleEndian(record[4..]); var directoryDisk = BinaryPrimitives.ReadUInt16LittleEndian(record[6..]);
        var onDisk = BinaryPrimitives.ReadUInt16LittleEndian(record[8..]); var declared = BinaryPrimitives.ReadUInt16LittleEndian(record[10..]);
        var size = BinaryPrimitives.ReadUInt32LittleEndian(record[12..]); var offset = BinaryPrimitives.ReadUInt32LittleEndian(record[16..]);
        if (disk != 0 || directoryDisk != 0 || onDisk != declared || offset == uint.MaxValue || size == uint.MaxValue) throw OfficeBudget.Invalid();
        if (declared > OfficeBudget.MaxEntries || size > 4 * 1024 * 1024) throw OfficeBudget.Limit();
        var directoryEnd = (long)offset + size;
        if (directoryEnd != length - tail.Length + end) throw OfficeBudget.Invalid();
        stream.Position = offset; var actual = 0; Span<byte> header = stackalloc byte[46];
        while (stream.Position < directoryEnd)
        {
            budget.Check(); if (++actual > OfficeBudget.MaxEntries) throw OfficeBudget.Limit();
            if (directoryEnd - stream.Position < header.Length) throw OfficeBudget.Invalid(); stream.ReadExactly(header);
            if (BinaryPrimitives.ReadUInt32LittleEndian(header) != 0x02014b50) throw OfficeBudget.Invalid();
            var name = BinaryPrimitives.ReadUInt16LittleEndian(header[28..]); var extra = BinaryPrimitives.ReadUInt16LittleEndian(header[30..]);
            var comment = BinaryPrimitives.ReadUInt16LittleEndian(header[32..]);
            if (name == 0 || name > 8192) throw OfficeBudget.Invalid();
            var next = stream.Position + name + extra + comment;
            if (next > directoryEnd) throw OfficeBudget.Invalid(); stream.Position = next;
        }
        if (actual != declared) throw OfficeBudget.Invalid(); stream.Position = 0;
    }
}
