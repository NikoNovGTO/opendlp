using System.Globalization;
using System.Xml;

namespace OurDLP.Core.Content;

internal static class WorksheetText
{
    public static void Read(OfficePackage package, string path, IReadOnlyList<string> strings, OfficeText output)
    {
        using var xml = package.Xml(path, "worksheet", OfficeNames.Sheet);
        OfficeText? value = null; SpreadsheetRichText? inline = null; var cellDepth = -1; var valueDepth = -1; var type = "n";
        while (xml.Read())
        {
            var r = xml.Reader;
            if (r.NodeType == XmlNodeType.Element && OfficeNames.Sheet(r.NamespaceURI))
            {
                if (r.LocalName == "c")
                {
                    if (cellDepth >= 0) throw OfficeBudget.Invalid();
                    cellDepth = r.Depth; type = r.GetAttribute("t") ?? "n"; value = new(); inline = type == "inlineStr" ? new() : null;
                    if (r.IsEmptyElement) { FinishCell(); continue; }
                }
                else if (cellDepth >= 0 && r.LocalName == "v" && !r.IsEmptyElement) valueDepth = r.Depth;
            }
            if (cellDepth >= 0)
            {
                inline?.Read(r);
                if (valueDepth >= 0 && r.NodeType is XmlNodeType.Text or XmlNodeType.CDATA or XmlNodeType.SignificantWhitespace or XmlNodeType.Whitespace) value!.Append(r.Value);
                if (r.NodeType == XmlNodeType.EndElement)
                { if (r.Depth == valueDepth) valueDepth = -1; if (r.LocalName == "c" && r.Depth == cellDepth) FinishCell(); }
            }
            if (r.NodeType == XmlNodeType.EndElement && r.LocalName == "row" && OfficeNames.Sheet(r.NamespaceURI)) output.Boundary();
        }
        output.Boundary();
        void FinishCell()
        {
            var content = type == "inlineStr" ? inline!.ToString() : value!.ToString();
            if (type == "s" && content.Length != 0)
            {
                if (!int.TryParse(content.Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out var index) || index < 0 || index >= strings.Count) throw OfficeBudget.Invalid();
                content = strings[index];
            }
            else if (type is not ("n" or "b" or "d" or "e" or "str" or "inlineStr" or "s")) throw OfficeBudget.Invalid();
            output.Append(content); output.Append("\t"); cellDepth = valueDepth = -1; value = null; inline = null;
        }
    }
}
