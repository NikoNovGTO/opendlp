using System.Diagnostics;

namespace OurDLP.Core.Content;

internal sealed class OfficeBudget(CancellationToken token)
{
    public const int MaxEntries = 2048, MaxPartBytes = 8 * 1024 * 1024;
    public const int MaxExpandedBytes = 32 * 1024 * 1024, MaxTextCharacters = 2_000_000;
    private readonly Stopwatch _time = Stopwatch.StartNew();
    private long _read;
    private int _nodes;
    public void Check()
    {
        token.ThrowIfCancellationRequested();
        if (_time.Elapsed > TimeSpan.FromSeconds(10)) throw Limit();
    }
    public void Read(int bytes) { Check(); _read += bytes; if (_read > MaxExpandedBytes) throw Limit(); }
    public void Node() { Check(); if (++_nodes > 500_000) throw Limit(); }
    public static ScanContentException Limit() => new("office-limit", "Документ превысил предел распаковки, текста, XML или времени. Файл пропущен.");
    public static ScanContentException Invalid() => new("office-invalid", "Не удалось прочитать структуру DOCX/XLSX. Файл повреждён, защищён или имеет другой формат.");
}
