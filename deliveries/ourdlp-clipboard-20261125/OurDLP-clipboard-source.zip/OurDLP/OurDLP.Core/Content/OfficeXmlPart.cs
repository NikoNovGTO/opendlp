using System.Xml;

namespace OurDLP.Core.Content;

internal sealed class OfficeXmlPart : IDisposable
{
    private readonly OfficeBudget _budget;
    public XmlReader Reader { get; }
    public OfficeXmlPart(Stream stream, OfficeBudget budget, string root, Func<string, bool> allowedNamespace)
    {
        _budget = budget;
        Reader = XmlReader.Create(stream, new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, CloseInput = true,
            IgnoreComments = true, IgnoreProcessingInstructions = true,
            MaxCharactersInDocument = OfficeBudget.MaxPartBytes
        });
        try
        {
            budget.Check(); Reader.MoveToContent();
            if (Reader.LocalName != root || !allowedNamespace(Reader.NamespaceURI)) throw OfficeBudget.Invalid();
        }
        catch { Reader.Dispose(); throw; }
    }
    public bool Read()
    {
        _budget.Node(); var read = Reader.Read();
        if (read && Reader.Depth > 128) throw OfficeBudget.Limit(); return read;
    }
    public void Dispose() => Reader.Dispose();
}
