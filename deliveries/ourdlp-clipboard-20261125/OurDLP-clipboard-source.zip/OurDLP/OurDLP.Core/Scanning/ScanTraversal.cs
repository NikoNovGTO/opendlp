namespace OurDLP.Core.Scanning;

internal static class ScanTraversal
{
    public static IEnumerable<string> Files(ScanSession session)
    {
        var directories = new Stack<string>();
        directories.Push(session.Request.RootPath);
        while (directories.TryPop(out var directory) && session.CanContinue())
        {
            IEnumerator<string>? entries = null;
            try { entries = Directory.EnumerateFileSystemEntries(directory).GetEnumerator(); }
            catch (Exception error) when (IsFileError(error)) { session.Issue(directory, "access", "Не удалось открыть каталог."); }
            if (entries is null) continue;
            using (entries)
            {
                while (session.CanContinue())
                {
                    string path;
                    try { if (!entries.MoveNext()) break; path = entries.Current; }
                    catch (Exception error) when (IsFileError(error)) { session.Issue(directory, "access", "Не удалось перечислить содержимое каталога."); break; }
                    if (session.EntriesVisited >= session.Request.Limits.MaxEntries)
                    { session.Stop(ScanCompletion.LimitReached, "Достигнут предел перечисленных файлов и папок."); yield break; }
                    session.EntriesVisited++;
                    var isFile = false;
                    try
                    {
                        var attributes = File.GetAttributes(path);
                        if (!ScanPaths.IsInside(session.Request.RootPath, path) || (attributes & FileAttributes.ReparsePoint) != 0)
                        { session.FilesSkipped++; session.Issue(path, "link", "Ссылка или reparse point пропущены."); continue; }
                        if (ScanPaths.IsExcluded(session.Request, path)) { session.FilesSkipped++; continue; }
                        if ((attributes & FileAttributes.Directory) != 0) { directories.Push(path); continue; }
                        if (!ScanPaths.IsSupportedFile(path)) { session.FilesSkipped++; continue; }
                        isFile = true;
                    }
                    catch (Exception error) when (IsFileError(error)) { session.FilesSkipped++; session.Issue(path, "access", "Не удалось прочитать сведения о файле."); }
                    if (isFile) yield return path;
                }
            }
        }
    }
    public static bool IsFileError(Exception error) => error is IOException or UnauthorizedAccessException or System.Security.SecurityException;
}
