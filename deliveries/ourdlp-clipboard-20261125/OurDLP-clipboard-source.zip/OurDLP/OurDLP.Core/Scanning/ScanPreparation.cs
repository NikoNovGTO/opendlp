using System.Text.RegularExpressions;

namespace OurDLP.Core.Scanning;

internal sealed record PreparedRule(ScanRule Definition, Regex Expression);
internal sealed record PreparedScan(ScanRequest Request, IReadOnlyList<PreparedRule> Rules);
internal static class ScanPreparation
{
    public static PreparedScan Prepare(ScanRequest request)
    {
        request = ScanRequestValidator.NormalizeDefinition(request);
        if (!Path.IsPathFullyQualified(request.RootPath)) throw new ArgumentException("Выберите полный путь к тестовой папке.");
        var root = Path.GetFullPath(request.RootPath);
        if (!Directory.Exists(root)) throw new ArgumentException("Выбранная папка не существует или недоступна.");
        for (var directory = new DirectoryInfo(root); directory is not null; directory = directory.Parent)
            if ((directory.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new ArgumentException("Для проверки выберите обычную папку без ссылок или junction в пути.");
        var rules = request.Rules.Select(rule => new PreparedRule(rule,
            new Regex(rule.Pattern, RegexOptions.CultureInvariant | RegexOptions.Multiline, TimeSpan.FromMilliseconds(100)))).ToArray();
        return new(request with { RootPath = root }, rules);
    }
}
