using System.Text.RegularExpressions;

namespace OurDLP.Core.Scanning;

public static class ScanRequestValidator
{
    public static ScanRequest NormalizeDefinition(ScanRequest request)
    {
        if (request is null || request.Limits is not { } limits || request.Rules is null || request.ExcludedDirectories is null)
            throw new ArgumentException("Параметры проверки не заданы.");
        if (limits.MaxFileBytes is < 1 or > 20 * 1024 * 1024 || limits.MaxFiles is < 1 or > 5_000
            || limits.MaxEntries is < 1 or > 20_000 || limits.MaxFindings is < 1 or > 1_000
            || limits.MaxIssues is < 1 or > 100 || limits.MaxMatchesPerFile is < 1 or > 1_000
            || limits.MaxDuration < TimeSpan.FromSeconds(1) || limits.MaxDuration > TimeSpan.FromMinutes(2))
            throw new ArgumentException("Пределы проверки превышают допустимые значения.");
        if (string.IsNullOrWhiteSpace(request.RootPath) || request.RootPath.Length > 1024 || request.RootPath.Contains('\0'))
            throw new ArgumentException("Укажите путь к папке до 1024 символов.");
        if (request.Rules.Count is < 1 or > 20 || request.Rules.Any(rule => rule is null)
            || request.Rules.Select(rule => rule.Id).Distinct().Count() != request.Rules.Count)
            throw new ArgumentException("Нужно от 1 до 20 правил с уникальными идентификаторами.");
        foreach (var rule in request.Rules)
        {
            if (rule.Id == Guid.Empty || string.IsNullOrWhiteSpace(rule.Name) || rule.Name.Length > 100
                || string.IsNullOrWhiteSpace(rule.Pattern) || rule.Pattern.Length > 2_000)
                throw new ArgumentException("Укажите название правила до 100 символов и выражение до 2000 символов.");
            try { _ = new Regex(rule.Pattern, RegexOptions.CultureInvariant | RegexOptions.Multiline, TimeSpan.FromMilliseconds(100)); }
            catch (ArgumentException) { throw new ArgumentException("Некорректное регулярное выражение. Исправьте правило до запуска проверки."); }
        }
        if (request.ExcludedDirectories.Count > 100) throw new ArgumentException("Допускается не более 100 исключений.");
        var excluded = request.ExcludedDirectories.Select(NormalizeExclusion).Distinct(ScanPaths.Comparison).ToArray();
        return request with { RootPath = request.RootPath.Trim(), Rules = request.Rules.ToArray(), ExcludedDirectories = excluded };
    }
    private static string NormalizeExclusion(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.Length > 1024 || Path.IsPathRooted(path) || path.StartsWith('\\') || path.Contains(':') || path.Contains('\0'))
            throw new ArgumentException("Исключения должны быть путями папок относительно выбранного каталога.");
        var parts = path.Replace('\\', '/').Trim('/').Split('/');
        if (parts.Any(part => part is ".." or "." or "")) throw new ArgumentException("В исключениях нельзя использовать переходы .. или пустые части пути.");
        return Path.Combine(parts);
    }
}
