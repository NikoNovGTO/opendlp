using OurDLP.Core.Content;
using System.Buffers;
using System.Text;

namespace OurDLP.Core.Scanning;

internal static class TextFileReader
{
    public static string Read(string path, long maximum, CancellationToken token)
    {
        using var stream = ScannableFile.Open(path, maximum);
        var buffer = ArrayPool<byte>.Shared.Rent(checked((int)maximum + 1));
        try
        {
            var read = 0;
            while (read <= maximum)
            {
                token.ThrowIfCancellationRequested();
                var count = stream.Read(buffer, read, Math.Min(64 * 1024, (int)maximum + 1 - read));
                if (count == 0) break;
                read += count;
            }
            if (read > maximum) throw new InvalidDataException("size");
            return Decode(buffer.AsSpan(0, read));
        }
        finally { ArrayPool<byte>.Shared.Return(buffer, clearArray: true); }
    }
    private static string Decode(ReadOnlySpan<byte> bytes)
    {
        if (bytes.StartsWith(new byte[] { 0xff, 0xfe, 0, 0 }) || bytes.StartsWith(new byte[] { 0, 0, 0xfe, 0xff })) throw new InvalidDataException("encoding");
        string text;
        if (bytes.StartsWith(new byte[] { 0xff, 0xfe })) text = new UnicodeEncoding(false, false, true).GetString(bytes[2..]);
        else if (bytes.StartsWith(new byte[] { 0xfe, 0xff })) text = new UnicodeEncoding(true, false, true).GetString(bytes[2..]);
        else text = new UTF8Encoding(false, true).GetString(bytes.StartsWith(new byte[] { 0xef, 0xbb, 0xbf }) ? bytes[3..] : bytes);
        if (text.Contains('\0')) throw new InvalidDataException("encoding");
        return text;
    }
}
