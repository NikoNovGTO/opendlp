﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Install','Stop','Remove')][string]$Mode='Install')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$install=Join-Path $env:ProgramFiles 'OurDLP\Agent'
$exe=Join-Path $install 'OurDLP.Session.exe'
$command='"'+$exe+'"'
$name='OurDLP.Session'
$shortcutPath=Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'OurDLP - Clipboard Monitor.lnk'
if($Mode -in @('Stop','Remove')){
    foreach($process in @(Get-Process -Name 'OurDLP.Session' -ErrorAction SilentlyContinue)){
        if($process.Path -and [string]::Equals($process.Path,$exe,[StringComparison]::OrdinalIgnoreCase)){
            Stop-Process -Id $process.Id -Force
            $process.WaitForExit(10000) | Out-Null
        }
    }
    if($Mode -eq 'Stop'){return}
}
$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)
try {
    $run=$base.CreateSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
    try {
        $existing=$run.GetValue($name)
        if($null -ne $existing -and $existing -ne $command){throw 'OurDLP startup entry has an unexpected value. Nothing was overwritten.'}
        $shell=New-Object -ComObject WScript.Shell
        if(Test-Path -LiteralPath $shortcutPath){
            $shortcut=$shell.CreateShortcut($shortcutPath)
            if(-not [string]::Equals($shortcut.TargetPath,$exe,[StringComparison]::OrdinalIgnoreCase)){throw 'OurDLP shortcut points to another executable. Nothing was overwritten.'}
        }
        if($Mode -eq 'Remove'){
            $run.DeleteValue($name,$false)
            if(Test-Path -LiteralPath $shortcutPath){Remove-Item -LiteralPath $shortcutPath}
            Write-Host 'Clipboard component stopped; OurDLP autorun and shortcut removed. Encrypted per-user metadata caches preserved.'
        } else {
            if(-not (Test-Path -LiteralPath $exe)){throw 'Published OurDLP.Session.exe was not found. Update the agent package first.'}
            foreach($path in @((Join-Path $env:ProgramFiles 'OurDLP'),$install,$exe)){
                if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Component installation must not contain links.'}
            }
            $shortcut=$shell.CreateShortcut($shortcutPath)
            $shortcut.TargetPath=$exe;$shortcut.WorkingDirectory=$install
            $shortcut.Description='OurDLP: clipboard observation status and exit'
            $shortcut.Save()
            $run.SetValue($name,$command,[Microsoft.Win32.RegistryValueKind]::String)
            Write-Host 'Clipboard monitor starts at next user sign-in. To start now, open OurDLP - Clipboard Monitor from Start as the normal user. A tray icon shows its status.'
        }
    } finally {$run.Dispose()}
} finally {$base.Dispose()}
