﻿#Requires -RunAsAdministrator
[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='High')]
param()
$ErrorActionPreference='Stop'
$service=Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'"
if(-not $service){Write-Host 'OurDLP.Agent service not found.';return}
if($PSCmdlet.ShouldProcess('OurDLP.Agent','Stop and remove the service; keep protected state and certificate trust')){
    & (Join-Path $PSScriptRoot 'Configure-SessionMonitor.ps1') -Mode Remove
    Stop-Service OurDLP.Agent -ErrorAction SilentlyContinue
    (Get-Service OurDLP.Agent).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(20))
    $result=$service | Invoke-CimMethod -MethodName Delete
    if($result.ReturnValue -ne 0){throw ('Could not remove service: '+$result.ReturnValue)}
    Write-Host 'Service removed. State, binary folder and public certificate trust preserved for explicit inspection. Revoke the device on the server.'
}
