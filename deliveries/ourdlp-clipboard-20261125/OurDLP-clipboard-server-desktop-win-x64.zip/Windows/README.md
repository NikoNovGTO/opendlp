# OurDLP Server + Desktop 0.8, Windows x64

Нужны .NET 10 ASP.NET Core Runtime и Desktop Runtime x64; SDK для мастеров настройки.

Остановите старый сервер/консоль, распакуйте в новую папку. Для существующей базы выполните tools/Apply-DatabaseMigrations.ps1, затем запустите Server/OurDLP.Server.exe и Desktop/OurDLP.Desktop.exe. User Secrets имеют прежний ID; не создавайте администратора повторно. Новая база: DATABASE-SETUP.md.

Для фонового буфера нужен отдельный OurDLP-clipboard-agent-win-x64.zip: Update-Agent.ps1, затем OurDLP - Clipboard Monitor из Пуска обычным пользователем. Политики/назначение/тест на одном ПК — **CLIPBOARD.md**.

Режим наблюдения без блокировки и без передачи содержимого буфера. Сам захват/трей и служба ещё требуют Windows-теста. Автоматические проверки: VALIDATION.md.
