using OurDLP.Desktop.Services;
using Xunit;

namespace OurDLP.Tests;

[Collection("Live server")]
public sealed class LiveHttpsTests
{
    [LiveHttpsFact]
    [Trait("Category", "Integration")]
    public async Task UsesStandardTlsValidationAgainstRunningServer()
    {
        var address = Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var expectedTrusted = Environment.GetEnvironmentVariable("OURDLP_EXPECT_TLS_TRUSTED") == "1";
        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false })
        {
            Timeout = TimeSpan.FromSeconds(5),
            MaxResponseContentBufferSize = 64 * 1024
        };
        var result = await new ServerApiClient(http).ProbeAsync(address, default);
        Assert.Equal(expectedTrusted, result.Available);
        if (expectedTrusted) Assert.Equal("0.7.0", result.Version);
        else Assert.Contains("сертификат", result.Details);
    }
    [LiveHttpsFact]
    [Trait("Category", "Integration")]
    public async Task RealClientDistinguishesApiFromDatabaseReadiness()
    {
        var address = Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var trusted = Environment.GetEnvironmentVariable("OURDLP_EXPECT_TLS_TRUSTED") == "1";
        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false })
        { Timeout = TimeSpan.FromSeconds(5), MaxResponseContentBufferSize = 64 * 1024 };
        var client = new ServerReadinessClient(new ServerApiClient(http), new DatabaseApiClient(http));
        var result = await client.ProbeAsync(address, default);
        Assert.Equal(trusted, result.Available);
        if (trusted)
            Assert.Equal(Environment.GetEnvironmentVariable("OURDLP_EXPECT_DATABASE_STATUS") ?? "ready", result.Database!.Status);
        else
            Assert.Null(result.Database);
    }

}

public sealed class LiveHttpsFactAttribute : FactAttribute
{
    public LiveHttpsFactAttribute()
    {
        if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")))
            Skip = "Requires an explicitly configured live test server and certificate trust.";
    }
}
