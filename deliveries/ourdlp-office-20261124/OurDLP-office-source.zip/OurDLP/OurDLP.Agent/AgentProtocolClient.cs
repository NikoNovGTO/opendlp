using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Runtime.InteropServices;
using System.Text.Json;
using OurDLP.Contracts;

namespace OurDLP.Agent;

public sealed record AgentCallResult(AgentAcknowledgement? Response, int StatusCode)
{
    public bool Succeeded => Response is not null;
    public bool AccessDenied => StatusCode is 401 or 403;
}

public sealed class AgentProtocolClient(HttpClient http)
{
    public static AgentHeartbeatRequest Metadata() => new(Environment.MachineName, RuntimeInformation.OSDescription, "0.7.0");
    public Task<AgentCallResult> EnrollAsync(AgentState state, string code, CancellationToken token)
    {
        var metadata = Metadata();
        return SendAsync(state, "/api/agent/enroll", new AgentEnrollmentRequest
        { Code = code, Token = state.Token, HostName = metadata.HostName, OperatingSystem = metadata.OperatingSystem, AgentVersion = metadata.AgentVersion }, false, token);
    }
    public Task<AgentCallResult> HeartbeatAsync(AgentState state, CancellationToken token) =>
        SendAsync(state, "/api/agent/heartbeat", Metadata(), true, token);

    private async Task<AgentCallResult> SendAsync<T>(AgentState state, string path, T body, bool authenticate, CancellationToken token)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, AgentAddress.Normalize(state.ServerAddress) + path)
        { Content = JsonContent.Create(body) };
        if (authenticate) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", state.Token);
        try
        {
            using var response = await http.SendAsync(request, token);
            if (!response.IsSuccessStatusCode) return new(null, (int)response.StatusCode);
            var acknowledgement = await response.Content.ReadFromJsonAsync<AgentAcknowledgement>(token);
            return acknowledgement is { DeviceId: var id } && id != Guid.Empty && acknowledgement.ServerTimeUtc != default
                ? new(acknowledgement, (int)response.StatusCode) : new(null, 502);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return new(null, 504); }
        catch (Exception exception) when (exception is HttpRequestException or JsonException or NotSupportedException) { return new(null, 503); }
    }
}
