# Структура OurDLP 0.7

Шесть проектов: Core (общий сканер), Contracts (версионируемые сообщения с моделями Core), Server (Identity/PostgreSQL/API), Desktop (WPF), Agent (служба Windows) и Tests. Вручную добавлять проекты к решению не требуется.

Сервер: ScanJobCommands создаёт/отменяет задания, ScanJobQueries читает историю, ScanWorkDelivery выдаёт работу, ScanReportValidation проверяет состав отчёта, ScanResultReceiver сохраняет его идемпотентно. Все мутации сериализованы блокировкой устройства, включая отзыв регистрации. ScanJob хранит снимок параметров и metadata JSONB; отдельный каталог политик ещё не реализован.

Агент: AgentWorker отправляет heartbeat. Независимый AgentScanWorker вызывает AgentScanCycle. Цикл сохраняет работу до анализа, AgentScanExecutor ограничивает область и вызывает Core, AgentScanProcessing следит за отменой, ScanReportTransmission ограничивает размер. WindowsAgentScanQueue и WindowsAgentStateStore используют WindowsAgentFiles: атомарные DPAPI-файлы с проверкой ACL. Сохраняется purpose и формат прежнего state.bin.

Desktop: RemoteScansViewModel управляет устройством, параметрами, очередью и командами; ScanJobRow локализует состояния, ScanJobsClient работает по административной cookie. Готовый отчёт показывает прежний ScanResultsViewModel, CSV делает прежний ScanCsvExporter. Модуль локальной проверки 0.5 сохранён отдельно.

Сетевая логика, хранение, анализ, представление и жизненный цикл разделены. Windows-специфичные действия находятся в Agent/WindowsAgentFiles и tools, переносимая логика проверяется на Linux.

Модуль Core/Content разделён: DocumentTextReader выбирает формат, OfficeZipDirectory проверяет центральный каталог до ZipArchive, OfficePackage контролирует части/связи, OfficeBudget/OfficeReadStream/OfficeXmlPart ограничивают ресурсы. WordTextExtractor читает Word-части; SpreadsheetTextExtractor/WorksheetText/SpreadsheetStrings извлекают Excel. OfficeSampleDocuments создаёт отдельные демонстрационные пакеты без замены существующих файлов. Контракты отчёта, БД и формат защищённой очереди не менялись.
