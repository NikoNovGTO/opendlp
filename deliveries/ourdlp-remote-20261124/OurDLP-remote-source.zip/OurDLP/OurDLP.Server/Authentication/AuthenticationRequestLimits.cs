using Microsoft.AspNetCore.Http.Features;

namespace OurDLP.Server.Authentication;

public sealed class AuthenticationRequestLimits(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.StartsWithSegments("/api/auth")
            || context.Request.Path.StartsWithSegments("/api/agent") || context.Request.Path.StartsWithSegments("/api/devices") || context.Request.Path.StartsWithSegments("/api/scans"))
        {
            if (!context.Request.IsHttps)
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsJsonAsync(new OurDLP.Contracts.AuthMessage("Для защищённого обмена требуется HTTPS."));
                return;
            }
            var size = context.Features.Get<IHttpMaxRequestBodySizeFeature>();
            if (size is { IsReadOnly: false }) size.MaxRequestBodySize = context.Request.Path.StartsWithSegments("/api/agent/scans")
                && context.Request.Path.Value!.EndsWith("/result", StringComparison.Ordinal) ? 4 * 1024 * 1024 : 16 * 1024;
        }
        await next(context);
    }
}
