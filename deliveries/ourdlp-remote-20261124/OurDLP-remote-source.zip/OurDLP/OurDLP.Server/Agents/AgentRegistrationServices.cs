using OurDLP.Server.Scanning;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace OurDLP.Server.Agents;

public static class AgentRegistrationServices
{
    public static IServiceCollection AddOurDlpAgents(this IServiceCollection services)
    {
        services.TryAddSingleton(TimeProvider.System);
        services.AddScoped<DeviceRegistry>();
        services.AddScoped<AgentRegistration>();
        services.AddScoped<ScanJobQueries>(); services.AddScoped<ScanJobCommands>();
        services.AddScoped<ScanWorkDelivery>(); services.AddScoped<ScanResultReceiver>();
        services.AddAuthentication().AddScheme<AuthenticationSchemeOptions, AgentAuthenticationHandler>(AgentAuthenticationHandler.SchemeName, _ => { });
        services.AddAuthorizationBuilder().AddPolicy(AgentAuthenticationHandler.PolicyName,
            policy => policy.AddAuthenticationSchemes(AgentAuthenticationHandler.SchemeName).RequireAuthenticatedUser().RequireClaim("device_id"));
        services.AddRateLimiter(options => options.AddPolicy("agent-enrollment", context =>
            RateLimitPartition.GetFixedWindowLimiter(context.Connection.RemoteIpAddress?.ToString() ?? "local", _ =>
                new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 })));
        return services;
    }
}
