using OurDLP.Server.Agents;
using OurDLP.Server.Authentication;
using OurDLP.Server.Data;
using OurDLP.Server.Endpoints;

var migrate = args.Contains("--migrate-database", StringComparer.Ordinal);
var bootstrap = args.Contains("--create-administrator", StringComparer.Ordinal);
var builder = WebApplication.CreateBuilder(args.Where(argument => argument is not "--migrate-database" and not "--create-administrator").ToArray());
builder.Logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", migrate ? LogLevel.Critical : LogLevel.Warning);
builder.Services.AddProblemDetails();
builder.Services.AddOurDlpDatabase(builder.Configuration);
builder.Services.AddOurDlpAuthentication(builder.Configuration);
builder.Services.AddOurDlpAgents();

var app = builder.Build();
if (migrate || bootstrap)
{
    try
    {
        Environment.ExitCode = migrate ? await DatabaseMigrationRunner.RunAsync(app.Services)
            : await AdministratorBootstrap.RunAsync(app.Services);
    }
    catch (Exception exception)
    {
        Console.Error.WriteLine($"Локальная команда не выполнена ({exception.GetType().Name}). Проверьте PostgreSQL и конфигурацию.");
        Environment.ExitCode = 1;
    }
    return;
}
app.UseExceptionHandler();
app.UseMiddleware<AuthenticationRequestLimits>();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.MapServerStatusEndpoints();
app.MapDatabaseHealthEndpoints();
app.MapAuthenticationEndpoints();
app.MapDeviceEndpoints();
app.MapAgentEndpoints();
app.MapScanEndpoints();
app.Run();

public partial class Program { }
