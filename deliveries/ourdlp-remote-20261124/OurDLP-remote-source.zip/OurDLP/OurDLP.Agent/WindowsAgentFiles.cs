using System.Runtime.Versioning;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;

namespace OurDLP.Agent;

[SupportedOSPlatform("windows")]
public sealed class WindowsAgentFiles
{
    private readonly string _directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OurDLP", "Agent");
    public async Task<T?> ReadAsync<T>(string file, string purpose, int maximum, CancellationToken token) where T : class
    {
        CheckPermissions(); var path = Path.Combine(_directory, file);
        if (!File.Exists(path)) return null;
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) throw new UnauthorizedAccessException();
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete);
        if (stream.Length > maximum + 64 * 1024) throw new InvalidDataException("Защищённый файл превышает предел.");
        var encrypted = new byte[checked((int)stream.Length)]; await stream.ReadExactlyAsync(encrypted, token);
        var plain = ProtectedData.Unprotect(encrypted, Encoding.UTF8.GetBytes(purpose), DataProtectionScope.LocalMachine);
        try { if (plain.Length > maximum) throw new InvalidDataException(); return JsonSerializer.Deserialize<T>(plain) ?? throw new InvalidDataException(); }
        finally { CryptographicOperations.ZeroMemory(plain); }
    }
    public async Task SaveAsync<T>(string file, string purpose, int maximum, T value, CancellationToken token)
    {
        CheckPermissions(); var plain = JsonSerializer.SerializeToUtf8Bytes(value); byte[] encrypted;
        try
        {
            if (plain.Length > maximum) throw new InvalidDataException("Защищённый файл превышает предел.");
            encrypted = ProtectedData.Protect(plain, Encoding.UTF8.GetBytes(purpose), DataProtectionScope.LocalMachine);
        }
        finally { CryptographicOperations.ZeroMemory(plain); }
        var temporary = Path.Combine(_directory, Guid.NewGuid().ToString("N") + ".tmp");
        try { await File.WriteAllBytesAsync(temporary, encrypted, token); token.ThrowIfCancellationRequested(); File.Move(temporary, Path.Combine(_directory, file), true); }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    public void Delete(string file) { CheckPermissions(); File.Delete(Path.Combine(_directory, file)); }
    public void Archive(string file)
    {
        CheckPermissions(); var path = Path.Combine(_directory, file);
        if (File.Exists(path)) File.Move(path, Path.Combine(_directory, "scan-archive-" + Guid.NewGuid().ToString("N") + ".bin"));
        foreach (var old in new DirectoryInfo(_directory).EnumerateFiles("scan-archive-*.bin").OrderByDescending(row => row.LastWriteTimeUtc).Skip(3)) old.Delete();
    }
    private void CheckPermissions()
    {
        if (!Directory.Exists(_directory)) throw new InvalidOperationException("Сначала выполните Install-Agent.ps1 от имени администратора.");
        var allowed = new HashSet<string>
        {
            new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null).Value,
            new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null).Value,
            ((SecurityIdentifier)new NTAccount("NT SERVICE", "OurDLP.Agent").Translate(typeof(SecurityIdentifier))).Value
        };
        foreach (var directory in new[] { Directory.GetParent(_directory)!.FullName, _directory })
        {
            if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0) throw new UnauthorizedAccessException("Недопустимая ссылка в каталоге агента.");
            var security = new DirectoryInfo(directory).GetAccessControl(AccessControlSections.Access | AccessControlSections.Owner);
            if (!allowed.Contains(security.GetOwner(typeof(SecurityIdentifier))?.Value ?? string.Empty)) throw new UnauthorizedAccessException("Небезопасный владелец каталога агента.");
            foreach (FileSystemAccessRule rule in security.GetAccessRules(true, true, typeof(SecurityIdentifier)))
                if (rule.AccessControlType == AccessControlType.Allow && !allowed.Contains(rule.IdentityReference.Value))
                    throw new UnauthorizedAccessException("Каталог агента доступен посторонним учётным записям.");
        }
    }
}
