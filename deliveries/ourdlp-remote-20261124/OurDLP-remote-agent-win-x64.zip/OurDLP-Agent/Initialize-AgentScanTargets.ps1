#Requires -RunAsAdministrator
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=Join-Path $env:ProgramData 'OurDLP\ScanTargets'
$parent=Split-Path $root -Parent
$admins=[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
$system=[Security.Principal.SecurityIdentifier]::new('S-1-5-18')
$agent=([Security.Principal.NTAccount]::new('NT SERVICE','OurDLP.Agent')).Translate([Security.Principal.SecurityIdentifier])
foreach($path in @($parent,$root)) {
    if(Test-Path -LiteralPath $path){
        if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Scan target folders must not be links or junctions.'}
        $current=Get-Acl -LiteralPath $path
        if($current.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin @($admins.Value,$system.Value,$agent.Value)){throw 'Unexpected owner of scan target folder.'}
        foreach($rule in $current.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])){
            if($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin @($admins.Value,$system.Value,$agent.Value)){throw 'Existing scan folder is accessible to other users. Inspect its ACL before retrying.'}
        }
    }
}
if(-not (Test-Path -LiteralPath $parent)){throw 'Install the OurDLP.Agent service first.'}
New-Item -ItemType Directory -Path $root -Force | Out-Null
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetAccessRuleProtection($true,$false);$acl.SetOwner($admins)
foreach($sid in @($admins,$system)){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit, ObjectInherit','None','Allow'))}
$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($agent,'ReadAndExecute','ContainerInherit, ObjectInherit','None','Allow'))
Set-Acl -LiteralPath $root -AclObject $acl
$demo=Join-Path $root 'Demo'
if(Test-Path -LiteralPath $demo){Write-Host ('Existing Demo preserved: '+$demo);return}
New-Item -ItemType Directory -Path (Join-Path $demo 'excluded') | Out-Null
[IO.File]::WriteAllText((Join-Path $demo 'sample.txt'),'OURDLP-TEST-0001 and OURDLP-TEST-0002',[Text.UTF8Encoding]::new($true))
[IO.File]::WriteAllText((Join-Path $demo 'list.csv'),"id;marker`r`n1;OURDLP-TEST-0003",[Text.UTF8Encoding]::new($true))
[IO.File]::WriteAllText((Join-Path $demo 'clean.log'),'No marker in this file.',[Text.UTF8Encoding]::new($true))
[IO.File]::WriteAllText((Join-Path $demo 'excluded\ignored.txt'),'OURDLP-TEST-9999',[Text.UTF8Encoding]::new($true))
Write-Host ('Agent read-only scan root: '+$root)
Write-Host ('Demo prepared: '+$demo+' (3 matches in 2 files)')
