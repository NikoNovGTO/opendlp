#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$ServerAddress = '',
    [string]$ServerCertificatePath = '',
    [string]$ExpectedCertificateSha256 = '',
    [string]$PayloadPath = '',
    [Security.SecureString]$Code,
    [switch]$ReEnroll
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$serviceName='OurDLP.Agent'
if(-not $ServerAddress){$ServerAddress=Read-Host 'LAN HTTPS server address (not localhost on PC 2)'}
$uri=[Uri]$ServerAddress
if($uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/'){throw 'Use a root HTTPS server address.'}
if(-not $ServerCertificatePath){$ServerCertificatePath=Read-Host 'Path to PUBLIC OurDLP-Server.cer copied from PC 1'}
if(-not $ExpectedCertificateSha256){$ExpectedCertificateSha256=Read-Host 'SHA256 shown by Configure-LanServer on PC 1'}
$expected=$ExpectedCertificateSha256.Replace(' ','').Replace(':','').ToUpperInvariant()
if($expected -notmatch '^[A-F0-9]{64}$' -or (Get-FileHash -LiteralPath $ServerCertificatePath -Algorithm SHA256).Hash -ne $expected){throw 'Certificate fingerprint mismatch. No certificate was trusted.'}
$cert=[Security.Cryptography.X509Certificates.X509Certificate2]::new((Resolve-Path -LiteralPath $ServerCertificatePath).Path)
if($cert.HasPrivateKey -or $cert.NotAfter -le (Get-Date) -or $cert.NotBefore -gt (Get-Date)){throw 'Use a valid PUBLIC server certificate only.'}
if(-not $PayloadPath){$PayloadPath=Join-Path $PSScriptRoot 'bin'}
$installParent=Join-Path $env:ProgramFiles 'OurDLP'
$install=Join-Path $installParent 'Agent'
$dataParent=Join-Path $env:ProgramData 'OurDLP'
$data=Join-Path $dataParent 'Agent'
foreach($path in @($installParent,$install,$dataParent,$data)){
    if(Test-Path -LiteralPath $path){if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Installation folders must not be junctions or symbolic links.'}}
}
$existing=Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'"
if($existing -and -not $ReEnroll){throw 'Agent already installed. For a new code use -ReEnroll explicitly.'}
if($existing -and ($existing.StartName -ne 'NT SERVICE\OurDLP.Agent' -or -not $existing.PathName.Contains((Join-Path $install 'OurDLP.Agent.exe')))){throw 'Existing service has unexpected configuration. Nothing was replaced.'}
if(-not $existing -and (Test-Path -LiteralPath $install)){throw 'Agent binary folder already exists without the service. Inspect it before retrying; nothing was overwritten.'}
$created=$false
$payloadCopied=$false
$started=$false
try {
    if($existing){Stop-Service -Name $serviceName -ErrorAction SilentlyContinue;(Get-Service $serviceName).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(20))}
    else {
        if(-not (Test-Path -LiteralPath (Join-Path $PayloadPath 'OurDLP.Agent.exe'))){throw 'Published Windows agent payload was not found.'}
        New-Item -ItemType Directory -Path $install -Force | Out-Null
        Copy-Item -Path (Join-Path $PayloadPath '*') -Destination $install -Recurse
        $payloadCopied=$true
        $result=Invoke-CimMethod -ClassName Win32_Service -MethodName Create -Arguments @{
            Name=$serviceName;DisplayName='OurDLP Agent';PathName=('"'+(Join-Path $install 'OurDLP.Agent.exe')+'"');
            ServiceType=[uint32]16;ErrorControl=[uint32]1;StartMode='Automatic';StartName='NT SERVICE\OurDLP.Agent'
        }
        if($result.ReturnValue -ne 0){throw ('Service creation failed: '+$result.ReturnValue)}
        $created=$true
    }
    $administrators=[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $system=[Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $agent=([Security.Principal.NTAccount]::new('NT SERVICE',$serviceName)).Translate([Security.Principal.SecurityIdentifier])
    $allowed=@($administrators.Value,$system.Value,$agent.Value)
    foreach($path in @($dataParent,$data)) {
        if(Test-Path -LiteralPath $path){
            $current=Get-Acl -LiteralPath $path
            $owner=$current.GetOwner([Security.Principal.SecurityIdentifier]).Value
            if($owner -notin $allowed){throw 'Existing agent directory has an unexpected owner.'}
            foreach($rule in $current.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])){
                if($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $allowed){throw 'Existing agent directory is accessible to other users. Inspect it before enrollment.'}
            }
        } else {
            New-Item -ItemType Directory -Path $path | Out-Null
            $security=[Security.AccessControl.DirectorySecurity]::new()
            $security.SetAccessRuleProtection($true,$false);$security.SetOwner($administrators)
            foreach($sid in @($administrators,$system)){$security.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit, ObjectInherit','None','Allow'))}
            $rights=if($path -eq $data){'Modify'}else{'ReadAndExecute'}
            $security.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($agent,$rights,'ContainerInherit, ObjectInherit','None','Allow'))
            Set-Acl -LiteralPath $path -AclObject $security
        }
    }
    & (Join-Path $PSScriptRoot 'Initialize-AgentScanTargets.ps1')
    Import-Certificate -FilePath $ServerCertificatePath -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null
    if(-not [Diagnostics.EventLog]::SourceExists($serviceName)){New-EventLog -LogName Application -Source $serviceName}
    if($null -eq $Code){$Code=Read-Host 'One-time code from OurDLP Devices page' -AsSecureString}
    $pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($Code)
    try{$plain=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)}
    $oldEncoding=$OutputEncoding
    try {
        $OutputEncoding=[Text.UTF8Encoding]::new($false)
        $json=@{serverAddress=$uri.GetLeftPart([UriPartial]::Authority);code=$plain;replaceExisting=[bool]$ReEnroll} | ConvertTo-Json -Compress
        $json | & (Join-Path $install 'OurDLP.Agent.exe') --enroll
        if($LASTEXITCODE -ne 0){throw 'Enrollment failed. Check HTTPS, code expiration and server readiness.'}
    } finally {$OutputEncoding=$oldEncoding;$plain=$null;$json=$null;$Code=$null}
    Start-Service -Name $serviceName
    (Get-Service $serviceName).WaitForStatus('Running',[TimeSpan]::FromSeconds(20))
    $confirmed=$false
    for($attempt=0;$attempt -lt 30;$attempt++) {
        if((Get-Service $serviceName).Status -ne 'Running'){throw 'Agent service stopped. Check Application event log, source OurDLP.Agent.'}
        $statusText=(& (Join-Path $install 'OurDLP.Agent.exe') --status | Out-String)
        if($LASTEXITCODE -eq 0) {
            $status=$statusText | ConvertFrom-Json
            if($null -ne $status.ServiceContactConfirmedAtUtc){$confirmed=$true;break}
        }
        Start-Sleep -Seconds 1
    }
    if(-not $confirmed){throw 'Service did not confirm its own HTTPS heartbeat. Check server address, certificate trust and Application event log.'}
    $started=$true
    Write-Host 'OurDLP.Agent installed and running as its own virtual service account. Check Devices on PC 1.'
} finally {
    if(-not $started -and $created){
        Stop-Service -Name $serviceName -ErrorAction SilentlyContinue
        Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'" | Invoke-CimMethod -MethodName Delete | Out-Null
        if($payloadCopied){Remove-Item -LiteralPath $install -Recurse -Force}
        Write-Host 'Incomplete service installation removed. Protected pending enrollment state retained for retry.'
    }
}
