using OurDLP.Contracts;
using OurDLP.Desktop.ViewModels.Clipboard;
using OurDLP.Desktop.ViewModels.RemoteScanning;
using OurDLP.Desktop.ViewModels.Scanning;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels.Guidance;

namespace OurDLP.Desktop.ViewModels;

public sealed class MainWindowViewModel : IDisposable
{
    public ConsoleNavigation Navigation { get; } = new();
    public HelpWorkspace Help { get; }
    public string ApplicationName => "OurDLP";
    public string Slogan => "Сложная защита. Простое управление.";
    public MoscowClock Clock { get; }
    public SettingsViewModel Settings { get; }
    public ServerConnectionViewModel Connection { get; }

    public AdministratorResponse Administrator { get; }
    public AsyncRelayCommand LogoutCommand { get; }

    public DevicesViewModel Devices { get; }

    public ScanWorkspaceViewModel Scanning { get; }

    public RemoteScansViewModel RemoteScans { get; }

    public ClipboardWorkspace Clipboard { get; }

    public MainWindowViewModel(MoscowClock clock, SettingsViewModel settings, ServerConnectionViewModel connection,
        AdministratorResponse administrator, AsyncRelayCommand logout, DevicesViewModel devices,
        ScanWorkspaceViewModel scanning, RemoteScansViewModel remoteScans, ClipboardWorkspace clipboard)
    {
        Clock = clock; Settings = settings; Connection = connection; Administrator = administrator;
        LogoutCommand = logout; Devices = devices; Scanning = scanning; RemoteScans = remoteScans;
        Clipboard = clipboard; Help = new(Navigation, clipboard);
    }

    public void Dispose()
    {
        Clipboard.Dispose();
        RemoteScans.Dispose();
        Scanning.Dispose();
        Devices.Dispose();
        Connection.Dispose();
        Clock.Dispose();
    }
}
