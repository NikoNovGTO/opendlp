@echo off
start "OurDLP.Server" /D "%~dp0Server" "%~dp0Server\OurDLP.Server.exe" --urls https://localhost:7443
start "OurDLP.Desktop" /D "%~dp0Desktop" "%~dp0Desktop\OurDLP.Desktop.exe"
