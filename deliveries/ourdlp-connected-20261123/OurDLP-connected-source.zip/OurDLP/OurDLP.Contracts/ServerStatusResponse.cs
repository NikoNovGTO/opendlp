namespace OurDLP.Contracts;

public sealed record ServerStatusResponse(
    string Component,
    string Version,
    string Status,
    DateTimeOffset ServerTimeUtc);
