﻿using System;

namespace OurDLP.Desktop.Services;

public static class ServerAddressValidator
{
    public static bool TryNormalize(string? input, out string address)
    {
        address = string.Empty;

        if (!Uri.TryCreate(input?.Trim(), UriKind.Absolute, out var uri))
            return false;

        if (uri.Scheme != Uri.UriSchemeHttps
            || string.IsNullOrEmpty(uri.Host)
            || !string.IsNullOrEmpty(uri.UserInfo)
            || !string.IsNullOrEmpty(uri.Query)
            || !string.IsNullOrEmpty(uri.Fragment)
            || uri.AbsolutePath != "/")
        {
            return false;
        }

        address = uri.GetLeftPart(UriPartial.Authority);

        return true;
    }
}