using System;
using System.IO;
using System.Text.Json;

namespace OurDLP.Desktop.Services;

public sealed class JsonSettingsStore
{
    public const string DefaultAddress = "https://localhost:7443";

    private readonly string _filePath;

    public JsonSettingsStore(string? filePath = null)
    {
        _filePath = filePath ?? Path.Combine(
        Environment.GetFolderPath(
            Environment.SpecialFolder.LocalApplicationData),
        "OurDLP",
        "Desktop",
        "server-address.json");
    }

    public string Load()
    {
        if (!File.Exists(_filePath))
            return DefaultAddress;

        var json = File.ReadAllText(_filePath);
        var savedAddress = JsonSerializer.Deserialize<string>(json);

        if (!ServerAddressValidator.TryNormalize(
                savedAddress, out var address))
        {
            throw new InvalidOperationException(
                "В файле настроек указан недопустимый адрес.");
        }

        return address;
    }

    public void Save(string serverAddress)
    {
        if (!ServerAddressValidator.TryNormalize(
                serverAddress, out var address))
        {
            throw new InvalidOperationException(
                "Недопустимый адрес сервера.");
        }

        Directory.CreateDirectory(
            Path.GetDirectoryName(_filePath)!);

        var temporaryPath = _filePath
            + "."
            + Guid.NewGuid().ToString("N")
            + ".tmp";

        try
        {
            File.WriteAllText(
                temporaryPath,
                JsonSerializer.Serialize(address));

            File.Move(
                temporaryPath,
                _filePath,
                overwrite: true);
        }
        finally
        {
            if (File.Exists(temporaryPath))
                File.Delete(temporaryPath);
        }
    }
}