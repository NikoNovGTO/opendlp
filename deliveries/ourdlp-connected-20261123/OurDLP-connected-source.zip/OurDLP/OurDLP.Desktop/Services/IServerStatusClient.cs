using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public interface IServerStatusClient
{
    Task<ServerProbeResult> ProbeAsync(string address, CancellationToken cancellationToken);
}
