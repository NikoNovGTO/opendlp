using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Authentication;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public sealed class ServerApiClient(HttpClient httpClient) : IServerStatusClient
{
    public async Task<ServerProbeResult> ProbeAsync(string address, CancellationToken cancellationToken)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized))
            return new(false, "Укажите HTTPS-адрес без пути, логина и параметров.");

        try
        {
            var endpoint = new Uri(normalized + "/api/status");
            using var response = await httpClient.GetAsync(endpoint, cancellationToken);
            if (!response.IsSuccessStatusCode)
                return new(false, $"Сервер вернул HTTP {(int)response.StatusCode}. Проверьте адрес и запуск OurDLP.Server.");

            var status = await response.Content.ReadFromJsonAsync<ServerStatusResponse>(cancellationToken);
            if (status is null || status.Component != "OurDLP.Server" || status.Status != "api-available"
                || string.IsNullOrWhiteSpace(status.Version) || status.ServerTimeUtc == default
                || status.ServerTimeUtc.Offset != TimeSpan.Zero)
                return new(false, "Получен ответ, который не соответствует API OurDLP.Server.");

            return new(true, "API OurDLP.Server отвечает по HTTPS. Авторизация и база данных этой проверкой не проверяются.", status.Version);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return new(false, "Истекло время ожидания ответа сервера. Проверьте адрес, сеть и запуск сервера.");
        }
        catch (HttpRequestException ex) when (HasTlsFailure(ex))
        {
            return new(false, "Не удалось установить защищённое соединение. Проверьте срок действия, имя сервера и доверие HTTPS-сертификату.");
        }
        catch (HttpRequestException)
        {
            return new(false, "Сервер недоступен. Проверьте его запуск, адрес, порт и сетевое соединение.");
        }
        catch (Exception ex) when (ex is JsonException or NotSupportedException)
        {
            return new(false, "Сервер вернул некорректный формат ответа. Проверьте адрес и совместимость API.");
        }
    }

    private static bool HasTlsFailure(Exception exception)
    {
        for (Exception? current = exception; current is not null; current = current.InnerException)
            if (current is AuthenticationException) return true;
        return false;
    }
}
