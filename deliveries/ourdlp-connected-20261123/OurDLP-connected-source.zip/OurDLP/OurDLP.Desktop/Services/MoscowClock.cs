﻿using System;
using System.Globalization;
using System.Windows.Threading;
using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.Services;

public sealed class MoscowClock : ObservableObject, IDisposable
{
    private readonly TimeZoneInfo _timeZone =
        TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time");

    private readonly DispatcherTimer _timer;
    private DateTimeOffset _currentTime;

    public string TimeText => _currentTime.ToString("HH:mm:ss");

    public string DateText => _currentTime.ToString(
        "d MMMM yyyy",
        CultureInfo.GetCultureInfo("ru-RU"));

    public MoscowClock()
    {
        _timer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1)
        };

        _timer.Tick += OnTick;

        UpdateTime();
        _timer.Start();
    }

    private void OnTick(object? sender, EventArgs e)
    {
        UpdateTime();
    }

    private void UpdateTime()
    {
        _currentTime = TimeZoneInfo.ConvertTime(
            DateTimeOffset.UtcNow,
            _timeZone);

        OnPropertyChanged(nameof(TimeText));
        OnPropertyChanged(nameof(DateText));
    }

    public void Dispose()
    {
        _timer.Stop();
        _timer.Tick -= OnTick;
    }
}