﻿using System.Windows.Controls;

namespace OurDLP.Desktop.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
    }
}