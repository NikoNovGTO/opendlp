using System.Windows.Controls;

namespace OurDLP.Desktop.Views;

public partial class ConnectionSummaryView : UserControl
{
    public ConnectionSummaryView() => InitializeComponent();
}
