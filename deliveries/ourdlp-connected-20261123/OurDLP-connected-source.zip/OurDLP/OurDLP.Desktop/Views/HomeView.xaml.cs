﻿using System.Windows.Controls;

namespace OurDLP.Desktop.Views;

public partial class HomeView : UserControl
{
    public HomeView()
    {
        InitializeComponent();
    }
}