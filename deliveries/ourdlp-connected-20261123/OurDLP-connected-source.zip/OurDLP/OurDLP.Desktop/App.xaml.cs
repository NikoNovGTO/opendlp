using System.Net.Http;
using System.Windows;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels;

namespace OurDLP.Desktop;

public partial class App : Application
{
    private HttpClient? _httpClient;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // No certificate-validation bypass or redirects to another endpoint.
        _httpClient = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false })
        {
            Timeout = TimeSpan.FromSeconds(5),
            MaxResponseContentBufferSize = 64 * 1024
        };
        var connection = new ServerConnectionViewModel(new ServerApiClient(_httpClient));
        var settings = new SettingsViewModel(new JsonSettingsStore(), connection);
        MainWindow = new MainWindow
        {
            DataContext = new MainWindowViewModel(new MoscowClock(), settings, connection)
        };
        MainWindow.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _httpClient?.Dispose();
        base.OnExit(e);
    }
}
