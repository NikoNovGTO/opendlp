using System.Windows.Input;

namespace OurDLP.Desktop.Infrastructure;

public sealed class AsyncRelayCommand(Func<Task> execute, Action<Exception> onError,
    Func<bool>? canExecute = null) : ICommand
{
    private bool _isExecuting;
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => !_isExecuting && (canExecute?.Invoke() ?? true);
    public async void Execute(object? parameter) => await ExecuteAsync();

    public async Task ExecuteAsync()
    {
        if (!CanExecute(null)) return;
        _isExecuting = true;
        Refresh();
        try { await execute(); }
        catch (Exception exception) { onError(exception); }
        finally
        {
            _isExecuting = false;
            Refresh();
        }
    }

    public void Refresh() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}
