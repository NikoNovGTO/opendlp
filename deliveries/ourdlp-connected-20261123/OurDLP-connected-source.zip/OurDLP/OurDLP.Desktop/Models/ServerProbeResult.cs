namespace OurDLP.Desktop.Models;

public sealed record ServerProbeResult(bool Available, string Details, string? Version = null);
