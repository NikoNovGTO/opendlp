namespace OurDLP.Desktop.Models;

public sealed record ConnectionSnapshot(
    ConnectionPhase Phase,
    string Address,
    string Details,
    DateTimeOffset? CheckedAtUtc = null,
    string? ServerVersion = null);
