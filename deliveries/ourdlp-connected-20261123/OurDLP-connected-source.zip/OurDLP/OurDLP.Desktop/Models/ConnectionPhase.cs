namespace OurDLP.Desktop.Models;

public enum ConnectionPhase
{
    NotChecked,
    Checking,
    Available,
    Unavailable,
    InvalidAddress
}
