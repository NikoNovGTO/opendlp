using System;
using System.IO;
using System.Text.Json;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Services;

namespace OurDLP.Desktop.ViewModels;

public sealed class SettingsViewModel : ObservableObject
{
    private readonly JsonSettingsStore _store;

    private string _serverAddress = JsonSettingsStore.DefaultAddress;
    private string _statusMessage = string.Empty;
    private bool _hasError;

    public string ServerAddress
    {
        get => _serverAddress;
        set
        {
            if (SetProperty(ref _serverAddress, value))
            {
                StatusMessage = string.Empty;
                HasError = false;
                Connection.SetAddress(value);
            }
        }
    }

    public string StatusMessage
    {
        get => _statusMessage;
        private set => SetProperty(ref _statusMessage, value);
    }

    public bool HasError
    {
        get => _hasError;
        private set => SetProperty(ref _hasError, value);
    }

    public RelayCommand SaveCommand { get; }

    public ServerConnectionViewModel Connection { get; }

    public SettingsViewModel(JsonSettingsStore store, ServerConnectionViewModel connection)
    {
        _store = store;
        Connection = connection;
        SaveCommand = new RelayCommand(Save);

        Load();
        Connection.SetAddress(ServerAddress);
    }

    private void Load()
    {
        try
        {
            ServerAddress = _store.Load();
        }
        catch (Exception ex) when (
            ex is IOException
            or UnauthorizedAccessException
            or JsonException
            or InvalidOperationException)
        {
            HasError = true;
            StatusMessage =
                "Не удалось прочитать настройки. "
                + "Использован адрес по умолчанию. "
                + ex.Message;
        }
    }

    private void Save()
    {
        if (!ServerAddressValidator.TryNormalize(
                ServerAddress, out var address))
        {
            HasError = true;
            StatusMessage =
                "Введите HTTPS-адрес без пути, логина и параметров. "
                + "Например: https://dlp-server:7443";

            return;
        }

        try
        {
            _store.Save(address);

            ServerAddress = address;
            HasError = false;
            StatusMessage =
                "Адрес сохранён. Для проверки доступности API нажмите «Проверить соединение».";
        }
        catch (Exception ex) when (
            ex is IOException
            or UnauthorizedAccessException
            or InvalidOperationException)
        {
            HasError = true;
            StatusMessage =
                "Не удалось сохранить настройки. " + ex.Message;
        }
    }
}