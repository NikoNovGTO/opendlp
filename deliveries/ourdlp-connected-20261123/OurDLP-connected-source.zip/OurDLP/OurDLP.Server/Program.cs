using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Server.Endpoints;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddProblemDetails();

var app = builder.Build();

app.UseExceptionHandler();

app.MapServerStatusEndpoints();

app.Run();