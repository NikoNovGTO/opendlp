using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using OurDLP.Contracts;

namespace OurDLP.Server.Endpoints;

public static class ServerStatusEndpoints
{
    public static IEndpointRouteBuilder MapServerStatusEndpoints(
        this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/status", GetStatus)
            .WithName("GetServerStatus");

        return endpoints;
    }

    private static ServerStatusResponse GetStatus()
    {
        return new ServerStatusResponse(
            Component: "OurDLP.Server",
            Version: "0.1.0",
            Status: "api-available",
            ServerTimeUtc: DateTimeOffset.UtcNow);
    }
}