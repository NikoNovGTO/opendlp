using System.Net;
using System.Security.Authentication;
using OurDLP.Desktop.Services;
using Xunit;

namespace OurDLP.Tests;

public sealed class ApiClientTests
{
    private const string Valid = """{"component":"OurDLP.Server","version":"0.1.0","status":"api-available","serverTimeUtc":"2026-11-23T12:00:00Z"}""";

    [Fact]
    public async Task ChecksExpectedRouteAndReturnsVersion()
    {
        using var http = MakeHttp((request, _) =>
        {
            Assert.Equal("https://localhost:7443/api/status", request.RequestUri!.AbsoluteUri);
            return Task.FromResult(Reply(Valid));
        });
        var result = await new ServerApiClient(http).ProbeAsync(" https://LOCALHOST:7443/ ", default);
        Assert.True(result.Available);
        Assert.Equal("0.1.0", result.Version);
    }

    [Theory]
    [InlineData("")]
    [InlineData("http://server")]
    [InlineData("https://user:secret@server")]
    [InlineData("https://server/api")]
    [InlineData("https://server/?q=1")]
    [InlineData("https://server/#fragment")]
    public async Task InvalidAddressDoesNotMakeRequest(string address)
    {
        using var http = MakeHttp((_, _) => throw new Exception("Must not make request"));
        Assert.False((await new ServerApiClient(http).ProbeAsync(address, default)).Available);
    }

    [Theory]
    [InlineData("not-json")]
    [InlineData("null")]
    [InlineData("{}")]
    [InlineData("{\"component\":\"AnotherProduct\"}")]
    [InlineData("{\"component\":\"OurDLP.Server\",\"version\":\"0.1\",\"status\":\"api-available\"}")]
    public async Task RejectsInvalidOrIncompleteResponse(string json)
    {
        using var http = MakeHttp((_, _) => Task.FromResult(Reply(json)));
        Assert.False((await new ServerApiClient(http).ProbeAsync("https://localhost", default)).Available);
    }

    [Theory]
    [InlineData(302)]
    [InlineData(401)]
    [InlineData(404)]
    [InlineData(500)]
    public async Task ReportsHttpFailure(int code)
    {
        using var http = MakeHttp((_, _) => Task.FromResult(new HttpResponseMessage((HttpStatusCode)code)));
        var result = await new ServerApiClient(http).ProbeAsync("https://localhost", default);
        Assert.False(result.Available);
        Assert.Contains(code.ToString(), result.Details);
    }

    [Fact]
    public async Task ExplainsCertificateFailure()
    {
        using var http = MakeHttp((_, _) => throw new HttpRequestException("TLS", new AuthenticationException()));
        var result = await new ServerApiClient(http).ProbeAsync("https://localhost", default);
        Assert.False(result.Available);
        Assert.Contains("сертификат", result.Details);
    }

    [Fact]
    public async Task TimeoutBecomesReadableFailure()
    {
        using var http = MakeHttp(async (_, token) =>
        {
            await Task.Delay(Timeout.Infinite, token);
            return Reply(Valid);
        });
        http.Timeout = TimeSpan.FromMilliseconds(100);
        var result = await new ServerApiClient(http).ProbeAsync("https://localhost", default);
        Assert.False(result.Available);
        Assert.Contains("ожидания", result.Details);
    }

    [Fact]
    public async Task CallerCancellationIsPreserved()
    {
        using var http = MakeHttp(async (_, token) =>
        {
            await Task.Delay(Timeout.Infinite, token);
            return Reply(Valid);
        });
        using var cancellation = new CancellationTokenSource();
        cancellation.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            new ServerApiClient(http).ProbeAsync("https://localhost", cancellation.Token));
    }

    private static HttpResponseMessage Reply(string json) => new(HttpStatusCode.OK)
    { Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json") };
    private static HttpClient MakeHttp(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> send) => new(new Handler(send));
    private sealed class Handler(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> send) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) => send(request, cancellationToken);
    }
}
