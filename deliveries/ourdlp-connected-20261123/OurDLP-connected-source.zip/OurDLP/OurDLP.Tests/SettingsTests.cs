using System.Text.Json;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels;
using Xunit;

namespace OurDLP.Tests;

public sealed class SettingsTests : IDisposable
{
    private readonly string _directory = Path.Combine(Path.GetTempPath(), "ourdlp-tests-" + Guid.NewGuid().ToString("N"));
    private JsonSettingsStore Store => new(Path.Combine(_directory, "server-address.json"));

    [Fact]
    public async Task SavingFormattingChangeKeepsLastCheckAndSurvivesReload()
    {
        using var connection = new ServerConnectionViewModel(new AvailableClient());
        var vm = new SettingsViewModel(Store, connection);
        await connection.CheckCommand.ExecuteAsync();
        var checkedAt = connection.Snapshot.CheckedAtUtc;
        vm.ServerAddress = " https://LOCALHOST:7443/ ";
        vm.SaveCommand.Execute(null);
        Assert.False(vm.HasError);
        Assert.True(connection.IsAvailable);
        Assert.Equal(checkedAt, connection.Snapshot.CheckedAtUtc);
        Assert.Equal("https://localhost:7443", Store.Load());
    }

    [Fact]
    public async Task EditingAddressResetsSharedConnectionAndInvalidValueIsNotSaved()
    {
        Store.Save("https://localhost:7443");
        using var connection = new ServerConnectionViewModel(new AvailableClient());
        var vm = new SettingsViewModel(Store, connection);
        Assert.Same(connection, vm.Connection);
        await connection.CheckCommand.ExecuteAsync();
        vm.ServerAddress = "http://invalid";
        vm.SaveCommand.Execute(null);
        Assert.True(vm.HasError);
        Assert.False(connection.IsAvailable);
        Assert.Equal("https://localhost:7443", Store.Load());
    }

    [Fact]
    public void CorruptFileReportsWarningAndKeepsDefaultAddress()
    {
        Directory.CreateDirectory(_directory);
        File.WriteAllText(Path.Combine(_directory, "server-address.json"), "{bad-json}");
        using var connection = new ServerConnectionViewModel(new AvailableClient());
        var vm = new SettingsViewModel(Store, connection);
        Assert.True(vm.HasError);
        Assert.Equal(JsonSettingsStore.DefaultAddress, vm.ServerAddress);
        Assert.Equal(vm.ServerAddress, connection.Snapshot.Address);
    }

    [Fact]
    public void SaveFailureIsReportedWithoutCrashing()
    {
        Directory.CreateDirectory(_directory);
        var blocker = Path.Combine(_directory, "not-a-directory");
        File.WriteAllText(blocker, "blocked");
        using var connection = new ServerConnectionViewModel(new AvailableClient());
        var vm = new SettingsViewModel(new JsonSettingsStore(Path.Combine(blocker, "settings.json")), connection);
        vm.SaveCommand.Execute(null);
        Assert.True(vm.HasError);
    }

    public void Dispose()
    {
        if (Directory.Exists(_directory)) Directory.Delete(_directory, true);
    }
    private sealed class AvailableClient : IServerStatusClient
    {
        public Task<ServerProbeResult> ProbeAsync(string address, CancellationToken cancellationToken) => Task.FromResult(new ServerProbeResult(true, "ok", "0.1"));
    }
}
