using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels;
using Xunit;

namespace OurDLP.Tests;

public sealed class ConnectionTests
{
    [Fact]
    public async Task SuccessHasTimeVersionAndCannotBeSentConcurrently()
    {
        var client = new ControlledClient();
        using var vm = new ServerConnectionViewModel(client);
        vm.SetAddress("https://localhost:7443");
        var check = vm.CheckCommand.ExecuteAsync();
        Assert.False(vm.CheckCommand.CanExecute(null));
        Assert.Equal(ConnectionPhase.Checking, vm.Snapshot.Phase);
        await vm.CheckCommand.ExecuteAsync();
        Assert.Equal(1, client.Calls);
        client.Pending.SetResult(new(true, "ok", "0.1.0"));
        await check;
        Assert.True(vm.IsAvailable);
        Assert.Equal("0.1.0", vm.Snapshot.ServerVersion);
        Assert.NotNull(vm.Snapshot.CheckedAtUtc);
        Assert.True(vm.CheckCommand.CanExecute(null));
    }

    [Fact]
    public async Task EditingAddressCancelsAndIgnoresOldResult()
    {
        var client = new ControlledClient();
        using var vm = new ServerConnectionViewModel(client);
        vm.SetAddress("https://old-server");
        var check = vm.CheckCommand.ExecuteAsync();
        vm.SetAddress("https://new-server");
        Assert.True(client.Token.IsCancellationRequested);
        client.Pending.SetResult(new(true, "old result", "0.1"));
        await check;
        Assert.Equal(ConnectionPhase.NotChecked, vm.Snapshot.Phase);
        Assert.Equal("https://new-server", vm.Snapshot.Address);
        Assert.Null(vm.Snapshot.CheckedAtUtc);
        Assert.False(vm.IsAvailable);
    }

    [Fact]
    public async Task EditingAwayAndBackStillRejectsOldRequest()
    {
        var client = new ControlledClient();
        using var vm = new ServerConnectionViewModel(client);
        vm.SetAddress("https://one");
        var check = vm.CheckCommand.ExecuteAsync();
        vm.SetAddress("https://two");
        vm.SetAddress("https://one");
        client.Pending.SetResult(new(true, "stale", "0.1"));
        await check;
        Assert.Equal(ConnectionPhase.NotChecked, vm.Snapshot.Phase);
    }

    [Fact]
    public async Task DisposalCancelsAndDoesNotPublishLateResult()
    {
        var client = new ControlledClient();
        var vm = new ServerConnectionViewModel(client);
        vm.SetAddress("https://server");
        var check = vm.CheckCommand.ExecuteAsync();
        vm.Dispose();
        Assert.True(client.Token.IsCancellationRequested);
        client.Pending.SetResult(new(true, "late", "0.1"));
        await check;
        Assert.False(vm.IsAvailable);
        Assert.False(vm.CheckCommand.CanExecute(null));
        vm.Dispose();
    }

    [Fact]
    public async Task FailedProbeClearsPreviousSuccess()
    {
        var client = new ControlledClient();
        using var vm = new ServerConnectionViewModel(client);
        vm.SetAddress("https://server");
        client.Pending.SetResult(new(true, "ok", "0.1"));
        await vm.CheckCommand.ExecuteAsync();
        Assert.True(vm.IsAvailable);
        client.Pending = new();
        client.Pending.SetResult(new(false, "offline"));
        await vm.CheckCommand.ExecuteAsync();
        Assert.True(vm.HasError);
        Assert.Null(vm.Snapshot.ServerVersion);
    }

    [Fact]
    public async Task InvalidAddressNeverCallsClient()
    {
        var client = new ControlledClient();
        using var vm = new ServerConnectionViewModel(client);
        vm.SetAddress("http://server");
        await vm.CheckCommand.ExecuteAsync();
        Assert.Equal(0, client.Calls);
        Assert.Equal(ConnectionPhase.InvalidAddress, vm.Snapshot.Phase);
        Assert.Null(vm.Snapshot.CheckedAtUtc);
    }

    [Fact]
    public async Task CommandObservesUnexpectedErrorsAndCanRetry()
    {
        Exception? observed = null;
        var command = new AsyncRelayCommand(() => throw new InvalidOperationException("test"), ex => observed = ex);
        await command.ExecuteAsync();
        Assert.IsType<InvalidOperationException>(observed);
        Assert.True(command.CanExecute(null));
    }

    private sealed class ControlledClient : IServerStatusClient
    {
        public TaskCompletionSource<ServerProbeResult> Pending { get; set; } = new();
        public int Calls { get; private set; }
        public CancellationToken Token { get; private set; }
        public Task<ServerProbeResult> ProbeAsync(string address, CancellationToken cancellationToken)
        {
            Calls++;
            Token = cancellationToken;
            return Pending.Task; // Deliberately ignores cancellation to test late responses.
        }
    }
}
