using OurDLP.Desktop.Services;
using Xunit;

namespace OurDLP.Tests;

public sealed class LiveHttpsTests
{
    [LiveHttpsFact]
    [Trait("Category", "Integration")]
    public async Task UsesStandardTlsValidationAgainstRunningServer()
    {
        var address = Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var expectedTrusted = Environment.GetEnvironmentVariable("OURDLP_EXPECT_TLS_TRUSTED") == "1";
        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false })
        {
            Timeout = TimeSpan.FromSeconds(5),
            MaxResponseContentBufferSize = 64 * 1024
        };
        var result = await new ServerApiClient(http).ProbeAsync(address, default);
        Assert.Equal(expectedTrusted, result.Available);
        if (expectedTrusted) Assert.Equal("0.1.0", result.Version);
        else Assert.Contains("сертификат", result.Details);
    }
}

public sealed class LiveHttpsFactAttribute : FactAttribute
{
    public LiveHttpsFactAttribute()
    {
        if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")))
            Skip = "Requires an explicitly configured live test server and certificate trust.";
    }
}
