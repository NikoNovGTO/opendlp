# Протокол OurDLP 0.4 — 24.11.2026

- SDK 10.0.404; PostgreSQL 17.12; EF Core/Identity 10.0.15, Npgsql EF 10.0.4.
- Release пяти проектов: 0 ошибок, 0 предупреждений.
- 74 случая логики/API/PostgreSQL: прошли без пропусков. Сохранены прежние 62 проверки авторизации, конфигурации, клиентов и миграций.
- Новое: хеши кода/токена; одноразовость и идемпотентность; срок кода; конкурентная регистрация; восстановление после потери ответа; pending/active/offline/revoked; перевыпуск и отзыв; разделение прав администратора/агента; невозможность выбрать чужое устройство телом heartbeat.
- Переносимая логика службы: собственный heartbeat и отметка подтверждения, остановка при 401 без саморегистрации, отказ от небезопасного URL. ViewModel: выбор созданного устройства, очистка использованного кода, отмена подтверждения, истёкший сеанс.
- 16 live-HTTPS случаев: по 4 для рабочего сервера, отсутствующей конфигурации БД, недоверенного сертификата и несовпадающего имени. Реальные AuthenticationClient/DevicesClient/AgentProtocolClient: вход, регистрация, heartbeat, реестр и отзыв. Неверный TLS блокирует вход без отключения проверки сертификатов.
- PowerShell 7.5.4: синтаксис tools/*.ps1 проверен Parser.ParseFile. Прежний мастер администратора ранее проверен на тестовой PostgreSQL. Windows-установщики не запускались.
- Windows x64: Server/Desktop framework-dependent; Agent self-contained с .NET. PE/runtimeconfig и ZIP проверены. Пароли, тестовые сертификаты, ключи и состояние в поставку не входят.

Здесь не проверялись: WPF/DPI, Windows SCM/виртуальная учётная запись, DPAPI, реальные ACL/доверие сертификатов/Firewall Windows, Windows PowerShell 5.1 и два Windows-ПК. Тесты в Linux не заменяют эти испытания. Порядок — AGENT-SETUP.md.

Тесты без PostgreSQL: `dotnet test OurDLP.Tests/OurDLP.Tests.csproj -c Release --filter "Category!=Postgres&Category!=Integration"`.

Для PostgreSQL-тестов OURDLP_TEST_POSTGRES_SETTINGS указывает на частный JSON с Admin и AppPassword (hex). Используйте отдельный тестовый экземпляр: создаются и удаляются временные базы/роли. Live-тестам нужны OURDLP_LIVE_BASE_URL, OURDLP_EXPECT_TLS_TRUSTED, OURDLP_EXPECT_DATABASE_STATUS, OURDLP_LIVE_LOGIN_FILE (частный JSON userName/password), OURDLP_EXPECT_LOGIN_SUCCESS. Без конфигурации они пропускаются. TLS-сценарии запускаются отдельными процессами с разным доверием.

Runner выводит рекомендацию VSTEST_ARTIFACTS_DIRECTORY; результаты TRX проверены отдельно.
