﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param([string]$ServerAddress = '', [string]$ExportPath = '', [switch]$LocalDemo)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
if (-not $ServerAddress) { $ServerAddress = Read-Host 'HTTPS-адрес сервера в локальной сети, например https://192.168.1.10:7443' }
$uri = [Uri]$ServerAddress
if ($uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/') { throw 'Укажите HTTPS-адрес сервера с портом, без дополнительных путей и параметров.' }
if ($LocalDemo -and $uri.Host -ne "localhost") { throw "Для демонстрации на одном ПК укажите https://localhost с нужным портом." }
if (-not $LocalDemo -and ($uri.IsLoopback -or $uri.Host -eq "0.0.0.0")) { throw "Для локальной сети укажите настоящее имя компьютера или его сетевой IP-адрес." }
$address = $uri.DnsSafeHost
$parsed = $null
$isIp = [Net.IPAddress]::TryParse($address,[ref]$parsed)
if (-not $isIp -and [Uri]::CheckHostName($address) -ne [UriHostNameType]::Dns) { throw 'Укажите IP-адрес или сетевое имя компьютера.' }
if (-not $ExportPath) { $ExportPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'OurDLP-Server.cer' }
if (Test-Path -LiteralPath $ExportPath) { throw 'Файл сертификата уже существует. Укажите новый путь -ExportPath. Существующий файл сохранён.' }
$names = @('DNS=localhost',('DNS='+$env:COMPUTERNAME))
if ($isIp) { $names += 'IPAddress='+$address } else { $names += 'DNS='+$address }
$san = '2.5.29.17={text}'+(($names | Select-Object -Unique) -join '&')
$certificate = New-SelfSignedCertificate -Type Custom -Subject ('CN='+$address) -CertStoreLocation 'Cert:\CurrentUser\My' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy Exportable -KeyUsage DigitalSignature,KeyEncipherment -NotAfter (Get-Date).AddYears(1) -TextExtension @($san,'2.5.29.37={text}1.3.6.1.5.5.7.3.1') -FriendlyName 'OurDLP LAN HTTPS'
$folder = Join-Path $env:LOCALAPPDATA 'OurDLP/Server/Certificates'
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$acl = [Security.AccessControl.DirectorySecurity]::new()
$acl.SetAccessRuleProtection($true,$false)
foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'),[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))) {
    $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit, ObjectInherit','None','Allow'))
}
Set-Acl -LiteralPath $folder -AclObject $acl
$pfx = Join-Path $folder ('lan-'+[Guid]::NewGuid().ToString('N')+'.pfx')
$random=[Security.Cryptography.RandomNumberGenerator]::Create();$bytes=New-Object byte[] 32
try {$random.GetBytes($bytes)} finally {$random.Dispose()}
$password=[Convert]::ToBase64String($bytes)
try {
    Export-PfxCertificate -Cert $certificate -FilePath $pfx -Password (ConvertTo-SecureString $password -AsPlainText -Force) | Out-Null
    Export-Certificate -Cert $certificate -FilePath $ExportPath | Out-Null
    Import-Certificate -FilePath $ExportPath -CertStoreLocation 'Cert:\CurrentUser\Root' | Out-Null
    $json=@{
        'Kestrel:Certificates:Default:Path'=$pfx
        'Kestrel:Certificates:Default:Password'=$password
        'Kestrel:Endpoints:Https:Url'=$(if($LocalDemo){'https://localhost:'+$uri.Port}else{'https://0.0.0.0:'+$uri.Port})
    } | ConvertTo-Json -Compress
    $oldEncoding=$OutputEncoding
    try {
        $OutputEncoding=[Text.UTF8Encoding]::new($false)
        $json | & dotnet user-secrets set --id $script:OurDlpSecretsId
        if($LASTEXITCODE -ne 0){throw 'Не удалось сохранить локальные настройки HTTPS-сервера.'}
    } finally {$OutputEncoding=$oldEncoding}
} finally {$password=$null;$json=$null}
$rule='OurDLP-HTTPS-'+$uri.Port
if ($LocalDemo) { Write-Host 'Демонстрация на одном ПК: сервер доступен только локально; правило брандмауэра не добавлено.' }
elseif (-not (Get-NetFirewallRule -Name $rule -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -Name $rule -DisplayName ('OurDLP HTTPS '+$uri.Port) -Direction Inbound -Action Allow -Protocol TCP -LocalPort $uri.Port -RemoteAddress LocalSubnet -Profile Private,Domain | Out-Null
} else {Write-Host 'Существующее правило брандмауэра сохранено.'}
Write-Host ('Адрес сервера: '+$uri.GetLeftPart([UriPartial]::Authority))
Write-Host ('Скопируйте на второй ПК этот публичный сертификат: '+$ExportPath)
Write-Host ('Контрольная сумма сертификата SHA256: '+(Get-FileHash -LiteralPath $ExportPath -Algorithm SHA256).Hash)
Write-Host 'Перезапустите OurDLP.Server под той же учётной записью Windows, в которой сохранялись настройки.'
