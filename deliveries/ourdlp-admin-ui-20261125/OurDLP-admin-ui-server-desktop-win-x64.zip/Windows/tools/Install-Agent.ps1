﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$ServerAddress = '',
    [string]$ServerCertificatePath = '',
    [string]$ExpectedCertificateSha256 = '',
    [string]$PayloadPath = '',
    [Security.SecureString]$Code,
    [switch]$ReEnroll
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$serviceName='OurDLP.Agent'
if(-not $ServerAddress){$ServerAddress=Read-Host 'HTTPS-адрес сервера (на втором ПК укажите сетевой адрес первого ПК)'}
$uri=[Uri]$ServerAddress
if($uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/'){throw 'Укажите HTTPS-адрес сервера без дополнительных путей и параметров.'}
if(-not $ServerCertificatePath){$ServerCertificatePath=Read-Host 'Путь к публичному сертификату OurDLP-Server.cer, полученному с сервера'}
if(-not $ExpectedCertificateSha256){$ExpectedCertificateSha256=Read-Host 'Контрольная сумма SHA256, показанная Configure-LanServer на сервере'}
$expected=$ExpectedCertificateSha256.Replace(' ','').Replace(':','').ToUpperInvariant()
if($expected -notmatch '^[A-F0-9]{64}$' -or (Get-FileHash -LiteralPath $ServerCertificatePath -Algorithm SHA256).Hash -ne $expected){throw 'Контрольная сумма сертификата не совпадает. Сертификат не добавлен в доверенные.'}
$cert=[Security.Cryptography.X509Certificates.X509Certificate2]::new((Resolve-Path -LiteralPath $ServerCertificatePath).Path)
if($cert.HasPrivateKey -or $cert.NotAfter -le (Get-Date) -or $cert.NotBefore -gt (Get-Date)){throw 'Укажите действующий публичный сертификат сервера без закрытого ключа.'}
if(-not $PayloadPath){$PayloadPath=Join-Path $PSScriptRoot 'bin'}
$installParent=Join-Path $env:ProgramFiles 'OurDLP'
$install=Join-Path $installParent 'Agent'
$dataParent=Join-Path $env:ProgramData 'OurDLP'
$data=Join-Path $dataParent 'Agent'
foreach($path in @($installParent,$install,$dataParent,$data)){
    if(Test-Path -LiteralPath $path){if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Папки установки не должны быть символическими ссылками или точками соединения.'}}
}
$existing=Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'"
if($existing -and -not $ReEnroll){throw 'Агент уже установлен. Для обновления используйте Update-Agent.ps1; для явной перерегистрации по новому коду — параметр -ReEnroll.'}
if($existing -and ($existing.StartName -ne 'NT SERVICE\OurDLP.Agent' -or -not $existing.PathName.Contains((Join-Path $install 'OurDLP.Agent.exe')))){throw 'Настройки существующей службы отличаются от ожидаемых. Проверьте её конфигурацию перед установкой.'}
if(-not $existing -and (Test-Path -LiteralPath $install)){throw 'Папка агента уже существует, но служба отсутствует. Проверьте эту папку перед повторной установкой; файлы сохранены.'}
$created=$false
$payloadCopied=$false
$started=$false
try {
    if($existing){Stop-Service -Name $serviceName -ErrorAction SilentlyContinue;(Get-Service $serviceName).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(20))}
    else {
        if(-not (Test-Path -LiteralPath (Join-Path $PayloadPath 'OurDLP.Agent.exe'))){throw 'Не найдены готовые файлы агента Windows. Распакуйте архив агента полностью.'}
        New-Item -ItemType Directory -Path $install -Force | Out-Null
        Copy-Item -Path (Join-Path $PayloadPath '*') -Destination $install -Recurse
        $payloadCopied=$true
        $result=Invoke-CimMethod -ClassName Win32_Service -MethodName Create -Arguments @{
            Name=$serviceName;DisplayName='OurDLP — Агент компьютера';PathName=('"'+(Join-Path $install 'OurDLP.Agent.exe')+'"');
            ServiceType=[uint32]16;ErrorControl=[uint32]1;StartMode='Automatic';StartName='NT SERVICE\OurDLP.Agent'
        }
        if($result.ReturnValue -ne 0){throw ('Не удалось создать службу. Код ошибки: '+$result.ReturnValue)}
        $created=$true
    }
    $administrators=[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $system=[Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $agent=([Security.Principal.NTAccount]::new('NT SERVICE',$serviceName)).Translate([Security.Principal.SecurityIdentifier])
    $allowed=@($administrators.Value,$system.Value,$agent.Value)
    foreach($path in @($dataParent,$data)) {
        if(Test-Path -LiteralPath $path){
            $current=Get-Acl -LiteralPath $path
            $owner=$current.GetOwner([Security.Principal.SecurityIdentifier]).Value
            if($owner -notin $allowed){throw 'У существующей папки агента неожиданный владелец. Проверьте её права доступа.'}
            foreach($rule in $current.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])){
                if($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $allowed){throw 'Папка агента доступна посторонним пользователям. Проверьте права доступа перед регистрацией.'}
            }
        } else {
            New-Item -ItemType Directory -Path $path | Out-Null
            $security=[Security.AccessControl.DirectorySecurity]::new()
            $security.SetAccessRuleProtection($true,$false);$security.SetOwner($administrators)
            foreach($sid in @($administrators,$system)){$security.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit, ObjectInherit','None','Allow'))}
            $rights=if($path -eq $data){'Modify'}else{'ReadAndExecute'}
            $security.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($agent,$rights,'ContainerInherit, ObjectInherit','None','Allow'))
            Set-Acl -LiteralPath $path -AclObject $security
        }
    }
    & (Join-Path $PSScriptRoot 'Initialize-AgentScanTargets.ps1')
    if($created){
        & (Join-Path $install 'OurDLP.Agent.exe') --prepare-demo-documents
        if($LASTEXITCODE -ne 0){throw 'Не удалось подготовить демонстрационные документы Word и Excel.'}
    }
    Import-Certificate -FilePath $ServerCertificatePath -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null
    if(-not [Diagnostics.EventLog]::SourceExists($serviceName)){New-EventLog -LogName Application -Source $serviceName}
    if($null -eq $Code){$Code=Read-Host 'Одноразовый код из раздела «Компьютеры» консоли OurDLP' -AsSecureString}
    $pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($Code)
    try{$plain=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)}
    $oldEncoding=$OutputEncoding
    try {
        $OutputEncoding=[Text.UTF8Encoding]::new($false)
        $json=@{serverAddress=$uri.GetLeftPart([UriPartial]::Authority);code=$plain;replaceExisting=[bool]$ReEnroll} | ConvertTo-Json -Compress
        $json | & (Join-Path $install 'OurDLP.Agent.exe') --enroll
        if($LASTEXITCODE -ne 0){throw 'Регистрация не выполнена. Проверьте HTTPS, срок действия кода и готовность сервера.'}
    } finally {$OutputEncoding=$oldEncoding;$plain=$null;$json=$null;$Code=$null}
    Start-Service -Name $serviceName
    (Get-Service $serviceName).WaitForStatus('Running',[TimeSpan]::FromSeconds(20))
    $confirmed=$false
    for($attempt=0;$attempt -lt 30;$attempt++) {
        if((Get-Service $serviceName).Status -ne 'Running'){throw 'Служба агента остановилась. Проверьте журнал Windows «Приложение», источник OurDLP.Agent.'}
        $statusText=(& (Join-Path $install 'OurDLP.Agent.exe') --status | Out-String)
        if($LASTEXITCODE -eq 0) {
            $status=$statusText | ConvertFrom-Json
            if($null -ne $status.ServiceContactConfirmedAtUtc){$confirmed=$true;break}
        }
        Start-Sleep -Seconds 1
    }
    if(-not $confirmed){throw 'Служба не подтвердила связь с сервером. Проверьте адрес сервера, доверие сертификату и журнал Windows «Приложение».'}
    if(Test-Path -LiteralPath (Join-Path $install 'OurDLP.Session.exe')){ & (Join-Path $PSScriptRoot 'Configure-SessionMonitor.ps1') -Mode Install }
    $started=$true
    Write-Host 'Агент установлен и запущен под отдельной служебной учётной записью. Проверьте компьютер в консоли OurDLP.'
} finally {
    if(-not $started -and $created){
        try { & (Join-Path $PSScriptRoot 'Configure-SessionMonitor.ps1') -Mode Remove } catch { Write-Warning 'Не удалось полностью убрать автозапуск пользовательского компонента. Проверьте существующую запись автозапуска.' }

        Stop-Service -Name $serviceName -ErrorAction SilentlyContinue
        Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'" | Invoke-CimMethod -MethodName Delete | Out-Null
        if($payloadCopied){Remove-Item -LiteralPath $install -Recurse -Force}
        Write-Host 'Незавершённая установка службы удалена. Защищённое состояние регистрации сохранено для повторной попытки.'
    }
}
