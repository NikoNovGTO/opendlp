﻿[CmdletBinding()]
param(
    [string]$UserName = 'admin',
    [Security.SecureString]$Password
)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
Write-Host 'Создание первого администратора OurDLP. Это отдельный пароль для консоли управления.'
Write-Host 'Используйте от 12 до 128 символов, включая заглавные и строчные латинские буквы и цифру.'
Invoke-OurDlpMigration
if ($null -eq $Password) {
    $Password = Read-Host "Новый пароль OurDLP для $UserName" -AsSecureString
    $confirmation = Read-Host 'Повторите пароль OurDLP' -AsSecureString
    try {
        $plain = ConvertFrom-OurDlpSecureString $Password
        $repeated = ConvertFrom-OurDlpSecureString $confirmation
        if (-not [string]::Equals($plain,$repeated,[StringComparison]::Ordinal)) { $plain=$null; $Password=$null; throw 'Пароли не совпадают.' }
    }
    finally { $repeated=$null; $confirmation=$null }
} else {
    $plain=ConvertFrom-OurDlpSecureString $Password
}
$root=Split-Path $PSScriptRoot -Parent
$exe=Join-Path $root 'Server/OurDLP.Server.exe'
$project=Join-Path $root 'OurDLP.Server/OurDLP.Server.csproj'
$previousEnvironment=$env:ASPNETCORE_ENVIRONMENT
$previousEncoding=$OutputEncoding
try {
    $env:ASPNETCORE_ENVIRONMENT='Development'
    $OutputEncoding=[Text.UTF8Encoding]::new($false)
    $payload=@{ userName=$UserName; password=$plain } | ConvertTo-Json -Compress
    if (Test-Path -LiteralPath $exe) {
        $payload | & $exe --create-administrator
    } elseif (Test-Path -LiteralPath $project) {
        $payload | & dotnet run --project $project --configuration Release --no-launch-profile -- --create-administrator
    } else { throw 'Не найден сервер OurDLP.Server или его исходный проект. Распакуйте архив полностью.' }
    if ($LASTEXITCODE -eq 2) { throw 'Администратор уже существует. Его пароль сохранён. Войдите с прежними данными.' }
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать администратора. Проверьте сообщение об ошибке выше.' }
    Write-Host "Готово. Запустите сервер и консоль, затем войдите как $UserName."
}
finally {
    $plain=$null; $payload=$null; $Password=$null
    $env:ASPNETCORE_ENVIRONMENT=$previousEnvironment
    $OutputEncoding=$previousEncoding
}
