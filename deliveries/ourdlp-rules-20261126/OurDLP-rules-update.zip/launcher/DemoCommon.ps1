﻿Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$script:BundleRoot=Split-Path $PSScriptRoot -Parent
$script:RuntimeRoot=Join-Path $script:BundleRoot 'runtime'
$script:DemoData=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'OurDLP/DemoLauncher'
$script:ServerExe=Join-Path $script:RuntimeRoot 'OurDLP.Server.exe'
. (Join-Path $script:BundleRoot 'tools/DatabaseTools.ps1')
. (Join-Path $PSScriptRoot 'DemoPayload.ps1')
$release=Get-DemoRelease
$script:RuntimeRoot=Join-Path $release.Root 'Server'
$script:DesktopRoot=Join-Path $release.Root 'Desktop'
$script:ServerExe=Join-Path $script:RuntimeRoot 'OurDLP.Server.exe'
$script:OurDlpPublishedServerExe=$script:ServerExe
function Initialize-DemoData {
    [IO.Directory]::CreateDirectory($script:DemoData)|Out-Null
    if((Get-Item -LiteralPath $script:DemoData -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Папка запуска не должна быть ссылкой.'}
}
function Get-DemoSettings {
    $file=Get-OurDlpSecretsFile
    if(-not (Test-Path -LiteralPath $file)){return $null}
    if((Get-Item -LiteralPath $file).Length -gt 1MB){throw 'Файл настроек слишком большой. Проверьте локальные настройки OurDLP.'}
    try{return Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json}
    catch{throw 'Не удалось прочитать локальные настройки OurDLP. Существующий файл не изменён.'}
}
function Get-DemoValue($Settings,[string]$Name) {
    if($null -eq $Settings){return $null}
    $flat=$Settings.PSObject.Properties[$Name];if($null -ne $flat){return $flat.Value}
    $value=$Settings
    foreach($part in $Name.Split(':')){if($null -eq $value){return $null};$entry=$value.PSObject.Properties[$part];if($null -eq $entry){return $null};$value=$entry.Value}
    return $value
}
function Get-DemoAddress {
    $settings=Get-DemoSettings;$url=Get-DemoValue $settings 'Kestrel:Endpoints:Https:Url'
    if(-not $url){return 'https://localhost:7443'}
    $uri=$null
    if(-not [Uri]::TryCreate([string]$url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.AbsolutePath -ne '/' -or $uri.Query -or $uri.Fragment -or $uri.UserInfo){throw 'В настройках указан неподдерживаемый HTTPS-адрес. Проверьте адрес сервера.'}
    if($uri.Host -notin @('localhost','127.0.0.1','0.0.0.0','[::]','[::1]')){throw 'Этот комплект запускает сервер на данном ПК. Для существующего сетевого адреса используйте обычную консоль.'}
    return 'https://localhost:'+$uri.Port
}
function Get-DemoLocalSetup {
    $old=$env:ASPNETCORE_ENVIRONMENT
    try{$env:ASPNETCORE_ENVIRONMENT='Development';$result=@(& $script:ServerExe --check-local-setup 2>$null);$code=$LASTEXITCODE}
    finally{$env:ASPNETCORE_ENVIRONMENT=$old}
    if($code -ne 0){throw 'Не удалось проверить базу. Убедитесь, что PostgreSQL запущен.'}
    try{return ($result -join [Environment]::NewLine)|ConvertFrom-Json}catch{throw 'Сервер вернул непонятный результат проверки. Откройте диагностику.'}
}
function Get-DemoCertificate {
    $settings=Get-DemoSettings;$path=[string](Get-DemoValue $settings 'Kestrel:Certificates:Default:Path')
    $password=[string](Get-DemoValue $settings 'Kestrel:Certificates:Default:Password')
    if(-not $path -or -not (Test-Path -LiteralPath $path)){throw 'Сертификат сервера не настроен. Нажмите «Первичная подготовка».'}
    try{$cert=[Security.Cryptography.X509Certificates.X509Certificate2]::new($path,$password,[Security.Cryptography.X509Certificates.X509KeyStorageFlags]::EphemeralKeySet)}
    catch{throw 'Не удалось открыть сертификат сервера. Проверьте сохранённый сертификат и его локальные настройки.'}
    if($cert.NotAfter -le (Get-Date) -or $cert.NotBefore -gt (Get-Date)){$cert.Dispose();throw 'Сертификат сервера недействителен по сроку. Обновите его через Configure-LanServer.ps1.'}
    return $cert
}
function Invoke-DemoJson([string]$Path) {
    [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
    $request=[Net.HttpWebRequest]::Create((Get-DemoAddress)+$Path)
    $request.AllowAutoRedirect=$false;$request.Timeout=2000;$request.ReadWriteTimeout=2000
    $response=$null;$reader=$null
    try{$response=$request.GetResponse();$reader=[IO.StreamReader]::new($response.GetResponseStream());return ($reader.ReadToEnd()|ConvertFrom-Json)}
    finally{if($null -ne $reader){$reader.Dispose()};if($null -ne $response){$response.Dispose()}}
}
function Test-DemoServerReady {
    try{$api=Invoke-DemoJson '/api/status';$db=Invoke-DemoJson '/api/health/database';return $api.Version -eq '0.10.0' -and $db.Status -eq 'ready'}catch{return $false}
}
function Assert-DemoCaller([string]$ExpectedSid) {
    if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -ne $ExpectedSid){throw 'Подготовку нужно запускать под тем же пользователем Windows, что и окно демонстрации. Другой профиль изменён не будет.'}
}
