using System.Collections.ObjectModel;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.ViewModels.Clipboard;

namespace OurDLP.Desktop.ViewModels.Guidance;

public sealed class HelpWorkspace : ObservableObject
{
    private readonly ConsoleNavigation _navigation;
    private readonly IReadOnlyList<GuideTopic> _all;
    private string _query = "";
    private GuideTopic? _selected;
    public ObservableCollection<GuideTopic> Topics { get; } = [];
    public GuideTopic? SelectedTopic { get => _selected; set => SetProperty(ref _selected, value); }
    public string Query { get => _query; set { if (SetProperty(ref _query, value)) Filter(); } }
    public bool NoTopics => Topics.Count == 0;
    public string SearchSummary => $"Найдено тем: {Topics.Count} из {_all.Count}";
    public ClipboardTestExample TestExample { get; }
    public RelayCommand StartCommand { get; }
    public RelayCommand EnrollmentCommand { get; }
    public RelayCommand ClipboardCommand { get; }
    public RelayCommand RulesCommand { get; }
    public RelayCommand StatesCommand { get; }
    public RelayCommand FilesCommand { get; }
    public RelayCommand ProblemsCommand { get; }
    public RelayCommand OfflineCommand { get; }
    public RelayCommand ContextCommand { get; }

    public HelpWorkspace(ConsoleNavigation navigation, ClipboardWorkspace clipboard)
    {
        _navigation = navigation; TestExample = clipboard.TestExample;
        var links = new GuideLinks(navigation, clipboard);
        _all = [GettingStartedTopics.Start(links), GettingStartedTopics.Enrollment(links),
            PolicyTopics.Rules(links), ClipboardTopics.FirstEvent(links), ClipboardTopics.States(links), ScanningTopics.Files(links),
            ScanningTopics.Offline(links), TroubleshootingTopics.Problems(links)];
        StartCommand = Topic("start"); EnrollmentCommand = Topic("enrollment");
        ClipboardCommand = Topic("clipboard"); StatesCommand = Topic("states");
        RulesCommand = Topic("rules");
        FilesCommand = Topic("files"); ProblemsCommand = Topic("problems"); OfflineCommand = Topic("offline");
        ContextCommand = new(() => Open(_navigation.Section switch
        { 1 => "enrollment", 2 => clipboard.Section == 0 ? "rules" : "clipboard", 3 or 4 => "files", 5 => "problems", 6 => SelectedTopic?.Id ?? "start", _ => "start" }));
        Filter();
    }

    private RelayCommand Topic(string id) => new(() => Open(id));
    private void Open(string id)
    {
        Query = "";
        SelectedTopic = _all.First(topic => topic.Id == id);
        _navigation.Help.Execute(null);
    }
    private void Filter()
    {
        var selectedId = SelectedTopic?.Id;
        Topics.Clear();
        foreach (var topic in _all.Where(topic => topic.Matches(Query.Trim()))) Topics.Add(topic);
        SelectedTopic = Topics.FirstOrDefault(topic => topic.Id == selectedId) ?? Topics.FirstOrDefault();
        OnPropertyChanged(nameof(NoTopics)); OnPropertyChanged(nameof(SearchSummary));
    }
}
