using System.Collections.ObjectModel;
using System.ComponentModel;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Rules;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed class ClipboardPolicyEditor : ObservableObject, IDisposable
{
    private string _name = "Контроль тестового маркера"; private bool _enabled = true; private int _maximum = 16384;
    private PolicyRuleEditor? _selected;
    public Guid? Id { get; private set; }
    public int Version { get; private set; }
    public string VersionText => Id is null ? "Новая политика — изменения ещё не сохранены" : $"Сохранённая версия: {Version}. При сохранении будет создана версия {Version + 1}.";
    public string Name { get => _name; set { if (SetProperty(ref _name, value)) Preview.Invalidate(); } }
    public bool Enabled { get => _enabled; set { if (SetProperty(ref _enabled, value)) Preview.Invalidate(); } }
    public int Maximum { get => _maximum; set { if (SetProperty(ref _maximum, value)) Preview.Invalidate(); } }
    public IReadOnlyList<int> Sizes { get; } = [4096, 16384, 65536];
    public ObservableCollection<PolicyRuleEditor> Rules { get; } = [];
    public PolicyRuleEditor? SelectedRule { get => _selected; set { if (SetProperty(ref _selected, value)) { OnPropertyChanged(nameof(HasRuleSelection)); DeleteRuleCommand.Refresh(); } } }
    public bool HasRuleSelection => SelectedRule is not null;
    public string RuleCount => $"Правил: {Rules.Count} из 20. Для ключевых слов и готовых проверок нужен агент и компонент буфера 0.10.0.";
    public bool CanAdd => Rules.Count < 20;
    // Kept as a source-compatible shortcut for integrations using the original one-rule editor.
    public string Pattern { get => SelectedRule?.Pattern ?? ""; set { if (SelectedRule is not null) SelectedRule.Pattern = value; } }
    public string RuleName { get => SelectedRule?.Name ?? ""; set { if (SelectedRule is not null) SelectedRule.Name = value; } }
    public AsyncRelayCommand AddKeywordsCommand { get; }
    public AsyncRelayCommand AddInnCommand { get; }
    public AsyncRelayCommand AddSnilsCommand { get; }
    public AsyncRelayCommand AddRegexCommand { get; }
    public AsyncRelayCommand DeleteRuleCommand { get; }
    public PolicyPreview Preview { get; }
    public ClipboardPolicyEditor()
    {
        Preview = new(Draft);
        AddKeywordsCommand = AddCommand(DetectionRuleKind.Keywords); AddInnCommand = AddCommand(DetectionRuleKind.Inn);
        AddSnilsCommand = AddCommand(DetectionRuleKind.Snils); AddRegexCommand = AddCommand(DetectionRuleKind.Regex);
        DeleteRuleCommand = new(() => { if (SelectedRule is { } row) { row.PropertyChanged -= Edited; Rules.Remove(row); SelectedRule = Rules.FirstOrDefault(); Changed(); } return Task.CompletedTask; }, _ => { }, () => SelectedRule is not null);
        Load(null);
    }
    private AsyncRelayCommand AddCommand(DetectionRuleKind kind) => new(() => { Add(PolicyRuleEditor.Create(kind)); return Task.CompletedTask; }, _ => { }, () => CanAdd);
    private void Add(PolicyRuleEditor row) { row.PropertyChanged += Edited; Rules.Add(row); SelectedRule = row; Changed(); }
    private void Edited(object? sender, PropertyChangedEventArgs args) => Preview.Invalidate();
    private void Changed()
    {
        OnPropertyChanged(nameof(RuleCount)); OnPropertyChanged(nameof(CanAdd)); Preview.Invalidate();
        foreach (var c in new[] { AddKeywordsCommand, AddInnCommand, AddSnilsCommand, AddRegexCommand }) c.Refresh();
    }
    public ClipboardPolicyDraft Draft()
    {
        var draft = new ClipboardPolicyDraft(Name.Trim(), Enabled, Maximum, Rules.Select(rule => rule.Draft()).ToArray(), Version);
        var normalized = new CompiledClipboardPolicy(new(Id ?? Guid.NewGuid(), Version + 1, draft.Name, draft.Enabled, draft.MaxTextCharacters, draft.Rules)).Definition;
        return draft with { Rules = normalized.Rules };
    }
    public void Load(ClipboardPolicy? policy)
    {
        Id = policy?.Id; Version = policy?.Version ?? 0; Name = policy?.Name ?? "Контроль тестового маркера"; Enabled = policy?.Enabled ?? true; Maximum = policy?.MaxTextCharacters ?? 16384;
        foreach (var row in Rules) row.PropertyChanged -= Edited; Rules.Clear();
        var rules = policy?.Rules ?? [new ScanRule(Guid.NewGuid(), "Тестовый маркер", "OURDLP-TEST-[0-9]{4}")];
        foreach (var rule in rules) Add(new(rule)); SelectedRule = Rules.FirstOrDefault(); Changed(); OnPropertyChanged(nameof(VersionText)); Preview.Clear();
    }
    public void Dispose() { Preview.Dispose(); foreach (var row in Rules) row.PropertyChanged -= Edited; }
}
