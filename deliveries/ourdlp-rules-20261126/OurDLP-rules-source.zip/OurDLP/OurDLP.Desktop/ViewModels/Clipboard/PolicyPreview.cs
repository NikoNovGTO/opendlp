using System.Collections.ObjectModel;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed record PolicyPreviewRow(string Rule, string Result);
public sealed class PolicyPreview : ObservableObject, IDisposable
{
    private string _text = "", _message = "Введите пример текста и нажмите «Проверить текст». Текст остаётся на этом ПК.";
    private int _revision; private bool _busy, _disposed;
    public string Text { get => _text; set { if (SetProperty(ref _text, value)) Invalidate(); } }
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public ObservableCollection<PolicyPreviewRow> Results { get; } = [];
    public AsyncRelayCommand TestCommand { get; }
    public PolicyPreview(Func<ClipboardPolicyDraft> draft)
    {
        TestCommand = new(async () =>
        {
            _busy = true; TestCommand!.Refresh(); Results.Clear(); var revision = _revision; var text = Text;
            try
            {
                var definition = draft();
                if (!definition.Enabled) { Message = "Наблюдение этой политики выключено. Включите его для проверки примера."; return; }
                Message = "Проверяем пример…";
                var result = await Task.Run(() =>
                {
                    var policy = new CompiledClipboardPolicy(new(Guid.NewGuid(), 1, definition.Name, true, definition.MaxTextCharacters, definition.Rules));
                    return policy.Analyze(text.AsSpan());
                });
                if (_disposed) return;
                if (revision != _revision) { Message = "Настройки или пример изменились. Повторите проверку."; return; }
                foreach (var rule in definition.Rules)
                {
                    var hit = result.Hits.FirstOrDefault(row => row.RuleId == rule.Id);
                    Results.Add(new(rule.Name, result.TimedOutRules.Contains(rule.Id) ? "Не завершено за 100 мс" : hit is null ? "Совпадений нет" : $"Совпадений: {hit.Count}" + (hit.CountLimited ? " (достигнут предел)" : "")));
                }
                Message = result.Truncated ? "Проверена только начальная часть примера по ограничению размера. Результат не отправлялся на сервер." : "Проверка завершена на этом ПК. Политика не сохранена и не назначена этим действием.";
            }
            catch (ArgumentException e) { if (!_disposed) Message = e.Message; }
            finally { _busy = false; if (!_disposed) TestCommand!.Refresh(); }
        }, _ => { if (!_disposed) Message = "Не удалось проверить пример. Проверьте настройки правил."; }, () => !_busy && !_disposed);
    }
    public void Invalidate() { _revision++; Results.Clear(); if (!_busy) Message = "Настройки изменены. Для актуального результата проверьте пример снова."; }
    public void Clear() { Text = ""; Results.Clear(); Message = "Введите пример текста и нажмите «Проверить текст». Текст остаётся на этом ПК."; }
    public void Dispose() { _disposed = true; _revision++; Text = ""; Results.Clear(); TestCommand.Refresh(); }
}
