using OurDLP.Core.Rules;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed class PolicyRuleEditor : ObservableObject
{
    private string _name, _pattern, _keywords;
    private bool _ignoreCase, _wholeWords;
    public Guid Id { get; }
    public DetectionRuleKind Kind { get; }
    public bool IsKeywords => Kind == DetectionRuleKind.Keywords;
    public bool IsRegex => Kind == DetectionRuleKind.Regex;
    public bool IsNumber => Kind is DetectionRuleKind.Inn or DetectionRuleKind.Snils;
    public string KindTitle => Kind switch { DetectionRuleKind.Keywords => "Ключевые слова", DetectionRuleKind.Inn => "ИНН", DetectionRuleKind.Snils => "СНИЛС", _ => "Регулярное выражение" };
    public string Name { get => _name; set => SetProperty(ref _name, value); }
    public string Pattern { get => _pattern; set => SetProperty(ref _pattern, value); }
    public string KeywordsText { get => _keywords; set => SetProperty(ref _keywords, value); }
    public bool IgnoreCase { get => _ignoreCase; set => SetProperty(ref _ignoreCase, value); }
    public bool WholeWords { get => _wholeWords; set => SetProperty(ref _wholeWords, value); }
    public PolicyRuleEditor(ScanRule rule)
    { Id = rule.Id; Kind = rule.Kind; _name = rule.Name; _pattern = rule.Pattern; _keywords = string.Join(Environment.NewLine, rule.Keywords ?? []); _ignoreCase = rule.IgnoreCase; _wholeWords = rule.WholeWords; }
    public ScanRule Draft() => new(Id, Name.Trim(), IsRegex ? Pattern : RuleFormats.TypedPattern)
    {
        Kind = Kind,
        Keywords = IsKeywords ? KeywordsText.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries) : null,
        IgnoreCase = IsKeywords && IgnoreCase,
        WholeWords = IsKeywords && WholeWords
    };
    public static PolicyRuleEditor Create(DetectionRuleKind kind) => new(new ScanRule(Guid.NewGuid(), kind switch
    { DetectionRuleKind.Keywords => "Мои ключевые слова", DetectionRuleKind.Inn => "ИНН", DetectionRuleKind.Snils => "СНИЛС", _ => "Мой шаблон" }, kind == DetectionRuleKind.Regex ? "" : RuleFormats.TypedPattern)
    { Kind = kind, Keywords = kind == DetectionRuleKind.Keywords ? [] : null, IgnoreCase = kind == DetectionRuleKind.Keywords, WholeWords = kind == DetectionRuleKind.Keywords });
}
