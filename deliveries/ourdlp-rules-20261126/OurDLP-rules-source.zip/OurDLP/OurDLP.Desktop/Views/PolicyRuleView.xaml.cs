using System.Windows.Controls;
namespace OurDLP.Desktop.Views;
public partial class PolicyRuleView : UserControl
{
    public PolicyRuleView()=>InitializeComponent();
}
