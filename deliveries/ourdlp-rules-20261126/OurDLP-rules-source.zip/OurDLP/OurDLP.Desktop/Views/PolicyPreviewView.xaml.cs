using System.Windows.Controls;
namespace OurDLP.Desktop.Views;
public partial class PolicyPreviewView : UserControl
{
    public PolicyPreviewView()=>InitializeComponent();
}
