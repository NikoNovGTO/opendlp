using OurDLP.Core.Clipboard;
using OurDLP.Core.Scanning;

namespace OurDLP.Contracts;

public sealed record ClipboardPolicyDraft(string Name, bool Enabled, int MaxTextCharacters, IReadOnlyList<ScanRule> Rules, int ExpectedVersion = 0);
public sealed record ClipboardPolicyList(IReadOnlyList<ClipboardPolicy> Policies);
public sealed record ClipboardAssignment(Guid? PolicyId);
public sealed record ClipboardHelperStatus(string UserSid, string UserName, int SessionId,
    Guid? AppliedPolicyId, int? AppliedVersion, DateTimeOffset LastSeenAtUtc, long DroppedCaptures, int RuleFormatVersion = 1);
public sealed record ClipboardDeviceState(Guid Id, string Name, bool Capable, string Status,
    Guid? AssignedPolicyId, int? DesiredVersion, Guid? CachedPolicyId, int? CachedVersion, IReadOnlyList<ClipboardHelperStatus> Helpers, int RuleFormatVersion = 1, int RequiredRuleFormat = 1);
public sealed record ClipboardDeviceList(IReadOnlyList<ClipboardDeviceState> Devices);

// Metadata only: clipboard text and content hashes are deliberately absent from the protocol.
public sealed record ClipboardSessionEvent(Guid Id, Guid PolicyId, int PolicyVersion, DateTimeOffset OccurredAtUtc,
    string SourceProcess, int TextCharacters, bool Truncated,
    IReadOnlyList<ClipboardRuleHit> Hits, IReadOnlyList<Guid> TimedOutRules, int OriginSessionId = 0);
public sealed record ClipboardEvent(ClipboardSessionEvent Detection, string UserSid, string UserName, int SessionId);
public sealed record ClipboardEventRejection(Guid Id, string Reason);
public sealed record ClipboardAgentSync(int ProtocolVersion, Guid? CachedPolicyId, int? CachedVersion,
    IReadOnlyList<ClipboardHelperStatus> Helpers, IReadOnlyList<ClipboardEvent> Events, int RuleFormatVersion = 1);
public sealed record ClipboardAgentResponse(ClipboardPolicy? Policy, IReadOnlyList<Guid> Accepted,
    IReadOnlyList<ClipboardEventRejection> Rejected, int RequiredRuleFormat = 1);
public sealed record ClipboardEventRow(Guid Id, Guid DeviceId, string DeviceName, Guid PolicyId, string PolicyName,
    int PolicyVersion, DateTimeOffset OccurredAtUtc, DateTimeOffset ReceivedAtUtc, string UserName, string UserSid,
    int SessionId, string SourceProcess, int TextCharacters, bool Truncated,
    IReadOnlyList<ClipboardRuleHit> Hits, IReadOnlyList<Guid> TimedOutRules, IReadOnlyList<ScanRule> Rules);
public sealed record ClipboardEventList(IReadOnlyList<ClipboardEventRow> Events);

public sealed record ClipboardSessionRequest(int ProtocolVersion, string? RegistrationKey,
    Guid? AppliedPolicyId, int? AppliedVersion, IReadOnlyList<ClipboardSessionEvent> Events, long DroppedCaptures, int RuleFormatVersion = 1);
public sealed record ClipboardSessionResponse(string RegistrationKey, ClipboardPolicy? Policy,
    IReadOnlyList<Guid> Accepted, IReadOnlyList<ClipboardEventRejection> Rejected, bool QueueFull, int RequiredRuleFormat = 1);
public sealed record ClipboardPeer(string UserSid, string UserName, int SessionId);
public static class ClipboardWire
{
    public const int Version = 1, MaxFrameBytes = 256 * 1024, MaxBatch = 32;
    public const string PipeName = "OurDLP.Clipboard.v1";
}
