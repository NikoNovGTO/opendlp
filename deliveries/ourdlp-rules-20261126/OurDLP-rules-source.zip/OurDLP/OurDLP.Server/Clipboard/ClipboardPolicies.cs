using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Rules;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Clipboard;

public sealed class ClipboardPolicies(OurDlpDbContext db, DeviceRegistry audit, TimeProvider time)
{
    public async Task<ClipboardPolicyList> ListAsync(CancellationToken token)
    {
        var rows = await (from p in db.ClipboardPolicies.AsNoTracking() join r in db.ClipboardPolicyRevisions.AsNoTracking()
            on new { PolicyId = p.Id, Version = p.CurrentVersion } equals new { r.PolicyId, r.Version }
            orderby p.Name select r.DefinitionJson).Take(100).ToListAsync(token);
        return new(rows.Select(ScanWire.Read<ClipboardPolicy>).ToArray());
    }
    public async Task<ClipboardPolicy> SaveAsync(Guid? id, ClipboardPolicyDraft draft, Guid actor, CancellationToken token)
    {
        var policyId = id ?? Guid.NewGuid();
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, policyId, token);
        var record = await db.ClipboardPolicies.FindAsync([policyId], token);
        if (id is not null && record is null) throw new ClipboardInputException("Политика не найдена.");
        if ((record?.CurrentVersion ?? 0) != draft.ExpectedVersion) throw new ClipboardConflictException("Политика уже изменена. Обновите список перед сохранением.");
        var definition = new ClipboardPolicy(policyId, checked((record?.CurrentVersion ?? 0) + 1), draft.Name?.Trim()!, draft.Enabled, draft.MaxTextCharacters, draft.Rules);
        try { definition = new CompiledClipboardPolicy(definition).Definition; }
        catch (ArgumentException e) { throw new ClipboardInputException(e.Message); }
        var required = RuleFormats.Required(definition);
        if (await db.ClipboardDevices.AnyAsync(c => c.AssignedPolicyId == policyId && c.RuleFormatVersion < required, token))
            throw new ClipboardConflictException("Политика назначена компьютерам со старым агентом. Обновите агент до 0.10.0, снимите назначение или создайте отдельную политику.");
        if (record is null) { record = new() { Id = policyId }; db.ClipboardPolicies.Add(record); }
        record.Name = definition.Name; record.CurrentVersion = definition.Version;
        record.RequiredRuleFormat = required;
        db.ClipboardPolicyRevisions.Add(new() { PolicyId = policyId, Version = definition.Version,
            DefinitionJson = ScanWire.Serialize(definition), AdministratorId = actor, CreatedAtUtc = time.GetUtcNow() });
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token); return definition;
    }
    public async Task AssignAsync(Guid deviceId, Guid? policyId, Guid actor, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, deviceId, token);
        var device = await db.Devices.FindAsync([deviceId], token);
        var config = await db.ClipboardDevices.FindAsync([deviceId], token);
        if (device is null || device.IsAccessRevoked || device.RegisteredAtUtc is null || config?.Capable != true)
            throw new ClipboardInputException("Нужен зарегистрированный агент 0.8 с поддержкой буфера обмена.");
        if (policyId is { } selected)
        {
            await AgentDatabaseLock.AcquireAsync(db, selected, token);
            var policy = await db.ClipboardPolicies.FindAsync([selected], token);
            if (policy is null) throw new ClipboardInputException("Политика не найдена.");
            var revision = await db.ClipboardPolicyRevisions.FindAsync([selected, policy.CurrentVersion], token);
            var required = RuleFormats.Required(ScanWire.Read<ClipboardPolicy>(revision!.DefinitionJson));
            if (config.RuleFormatVersion < required) throw new ClipboardConflictException("Для ключевых слов и готовых проверок обновите агент до 0.10.0 и дождитесь обмена с сервером.");
        }
        config.AssignedPolicyId = policyId;
        audit.AddAudit(deviceId, actor, policyId is null ? "clipboard.unassigned" : "clipboard.assigned");
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token);
    }
    public static Task<int> ResetDeviceAsync(OurDlpDbContext db, Guid device, CancellationToken token) => db.ClipboardDevices.Where(row => row.DeviceId == device)
        .ExecuteUpdateAsync(update => update.SetProperty(row => row.Capable, false).SetProperty(row => row.RuleFormatVersion, 1).SetProperty(row => row.AssignedPolicyId, (Guid?)null)
            .SetProperty(row => row.CachedPolicyId, (Guid?)null).SetProperty(row => row.CachedVersion, (int?)null).SetProperty(row => row.HelpersJson, "[]"), token);
}
