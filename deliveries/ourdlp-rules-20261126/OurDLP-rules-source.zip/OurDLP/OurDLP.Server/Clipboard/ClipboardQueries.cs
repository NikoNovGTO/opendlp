using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Server.Data;

namespace OurDLP.Server.Clipboard;

public sealed class ClipboardQueries(OurDlpDbContext db, TimeProvider time)
{
    public async Task<ClipboardDeviceList> DevicesAsync(CancellationToken token)
    {
        var rows = await (from d in db.Devices.AsNoTracking()
            join c in db.ClipboardDevices.AsNoTracking() on d.Id equals c.DeviceId into configurations from c in configurations.DefaultIfEmpty()
            join p in db.ClipboardPolicies.AsNoTracking() on c.AssignedPolicyId equals (Guid?)p.Id into policies from p in policies.DefaultIfEmpty()
            where d.RegisteredAtUtc != null && !d.IsAccessRevoked orderby d.Name
            select new { Device = d, Config = c, Desired = p == null ? (int?)null : p.CurrentVersion, Required = p == null ? 1 : p.RequiredRuleFormat }).Take(200).ToListAsync(token);
        var now = time.GetUtcNow();
        return new(rows.Select(row => new ClipboardDeviceState(row.Device.Id, row.Device.Name, row.Config?.Capable ?? false,
            row.Device.LastSeenAtUtc >= now.AddSeconds(-90) ? "active" : "offline", row.Config?.AssignedPolicyId,
            row.Desired, row.Config?.CachedPolicyId, row.Config?.CachedVersion,
            row.Config is null ? [] : ScanWire.Read<ClipboardHelperStatus[]>(row.Config.HelpersJson), row.Config?.RuleFormatVersion ?? 1, row.Required)).ToArray());
    }
    public async Task<ClipboardEventList> EventsAsync(CancellationToken token)
    {
        var rows = await (from e in db.ClipboardEvents.AsNoTracking() join d in db.Devices.AsNoTracking() on e.DeviceId equals d.Id
            join r in db.ClipboardPolicyRevisions.AsNoTracking() on new { e.PolicyId, Version = e.PolicyVersion } equals new { r.PolicyId, r.Version }
            orderby e.ReceivedAtUtc descending select new { Event = e, DeviceName = d.Name, r.DefinitionJson }).Take(200).ToListAsync(token);
        return new(rows.Select(row =>
        {
            var metadata = ScanWire.Read<ClipboardEvent>(row.Event.MetadataJson); var detection = metadata.Detection;
            var policy = ScanWire.Read<ClipboardPolicy>(row.DefinitionJson);
            return new ClipboardEventRow(row.Event.Id, row.Event.DeviceId, row.DeviceName, policy.Id, policy.Name, policy.Version,
                detection.OccurredAtUtc, row.Event.ReceivedAtUtc, metadata.UserName, metadata.UserSid, metadata.SessionId,
                detection.SourceProcess, detection.TextCharacters, detection.Truncated, detection.Hits, detection.TimedOutRules, policy.Rules);
        }).ToArray());
    }
}
