namespace OurDLP.Server.Data.Entities;

public sealed class ClipboardPolicyRecord
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int CurrentVersion { get; set; }
    public int RequiredRuleFormat { get; set; } = 1;
}
public sealed class ClipboardPolicyRevision
{
    public Guid PolicyId { get; set; }
    public int Version { get; set; }
    public string DefinitionJson { get; set; } = string.Empty;
    public Guid AdministratorId { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; }
}
public sealed class ClipboardDeviceConfiguration
{
    public Guid DeviceId { get; set; }
    public bool Capable { get; set; }
    public int RuleFormatVersion { get; set; } = 1;
    public Guid? AssignedPolicyId { get; set; }
    public Guid? CachedPolicyId { get; set; }
    public int? CachedVersion { get; set; }
    public string HelpersJson { get; set; } = "[]";
}
public sealed class ClipboardPolicyDelivery
{
    public Guid DeviceId { get; set; }
    public string CredentialHash { get; set; } = string.Empty;
    public Guid PolicyId { get; set; }
    public int Version { get; set; }
    public DateTimeOffset DeliveredAtUtc { get; set; }
}
public sealed class ClipboardEventRecord
{
    public Guid Id { get; set; }
    public Guid DeviceId { get; set; }
    public Guid PolicyId { get; set; }
    public int PolicyVersion { get; set; }
    public string CredentialHash { get; set; } = string.Empty;
    public string MetadataJson { get; set; } = string.Empty;
    public string PayloadHash { get; set; } = string.Empty;
    public DateTimeOffset OccurredAtUtc { get; set; }
    public DateTimeOffset ReceivedAtUtc { get; set; }
}
