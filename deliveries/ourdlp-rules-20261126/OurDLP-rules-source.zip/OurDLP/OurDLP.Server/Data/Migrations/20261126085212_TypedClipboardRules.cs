﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OurDLP.Server.Data.Migrations
{
    /// <inheritdoc />
    public partial class TypedClipboardRules : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RequiredRuleFormat",
                table: "clipboard_policies",
                type: "integer",
                nullable: false,
                defaultValue: 1);

            migrationBuilder.AddColumn<int>(
                name: "RuleFormatVersion",
                table: "clipboard_device_configuration",
                type: "integer",
                nullable: false,
                defaultValue: 1);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RequiredRuleFormat",
                table: "clipboard_policies");

            migrationBuilder.DropColumn(
                name: "RuleFormatVersion",
                table: "clipboard_device_configuration");
        }
    }
}
