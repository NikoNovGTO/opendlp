using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data.Configurations;

public sealed class ClipboardConfiguration : IEntityTypeConfiguration<ClipboardPolicyRecord>, IEntityTypeConfiguration<ClipboardPolicyRevision>,
    IEntityTypeConfiguration<ClipboardDeviceConfiguration>, IEntityTypeConfiguration<ClipboardPolicyDelivery>, IEntityTypeConfiguration<ClipboardEventRecord>
{
    public void Configure(EntityTypeBuilder<ClipboardPolicyRecord> b)
    { b.ToTable("clipboard_policies"); b.HasKey(x => x.Id); b.Property(x => x.Name).HasMaxLength(100).IsRequired(); b.Property(x => x.RequiredRuleFormat).HasDefaultValue(1); }
    public void Configure(EntityTypeBuilder<ClipboardPolicyRevision> b)
    {
        b.ToTable("clipboard_policy_revisions"); b.HasKey(x => new { x.PolicyId, x.Version });
        b.Property(x => x.DefinitionJson).HasColumnType("jsonb").IsRequired();
        b.HasOne<ClipboardPolicyRecord>().WithMany().HasForeignKey(x => x.PolicyId);
    }
    public void Configure(EntityTypeBuilder<ClipboardDeviceConfiguration> b)
    {
        b.ToTable("clipboard_device_configuration"); b.HasKey(x => x.DeviceId);
        b.Property(x => x.RuleFormatVersion).HasDefaultValue(1);
        b.Property(x => x.HelpersJson).HasColumnType("jsonb").IsRequired();
        b.HasOne<Device>().WithOne().HasForeignKey<ClipboardDeviceConfiguration>(x => x.DeviceId);
        b.HasOne<ClipboardPolicyRecord>().WithMany().HasForeignKey(x => x.AssignedPolicyId).OnDelete(DeleteBehavior.Restrict);
    }
    public void Configure(EntityTypeBuilder<ClipboardPolicyDelivery> b)
    {
        b.ToTable("clipboard_policy_deliveries"); b.HasKey(x => new { x.DeviceId, x.CredentialHash, x.PolicyId, x.Version });
        b.Property(x => x.CredentialHash).HasMaxLength(64); b.HasOne<Device>().WithMany().HasForeignKey(x => x.DeviceId);
        b.HasOne<ClipboardPolicyRevision>().WithMany().HasForeignKey(x => new { x.PolicyId, x.Version });
    }
    public void Configure(EntityTypeBuilder<ClipboardEventRecord> b)
    {
        b.ToTable("clipboard_events"); b.HasKey(x => x.Id); b.Property(x => x.CredentialHash).HasMaxLength(64);
        b.Property(x => x.PayloadHash).HasMaxLength(64); b.Property(x => x.MetadataJson).HasColumnType("jsonb").IsRequired();
        b.HasIndex(x => x.ReceivedAtUtc); b.HasIndex(x => new { x.DeviceId, x.ReceivedAtUtc });
        b.HasOne<Device>().WithMany().HasForeignKey(x => x.DeviceId);
        b.HasOne<ClipboardPolicyRevision>().WithMany().HasForeignKey(x => new { x.PolicyId, Version = x.PolicyVersion });
    }
}
