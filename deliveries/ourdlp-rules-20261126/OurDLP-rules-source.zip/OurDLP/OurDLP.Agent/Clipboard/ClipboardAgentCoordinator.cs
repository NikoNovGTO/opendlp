using System.Security.Cryptography;
using System.Text;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Rules;

namespace OurDLP.Agent.Clipboard;

public sealed class ClipboardAgentCoordinator(IAgentStateStore registration, IClipboardAgentStore store)
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly Dictionary<string, ClipboardHelperStatus> _helpers = [];
    private ClipboardAgentState? _state;
    private CompiledClipboardPolicy? _validatedPolicy;
    private bool _persisted;
    public static string Key(AgentState state) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(state.ServerAddress + "\n" + state.DeviceId + "\n" + state.Token)));
    private async Task<ClipboardAgentState> LoadAsync(CancellationToken token)
    {
        if (_state is not null) return _state;
        var identity = await registration.ReadAsync(token);
        if (identity?.DeviceId is null) throw new InvalidOperationException("Агент не зарегистрирован.");
        var key = Key(identity); var saved = await store.ReadAsync(token);
        if (saved is not null && saved.RegistrationKey != key) { await store.ArchiveAsync(token); saved = null; }
        if (saved is not null && (saved.SchemaVersion is < 1 or > 2 || saved.Pending is null || saved.Pending.Count > 512)) throw new InvalidDataException("Очередь буфера повреждена или требует обновления агента.");
        _persisted = saved is not null;
        return _state = saved ?? new() { RegistrationKey = key };
    }
    public async Task<ClipboardSessionResponse> SessionAsync(ClipboardPeer peer, ClipboardSessionRequest request, CancellationToken token)
    {
        if (!ClipboardValidation.Peer(peer.UserSid, peer.UserName, peer.SessionId) || request.ProtocolVersion != ClipboardWire.Version
            || request.Events is null || request.Events.Count > ClipboardWire.MaxBatch || request.DroppedCaptures < 0
            || request.RuleFormatVersion is < 1 or > RuleFormats.Current) throw new InvalidDataException("Неверный пакет пользовательского компонента.");
        await _gate.WaitAsync(token);
        try
        {
            var current = await LoadAsync(token); var accepted = new List<Guid>(); var rejected = new List<ClipboardEventRejection>(); var full = false;
            if (request.RegistrationKey == current.RegistrationKey && request.Events.Count != 0)
            {
                var added = false;
                var pending = current.Pending.ToList();
                foreach (var item in request.Events)
                {
                    if (!ClipboardValidation.Detection(item)) { rejected.Add(new(item?.Id ?? Guid.Empty, "invalid-metadata")); continue; }
                    var existing = pending.FirstOrDefault(row => row.Detection.Id == item.Id);
                    if (existing is not null)
                    {
                        if (existing.UserSid == peer.UserSid && existing.SessionId == (item.OriginSessionId > 0 ? item.OriginSessionId : peer.SessionId) && ScanWire.Serialize(existing.Detection) == ScanWire.Serialize(item)) accepted.Add(item.Id);
                        else rejected.Add(new(item.Id, "event-conflict"));
                        continue;
                    }
                    if (pending.Count >= 512) { full = true; break; }
                    var stamped = new ClipboardEvent(item, peer.UserSid, peer.UserName, item.OriginSessionId > 0 ? item.OriginSessionId : peer.SessionId);
                    var candidate = current with { Pending = pending.Append(stamped).ToArray() };
                    if (Encoding.UTF8.GetByteCount(ScanWire.Serialize(candidate)) > 1900 * 1024) { full = true; break; }
                    pending.Add(stamped); accepted.Add(item.Id); added = true;
                }
                var updated = current with { Pending = pending.ToArray() };
                if (added) { await store.SaveAsync(updated, token); _state = current = updated; _persisted = true; }
            }
            var required = RuleFormats.Required(current.Policy);
            var compatible = request.RuleFormatVersion >= required;
            var helper = new ClipboardHelperStatus(peer.UserSid, peer.UserName, peer.SessionId,
                compatible && request.RegistrationKey == current.RegistrationKey ? request.AppliedPolicyId : null,
                compatible && request.RegistrationKey == current.RegistrationKey ? request.AppliedVersion : null,
                DateTimeOffset.UtcNow, request.DroppedCaptures, request.RuleFormatVersion);
            _helpers[peer.UserSid + "/" + peer.SessionId] = helper;
            if (_helpers.Count > 16)
                foreach (var stale in _helpers.OrderByDescending(row => row.Value.LastSeenAtUtc).Skip(16).Select(row => row.Key).ToArray()) _helpers.Remove(stale);
            return new(current.RegistrationKey, compatible ? current.Policy : null, accepted, rejected, full, required);
        }
        finally { _gate.Release(); }
    }
    public async Task<ClipboardAgentSync> SnapshotAsync(CancellationToken token)
    {
        await _gate.WaitAsync(token);
        try
        {
            var state = await LoadAsync(token);
            return new(ClipboardWire.Version, state.Policy?.Id, state.Policy?.Version, _helpers.Values.ToArray(), state.Pending.Take(ClipboardWire.MaxBatch).ToArray(), RuleFormats.Current);
        }
        finally { _gate.Release(); }
    }
    public async Task ApplyAsync(ClipboardAgentResponse response, IReadOnlyList<Guid> sent, CancellationToken token)
    {
        if (response.Accepted is null || response.Rejected is null || response.Accepted.Count > ClipboardWire.MaxBatch || response.Rejected.Count > ClipboardWire.MaxBatch)
            throw new InvalidDataException("Неверное подтверждение событий.");
        if (response.Accepted.Concat(response.Rejected.Select(row => row.Id)).Any(id => !sent.Contains(id)))
            throw new InvalidDataException("Подтверждение относится к другому пакету.");
        await _gate.WaitAsync(token);
        try
        {
            var state = await LoadAsync(token);
            var compiled = response.Policy is null ? null
                : _validatedPolicy is not null && ClipboardPolicyContent.Same(_validatedPolicy.Definition, response.Policy)
                    ? _validatedPolicy : new CompiledClipboardPolicy(response.Policy);
            var done = response.Accepted.Concat(response.Rejected.Select(row => row.Id)).ToHashSet();
            var rejected = response.Rejected.Select(row => row.Id).ToHashSet();
            var schema = RuleFormats.Required(response.Policy);
            if (_persisted && state.SchemaVersion == schema && ClipboardPolicyContent.Same(state.Policy, response.Policy) && !state.Pending.Any(row => done.Contains(row.Detection.Id)))
            { _validatedPolicy = compiled; return; }
            var updated = state with { SchemaVersion = schema, Policy = compiled?.Definition, Pending = state.Pending.Where(row => !done.Contains(row.Detection.Id)).ToArray(),
                RejectedEvents = state.RejectedEvents + state.Pending.Count(row => rejected.Contains(row.Detection.Id)) };
            await store.SaveAsync(updated, token); _state = updated; _persisted = true; _validatedPolicy = compiled;
        }
        finally { _gate.Release(); }
    }
}
