using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Rules;

namespace OurDLP.Session;

public sealed class SessionCoordinator(ISessionStateStore store, IClipboardSessionClient client)
{
    private SessionPolicy? _policy;
    private SessionState _state = new();
    private int _ready, _connected;
    public SessionPolicy? CurrentPolicy => Volatile.Read(ref _policy);
    public bool ListenerReady => Volatile.Read(ref _ready) == 1;
    public void SetListenerReady(bool value) => Volatile.Write(ref _ready, value ? 1 : 0);
    public string Describe()
    {
        var policy = CurrentPolicy;
        return "OurDLP — наблюдение буфера обмена\n" +
            (policy is null ? "Политика не назначена." : $"Политика: {policy.Compiled.Definition.Name}, версия {policy.Compiled.Definition.Version}. Наблюдение: {(policy.Compiled.Definition.Enabled ? "включено" : "выключено")}.") +
            $"\nКомпонент Windows: {(ListenerReady ? "подключён" : "не готов")}. Служба: {(Volatile.Read(ref _connected) == 1 ? "доступна" : "нет связи, используется кэш")}." +
            $"\nВ очереди: {_state.Pending.Count}. Пропущено: {_state.DroppedCaptures}. Отклонено: {_state.RejectedEvents}.\nСодержимое буфера на сервер не отправляется. Блокировка не выполняется.";
    }
    public async Task InitializeAsync(CancellationToken token) => ApplyLocal(await store.ReadAsync(token));
    private CompiledClipboardPolicy? Compile(ClipboardPolicy? definition)
    {
        if (definition is null) return null;
        var cached = CurrentPolicy?.Compiled;
        return cached is not null && ClipboardPolicyContent.Same(cached.Definition, definition) ? cached : new(definition);
    }
    private void ApplyLocal(SessionState state, CompiledClipboardPolicy? validated = null)
    {
        var compiled = state.Policy is null || state.RegistrationKey is null ? null
            : validated is not null && ClipboardPolicyContent.Same(validated.Definition, state.Policy) ? validated : Compile(state.Policy);
        var active = CurrentPolicy;
        var policy = compiled is null ? null
            : active is not null && active.RegistrationKey == state.RegistrationKey && ReferenceEquals(active.Compiled, compiled) ? active
            : new SessionPolicy(state.RegistrationKey!, compiled);
        _state = state; Volatile.Write(ref _policy, policy);
    }
    public async Task EnqueueAsync(CapturedClipboard captured, CancellationToken token)
    {
        var result = captured.Policy.Compiled.Analyze(captured.Buffer.Text, captured.Truncated);
        if (!result.HasEvent) return;
        var metadata = new ClipboardSessionEvent(Guid.NewGuid(), captured.Policy.Compiled.Definition.Id,
            captured.Policy.Compiled.Definition.Version, captured.OccurredAtUtc, captured.SourceProcess,
            result.TextCharacters, result.Truncated, result.Hits, result.TimedOutRules, captured.SessionId);
        var state = await store.UpdateAsync(current => current.RegistrationKey != captured.Policy.RegistrationKey || current.Pending.Count >= 128
            ? current with { DroppedCaptures = current.DroppedCaptures + 1 }
            : current with { Pending = current.Pending.Append(metadata).ToArray() }, token);
        _state = state;
    }
    public async Task DroppedAsync(CancellationToken token) => _state = await store.UpdateAsync(current => current with { DroppedCaptures = current.DroppedCaptures + 1 }, token);
    public async Task SyncOnceAsync(CancellationToken token)
    {
        var before = await store.ReadAsync(token); var active = CurrentPolicy;
        var sent = before.Pending.Take(ClipboardWire.MaxBatch).ToArray();
        var response = await client.SyncAsync(new(ClipboardWire.Version, before.RegistrationKey,
            ListenerReady ? active?.Compiled.Definition.Id : null, ListenerReady ? active?.Compiled.Definition.Version : null, sent, before.DroppedCaptures, RuleFormats.Current), token);
        Volatile.Write(ref _connected, response is null ? 0 : 1);
        if (response is null) return;
        if (response.RegistrationKey is not { Length: 64 } || !response.RegistrationKey.All(Uri.IsHexDigit)
            || response.Accepted is null || response.Rejected is null) throw new InvalidDataException("Неверный ответ службы.");
        var compiled = Compile(response.Policy);
        var same = before.RegistrationKey == response.RegistrationKey;
        var sentIds = sent.Select(row => row.Id).ToHashSet();
        if (same && response.Accepted.Concat(response.Rejected.Select(row => row.Id)).Any(id => !sentIds.Contains(id)))
            throw new InvalidDataException("Подтверждение относится к другому пакету.");
        var done = response.Accepted.Concat(response.Rejected.Select(row => row.Id)).ToHashSet();
        var rejected = response.Rejected.Select(row => row.Id).ToHashSet();
        var next = await store.UpdateAsync(current => current.RegistrationKey != before.RegistrationKey && current.RegistrationKey != response.RegistrationKey
            ? current // Another logon session has already advanced the shared registration cache.
            : current.RegistrationKey != response.RegistrationKey
            ? new() { SchemaVersion = RuleFormats.Required(response.Policy), RegistrationKey = response.RegistrationKey, Policy = compiled?.Definition }
            : current.SchemaVersion == RuleFormats.Required(response.Policy) && ClipboardPolicyContent.Same(current.Policy, response.Policy) && !current.Pending.Any(row => done.Contains(row.Id))
            ? current // Preserve shared-store concurrency checks, but skip encryption and replacement when nothing changed.
            : current with { SchemaVersion = RuleFormats.Required(response.Policy), Policy = compiled?.Definition, Pending = current.Pending.Where(row => !done.Contains(row.Id)).ToArray(),
                RejectedEvents = current.RejectedEvents + current.Pending.Count(row => rejected.Contains(row.Id)) }, token);
        ApplyLocal(next, compiled);
    }
}
