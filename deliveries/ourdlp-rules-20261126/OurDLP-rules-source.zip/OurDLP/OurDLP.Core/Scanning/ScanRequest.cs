using System.Text.Json.Serialization;
using OurDLP.Core.Rules;
namespace OurDLP.Core.Scanning;

public sealed record ScanRule(Guid Id, string Name, string Pattern)
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public DetectionRuleKind Kind { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyList<string>? Keywords { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public bool IgnoreCase { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public bool WholeWords { get; init; }
}
public sealed record ScanRequest(string RootPath, IReadOnlyList<ScanRule> Rules,
    IReadOnlyList<string> ExcludedDirectories, ScanLimits Limits);

public sealed record ScanLimits
{
    public long MaxFileBytes { get; init; } = 5 * 1024 * 1024;
    public int MaxFiles { get; init; } = 5_000;
    public int MaxEntries { get; init; } = 20_000;
    public int MaxFindings { get; init; } = 1_000;
    public int MaxIssues { get; init; } = 100;
    public int MaxMatchesPerFile { get; init; } = 1_000;
    public TimeSpan MaxDuration { get; init; } = TimeSpan.FromMinutes(2);
}
