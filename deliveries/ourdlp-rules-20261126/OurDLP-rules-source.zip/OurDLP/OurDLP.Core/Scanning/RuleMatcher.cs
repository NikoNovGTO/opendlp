namespace OurDLP.Core.Scanning;

internal static class RuleMatcher
{
    public static void Apply(string text, string path, IReadOnlyList<PreparedRule> rules, ScanSession session)
    {
        foreach (var rule in rules)
        {
            if (!session.CanContinue()) return;
            var matched = rule.Matcher.Count(text, session.Request.Limits.MaxMatchesPerFile, session.CanContinue);
            var count = matched.Count; var limited = matched.Limited;
            if (matched.TimedOut) session.Issue(path, "regex-timeout", "Правило превысило 100 мс при поиске; результат может быть неполным.");
            if (count == 0) continue;
            if (session.Findings.Count >= session.Request.Limits.MaxFindings)
            { session.Stop(ScanCompletion.LimitReached, "Достигнут предел строк результатов."); return; }
            session.Findings.Add(new(Guid.NewGuid(), path, Path.GetRelativePath(session.Request.RootPath, path),
                rule.Definition.Id, rule.Definition.Name, count, limited, DateTimeOffset.UtcNow));
        }
    }
}
