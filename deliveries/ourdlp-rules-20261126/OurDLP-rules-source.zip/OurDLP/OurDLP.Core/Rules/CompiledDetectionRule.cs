using System.Diagnostics;
using System.Text.RegularExpressions;
using OurDLP.Core.Scanning;
namespace OurDLP.Core.Rules;

public readonly record struct RuleMatchCount(int Count, bool Limited, bool TimedOut);
public sealed class CompiledDetectionRule
{
    public ScanRule Definition { get; }
    private readonly Regex _expression;
    public CompiledDetectionRule(ScanRule definition)
    {
        var prepared=RulePreparation.Prepare(definition);Definition=prepared.Definition;_expression=prepared.Expression;
    }
    public RuleMatchCount Count(ReadOnlySpan<char> text, int maximum, Func<bool>? canContinue=null)
    {
        var count=0;var start=Stopwatch.GetTimestamp();
        try
        {
            foreach(var match in _expression.EnumerateMatches(text))
            {
                if(canContinue?.Invoke()==false)return new(count,true,false);
                if(Stopwatch.GetElapsedTime(start)>=TimeSpan.FromMilliseconds(100))return new(count,true,true);
                var candidate=text.Slice(match.Index,match.Length);
                if(Definition.Kind==DetectionRuleKind.Inn && !RussianIdentifiers.IsInn(candidate)
                    || Definition.Kind==DetectionRuleKind.Snils && !RussianIdentifiers.IsSnils(candidate)) continue;
                if(count==maximum)return new(count,true,false);
                count++;
            }
        }
        catch(RegexMatchTimeoutException){return new(count,true,true);}
        return new(count,false,false);
    }
}
