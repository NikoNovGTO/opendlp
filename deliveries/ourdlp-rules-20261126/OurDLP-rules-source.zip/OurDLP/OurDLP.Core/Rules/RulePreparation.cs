using System.Text.RegularExpressions;
using OurDLP.Core.Scanning;
namespace OurDLP.Core.Rules;

internal static class RulePreparation
{
    public static (ScanRule Definition, Regex Expression) Prepare(ScanRule rule)
    {
        if(rule is null || rule.Id==Guid.Empty || string.IsNullOrWhiteSpace(rule.Name) || rule.Name.Length>100 || !Enum.IsDefined(rule.Kind))
            throw new ArgumentException("Задайте название правила до 100 символов и поддерживаемый тип проверки.");
        var options=RegexOptions.Multiline|RegexOptions.CultureInvariant; string pattern;
        if(rule.Kind==DetectionRuleKind.Regex)
        {
            if(string.IsNullOrWhiteSpace(rule.Pattern)||rule.Pattern.Length>2000||rule.Keywords is not null||rule.IgnoreCase||rule.WholeWords)
                throw new ArgumentException("Задайте регулярное выражение до 2000 символов. Настройки ключевых слов используются только в соответствующем типе.");
            pattern=rule.Pattern;
        }
        else
        {
            if(rule.Pattern!=RuleFormats.TypedPattern)throw new ArgumentException("Некорректный формат готового правила. Обновите редактор.");
            if(rule.Kind==DetectionRuleKind.Keywords)
            {
                if(rule.Keywords is null||rule.Keywords.Count is <1 or >100||rule.Keywords.Any(word=>string.IsNullOrWhiteSpace(word)||word.Length>120||word.Any(char.IsControl))
                    ||rule.Keywords.Sum(word=>word.Length)>8192)throw new ArgumentException("Введите от 1 до 100 слов или фраз: до 120 символов в строке и 8192 символов суммарно.");
                var words=rule.Keywords.Select(word=>word.Trim()).Distinct(rule.IgnoreCase?StringComparer.OrdinalIgnoreCase:StringComparer.Ordinal).ToArray();
                rule=rule with{Keywords=words};
                pattern="(?:"+string.Join("|",words.OrderByDescending(word=>word.Length).Select(Regex.Escape))+")";
                if(rule.WholeWords)pattern=@"(?<![\p{L}\p{N}_])"+pattern+@"(?![\p{L}\p{N}_])";
                if(rule.IgnoreCase)options|=RegexOptions.IgnoreCase;
            }
            else
            {
                if(rule.Keywords is not null||rule.IgnoreCase||rule.WholeWords)throw new ArgumentException("Для готовой проверки номера дополнительные параметры не требуются.");
                pattern=rule.Kind==DetectionRuleKind.Inn?@"(?<![0-9])[0-9]{10}(?:[0-9]{2})?(?![0-9])":@"(?<![0-9])[0-9]{3}[ -]?[0-9]{3}[ -]?[0-9]{3}[ -]?[0-9]{2}(?![0-9])";
            }
        }
        try{return(rule with{Name=rule.Name.Trim()},new Regex(pattern,options,TimeSpan.FromMilliseconds(100)));}
        catch(ArgumentException){throw new ArgumentException("Некорректное регулярное выражение. Исправьте правило до сохранения.");}
    }
}
