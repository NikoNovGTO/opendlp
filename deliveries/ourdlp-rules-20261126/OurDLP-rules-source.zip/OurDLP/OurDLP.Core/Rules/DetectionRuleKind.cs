using System.Text.Json.Serialization;
namespace OurDLP.Core.Rules;

[JsonConverter(typeof(JsonStringEnumConverter<DetectionRuleKind>))]
public enum DetectionRuleKind { Regex, Keywords, Inn, Snils }
