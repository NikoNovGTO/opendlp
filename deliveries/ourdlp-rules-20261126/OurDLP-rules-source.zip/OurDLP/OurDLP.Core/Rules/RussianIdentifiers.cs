namespace OurDLP.Core.Rules;

public static class RussianIdentifiers
{
    public static bool IsInn(ReadOnlySpan<char> value)
    {
        if (value.Length is not (10 or 12)) return false;
        foreach (var c in value) if (c is < '0' or > '9') return false;
        var identical = true; foreach (var c in value) identical &= c == value[0];
        if (identical) return false;
        return value.Length == 10 ? Digit(value, [2,4,10,3,5,9,4,6,8]) == value[9]-'0'
            : Digit(value, [7,2,4,10,3,5,9,4,6,8]) == value[10]-'0'
                && Digit(value, [3,7,2,4,10,3,5,9,4,6,8]) == value[11]-'0';
    }
    private static int Digit(ReadOnlySpan<char> value, ReadOnlySpan<int> weights)
    { var sum=0; for(var i=0;i<weights.Length;i++) sum+=(value[i]-'0')*weights[i]; return sum%11%10; }
    public static bool IsSnils(ReadOnlySpan<char> value)
    {
        Span<int> digits=stackalloc int[11]; var count=0;
        foreach(var c in value)
        {
            if(c is ' ' or '-') continue;
            if(c is < '0' or > '9' || count==11) return false;
            digits[count++]=c-'0';
        }
        if(count!=11) return false;
        var serial=0;for(var i=0;i<9;i++) serial=serial*10+digits[i];
        // Historical numbers without a verifiable checksum are outside this detector's confirmed scope.
        if(serial<=1001998) return false;
        var sum=0;for(var i=0;i<9;i++)sum+=digits[i]*(9-i);
        var check=sum%101;if(check==100)check=0;
        return check==digits[9]*10+digits[10];
    }
}
