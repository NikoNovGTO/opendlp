using OurDLP.Core.Clipboard;
using OurDLP.Core.Scanning;
namespace OurDLP.Core.Rules;

public static class RuleFormats
{
    public const int Current = 2;
    // Invalid regex on purpose: an older program must reject a cached typed rule, never reinterpret it.
    public const string TypedPattern = "[OURDLP-RULE-V2";
    public static int Required(ScanRule rule) => rule.Kind == DetectionRuleKind.Regex && rule.Keywords is null && !rule.IgnoreCase && !rule.WholeWords ? 1 : 2;
    public static int Required(ClipboardPolicy? policy) => policy?.Rules.Select(Required).DefaultIfEmpty(1).Max() ?? 1;
    public static bool Same(ScanRule a, ScanRule b) => a.Id == b.Id && a.Name == b.Name && a.Pattern == b.Pattern
        && a.Kind == b.Kind && a.IgnoreCase == b.IgnoreCase && a.WholeWords == b.WholeWords
        && (a.Keywords is null || b.Keywords is null ? a.Keywords is null && b.Keywords is null : a.Keywords.SequenceEqual(b.Keywords, StringComparer.Ordinal));
}
