using OurDLP.Core.Rules;

namespace OurDLP.Core.Clipboard;

public sealed class CompiledClipboardPolicy
{
    public ClipboardPolicy Definition { get; }
    private readonly IReadOnlyList<CompiledDetectionRule> _rules;
    public CompiledClipboardPolicy(ClipboardPolicy definition)
    {
        if (definition is null || definition.Id == Guid.Empty || definition.Version < 1
            || string.IsNullOrWhiteSpace(definition.Name) || definition.Name.Length > 100
            || definition.MaxTextCharacters is < 1024 or > 65536 || definition.Rules is null
            || definition.Rules.Count is < 1 or > 20 || definition.Rules.Any(rule => rule is null)
            || definition.Rules.Select(rule => rule.Id).Distinct().Count() != definition.Rules.Count)
            throw new ArgumentException("Некорректная политика буфера обмена.");
        if (System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(definition).Length > 128 * 1024) throw new ArgumentException("Политика превышает 128 КиБ.");
        _rules = definition.Rules.Select(rule => new CompiledDetectionRule(rule)).ToArray();
        Definition = definition with { Rules = _rules.Select(rule => rule.Definition).ToArray() };
    }

    public ClipboardAnalysis Analyze(ReadOnlySpan<char> text, bool truncated = false)
    {
        if (!Definition.Enabled) return new(0, false, [], []);
        if (text.Length > Definition.MaxTextCharacters) { text = text[..Definition.MaxTextCharacters]; truncated = true; }
        var hits = new List<ClipboardRuleHit>(); var timeouts = new List<Guid>();
        foreach (var rule in _rules)
        {
            var result = rule.Count(text, 100);
            if (result.TimedOut) timeouts.Add(rule.Definition.Id);
            if (result.Count != 0) hits.Add(new(rule.Definition.Id, result.Count, result.Limited));
        }
        return new(text.Length, truncated, hits, timeouts);
    }
}
