namespace OurDLP.Core.Clipboard;

/// <summary>Compares every persisted policy field, including ordered rule content.</summary>
public static class ClipboardPolicyContent
{
    public static bool Same(ClipboardPolicy? left, ClipboardPolicy? right)
    {
        if (left is null || right is null) return left is null && right is null;
        return left.Id == right.Id && left.Version == right.Version && left.Name == right.Name
            && left.Enabled == right.Enabled && left.MaxTextCharacters == right.MaxTextCharacters
            && left.Rules is not null && right.Rules is not null && left.Rules.Count == right.Rules.Count
            && left.Rules.Zip(right.Rules).All(pair => pair.First is not null && pair.Second is not null && OurDLP.Core.Rules.RuleFormats.Same(pair.First, pair.Second));
    }
}
