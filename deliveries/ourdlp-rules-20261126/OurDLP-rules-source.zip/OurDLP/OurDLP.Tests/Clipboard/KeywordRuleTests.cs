using System.Text.RegularExpressions;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Rules;
using OurDLP.Core.Scanning;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class KeywordRuleTests
{
    internal static ScanRule Words(params string[] words) => new(Guid.NewGuid(), "Мои слова", RuleFormats.TypedPattern)
    { Kind = DetectionRuleKind.Keywords, Keywords = words, IgnoreCase = true, WholeWords = true };

    [Theory]
    [InlineData("C++", "C++ C-- C++", 2)]
    [InlineData("a.b", "a.b axb", 1)]
    [InlineData("(тайна)", "(тайна) тайна", 1)]
    [InlineData("акт", "акт контракт акты АКТ", 2)]
    [InlineData("тайна", "тайна_код 1тайна тайна2 тайна", 1)]
    [InlineData("коммерческая тайна", "Коммерческая тайна; коммерческая  тайна", 1)]
    public void LiteralUnicodeWordsAndPhrasesHavePredictableBoundaries(string word, string text, int count)
        => Assert.Equal(count, new CompiledDetectionRule(Words(word)).Count(text, 100).Count);

    [Fact]
    public void CaseAndSubstringOptionsAreIndependent()
    {
        var rule = Words("акт");
        Assert.Equal(1, new CompiledDetectionRule(rule with { IgnoreCase = false }).Count("АКТ акт контракт", 100).Count);
        Assert.Equal(3, new CompiledDetectionRule(rule with { WholeWords = false }).Count("АКТ акт контракт", 100).Count);
    }

    [Fact]
    public void DuplicatesAreNormalizedAndLongestPhraseWinsWithoutDoubleCounting()
    {
        var prepared = new CompiledDetectionRule(Words(" тайна ", "ТАЙНА", "тайна проекта"));
        Assert.Equal(new[] { "тайна", "тайна проекта" }, prepared.Definition.Keywords);
        Assert.Equal(2, prepared.Count("тайна проекта; тайна", 100).Count);
    }

    [Fact]
    public void LimitsRejectMalformedOrUnboundedLists()
    {
        foreach (var words in new string[][] { [], [" "], ["a\tb"], [new('я', 121)], Enumerable.Repeat("a", 101).ToArray(), Enumerable.Repeat(new string('b', 120), 69).ToArray() })
            Assert.Throws<ArgumentException>(() => new CompiledDetectionRule(Words(words)));
        var rule = Words("тайна");
        foreach (var bad in new[] { rule with { Kind = (DetectionRuleKind)99 }, rule with { Pattern = "тайна" }, rule with { Kind = DetectionRuleKind.Regex } })
            Assert.Throws<ArgumentException>(() => new CompiledDetectionRule(bad));
    }

    [Fact]
    public void LegacyRegexJsonIsUnchangedAndTypedRulesCannotBeReadAsRegex()
    {
        var id = Guid.NewGuid(); var legacy = new ScanRule(id, "Legacy", "SECRET");
        Assert.Equal($"{{\"id\":\"{id}\",\"name\":\"Legacy\",\"pattern\":\"SECRET\"}}", ScanWire.Serialize(legacy));
        Assert.Equal(DetectionRuleKind.Regex, ScanWire.Read<ScanRule>(ScanWire.Serialize(legacy)).Kind);
        var typed = ScanWire.Read<ScanRule>(ScanWire.Serialize(Words("тайна")));
        Assert.Equal(DetectionRuleKind.Keywords, typed.Kind);
        Assert.Throws<RegexParseException>(() => new Regex(typed.Pattern));
    }

    [Fact]
    public void KeywordMetadataContainsCountsWithoutMatchedText()
    {
        var p = ClipboardSamples.Policy() with { Rules = [Words("внутренний секрет")] };
        var result = new CompiledClipboardPolicy(p).Analyze(string.Join(";", Enumerable.Repeat("ВНУТРЕННИЙ СЕКРЕТ", 110)));
        Assert.Equal(100, Assert.Single(result.Hits).Count); Assert.True(result.Hits[0].CountLimited);
        Assert.DoesNotContain("секрет", ScanWire.Serialize(result), StringComparison.OrdinalIgnoreCase);
        Assert.True(ClipboardPolicyContent.Same(p, ScanWire.Read<ClipboardPolicy>(ScanWire.Serialize(p))));
        Assert.False(ClipboardPolicyContent.Same(p, p with { Rules = [p.Rules[0] with { WholeWords = false }] }));
        Assert.False(ClipboardPolicyContent.Same(p, p with { Rules = [Words("другое слово") with { Id = p.Rules[0].Id }] }));
    }
}
