using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Server.Data;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class TypedRulesPostgresTests
{
    [PostgresFact]
    [Trait("Category", "Postgres")]
    public async Task NewPolicyRoundTripsAndOldAgentCannotReceiveOrConfirmTypedRules()
    {
        await using var f = await ClipboardFixture.CreateAsync();
        var created = (await f.Admin.SaveAsync(null, new("Мои данные", true, 16384, [KeywordRuleTests.Words("Коммерческая тайна", "Проект Орион")]), default)).Value!;
        Assert.NotNull(created); Assert.Equal(2, Assert.Single((await f.Admin.DevicesAsync(default)).Value!.Devices).RuleFormatVersion);
        var loaded = Assert.Single((await f.Admin.PoliciesAsync(default)).Value!.Policies);
        Assert.True(ClipboardPolicyContent.Same(created, loaded));
        Assert.NotNull((await f.Admin.AssignAsync(f.State.DeviceId!.Value, created.Id, default)).Value);
        var reply = await f.ExchangeAsync(); Assert.Equal(2, reply.RequiredRuleFormat); Assert.NotNull(reply.Policy);
        var detection = ClipboardSamples.Detection(created);
        var legacy = new ClipboardAgentSync(1, created.Id, 1, [new(ClipboardSamples.Peer.UserSid, ClipboardSamples.Peer.UserName, 3, created.Id, 1, DateTimeOffset.UtcNow, 0)],
            [new(detection, ClipboardSamples.Peer.UserSid, ClipboardSamples.Peer.UserName, 3)]);
        // Historical queued metadata still receives an acknowledgement, even after an agent downgrade.
        var oldReply = (await f.Agent.SyncAsync(f.State, legacy, default)).Value!;
        Assert.Null(oldReply.Policy); Assert.Equal(2, oldReply.RequiredRuleFormat); Assert.Single(oldReply.Accepted);
        var state = Assert.Single((await f.Admin.DevicesAsync(default)).Value!.Devices);
        Assert.Equal(1, state.RuleFormatVersion); Assert.Equal(2, state.RequiredRuleFormat); Assert.Null(Assert.Single(state.Helpers).AppliedVersion);
        var denied = await f.Admin.AssignAsync(f.State.DeviceId.Value, created.Id, default); Assert.Null(denied.Value); Assert.Contains("0.10.0", denied.Error!);
        Assert.Equal(400, (await f.Agent.SyncAsync(f.State, legacy with { RuleFormatVersion = 99 }, default)).StatusCode);
        await f.ExchangeAsync(); Assert.NotNull((await f.Admin.AssignAsync(f.State.DeviceId.Value, created.Id, default)).Value);
        var events = (await f.Admin.EventsAsync(default)).Value!.Events; Assert.Single(events);
    }

    [PostgresFact]
    [Trait("Category", "Postgres")]
    public async Task AddingTypedRuleToAssignedPolicyRequiresAgentUpgradeAndPreservesOldRevision()
    {
        await using var f = await ClipboardFixture.CreateAsync(); var old = await f.AssignAsync();
        await f.Agent.SyncAsync(f.State, new(1, old.Id, 1, [], []), default); // Real legacy clients omit the optional capability field.
        var draft = new ClipboardPolicyDraft(old.Name, true, old.MaxTextCharacters, [old.Rules[0], KeywordRuleTests.Words("тайна")], old.Version);
        var rejected = await f.Admin.SaveAsync(old.Id, draft, default); Assert.Null(rejected.Value); Assert.Contains("старым агентом", rejected.Error!);
        var unchanged = Assert.Single((await f.Admin.PoliciesAsync(default)).Value!.Policies); Assert.Equal(1, unchanged.Version); Assert.Single(unchanged.Rules);
        await f.ExchangeAsync(); var next = (await f.Admin.SaveAsync(old.Id, draft, default)).Value!;
        Assert.Equal(2, next.Version); Assert.Equal(2, next.Rules.Count);
        var delivered = await f.ExchangeAsync(); Assert.Equal(2, delivered.Policy!.Version);
        await using var scope = f.Context.Server.Services.CreateAsyncScope(); var db = scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        Assert.Equal(2, (await db.ClipboardPolicies.SingleAsync()).RequiredRuleFormat);
        var historical = ScanWire.Read<ClipboardPolicy>((await db.ClipboardPolicyRevisions.SingleAsync(r => r.Version == 1)).DefinitionJson);
        Assert.True(ClipboardPolicyContent.Same(old, historical));
    }

    [PostgresFact]
    [Trait("Category", "Postgres")]
    public async Task UpgradeFromPreviousSchemaPreservesLegacyPolicyAndDefaultsCapabilitiesToOne()
    {
        await using var database = await PostgresTestDatabase.CreateAsync();
        var options = new DbContextOptionsBuilder<OurDlpDbContext>().UseNpgsql(database.ConnectionString).Options;
        var policy = ClipboardSamples.Policy(); var id = Guid.NewGuid(); var json = ScanWire.Serialize(policy);
        await using (var db = new OurDlpDbContext(options))
        {
            await db.GetService<IMigrator>().MigrateAsync("20261125054700_ClipboardPolicies");
            await db.Database.ExecuteSqlInterpolatedAsync($"INSERT INTO clipboard_policies (\"Id\",\"Name\",\"CurrentVersion\") VALUES ({policy.Id},{policy.Name},{1})");
            await db.Database.ExecuteSqlInterpolatedAsync($"INSERT INTO clipboard_policy_revisions (\"PolicyId\",\"Version\",\"DefinitionJson\",\"AdministratorId\",\"CreatedAtUtc\") VALUES ({policy.Id},{1},{json}::jsonb,{id},{DateTimeOffset.UtcNow})");
            await db.Database.ExecuteSqlInterpolatedAsync($"INSERT INTO devices (\"Id\",\"Name\",\"CreatedAtUtc\",\"IsAccessRevoked\") VALUES ({id},{"Legacy-PC"},{DateTimeOffset.UtcNow},{false})");
            await db.Database.ExecuteSqlInterpolatedAsync($"INSERT INTO clipboard_device_configuration (\"DeviceId\",\"Capable\",\"AssignedPolicyId\",\"HelpersJson\") VALUES ({id},{true},{policy.Id},{"[]"}::jsonb)");
            await db.Database.MigrateAsync(); await db.Database.MigrateAsync();
        }
        await using (var db = new OurDlpDbContext(options))
        {
            Assert.Equal(1, (await db.ClipboardPolicies.SingleAsync()).RequiredRuleFormat);
            var device = await db.ClipboardDevices.SingleAsync(); Assert.Equal(1, device.RuleFormatVersion); Assert.Equal(policy.Id, device.AssignedPolicyId);
            Assert.True(ClipboardPolicyContent.Same(policy, ScanWire.Read<ClipboardPolicy>((await db.ClipboardPolicyRevisions.SingleAsync()).DefinitionJson)));
            Assert.Empty(await db.Database.GetPendingMigrationsAsync());
        }
    }
}
