using OurDLP.Agent;
using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Session;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class ClipboardIdleTests
{
    private static T Copy<T>(T value) => value is null ? value : ScanWire.Read<T>(ScanWire.Serialize(value));
    private static readonly string Key = new('A', 64);

    [Theory][InlineData(false)][InlineData(true)]
    public async Task OneHundredUnchangedUserRepliesReuseThePreparedPolicyAndDoNotRewriteTheStore(bool typed)
    {
        var policy = ClipboardSamples.Policy();
        if(typed) policy=policy with{Rules=[KeywordRuleTests.Words("тайна")]};
        var store = new CountingSessionStore { State = new() { SchemaVersion=OurDLP.Core.Rules.RuleFormats.Required(policy),RegistrationKey = Key, Policy = policy } };
        var pipe = new TestSessionClient { Exchange = _ => Task.FromResult<ClipboardSessionResponse?>(new(Key, Copy(policy), [], [], false)) };
        var session = new SessionCoordinator(store, pipe); await session.InitializeAsync(default);
        var prepared = session.CurrentPolicy;
        for (var i = 0; i < 100; i++) await session.SyncOnceAsync(default);
        Assert.Same(prepared, session.CurrentPolicy); Assert.Equal(100, store.Updates); Assert.Equal(0, store.Writes);
    }

    [Theory][InlineData(true)][InlineData(false)]
    public async Task ServicePersistsInitialStateOnceAndDoesNotRewriteIdenticalReplies(bool assigned)
    {
        var registration = new MemoryAgentState();
        await registration.SaveAsync(new() { ServerAddress = "https://localhost", DeviceId = Guid.NewGuid(), Token = new('B', 43) }, default);
        var store = new CountingAgentStore(); var service = new ClipboardAgentCoordinator(registration, store);
        var policy = assigned ? ClipboardSamples.Policy() : null;
        for (var i = 0; i < 100; i++) await service.ApplyAsync(new(Copy(policy), [], []), [], default);
        Assert.Equal(1, store.Writes); Assert.NotNull(store.State);
    }

    [Fact]
    public async Task ChangedContentUnderTheSameIdAndVersionIsAppliedAndInvalidChangesAreRejected()
    {
        var policy = ClipboardSamples.Policy();
        var store = new CountingSessionStore { State = new() { RegistrationKey = Key, Policy = policy } };
        var response = policy;
        var session = new SessionCoordinator(store, new TestSessionClient { Exchange = _ => Task.FromResult<ClipboardSessionResponse?>(new(Key, Copy(response), [], [], false)) });
        await session.InitializeAsync(default); var original = session.CurrentPolicy;
        response = policy with { Rules = [policy.Rules[0] with { Pattern = "CHANGED" }] };
        await session.SyncOnceAsync(default);
        Assert.NotSame(original!.Compiled, session.CurrentPolicy!.Compiled);
        Assert.Single(session.CurrentPolicy.Compiled.Analyze("CHANGED").Hits); Assert.Equal(1, store.Writes);
        var lastGood = session.CurrentPolicy;
        response = response with { Rules = [response.Rules[0] with { Pattern = "(" }] };
        await Assert.ThrowsAsync<ArgumentException>(() => session.SyncOnceAsync(default));
        Assert.Same(lastGood, session.CurrentPolicy); Assert.Equal(1, store.Writes);
    }

    [Fact]
    public async Task ConcurrentlyPersistedNewEventSurvivesAnUnchangedInFlightReply()
    {
        var p = ClipboardSamples.Policy(); var detection = ClipboardSamples.Detection(p);
        var store = new CountingSessionStore { State = new() { RegistrationKey = Key, Policy = p } };
        var pipe = new TestSessionClient { Exchange = _ =>
        {
            store.State = store.State with { Pending = [detection], DroppedCaptures = 3 };
            return Task.FromResult<ClipboardSessionResponse?>(new(Key, Copy(p), [], [], false));
        } };
        var session = new SessionCoordinator(store, pipe); await session.InitializeAsync(default); await session.SyncOnceAsync(default);
        Assert.Equal(detection.Id, Assert.Single(store.State.Pending).Id); Assert.Equal(3, store.State.DroppedCaptures);
        Assert.Equal(0, store.Writes);
    }

    [Fact]
    public async Task FailedPolicyWriteDoesNotAdvanceTheAppliedVersion()
    {
        var p = ClipboardSamples.Policy(); var next = p with { Version = 2, Enabled = false };
        var store = new CountingSessionStore { State = new() { RegistrationKey = Key, Policy = p }, FailWrite = true };
        var session = new SessionCoordinator(store, new TestSessionClient { Exchange = _ => Task.FromResult<ClipboardSessionResponse?>(new(Key, next, [], [], false)) });
        await session.InitializeAsync(default);
        await Assert.ThrowsAsync<IOException>(() => session.SyncOnceAsync(default));
        Assert.Equal(1, session.CurrentPolicy!.Compiled.Definition.Version);
        store.FailWrite = false; await session.SyncOnceAsync(default);
        Assert.Equal(2, session.CurrentPolicy!.Compiled.Definition.Version); Assert.False(session.CurrentPolicy.Compiled.Definition.Enabled);
    }

    [Fact]
    public async Task DuplicateDurableEventNeedsNoNewWriteButANewEventStillRequiresPersistence()
    {
        var registration = new MemoryAgentState();
        await registration.SaveAsync(new() { ServerAddress = "https://localhost", DeviceId = Guid.NewGuid(), Token = new('B', 43) }, default);
        var store = new CountingAgentStore(); var service = new ClipboardAgentCoordinator(registration, store);
        var p = ClipboardSamples.Policy(); await service.ApplyAsync(new(p, [], []), [], default);
        var detection = ClipboardSamples.Detection(p); var request = ClipboardSamples.Request(store.State!.RegistrationKey, detection);
        await service.SessionAsync(ClipboardSamples.Peer, request, default); var writes = store.Writes;
        store.FailWrite = true;
        var duplicate = await service.SessionAsync(ClipboardSamples.Peer, request, default);
        Assert.Equal(detection.Id, Assert.Single(duplicate.Accepted)); Assert.Equal(writes, store.Writes);
        await Assert.ThrowsAsync<IOException>(() => service.SessionAsync(ClipboardSamples.Peer, request with { Events = [detection with { Id = Guid.NewGuid() }] }, default));
        Assert.Single(store.State.Pending);
    }

    [Fact]
    public void PolicyEqualityUsesAllFieldsAndOrderedRulesRatherThanOnlyIdsAndVersions()
    {
        var p = ClipboardSamples.Policy() with { Rules = [ClipboardSamples.Policy().Rules[0], ClipboardSamples.Policy().Rules[0]] };
        Assert.True(ClipboardPolicyContent.Same(p, Copy(p)));
        foreach (var changed in new[] { p with { Id = Guid.NewGuid() }, p with { Version = 2 }, p with { Name = "other" },
            p with { Enabled = false }, p with { MaxTextCharacters = 4096 }, p with { Rules = p.Rules.Reverse().ToArray() },
            p with { Rules = [p.Rules[0] with { Name = "other" }, p.Rules[1]] }, p with { Rules = [p.Rules[0] with { Pattern = "other" }, p.Rules[1]] } })
            Assert.False(ClipboardPolicyContent.Same(p, changed));
        Assert.False(ClipboardPolicyContent.Same(p, null)); Assert.True(ClipboardPolicyContent.Same(null, null));
    }

    private sealed class CountingSessionStore : ISessionStateStore
    {
        public SessionState State { get; set; } = new();
        public int Writes { get; private set; }
        public int Updates { get; private set; }
        public bool FailWrite { get; set; }
        public Task<SessionState> ReadAsync(CancellationToken token) => Task.FromResult(Copy(State));
        public Task<SessionState> UpdateAsync(Func<SessionState, SessionState> update, CancellationToken token)
        {
            Updates++; var current = Copy(State); var next = update(current);
            if (!ReferenceEquals(current, next))
            {
                if (FailWrite) throw new IOException("Fixture write unavailable");
                Writes++; State = Copy(next);
            }
            return Task.FromResult(Copy(State));
        }
    }
    private sealed class CountingAgentStore : IClipboardAgentStore
    {
        public ClipboardAgentState? State { get; private set; }
        public int Writes { get; private set; }
        public bool FailWrite { get; set; }
        public Task<ClipboardAgentState?> ReadAsync(CancellationToken token) => Task.FromResult(Copy(State));
        public Task SaveAsync(ClipboardAgentState value, CancellationToken token)
        { if (FailWrite) throw new IOException("Fixture write unavailable"); Writes++; State = Copy(value); return Task.CompletedTask; }
        public Task ArchiveAsync(CancellationToken token) { State = null; return Task.CompletedTask; }
    }
}
