using OurDLP.Core.Rules;
using OurDLP.Core.Scanning;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class NumberRuleTests
{
    internal static ScanRule Number(DetectionRuleKind kind) => new(Guid.NewGuid(), kind.ToString(), RuleFormats.TypedPattern) { Kind = kind };

    [Theory]
    [InlineData("7707083893", true)]
    [InlineData("500100732259", true)]
    [InlineData("7707083894", false)]
    [InlineData("500100732258", false)]
    [InlineData("0000000000", false)]
    [InlineData("111111111111", false)]
    [InlineData("770708389", false)]
    [InlineData("７707083893", false)]
    public void InnChecksBothLengthsAndChecksums(string text, bool expected)
        => Assert.Equal(expected, RussianIdentifiers.IsInn(text));

    [Theory]
    [InlineData("112-233-445 95", true)]
    [InlineData("11223344595", true)]
    [InlineData("112 233 445 95", true)]
    [InlineData("112-233-445 96", false)]
    [InlineData("001-001-998 00", false)]
    [InlineData("00000000000", false)]
    [InlineData("1122334459", false)]
    public void SnilsChecksFormatAndExcludesHistoricalUnverifiableNumbers(string text, bool expected)
        => Assert.Equal(expected, new CompiledDetectionRule(Number(DetectionRuleKind.Snils)).Count(text, 100).Count == 1);

    [Fact]
    public void EmbeddedLongDigitRunsDoNotBecomeShorterValidNumbers()
    {
        var inn = new CompiledDetectionRule(Number(DetectionRuleKind.Inn));
        Assert.Equal(2, inn.Count("ИНН: 7707083893 / 500100732259", 100).Count);
        Assert.Equal(0, inn.Count("17707083893 77070838930 1500100732259 5001007322590", 100).Count);
        var snils = new CompiledDetectionRule(Number(DetectionRuleKind.Snils));
        Assert.Equal(0, snils.Count("111223344595 112233445950", 100).Count);
    }

    [Fact]
    public void NumberRulesRejectKeywordParameters()
        => Assert.Throws<ArgumentException>(() => new CompiledDetectionRule(Number(DetectionRuleKind.Inn) with { IgnoreCase = true }));
}
