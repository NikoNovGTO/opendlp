using OurDLP.Core.Rules;
using OurDLP.Desktop.ViewModels.Clipboard;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class PolicyEditorTests
{
    [Fact]
    public async Task EditorRoundTripsEveryRuleAndIdAndAllowsTargetedEditing()
    {
        var p = ClipboardSamples.Policy() with { Rules = [ClipboardSamples.Policy().Rules[0], KeywordRuleTests.Words("тайна"), NumberRuleTests.Number(DetectionRuleKind.Inn)] };
        using var editor = new ClipboardPolicyEditor(); editor.Load(p);
        Assert.Equal(p.Rules.Select(r => r.Id), editor.Draft().Rules.Select(r => r.Id));
        editor.SelectedRule = editor.Rules[1]; editor.SelectedRule.KeywordsText = "тайна\r\nПроект Орион\n\n  тайна  ";
        var saved = editor.Draft(); Assert.Equal(1, saved.ExpectedVersion);
        Assert.Equal(new[] { "тайна", "Проект Орион" }, saved.Rules[1].Keywords);
        Assert.Equal(p.Rules[0], saved.Rules[0]); Assert.Equal(p.Rules[2], saved.Rules[2]);
        await editor.DeleteRuleCommand.ExecuteAsync();
        Assert.Equal(new[] { p.Rules[0].Id, p.Rules[2].Id }, editor.Draft().Rules.Select(r => r.Id));
    }

    [Fact]
    public async Task AddButtonsAndRuleLimitPreserveExistingRules()
    {
        using var editor = new ClipboardPolicyEditor();
        await editor.AddKeywordsCommand.ExecuteAsync(); editor.SelectedRule!.KeywordsText = "Коммерческая тайна\nПроект Орион";
        await editor.AddInnCommand.ExecuteAsync(); await editor.AddSnilsCommand.ExecuteAsync();
        Assert.Equal(new[] { DetectionRuleKind.Regex, DetectionRuleKind.Keywords, DetectionRuleKind.Inn, DetectionRuleKind.Snils }, editor.Draft().Rules.Select(r => r.Kind));
        for (var i = 4; i < 20; i++) await editor.AddInnCommand.ExecuteAsync();
        Assert.False(editor.AddKeywordsCommand.CanExecute(null)); Assert.Equal(20, editor.Draft().Rules.Count);
    }

    [Fact]
    public async Task LocalPreviewUsesUnsavedRulesAndInvalidatesResultsAfterEditing()
    {
        using var editor = new ClipboardPolicyEditor(); await editor.AddKeywordsCommand.ExecuteAsync();
        editor.SelectedRule!.KeywordsText = "коммерческая тайна";
        editor.Preview.Text = "КОММЕРЧЕСКАЯ ТАЙНА"; await editor.Preview.TestCommand.ExecuteAsync();
        Assert.Contains(editor.Preview.Results, row => row.Rule == "Мои ключевые слова" && row.Result == "Совпадений: 1");
        Assert.Null(editor.Id); Assert.Contains("не сохранена", editor.Preview.Message);
        editor.SelectedRule.WholeWords = false; Assert.Empty(editor.Preview.Results);
        editor.Enabled = false; await editor.Preview.TestCommand.ExecuteAsync(); Assert.Contains("выключено", editor.Preview.Message);
        editor.Enabled = true; editor.SelectedRule.KeywordsText = "";
        await editor.Preview.TestCommand.ExecuteAsync(); Assert.Empty(editor.Preview.Results); Assert.Contains("100", editor.Preview.Message);
        editor.Dispose(); Assert.Equal("", editor.Preview.Text); Assert.False(editor.Preview.TestCommand.CanExecute(null));
    }
}
