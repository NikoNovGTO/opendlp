using OurDLP.Agent.Clipboard;
using OurDLP.Contracts;
using OurDLP.Core.Rules;
using OurDLP.Desktop.ViewModels.Clipboard;
using OurDLP.Session;
using Xunit;

namespace OurDLP.Tests.Clipboard;

public sealed class TypedPolicyCompatibilityTests
{
    [Fact]
    public async Task OldHelperReceivesNoUnsupportedPolicyAndCannotConfirmIt()
    {
        var p = ClipboardSamples.Policy() with { Rules = [KeywordRuleTests.Words("тайна")] };
        var (_, service, store) = await ClipboardSamples.AgentAsync(p);
        Assert.Equal(2, store.State!.SchemaVersion);
        var old = ClipboardSamples.Request(store.State.RegistrationKey) with { AppliedPolicyId = p.Id, AppliedVersion = p.Version };
        var reply = await service.SessionAsync(ClipboardSamples.Peer, old, default);
        Assert.Null(reply.Policy); Assert.Equal(2, reply.RequiredRuleFormat);
        var packet = await service.SnapshotAsync(default); Assert.Equal(2, packet.RuleFormatVersion);
        var helper = Assert.Single(packet.Helpers); Assert.Null(helper.AppliedVersion); Assert.Equal(1, helper.RuleFormatVersion);
        await Assert.ThrowsAsync<InvalidDataException>(() => service.SessionAsync(ClipboardSamples.Peer, old with { RuleFormatVersion = 99 }, default));
    }

    [Fact]
    public async Task NewHelperLoadsTypedPolicyPersistsSchemaAndDetectsOffline()
    {
        var p = ClipboardSamples.Policy() with { Rules = [KeywordRuleTests.Words("тайна")] };
        var (_, service, _) = await ClipboardSamples.AgentAsync(p); var pipe = new TestSessionClient(); pipe.Connect(service);
        var store = new TestSessionStore(); var session = new SessionCoordinator(store, pipe);
        await session.InitializeAsync(default); await session.SyncOnceAsync(default); session.SetListenerReady(true); await session.SyncOnceAsync(default);
        Assert.Equal(2, pipe.LastRequest!.RuleFormatVersion); Assert.Equal(2, store.State.SchemaVersion);
        var active = session.CurrentPolicy!; pipe.Exchange = _ => Task.FromResult<ClipboardSessionResponse?>(null);
        var chars = "ТАЙНА".ToCharArray();
        using (var captured = new CapturedClipboard(new(chars, chars.Length), active, false, "notepad", 3, DateTimeOffset.UtcNow))
            await session.EnqueueAsync(captured, default);
        await session.SyncOnceAsync(default); Assert.Single(store.State.Pending); Assert.DoesNotContain("ТАЙНА", ScanWire.Serialize(store.State.Pending));
        var restarted = new SessionCoordinator(store, pipe); await restarted.InitializeAsync(default);
        Assert.Single(restarted.CurrentPolicy!.Compiled.Analyze("ТАЙНА").Hits);
    }

    [Fact]
    public async Task SwitchingBackToLegacyKeepsQueuedEventsAndUsesLegacySchema()
    {
        var p = ClipboardSamples.Policy() with { Rules = [KeywordRuleTests.Words("тайна")] };
        var (registration, service, store) = await ClipboardSamples.AgentAsync(p);
        var detection = ClipboardSamples.Detection(p);
        await service.SessionAsync(ClipboardSamples.Peer, ClipboardSamples.Request(store.State!.RegistrationKey, detection) with { RuleFormatVersion = 2 }, default);
        var legacy = ClipboardSamples.Policy(); await service.ApplyAsync(new(legacy, [], []), [], default);
        Assert.Equal(1, store.State!.SchemaVersion); Assert.Single(store.State.Pending);
        var restarted = new ClipboardAgentCoordinator(registration, store);
        Assert.Equal(legacy.Id, (await restarted.SessionAsync(ClipboardSamples.Peer, ClipboardSamples.Request(store.State.RegistrationKey), default)).Policy!.Id);
    }

    [Fact]
    public void ConsoleDoesNotShowUnsupportedAgentOrHelperAsObserving()
    {
        var p = ClipboardSamples.Policy() with { Rules = [KeywordRuleTests.Words("тайна")] }; var now = DateTimeOffset.UtcNow;
        var helper = new ClipboardHelperStatus(ClipboardSamples.Peer.UserSid, "Тест", 3, p.Id, 1, now, 0);
        var d = new ClipboardDeviceState(Guid.NewGuid(), "PC", true, "active", p.Id, 1, p.Id, 1, [helper], 1, 2);
        Assert.Equal("update-rules", ClipboardDeviceStatus.Evaluate(d, p, now).Code);
        Assert.Equal("update-session", ClipboardDeviceStatus.Evaluate(d with { RuleFormatVersion = 2 }, p, now).Code);
        Assert.Equal("observing", ClipboardDeviceStatus.Evaluate(d with { RuleFormatVersion = 2, Helpers = [helper with { RuleFormatVersion = 2 }] }, p, now).Code);
        Assert.Equal("update-rules", ClipboardDeviceStatus.Evaluate(d, null, now).Code);
    }
}
