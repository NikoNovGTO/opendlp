using OurDLP.Server.Data;
using OurDLP.Server.Endpoints;

var migrate = args.Contains("--migrate-database", StringComparer.Ordinal);
var builder = WebApplication.CreateBuilder(args.Where(argument => argument != "--migrate-database").ToArray());
builder.Logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", migrate ? LogLevel.Critical : LogLevel.Warning);
builder.Services.AddProblemDetails();
builder.Services.AddOurDlpDatabase(builder.Configuration);

var app = builder.Build();
if (migrate)
{
    Environment.ExitCode = await DatabaseMigrationRunner.RunAsync(app.Services);
    return;
}
app.UseExceptionHandler();
app.MapServerStatusEndpoints();
app.MapDatabaseHealthEndpoints();
app.Run();

public partial class Program { }
