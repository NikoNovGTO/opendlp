using OurDLP.Server.Data;

namespace OurDLP.Server.Endpoints;

public static class DatabaseHealthEndpoints
{
    public static IEndpointRouteBuilder MapDatabaseHealthEndpoints(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/api/health/database", async (DatabaseReadiness readiness, CancellationToken token) =>
        {
            var result = await readiness.CheckAsync(token);
            return Results.Json(result, statusCode: result.Status == "ready" ? 200 : 503);
        }).WithName("GetDatabaseHealth");
        return endpoints;
    }
}
