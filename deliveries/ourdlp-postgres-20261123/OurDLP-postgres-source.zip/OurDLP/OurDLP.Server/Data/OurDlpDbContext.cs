using Microsoft.EntityFrameworkCore;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data;

public sealed class OurDlpDbContext(DbContextOptions<OurDlpDbContext> options) : DbContext(options)
{
    public DbSet<Device> Devices => Set<Device>();

    protected override void OnModelCreating(ModelBuilder modelBuilder) =>
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OurDlpDbContext).Assembly);
}
