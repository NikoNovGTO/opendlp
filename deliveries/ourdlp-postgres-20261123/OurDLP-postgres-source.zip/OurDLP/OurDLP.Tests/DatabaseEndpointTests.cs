using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using OurDLP.Contracts;
using Xunit;

namespace OurDLP.Tests;

public sealed class DatabaseEndpointTests
{
    [Fact]
    public async Task MissingConfigurationHasReadable503WhileApiRemainsAvailable()
    {
        await using var server=new DatabaseTestServer("");
        using var client=server.CreateClient();
        var api=await client.GetFromJsonAsync<ServerStatusResponse>("/api/status");
        Assert.Equal("api-available",api!.Status);
        using var response=await client.GetAsync("/api/health/database");
        Assert.Equal(HttpStatusCode.ServiceUnavailable,response.StatusCode);
        Assert.Equal("not-configured",(await response.Content.ReadFromJsonAsync<DatabaseStatusResponse>())!.Status);
    }
}

public sealed class DatabaseTestServer(string connectionString):WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.UseSetting("ConnectionStrings:OurDlp",connectionString);
    }
}
