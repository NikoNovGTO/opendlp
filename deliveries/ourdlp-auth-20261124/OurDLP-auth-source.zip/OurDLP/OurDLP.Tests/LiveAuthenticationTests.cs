using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Services;
using Xunit;

namespace OurDLP.Tests;

public sealed class LiveAuthenticationTests
{
    [LiveAuthenticationFact]
    [Trait("Category","Integration")]
    public async Task LoginProtectedRequestAndLogoutUseRealTlsAndMemoryCookies()
    {
        var address=Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var expected=Environment.GetEnvironmentVariable("OURDLP_EXPECT_LOGIN_SUCCESS")=="1";
        var path=Environment.GetEnvironmentVariable("OURDLP_LIVE_LOGIN_FILE")!;
        var credential=JsonSerializer.Deserialize<LoginRequest>(await File.ReadAllTextAsync(path),new JsonSerializerOptions(JsonSerializerDefaults.Web))!;
        using var http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false,UseCookies=true,CookieContainer=new()})
        {Timeout=TimeSpan.FromSeconds(5),MaxResponseContentBufferSize=64*1024};
        var client=new AuthenticationClient(http);
        var result=await client.LoginAsync(address,credential.UserName,credential.Password,default);
        Assert.Equal(expected,result.Succeeded);
        Assert.DoesNotContain(credential.Password,result.Message);
        if(!expected)return;
        Assert.True(await client.IsSessionValidAsync(address,result.Administrator!.Id,default));
        Assert.True(await client.LogoutAsync(address,default));
        Assert.False(await client.IsSessionValidAsync(address,result.Administrator.Id,default));
    }
}

public sealed class LiveAuthenticationFactAttribute:FactAttribute
{
    public LiveAuthenticationFactAttribute()
    {
        if(string.IsNullOrEmpty(Environment.GetEnvironmentVariable("OURDLP_LIVE_LOGIN_FILE"))
            ||string.IsNullOrEmpty(Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")))
            Skip="Requires an explicitly configured test server and private test credentials file.";
    }
}
