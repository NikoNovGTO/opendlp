using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Contracts;
using OurDLP.Server.Authentication;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;
using Xunit;

namespace OurDLP.Tests;

public sealed class AuthenticationIntegrationTests
{
    private const string Password="OurDlpTestPassword2026!";
    private static HttpClient Client(DatabaseTestServer server)=>server.CreateClient(new()
    { BaseAddress=new Uri("https://localhost"), AllowAutoRedirect=false, HandleCookies=true });
    private static Task<HttpResponseMessage> Login(HttpClient client,string password=Password,string username="admin")=>
        client.PostAsJsonAsync("/api/auth/login",new LoginRequest{UserName=username,Password=password});

    private static async Task<Administrator> CreateAdministrator(DatabaseTestServer server,bool administrator=true)
    {
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        await using var scope=server.Services.CreateAsyncScope();
        var users=scope.ServiceProvider.GetRequiredService<UserManager<Administrator>>();
        var roles=scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        Assert.True((await roles.CreateAsync(new(AuthDefaults.AdministratorRole))).Succeeded);
        var user=new Administrator{Id=Guid.NewGuid(),UserName="admin"};
        Assert.True((await users.CreateAsync(user,Password)).Succeeded);
        if(administrator) Assert.True((await users.AddToRoleAsync(user,AuthDefaults.AdministratorRole)).Succeeded);
        return user;
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task LoginUsesSecureCookieAndLogoutRevokesOtherAndCopiedCookies()
    {
        await using var db=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(db.ConnectionString);
        var admin=await CreateAdministrator(server);
        using var first=Client(server);
        using var second=Client(server);
        Assert.Equal(HttpStatusCode.Unauthorized,(await first.GetAsync("/api/auth/me")).StatusCode);
        using var login=await Login(first);
        Assert.Equal(HttpStatusCode.OK,login.StatusCode);
        var cookie=Assert.Single(login.Headers.GetValues("Set-Cookie"));
        Assert.Contains("secure",cookie,StringComparison.OrdinalIgnoreCase);
        Assert.Contains("httponly",cookie,StringComparison.OrdinalIgnoreCase);
        Assert.Contains("samesite=strict",cookie,StringComparison.OrdinalIgnoreCase);
        Assert.DoesNotContain(Password,cookie);
        Assert.Equal(admin.Id,(await first.GetFromJsonAsync<AdministratorResponse>("/api/auth/me"))!.Id);
        Assert.Equal(HttpStatusCode.OK,(await Login(second)).StatusCode);
        Assert.Equal(HttpStatusCode.NoContent,(await first.PostAsync("/api/auth/logout",null)).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await first.GetAsync("/api/auth/me")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await second.GetAsync("/api/auth/me")).StatusCode);
        using var replay=Client(server);
        replay.DefaultRequestHeaders.Add("Cookie",cookie.Split(';')[0]);
        Assert.Equal(HttpStatusCode.Unauthorized,(await replay.GetAsync("/api/auth/me")).StatusCode);
        await using var scope=server.Services.CreateAsyncScope();
        var context=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        var stored=await context.Users.SingleAsync();
        Assert.NotEqual(Password,stored.PasswordHash);
        Assert.Equal(PasswordVerificationResult.Success,
            scope.ServiceProvider.GetRequiredService<IPasswordHasher<Administrator>>().VerifyHashedPassword(stored,stored.PasswordHash!,Password));
        Assert.Equal(2,await context.AuthenticationAudit.CountAsync(entry=>entry.Action=="login.succeeded"));
        Assert.Equal(1,await context.AuthenticationAudit.CountAsync(entry=>entry.Action=="logout.succeeded"));
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task FiveWrongPasswordsLockAccountAndNeverIssueCookie()
    {
        await using var db=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(db.ConnectionString);
        var admin=await CreateAdministrator(server);
        using var client=Client(server);
        for(int i=0;i<5;i++)
        {
            using var response=await Login(client,"wrong-test-password");
            Assert.Equal(HttpStatusCode.Unauthorized,response.StatusCode);
            Assert.False(response.Headers.Contains("Set-Cookie"));
        }
        Assert.Equal(HttpStatusCode.Unauthorized,(await Login(client)).StatusCode);
        await using var scope=server.Services.CreateAsyncScope();
        var users=scope.ServiceProvider.GetRequiredService<UserManager<Administrator>>();
        var stored=(await users.FindByIdAsync(admin.Id.ToString()))!;
        Assert.True(await users.IsLockedOutAsync(stored));
        Assert.True((await users.SetLockoutEndDateAsync(stored,DateTimeOffset.UtcNow.AddMinutes(-1))).Succeeded);
        Assert.Equal(HttpStatusCode.OK,(await Login(client)).StatusCode);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task CorrectPasswordWithoutAdministratorRoleCannotSignIn()
    {
        await using var db=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(db.ConnectionString);
        await CreateAdministrator(server,false);
        using var client=Client(server);
        using var response=await Login(client);
        Assert.Equal(HttpStatusCode.Forbidden,response.StatusCode);
        Assert.False(response.Headers.Contains("Set-Cookie"));
        Assert.Equal(HttpStatusCode.Unauthorized,(await client.GetAsync("/api/auth/me")).StatusCode);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task ApiCanAnswerWhileLoginNeedsDatabaseAndHttpIsRejected()
    {
        await using var server=new DatabaseTestServer("");
        using var client=Client(server);
        Assert.Equal(HttpStatusCode.OK,(await client.GetAsync("/api/status")).StatusCode);
        Assert.Equal(HttpStatusCode.ServiceUnavailable,(await Login(client)).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await client.PostAsJsonAsync("/api/auth/register",new{})).StatusCode);
        using var insecure=server.CreateClient(new(){BaseAddress=new Uri("http://localhost"),AllowAutoRedirect=false});
        Assert.Equal(HttpStatusCode.BadRequest,(await Login(insecure)).StatusCode);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task LoginHasRateLimitAndDoesNotBecomeUnprotectedOnMalformedCookie()
    {
        await using var db=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(db.ConnectionString);
        await CreateAdministrator(server);
        using var client=Client(server);
        client.DefaultRequestHeaders.Add("Cookie","OurDLP.Session=forged-cookie");
        Assert.Equal(HttpStatusCode.Unauthorized,(await client.GetAsync("/api/auth/me")).StatusCode);
        for(int i=0;i<10;i++) Assert.Equal(HttpStatusCode.Unauthorized,(await Login(client,"wrong","unknown-user")).StatusCode);
        Assert.Equal(HttpStatusCode.TooManyRequests,(await Login(client)).StatusCode);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task ExpiredTicketIsRejectedWithoutWaitingEightHours()
    {
        await using var db=await PostgresTestDatabase.CreateAsync();
        var time=new AdvancingTime();
        await using var server=new DatabaseTestServer(db.ConnectionString,time);
        await CreateAdministrator(server);
        using var client=Client(server);
        Assert.Equal(HttpStatusCode.OK,(await Login(client)).StatusCode);
        time.Advance(TimeSpan.FromHours(9));
        Assert.Equal(HttpStatusCode.Unauthorized,(await client.GetAsync("/api/auth/me")).StatusCode);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task UpgradePreservesExistingDeviceRows()
    {
        await using var db=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(db.ConnectionString);
        using var client=Client(server);
        await using(var scope=server.Services.CreateAsyncScope())
        {
            var context=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
            var migrator=context.GetService<Microsoft.EntityFrameworkCore.Migrations.IMigrator>();
            await migrator.MigrateAsync("20261123191722_InitialDeviceRegistry");
            context.Devices.Add(new Device{Id=Guid.NewGuid(),Name="EXISTING-PC",CreatedAtUtc=DateTimeOffset.UtcNow});
            await context.SaveChangesAsync();
        }
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        await using var verification=server.Services.CreateAsyncScope();
        Assert.Equal("EXISTING-PC",(await verification.ServiceProvider.GetRequiredService<OurDlpDbContext>().Devices.SingleAsync()).Name);
    }
    private sealed class AdvancingTime:TimeProvider
    {
        private DateTimeOffset _now=DateTimeOffset.UtcNow;
        public override DateTimeOffset GetUtcNow()=>_now;
        public void Advance(TimeSpan interval)=>_now+=interval;
    }
}
