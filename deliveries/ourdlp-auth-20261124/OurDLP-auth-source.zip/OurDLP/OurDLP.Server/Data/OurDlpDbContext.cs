using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data;

public sealed class OurDlpDbContext(DbContextOptions<OurDlpDbContext> options)
    : IdentityDbContext<Administrator, IdentityRole<Guid>, Guid>(options)
{
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<AuthenticationAudit> AuthenticationAudit => Set<AuthenticationAudit>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(OurDlpDbContext).Assembly);
    }
}
