using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data.Configurations;

public sealed class DeviceConfiguration : IEntityTypeConfiguration<Device>
{
    public void Configure(EntityTypeBuilder<Device> builder)
    {
        builder.ToTable("devices");
        builder.HasKey(device => device.Id);
        builder.Property(device => device.Name).HasMaxLength(255).IsRequired();
        builder.Property(device => device.OperatingSystem).HasMaxLength(255);
        builder.Property(device => device.AgentVersion).HasMaxLength(64);
        builder.HasIndex(device => device.Name);
    }
}
