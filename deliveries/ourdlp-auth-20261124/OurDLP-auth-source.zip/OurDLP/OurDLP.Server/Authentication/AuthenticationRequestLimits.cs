using Microsoft.AspNetCore.Http.Features;

namespace OurDLP.Server.Authentication;

public sealed class AuthenticationRequestLimits(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.StartsWithSegments("/api/auth"))
        {
            if (!context.Request.IsHttps)
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsJsonAsync(new OurDLP.Contracts.AuthMessage("Для входа требуется HTTPS."));
                return;
            }
            var size = context.Features.Get<IHttpMaxRequestBodySizeFeature>();
            if (size is { IsReadOnly: false }) size.MaxRequestBodySize = 16 * 1024;
        }
        await next(context);
    }
}
