﻿function Get-DemoRelease {
    $manifestPath=Join-Path $script:BundleRoot 'payload/apps.json'
    if(-not (Test-Path -LiteralPath $manifestPath) -or (Get-Item -LiteralPath $manifestPath).Length -gt 2MB){throw 'Описание состава пакета отсутствует или повреждено. Распакуйте архив заново.'}
    $hash=(Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    return @{Manifest=(Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json);Root=(Join-Path $script:DemoData ('releases/'+$hash))}
}
function Get-DemoRelativeFile([string]$Root,[string]$Relative) {
    if(-not $Relative -or [IO.Path]::IsPathRooted($Relative) -or $Relative.Split([char[]]@('/','\')) -contains '..' -or $Relative.Split([char[]]@('/','\')) -contains '.' -or $Relative.Contains(':')){throw 'Недопустимый путь в составе пакета.'}
    $prefix=[IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
    $file=[IO.Path]::GetFullPath((Join-Path $Root $Relative))
    if(-not $file.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Файл пакета находится вне разрешённой папки.'}
    return $file
}
function Assert-DemoNoLinks([string]$Root,[string]$File) {
    $minimum=[IO.Path]::GetFullPath($Root).Length;$item=$File
    while($item.Length -ge $minimum){
        if((Test-Path -LiteralPath $item) -and ((Get-Item -LiteralPath $item -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Файлы комплекта не должны быть ссылками.'}
        $next=Split-Path $item -Parent;if($next -eq $item -or -not $next){break};$item=$next
    }
}
function Expand-DemoApplication([ValidateSet('Server','Desktop','Agent')][string]$Name) {
    $release=Get-DemoRelease;$group=$release.Manifest.Apps.PSObject.Properties[$Name]
    if($null -eq $group -or $group.Value.Count -gt 2000){throw 'Состав приложения повреждён. Распакуйте архив заново.'}
    $destination=Join-Path $release.Root $Name;$content=Join-Path $script:BundleRoot 'payload/content'
    Assert-DemoNoLinks $script:DemoData $destination
    [IO.Directory]::CreateDirectory($destination)|Out-Null
    $done=0
    foreach($entry in $group.Value){
        $done++;if($done % 25 -eq 0 -and ('System.Windows.Forms.Application' -as [type])){[System.Windows.Forms.Application]::DoEvents()}
        $hash=[string]$entry.Sha256
        if($hash -notmatch '^[0-9a-f]{64}$'){throw 'Повреждена контрольная сумма в описании пакета.'}
        $source=Join-Path $content ($hash+'.bin');Assert-DemoNoLinks $script:BundleRoot $source
        $target=Get-DemoRelativeFile $destination ([string]$entry.Path);Assert-DemoNoLinks $script:DemoData $target
        if((Test-Path -LiteralPath $target -PathType Leaf) -and (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $hash){continue}
        if(-not (Test-Path -LiteralPath $source -PathType Leaf) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $hash){throw 'Файл комплекта отсутствует или его контрольная сумма не совпадает. Распакуйте архив заново.'}
        [IO.Directory]::CreateDirectory((Split-Path $target -Parent))|Out-Null
        $temporary=$target+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
        try{Copy-Item -LiteralPath $source -Destination $temporary;if(Test-Path -LiteralPath $target){[IO.File]::Replace($temporary,$target,[NullString]::Value)}else{[IO.File]::Move($temporary,$target)}}
        finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force}}
    }
    $expected=switch($Name){'Server'{'OurDLP.Server.exe'}'Desktop'{'OurDLP.Desktop.exe'}'Agent'{'OurDLP.Agent.exe'}}
    if(-not (Test-Path -LiteralPath (Join-Path $destination $expected))){throw 'Основной файл приложения отсутствует в пакете.'}
    return $destination
}
function Initialize-DemoApplications {
    $script:RuntimeRoot=Expand-DemoApplication 'Server'
    $script:ServerExe=Join-Path $script:RuntimeRoot 'OurDLP.Server.exe'
    $script:OurDlpPublishedServerExe=$script:ServerExe
    $script:DesktopRoot=Expand-DemoApplication 'Desktop'
}
function Copy-DemoAgentPayload {
    $destination=Expand-DemoApplication 'Agent'
    foreach($name in @('OurDLP.Agent.exe','OurDLP.Session.exe','coreclr.dll')){if(-not (Test-Path -LiteralPath (Join-Path $destination $name))){throw 'Пакет агента неполон. Распакуйте архив полностью.'}}
    return $destination
}
