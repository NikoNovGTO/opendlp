﻿#Requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'tools/ResourceSamples.ps1')
$directory=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'OurDLP/ResourceReports'
$form=[Windows.Forms.Form]::new();$form.Text='OurDLP — Замер ресурсов агента';$form.Size=[Drawing.Size]::new(740,540);$form.MinimumSize=[Drawing.Size]::new(650,480)
$form.StartPosition='CenterScreen';$form.Font=[Drawing.Font]::new('Segoe UI',11);$form.AutoScaleMode='Dpi';$form.BackColor=[Drawing.ColorTranslator]::FromHtml('#F2F5F5')
$layout=[Windows.Forms.TableLayoutPanel]::new();$layout.Dock='Fill';$layout.Padding=[Windows.Forms.Padding]::new(24);$layout.ColumnCount=1;$layout.RowCount=4
$layout.RowStyles.Add([Windows.Forms.RowStyle]::new('AutoSize'))|Out-Null;$layout.RowStyles.Add([Windows.Forms.RowStyle]::new('AutoSize'))|Out-Null;$layout.RowStyles.Add([Windows.Forms.RowStyle]::new('Percent',100))|Out-Null;$layout.RowStyles.Add([Windows.Forms.RowStyle]::new('AutoSize'))|Out-Null;$form.Controls.Add($layout)
$intro=[Windows.Forms.Label]::new();$intro.AutoSize=$true;$intro.MaximumSize=[Drawing.Size]::new(650,0);$intro.Text="Измеряется только агент и компонент буфера на этом ПК в течение 60 секунд. Для замера в покое не запускайте проверку файлов. Сервер и это окно в показатели не входят.";$intro.Margin=[Windows.Forms.Padding]::new(0,0,0,16);$layout.Controls.Add($intro,0,0)
$progress=[Windows.Forms.ProgressBar]::new();$progress.Dock='Top';$progress.Maximum=60;$progress.Height=12;$layout.Controls.Add($progress,0,1)
$output=[Windows.Forms.TextBox]::new();$output.Multiline=$true;$output.ReadOnly=$true;$output.Dock='Fill';$output.ScrollBars='Vertical';$output.BorderStyle='None';$output.BackColor=$form.BackColor;$output.Margin=[Windows.Forms.Padding]::new(0,18,0,18);$layout.Controls.Add($output,0,2)
$buttons=[Windows.Forms.FlowLayoutPanel]::new();$buttons.AutoSize=$true;$buttons.Dock='Fill';$layout.Controls.Add($buttons,0,3)
$restart=[Windows.Forms.Button]::new();$restart.Text='Повторить замер';$restart.AutoSize=$true;$restart.Enabled=$false;$restart.Padding=[Windows.Forms.Padding]::new(12,6,12,6);$buttons.Controls.Add($restart)
$folder=[Windows.Forms.Button]::new();$folder.Text='Папка отчётов';$folder.AutoSize=$true;$folder.Enabled=$false;$folder.Padding=[Windows.Forms.Padding]::new(12,6,12,6);$buttons.Controls.Add($folder)
$folder.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$directory+'"')|Out-Null})
$timer=[Windows.Forms.Timer]::new();$timer.Interval=1000
$script:ResourceRows=[Collections.Generic.List[object]]::new();$script:ResourcePrevious=@{};$script:ResourceClock=[Diagnostics.Stopwatch]::new();$script:ResourceSample=0;$script:ResourceRunning=$false
function Resource-Status([string]$Status){switch($Status){'ok'{'измеряется'}'not-running'{'не запущен'}'partial-metrics'{'часть счётчиков недоступна'}'process-ended'{'процесс завершился'}default{'счётчики недоступны'}}}
function Resource-Value($Value,[string]$Suffix){if($null -eq $Value){return 'нет доступных данных'};return ([string]$Value+$Suffix)}
function Finish-ResourceMeasurement([bool]$Completed){
    $timer.Stop();$script:ResourceRunning=$false;$script:ResourceClock.Stop()
    try{
        $report=Save-OurDlpResourceReport $script:ResourceRows.ToArray() $directory 'idle' $script:ResourceClock.Elapsed.TotalSeconds 2 $Completed
        $summary=$report.Summary
        $output.Text="Замер завершён. Полных измерений памяти: $($summary.CompleteMemorySamples).`r`n`r`n"+
            'Максимальная сумма рабочих наборов: '+(Resource-Value $summary.MaxWorkingSetSumMiB ' МиБ')+"`r`n"+
            'Максимальная частная память: '+(Resource-Value $summary.MaxPrivateSumMiB ' МиБ')+"`r`n"+
            'Средний CPU: '+(Resource-Value $summary.AverageCpuPercent ' %')+"`r`n`r`n"+
            "Сумма рабочих наборов может повторно учитывать общие страницы.`r`nЕсли процесс не запущен или доступ к счётчикам закрыт, показатель считается недоступным, а не нулевым.`r`n`r`nCSV и JSON сохранены в папке отчётов. Это результат данного ПК и сценария, не гарантия для всех компьютеров."
        $folder.Enabled=$true
    }catch{$output.Text='Не удалось сохранить отчёт: '+$_.Exception.Message}
    $restart.Enabled=$true
}
function Sample-ResourceMeasurement{
    try{
        $batch=@(Get-OurDlpResourceRows @('OurDLP.Agent','OurDLP.Session') $script:ResourcePrevious $script:ResourceClock.Elapsed.TotalSeconds $script:ResourceSample)
        foreach($row in $batch){$script:ResourceRows.Add($row)};$script:ResourceSample++
        $progress.Value=[Math]::Min(60,[int]$script:ResourceClock.Elapsed.TotalSeconds)
        $output.Text='Измерение: '+$progress.Value+" / 60 секунд.`r`n`r`n"+($batch|ForEach-Object{$_.Process+': '+(Resource-Status $_.Status)+'; память '+(Resource-Value $_.WorkingSetMiB ' МиБ')+'; CPU '+(Resource-Value $_.CpuPercent ' %')}|Out-String)
        if($script:ResourceClock.Elapsed.TotalSeconds -ge 60){Finish-ResourceMeasurement $true}
    }catch{$timer.Stop();$script:ResourceRunning=$false;$output.Text='Замер не завершён: '+$_.Exception.Message;$restart.Enabled=$true}
}
function Start-ResourceMeasurement{
    $restart.Enabled=$false;$folder.Enabled=$false;$progress.Value=0;$script:ResourceRows.Clear();$script:ResourcePrevious=@{};$script:ResourceSample=0;$script:ResourceClock.Restart();$script:ResourceRunning=$true
    Sample-ResourceMeasurement;if($script:ResourceRunning){$timer.Start()}
}
$timer.Add_Tick({Sample-ResourceMeasurement});$restart.Add_Click({Start-ResourceMeasurement});$form.Add_Shown({Start-ResourceMeasurement})
$form.Add_FormClosing({if($script:ResourceRunning){Finish-ResourceMeasurement $false}})
try{[Windows.Forms.Application]::Run($form)}finally{$timer.Dispose();$form.Dispose()}
