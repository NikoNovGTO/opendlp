﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ExpectedSid)
. (Join-Path $PSScriptRoot 'DemoCommon.ps1')
. (Join-Path $PSScriptRoot 'DemoPayload.ps1')
$payload=$null
try {
    Assert-DemoCaller $ExpectedSid;Initialize-DemoData
    Initialize-DemoApplications
    if(-not (Test-DemoServerReady)){throw 'Сначала запустите новый сервер и консоль через окно демонстрации.'}
    Write-Host 'Если сохранённая регистрация найдена, установщик проверит её и восстановит службу без нового кода.'
    Write-Host 'Для действительно нового агента получите код в разделе «Компьютеры» консоли OurDLP.'
    Write-Host 'Существующая служба будет обновлена с сохранением регистрации.'
    $payload=Copy-DemoAgentPayload
    $cert=Get-DemoCertificate;$publicPath=Join-Path $script:DemoData ('agent-server-'+[Guid]::NewGuid().ToString('N')+'.cer')
    try{[IO.File]::WriteAllBytes($publicPath,$cert.Export([Security.Cryptography.X509Certificates.X509ContentType]::Cert))}finally{$cert.Dispose()}
    $sha=(Get-FileHash -LiteralPath $publicPath -Algorithm SHA256).Hash
    $existing=Get-Service -Name 'OurDLP.Agent' -ErrorAction SilentlyContinue
    if($null -ne $existing){& (Join-Path $script:BundleRoot 'tools/Update-Agent.ps1') -PayloadPath $payload -ServerCertificatePath $publicPath -ExpectedCertificateSha256 $sha}
    else{& (Join-Path $script:BundleRoot 'tools/Install-Agent.ps1') -PayloadPath $payload -ServerAddress (Get-DemoAddress) -ServerCertificatePath $publicPath -ExpectedCertificateSha256 $sha}
    Write-Host 'Готово. Вернитесь в окно демонстрации и нажмите «Открыть тестовый текст». В консоли создайте и назначьте политику буфера.' -ForegroundColor Green
}catch{Write-Host ('Подключение агента не завершено: '+$_.Exception.Message) -ForegroundColor Red}

Read-Host 'Нажмите Enter, чтобы закрыть это окно'|Out-Null
