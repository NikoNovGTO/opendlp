﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ExpectedSid)
. (Join-Path $PSScriptRoot 'DemoCommon.ps1')
try {
    Assert-DemoCaller $ExpectedSid;Initialize-DemoData
    Initialize-DemoApplications
    Write-Host 'OurDLP: первичная подготовка этого Windows-ПК.'
    Write-Host 'Используются ваши существующие локальные настройки, база и учётная запись. Существующие пароли не сбрасываются.'
    & (Join-Path $script:BundleRoot 'tools/Initialize-LocalDatabase.ps1')
    $setup=Get-DemoLocalSetup
    if(-not $setup.AdministratorExists){& (Join-Path $script:BundleRoot 'tools/Create-Administrator.ps1')}
    $settings=Get-DemoSettings;$pfx=Get-DemoValue $settings 'Kestrel:Certificates:Default:Path'
    if(-not $pfx){
        & (Join-Path $script:BundleRoot 'tools/Configure-LanServer.ps1') -LocalDemo -ServerAddress 'https://localhost:7443' -ExportPath (Join-Path $script:DemoData ('server-'+[Guid]::NewGuid().ToString('N')+'.cer'))
    }else{
        $cert=Get-DemoCertificate
        try{
            $public=[Security.Cryptography.X509Certificates.X509Certificate2]::new($cert.Export([Security.Cryptography.X509Certificates.X509ContentType]::Cert))
            $store=[Security.Cryptography.X509Certificates.X509Store]::new('Root','CurrentUser')
            try{$store.Open([Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite);$store.Add($public)}finally{$store.Close();$public.Dispose()}
        }finally{$cert.Dispose()}
    }
    Write-Host 'Подготовка завершена. Вернитесь в окно демонстрации и нажмите «Запустить сервер и консоль».' -ForegroundColor Green
}catch{Write-Host ('Подготовка не завершена: '+$_.Exception.Message) -ForegroundColor Red}
Read-Host 'Нажмите Enter, чтобы закрыть это окно'|Out-Null
