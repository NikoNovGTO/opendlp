﻿function Get-DemoProcessIdentity([int]$ProcessId) {
    try{$process=Get-Process -Id $ProcessId -ErrorAction Stop;return @{Id=$process.Id;Path=$process.Path;Ticks=$process.StartTime.ToUniversalTime().Ticks}}
    catch{return $null}
}
function Get-OwnedDemoServer {
    $file=Join-Path $script:DemoData 'server-process.json'
    if(-not (Test-Path -LiteralPath $file)){return $null}
    try{
        $saved=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
        $actual=Get-DemoProcessIdentity $saved.Id
        if($null -eq $actual -or $actual.Ticks -ne $saved.Ticks -or -not [string]::Equals($actual.Path,$script:ServerExe,[StringComparison]::OrdinalIgnoreCase)){return $null}
        return $actual
    }catch{return $null}
}
function Start-DemoServer {
    if(Test-DemoServerReady){return}
    $setup=Get-DemoLocalSetup
    if($setup.DatabaseStatus -ne 'ready' -or -not $setup.AdministratorExists){throw 'Нужна первичная подготовка: база, её структура и учётная запись администратора.'}
    $cert=Get-DemoCertificate;$cert.Dispose()
    if($null -eq (Get-OwnedDemoServer)){
        $old=$env:ASPNETCORE_ENVIRONMENT
        try{
            $env:ASPNETCORE_ENVIRONMENT='Development'
            $process=Start-Process -FilePath $script:ServerExe -ArgumentList @('--urls',(Get-DemoAddress)) -WorkingDirectory $script:RuntimeRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $script:DemoData 'server-output.log') -RedirectStandardError (Join-Path $script:DemoData 'server-error.log')
            @{Id=$process.Id;Ticks=$process.StartTime.ToUniversalTime().Ticks}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $script:DemoData 'server-process.json') -Encoding UTF8
        }finally{$env:ASPNETCORE_ENVIRONMENT=$old}
    }
    $deadline=[DateTime]::UtcNow.AddSeconds(30)
    while([DateTime]::UtcNow -lt $deadline){
        if(Test-DemoServerReady){return}
        [Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 300
    }
    throw 'Сервер не подтвердил готовность. Закройте старый сервер из Visual Studio, проверьте PostgreSQL и сертификат. Журналы доступны через «Диагностика».'
}
function Stop-OwnedDemoServer {
    $actual=Get-OwnedDemoServer
    if($null -eq $actual){throw 'Сервер, запущенный этим комплектом, не найден. Другие процессы не останавливались.'}
    # Recheck immediately before stopping: a reused PID must not stop another process.
    $again=Get-DemoProcessIdentity $actual.Id
    if($null -eq $again -or $again.Ticks -ne $actual.Ticks -or -not [string]::Equals($again.Path,$script:ServerExe,[StringComparison]::OrdinalIgnoreCase)){throw 'Процесс сервера уже изменился. Обновите состояние.'}
    Stop-Process -Id $actual.Id -ErrorAction Stop
    Remove-Item -LiteralPath (Join-Path $script:DemoData 'server-process.json') -Force -ErrorAction SilentlyContinue
}
function Start-DemoDesktop {
    $exe=Join-Path $script:DesktopRoot 'OurDLP.Desktop.exe'
    foreach($p in @(Get-Process -Name 'OurDLP.Desktop' -ErrorAction SilentlyContinue)){try{if([string]::Equals($p.Path,$exe,[StringComparison]::OrdinalIgnoreCase)){return}}catch{}}
    $file=Join-Path $script:DemoData 'server-address.json'
    (Get-DemoAddress)|ConvertTo-Json|Set-Content -LiteralPath $file -Encoding UTF8
    $old=$env:OURDLP_DESKTOP_SETTINGS_PATH
    try{$env:OURDLP_DESKTOP_SETTINGS_PATH=$file;Start-Process -FilePath $exe -WorkingDirectory $script:DesktopRoot|Out-Null}
    finally{$env:OURDLP_DESKTOP_SETTINGS_PATH=$old}
}
function Start-DemoSession {
    $exe=Join-Path $env:ProgramFiles 'OurDLP/Agent/OurDLP.Session.exe'
    if(-not (Test-Path -LiteralPath $exe)){throw 'Сначала подключите или обновите агент кнопкой «Агент на этом ПК».'}
    Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe -Parent)|Out-Null
}
