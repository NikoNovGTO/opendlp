﻿#Requires -RunAsAdministrator
[CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='High')]
param()
$ErrorActionPreference='Stop'
$service=Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'"
if(-not $service){Write-Host 'Служба OurDLP.Agent не найдена.';return}
if($PSCmdlet.ShouldProcess('OurDLP.Agent','Остановить и удалить службу, сохранив защищённое состояние и доверие сертификату')){
    & (Join-Path $PSScriptRoot 'Configure-SessionMonitor.ps1') -Mode Remove
    Stop-Service OurDLP.Agent -ErrorAction SilentlyContinue
    (Get-Service OurDLP.Agent).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(20))
    $result=$service | Invoke-CimMethod -MethodName Delete
    if($result.ReturnValue -ne 0){throw ('Не удалось удалить службу. Код ошибки: '+$result.ReturnValue)}
    Write-Host 'Служба удалена. Защищённое состояние, папка программы и доверие сертификату сохранены. Отзовите доступ компьютера в консоли.'
}
