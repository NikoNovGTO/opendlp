﻿[CmdletBinding()]
param(
    [string]$HostName = '127.0.0.1',
    [ValidateRange(1,65535)][int]$Port = 5432,
    [string]$DatabaseName = 'ourdlp',
    [string]$Username = 'ourdlp_app',
    [Security.SecureString]$Password
)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
Write-Host 'Будут сохранены параметры подключения к существующей базе и обновлена её структура. Пароли базы не меняются.'
if ($null -eq $Password) { $Password = Read-Host "Пароль пользователя базы $Username (сохранится только в локальных настройках разработки)" -AsSecureString }
try {
    $plain = ConvertFrom-OurDlpSecureString $Password
    Save-OurDlpConnection $HostName $Port $DatabaseName $Username $plain
}
finally { $plain = $null; $Password = $null }
Invoke-OurDlpMigration
