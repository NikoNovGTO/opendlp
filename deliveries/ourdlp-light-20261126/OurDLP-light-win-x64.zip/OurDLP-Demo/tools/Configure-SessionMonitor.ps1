﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Install','Stop','Remove')][string]$Mode='Install')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$install=Join-Path $env:ProgramFiles 'OurDLP\Agent'
$exe=Join-Path $install 'OurDLP.Session.exe'
$command='"'+$exe+'"'
$name='OurDLP.Session'
$programs=[Environment]::GetFolderPath('CommonPrograms')
$shortcutPath=Join-Path $programs 'OurDLP — Контроль буфера обмена.lnk'
$legacyShortcutPath=Join-Path $programs 'OurDLP - Clipboard Monitor.lnk' 
if($Mode -in @('Stop','Remove')){
    foreach($process in @(Get-Process -Name 'OurDLP.Session' -ErrorAction SilentlyContinue)){
        if($process.Path -and [string]::Equals($process.Path,$exe,[StringComparison]::OrdinalIgnoreCase)){
            Stop-Process -Id $process.Id -Force
            $process.WaitForExit(10000) | Out-Null
        }
    }
    if($Mode -eq 'Stop'){return}
}
$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,[Microsoft.Win32.RegistryView]::Registry64)
try {
    $run=$base.CreateSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
    try {
        $existing=$run.GetValue($name)
        if($null -ne $existing -and $existing -ne $command){throw 'Запись автозапуска OurDLP отличается от ожидаемой. Проверьте её перед продолжением.'}
        $shell=New-Object -ComObject WScript.Shell
        if(Test-Path -LiteralPath $shortcutPath){
            $shortcut=$shell.CreateShortcut($shortcutPath)
            if(-not [string]::Equals($shortcut.TargetPath,$exe,[StringComparison]::OrdinalIgnoreCase)){throw 'Существующий ярлык OurDLP указывает на другую программу. Он сохранён; проверьте его перед продолжением.'}
        }
        if($Mode -eq 'Remove'){
            $run.DeleteValue($name,$false)
            if(Test-Path -LiteralPath $shortcutPath){Remove-Item -LiteralPath $shortcutPath}
            if(Test-Path -LiteralPath $legacyShortcutPath){
                $legacy=$shell.CreateShortcut($legacyShortcutPath)
                if([string]::Equals($legacy.TargetPath,$exe,[StringComparison]::OrdinalIgnoreCase)){Remove-Item -LiteralPath $legacyShortcutPath}
            }
            Write-Host 'Компонент буфера остановлен, его автозапуск и ярлык удалены. Зашифрованные пользовательские очереди сохранены.'
        } else {
            if(-not (Test-Path -LiteralPath $exe)){throw 'Компонент OurDLP.Session.exe не найден. Сначала обновите пакет агента.'}
            foreach($path in @((Join-Path $env:ProgramFiles 'OurDLP'),$install,$exe)){
                if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Папка пользовательского компонента не должна содержать ссылки.'}
            }
            $shortcut=$shell.CreateShortcut($shortcutPath)
            $shortcut.TargetPath=$exe;$shortcut.WorkingDirectory=$install
            $shortcut.Description='OurDLP: состояние наблюдения буфера обмена и выход'
            $shortcut.Save()
            $run.SetValue($name,$command,[Microsoft.Win32.RegistryValueKind]::String)
            # Retire only our own old English shortcut; preserve unrelated shortcuts.
            if(Test-Path -LiteralPath $legacyShortcutPath){
                $legacy=$shell.CreateShortcut($legacyShortcutPath)
                if([string]::Equals($legacy.TargetPath,$exe,[StringComparison]::OrdinalIgnoreCase)){Remove-Item -LiteralPath $legacyShortcutPath}
            }
            Write-Host 'Компонент запустится при следующем входе в Windows. Для запуска сейчас откройте «OurDLP — Контроль буфера обмена» из меню Пуск обычным пользователем. Состояние доступно через значок рядом с часами.'
        }
    } finally {$run.Dispose()}
} finally {$base.Dispose()}
