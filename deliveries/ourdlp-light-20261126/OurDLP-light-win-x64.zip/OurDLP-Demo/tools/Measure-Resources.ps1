﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateRange(1,3600)][int]$DurationSeconds=60,
    [ValidateRange(1,10)][int]$IntervalSeconds=1,
    [ValidateSet('idle','clipboard','scan')][string]$Scenario='idle',
    [ValidateCount(1,8)][ValidatePattern('^[A-Za-z0-9_.-]{1,80}$')][string[]]$ProcessName=@('OurDLP.Agent','OurDLP.Session'),
    [string]$OutputDirectory=''
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'ResourceSamples.ps1')
if(-not $OutputDirectory){$OutputDirectory=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'OurDLP/ResourceReports'}
$rows=[Collections.Generic.List[object]]::new();$previous=@{};$clock=[Diagnostics.Stopwatch]::StartNew();$sample=0
Write-Host 'Замер CPU и памяти. Отчёт не содержит текстов буфера, имён пользователей, паролей и командных строк.'
do{
    foreach($row in @(Get-OurDlpResourceRows $ProcessName $previous $clock.Elapsed.TotalSeconds $sample)){$rows.Add($row)}
    $sample++
    if($clock.Elapsed.TotalSeconds -ge $DurationSeconds){break}
    $remaining=[Math]::Max(0,[Math]::Min($IntervalSeconds,$DurationSeconds-$clock.Elapsed.TotalSeconds));if($remaining -gt 0){Start-Sleep -Milliseconds ([int]($remaining*1000))}
}while($true)
$report=Save-OurDlpResourceReport $rows.ToArray() $OutputDirectory $Scenario $clock.Elapsed.TotalSeconds $ProcessName.Count $true
$report.Summary|Format-List
Write-Host ('CSV: '+$report.Csv);Write-Host ('JSON: '+$report.Json)
if($report.Summary.CompleteMemorySamples -eq 0){Write-Warning 'Нет полного набора доступных процессов. Отсутствующие значения не считаются нулевым потреблением.'}
