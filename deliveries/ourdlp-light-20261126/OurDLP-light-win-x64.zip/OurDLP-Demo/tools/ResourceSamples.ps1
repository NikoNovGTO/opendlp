﻿function Get-OurDlpCpuPercent($PreviousCpu,$CurrentCpu,[double]$ElapsedSeconds,[int]$Processors){
    if($null -eq $PreviousCpu -or $null -eq $CurrentCpu -or $ElapsedSeconds -le 0 -or $Processors -le 0 -or $CurrentCpu -lt $PreviousCpu){return $null}
    return [Math]::Round(100.0*($CurrentCpu-$PreviousCpu)/$ElapsedSeconds/$Processors,3)
}

function Get-OurDlpResourceRows([string[]]$Names,[hashtable]$Previous,[double]$Elapsed,[int]$Sample){
    $rows=@();$active=@{}
    foreach($name in $Names){
        $processes=@(Get-Process -Name $name -ErrorAction SilentlyContinue)
        if($processes.Count -eq 0){
            $rows+=[pscustomobject]@{Sample=$Sample;TimeUtc=[DateTime]::UtcNow.ToString('o');Process=$name;Pid=$null;WorkingSetMiB=$null;PrivateMiB=$null;CpuPercent=$null;Status='not-running'}
        }
        foreach($process in $processes){
            $working=$null;$private=$null;$cpu=$null;$start=$null;$percent=$null;$status='ok';$processId=$process.Id
            try{
                $process.Refresh()
                try{$working=[Math]::Round($process.WorkingSet64/1MB,3);$private=[Math]::Round($process.PrivateMemorySize64/1MB,3)}catch{$status='metrics-unavailable'}
                try{$cpu=$process.TotalProcessorTime.TotalSeconds;$start=$process.StartTime.ToUniversalTime().Ticks}catch{$status='partial-metrics'}
                if($null -ne $start -and $null -ne $cpu){
                    $key=$name+'/'+$processId+'/'+$start;$active[$key]=$true
                    if($Previous.ContainsKey($key)){$percent=Get-OurDlpCpuPercent $Previous[$key].Cpu $cpu ($Elapsed-$Previous[$key].Elapsed) ([Environment]::ProcessorCount)}
                    $Previous[$key]=@{Cpu=$cpu;Elapsed=$Elapsed}
                }
            }catch{$status='process-ended'}finally{$process.Dispose()}
            $rows+=[pscustomobject]@{Sample=$Sample;TimeUtc=[DateTime]::UtcNow.ToString('o');Process=$name;Pid=$processId;WorkingSetMiB=$working;PrivateMiB=$private;CpuPercent=$percent;Status=$status}
        }
    }
    foreach($key in @($Previous.Keys)){if(-not $active.ContainsKey($key)){$Previous.Remove($key)}}
    return $rows
}

function Get-OurDlpResourceSummary([object[]]$Rows,[int]$ExpectedNames){
    $groups=@($Rows|Group-Object Sample);$complete=@()
    foreach($group in $groups){
        $items=@($group.Group)
        if(@($items|Select-Object -ExpandProperty Process -Unique).Count -ne $ExpectedNames -or @($items|Where-Object{$_.Status -in @('not-running','process-ended') -or $null -eq $_.WorkingSetMiB -or $null -eq $_.PrivateMiB}).Count){continue}
        $cpu=$null
        if(@($items|Where-Object{$null -eq $_.CpuPercent}).Count -eq 0){$cpu=($items|Measure-Object CpuPercent -Sum).Sum}
        $complete+=[pscustomobject]@{WorkingSetMiB=($items|Measure-Object WorkingSetMiB -Sum).Sum;PrivateMiB=($items|Measure-Object PrivateMiB -Sum).Sum;CpuPercent=$cpu}
    }
    $cpuSamples=@($complete|Where-Object{$null -ne $_.CpuPercent})
    return [pscustomobject]@{
        Samples=$groups.Count;CompleteMemorySamples=$complete.Count;CompleteCpuSamples=$cpuSamples.Count
        MaxWorkingSetSumMiB=if($complete.Count){[Math]::Round(($complete|Measure-Object WorkingSetMiB -Maximum).Maximum,2)}else{$null}
        MaxPrivateSumMiB=if($complete.Count){[Math]::Round(($complete|Measure-Object PrivateMiB -Maximum).Maximum,2)}else{$null}
        AverageCpuPercent=if($cpuSamples.Count){[Math]::Round(($cpuSamples|Measure-Object CpuPercent -Average).Average,3)}else{$null}
        PeakSampleCpuPercent=if($cpuSamples.Count){[Math]::Round(($cpuSamples|Measure-Object CpuPercent -Maximum).Maximum,3)}else{$null}
        Note='Working-set sums may count shared pages more than once. CPU is normalized by logical processor count; missing metrics are null, not zero.'
    }
}

function Save-OurDlpResourceReport([object[]]$Rows,[string]$Directory,[string]$Scenario,[double]$Elapsed,[int]$ExpectedNames,[bool]$Completed){
    [IO.Directory]::CreateDirectory($Directory)|Out-Null
    $name='resources-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
    $csv=Join-Path $Directory ($name+'.csv');$json=Join-Path $Directory ($name+'.json')
    $summary=Get-OurDlpResourceSummary $Rows $ExpectedNames
    $Rows|Export-Csv -LiteralPath $csv -NoTypeInformation -UseCulture -Encoding UTF8
    [pscustomobject]@{SchemaVersion=1;Scenario=$Scenario;Completed=$Completed;DurationSeconds=[Math]::Round($Elapsed,2);LogicalProcessors=[Environment]::ProcessorCount;Platform=if([Environment]::OSVersion.Platform -eq 'Win32NT'){'Windows'}else{'Portable test, not Windows'};Summary=$summary}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $json -Encoding UTF8
    return [pscustomobject]@{Csv=$csv;Json=$json;Summary=$summary}
}
