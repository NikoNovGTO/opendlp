﻿Set-StrictMode -Version Latest
function Protect-OurDlpSettingsPath([string]$Path) {
    $user=[Security.Principal.WindowsIdentity]::GetCurrent().User
    $folder=(Get-Item -LiteralPath $Path).PSIsContainer
    $acl=if($folder){[Security.AccessControl.DirectorySecurity]::new()}else{[Security.AccessControl.FileSecurity]::new()}
    $acl.SetAccessRuleProtection($true,$false);$acl.SetOwner($user)
    foreach($sid in @($user,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'),[Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))){
        $rule=if($folder){[Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','ContainerInherit, ObjectInherit','None','Allow')}else{[Security.AccessControl.FileSystemAccessRule]::new($sid,'FullControl','Allow')}
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}
function Expand-OurDlpSettings($Value,[string]$Prefix,[hashtable]$Target,[int]$Depth=0) {
    if($Depth -gt 32){throw 'Локальные настройки вложены слишком глубоко.'}
    if($Value -is [PSCustomObject]){
        foreach($p in $Value.PSObject.Properties){$key=if($Prefix){$Prefix+':'+$p.Name}else{$p.Name};Expand-OurDlpSettings $p.Value $key $Target ($Depth+1)}
    }elseif($Value -is [Array]){
        for($i=0;$i -lt $Value.Length;$i++){Expand-OurDlpSettings $Value[$i] ($Prefix+':'+$i) $Target ($Depth+1)}
    }else{
        if($Target.ContainsKey($Prefix)){throw 'Локальные настройки содержат повторяющиеся ключи. Проверьте файл вручную.'}
        $Target[$Prefix]=$Value
    }
}
function Save-OurDlpSettings([hashtable]$Values) {
    $file=Get-OurDlpSecretsFile;$folder=Split-Path $file -Parent
    [IO.Directory]::CreateDirectory($folder)|Out-Null
    if((Get-Item -LiteralPath $folder -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Папка локальных настроек не должна быть ссылкой.'}
    Protect-OurDlpSettingsPath $folder
    $lockPath=Join-Path $folder 'settings.lock'
    if((Test-Path -LiteralPath $lockPath) -and ((Get-Item -LiteralPath $lockPath -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Файл блокировки настроек не должен быть ссылкой.'}
    $locked=$null;$temporary=Join-Path $folder ([Guid]::NewGuid().ToString('N')+'.tmp')
    try {
        $deadline=[DateTime]::UtcNow.AddSeconds(5)
        while($null -eq $locked){
            try{$locked=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
            catch [IO.IOException]{if([DateTime]::UtcNow -ge $deadline){throw 'Настройки заняты другим процессом. Повторите подготовку.'};Start-Sleep -Milliseconds 100}
        }
        $merged=@{}
        if(Test-Path -LiteralPath $file){
            $item=Get-Item -LiteralPath $file -Force
            if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -gt 1MB){throw 'Файл локальных настроек недопустим. Проверьте его вручную.'}
            try{$saved=Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json}catch{throw 'Не удалось прочитать существующие настройки. Файл не изменён.'}
            if($null -eq $saved -or $saved -isnot [PSCustomObject]){throw 'Локальные настройки должны содержать объект JSON.'}
            Expand-OurDlpSettings $saved '' $merged
            Protect-OurDlpSettingsPath $file
        }
        foreach($key in $Values.Keys){$merged[$key]=$Values[$key]}
        [IO.File]::WriteAllText($temporary,($merged|ConvertTo-Json -Depth 32),[Text.UTF8Encoding]::new($true))
        Protect-OurDlpSettingsPath $temporary
        if(Test-Path -LiteralPath $file){[IO.File]::Replace($temporary,$file,[NullString]::Value)}else{[IO.File]::Move($temporary,$file)}
    } finally {if($null -ne $locked){$locked.Dispose()};if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force}}
}
