﻿. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
Invoke-OurDlpMigration
