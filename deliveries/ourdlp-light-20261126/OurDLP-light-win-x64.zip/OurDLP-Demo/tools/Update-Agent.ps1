﻿#Requires -RunAsAdministrator
[CmdletBinding()]
param([string]$PayloadPath='', [string]$ServerCertificatePath='', [string]$ExpectedCertificateSha256='')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$name='OurDLP.Agent'
if($ServerCertificatePath -or $ExpectedCertificateSha256){
    $expected=$ExpectedCertificateSha256.Replace(' ','').Replace(':','').ToUpperInvariant()
    if(-not $ServerCertificatePath -or $expected -notmatch '^[A-F0-9]{64}$' -or (Get-FileHash -LiteralPath $ServerCertificatePath -Algorithm SHA256).Hash -ne $expected){throw 'Контрольная сумма SHA256 публичного сертификата не совпадает. Сертификат не добавлен в доверенные.'}
    $cert=[Security.Cryptography.X509Certificates.X509Certificate2]::new((Resolve-Path -LiteralPath $ServerCertificatePath).Path)
    if($cert.HasPrivateKey -or $cert.NotAfter -le (Get-Date) -or $cert.NotBefore -gt (Get-Date)){throw 'Укажите действующий публичный сертификат сервера без закрытого ключа.'}
    Import-Certificate -FilePath $ServerCertificatePath -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null
}
if(-not $PayloadPath){$PayloadPath=Join-Path $PSScriptRoot 'bin'}
$parent=Join-Path $env:ProgramFiles 'OurDLP';$install=Join-Path $parent 'Agent'
$exe=Join-Path $install 'OurDLP.Agent.exe'
$service=Get-CimInstance Win32_Service -Filter "Name='OurDLP.Agent'"
if(-not $service -or $service.StartName -ne 'NT SERVICE\OurDLP.Agent' -or $service.PathName -ne ('"'+$exe+'"')){throw 'Не найдена служба OurDLP.Agent с ожидаемыми настройками. Для первой установки используйте Install-Agent.ps1.'}
foreach($path in @($parent,$install,$PayloadPath)){
    if(-not (Test-Path -LiteralPath $path) -or ((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Папки обновления должны существовать и не должны быть ссылками.'}
}
if(-not (Test-Path -LiteralPath (Join-Path $PayloadPath 'OurDLP.Session.exe'))){throw 'В новом пакете не найден пользовательский компонент буфера. Распакуйте архив агента полностью.'}
if(-not (Test-Path -LiteralPath (Join-Path $PayloadPath 'OurDLP.Agent.exe'))){throw 'Не найдены новые файлы агента для Windows. Распакуйте архив полностью.'}
if([IO.Path]::GetFullPath($PayloadPath).StartsWith([IO.Path]::GetFullPath($install),[StringComparison]::OrdinalIgnoreCase)){throw 'Сначала распакуйте новый пакет в отдельную папку.'}
$backup=Join-Path $parent ('Agent-backup-'+[Guid]::NewGuid().ToString('N'))
$moved=$false;$ready=$false
try {
    Stop-Service $name
    (Get-Service $name).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(20))
    & (Join-Path $PSScriptRoot 'Configure-SessionMonitor.ps1') -Mode Stop
    Start-Sleep -Milliseconds 500
    Move-Item -LiteralPath $install -Destination $backup;$moved=$true
    New-Item -ItemType Directory -Path $install | Out-Null
    Copy-Item -Path (Join-Path $PayloadPath '*') -Destination $install -Recurse
    & (Join-Path $PSScriptRoot 'Initialize-AgentScanTargets.ps1')
    & $exe --prepare-demo-documents
    if($LASTEXITCODE -ne 0){throw 'Не удалось подготовить демонстрационные документы Word и Excel.'}
    & $exe --prepare-service-start
    if($LASTEXITCODE -ne 0){throw 'Не удалось подготовить защищённое состояние агента.'}
    Set-Service -Name $name -DisplayName 'OurDLP — Агент компьютера'
    Start-Service $name
    (Get-Service $name).WaitForStatus('Running',[TimeSpan]::FromSeconds(20))
    for($attempt=0;$attempt -lt 30;$attempt++){
        if((Get-Service $name).Status -ne 'Running'){throw 'После обновления служба остановилась. Проверьте журнал Windows «Приложение», источник OurDLP.Agent.'}
        $statusText=(& $exe --status | Out-String)
        if($LASTEXITCODE -eq 0){$status=$statusText|ConvertFrom-Json;if($null -ne $status.ServiceContactConfirmedAtUtc){$ready=$true;break}}
        Start-Sleep -Seconds 1
    }
    if(-not $ready){throw 'Обновлённая служба не подтвердила связь по HTTPS. Проверьте сервер, адрес и доверие сертификату.'}
    & (Join-Path $PSScriptRoot 'Configure-SessionMonitor.ps1') -Mode Install
    Write-Host 'Агент OurDLP обновлён. Регистрация и защищённые очереди результатов сохранены.'
} catch {
    if($moved){
        Stop-Service $name -ErrorAction SilentlyContinue
        (Get-Service $name).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(20))
        if(Test-Path -LiteralPath $install){Remove-Item -LiteralPath $install -Recurse -Force}
        $ready=$false
        Move-Item -LiteralPath $backup -Destination $install
        Start-Service $name
        Write-Host 'Предыдущие файлы программы восстановлены. Защищённое состояние сохранено.'
    }
    throw
} finally {
    if($ready -and (Test-Path -LiteralPath $backup)){Remove-Item -LiteralPath $backup -Recurse -Force}
}
