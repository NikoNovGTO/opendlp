﻿[CmdletBinding()]
param(
    [string]$PsqlPath = '',
    [ValidateRange(1,65535)][int]$Port = 5432,
    [string]$AdminUser = 'postgres',
    [Security.SecureString]$AdminPassword
)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')

if (Test-OurDlpConfiguration) {
    Write-Host 'Найдены существующие настройки OurDLP. Будет обновлена только структура базы.'
    Invoke-OurDlpMigration
    return
}
$psql = Find-OurDlpPsql $PsqlPath
if ($null -eq $AdminPassword) {
    $AdminPassword = Read-Host "Пароль администратора PostgreSQL $AdminUser (не сохраняется)" -AsSecureString
}
$previousPassword = $env:PGPASSWORD
try {
    $env:PGPASSWORD = ConvertFrom-OurDlpSecureString $AdminPassword
    $arguments = @('-X', '-w', '-q', '-t', '-A', '-h', '127.0.0.1', '-p', "$Port", '-U', $AdminUser, '-d', 'postgres', '-v', 'ON_ERROR_STOP=1')
    $query = "SELECT CASE WHEN EXISTS(SELECT FROM pg_roles WHERE rolname='ourdlp_app') OR EXISTS(SELECT FROM pg_database WHERE datname='ourdlp') THEN 1 ELSE 0 END;"
    $existing = $query | & $psql @arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось подключиться к PostgreSQL. Проверьте службу, порт, имя администратора и пароль.' }
    if (($existing -join '').Trim() -ne '0') {
        throw 'База ourdlp или пользователь ourdlp_app уже существуют. Для подключения к ним используйте Configure-ExistingDatabase.ps1.'
    }
    $random = [Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 32
    try { $random.GetBytes($bytes) } finally { $random.Dispose() }
    $appPassword = [Convert]::ToBase64String($bytes)
    # Identifiers are fixed; the generated password contains no SQL quotes.
    $sql = "CREATE ROLE ourdlp_app WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD '$appPassword';`nCREATE DATABASE ourdlp OWNER ourdlp_app;"
    $result = $sql | & $psql @arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать базу данных. Существующие базы и учётные записи сохранены.' }
    Save-OurDlpConnection '127.0.0.1' $Port 'ourdlp' 'ourdlp_app' $appPassword
    Write-Host 'Созданы база ourdlp и пользователь приложения без полномочий администратора PostgreSQL.'
}
finally {
    $env:PGPASSWORD = $previousPassword
    $appPassword = $null
    $sql = $null
    $AdminPassword = $null
}
Invoke-OurDlpMigration
Write-Host 'База готова. Запустите сервер и консоль, затем проверьте соединение.'
