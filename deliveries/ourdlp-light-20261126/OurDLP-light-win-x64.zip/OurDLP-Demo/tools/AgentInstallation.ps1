﻿Set-StrictMode -Version Latest
function Assert-OurDlpAgentPayload([string]$PayloadPath) {
    foreach($name in @('OurDLP.Agent.exe','OurDLP.Session.exe','OurDLP.Core.dll')){
        if(-not (Test-Path -LiteralPath (Join-Path $PayloadPath $name) -PathType Leaf)){throw 'Новый пакет агента неполон. Распакуйте комплект полностью перед восстановлением.'}
    }
}
function Backup-OurDlpAgentFolder([string]$InstallPath) {
    if(-not (Test-Path -LiteralPath $InstallPath)){return $null}
    $item=Get-Item -LiteralPath $InstallPath -Force
    if(-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Папка программы агента должна быть обычной папкой.'}
    $backup=Join-Path (Split-Path $InstallPath -Parent) ('Agent-before-repair-'+[Guid]::NewGuid().ToString('N'))
    Move-Item -LiteralPath $InstallPath -Destination $backup -ErrorAction Stop
    return $backup
}
function Restore-OurDlpAgentFolder([string]$InstallPath,[string]$BackupPath,[bool]$NewFolderCreated) {
    if($NewFolderCreated -and (Test-Path -LiteralPath $InstallPath)){Remove-Item -LiteralPath $InstallPath -Recurse -Force -ErrorAction Stop}
    if($BackupPath -and (Test-Path -LiteralPath $BackupPath)){
        if(Test-Path -LiteralPath $InstallPath){throw 'Новая папка занята. Прежние файлы сохранены в резервной папке; проверьте установку вручную.'}
        Move-Item -LiteralPath $BackupPath -Destination $InstallPath -ErrorAction Stop
    }
}
function Get-OurDlpEnrollmentMode($Status,[bool]$ReEnroll,[bool]$CodeProvided) {
    if($ReEnroll){return 'Enroll'}
    if($null -eq $Status){throw 'Не удалось проверить сохранённую регистрацию. Защищённые файлы не изменены.'}
    $id=$Status.PSObject.Properties['DeviceId']
    if($null -eq $id){throw 'Ответ агента не содержит состояния регистрации. Проверьте состав пакета.'}
    if($null -eq $id.Value){return 'Enroll'}
    $parsed=[Guid]::Empty
    if(-not [Guid]::TryParse([string]$id.Value,[ref]$parsed) -or $parsed -eq [Guid]::Empty){throw 'Сохранённый идентификатор регистрации недопустим. Защищённое состояние сохранено.'}
    if($CodeProvided){throw 'Агент уже зарегистрирован. Для замены регистрации по новому коду укажите -ReEnroll явно.'}
    return 'Resume'
}
