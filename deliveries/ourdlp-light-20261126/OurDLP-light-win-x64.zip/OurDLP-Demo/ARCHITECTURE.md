# Структура OurDLP 0.7

Шесть проектов: Core (общий сканер), Contracts (версионируемые сообщения с моделями Core), Server (Identity/PostgreSQL/API), Desktop (WPF), Agent (служба Windows) и Tests. Вручную добавлять проекты к решению не требуется.

Сервер: ScanJobCommands создаёт/отменяет задания, ScanJobQueries читает историю, ScanWorkDelivery выдаёт работу, ScanReportValidation проверяет состав отчёта, ScanResultReceiver сохраняет его идемпотентно. Все мутации сериализованы блокировкой устройства, включая отзыв регистрации. ScanJob хранит снимок параметров и metadata JSONB; отдельный каталог политик ещё не реализован.

Агент: AgentWorker отправляет heartbeat. Независимый AgentScanWorker вызывает AgentScanCycle. Цикл сохраняет работу до анализа, AgentScanExecutor ограничивает область и вызывает Core, AgentScanProcessing следит за отменой, ScanReportTransmission ограничивает размер. WindowsAgentScanQueue и WindowsAgentStateStore используют WindowsAgentFiles: атомарные DPAPI-файлы с проверкой ACL. Сохраняется purpose и формат прежнего state.bin.

Desktop: RemoteScansViewModel управляет устройством, параметрами, очередью и командами; ScanJobRow локализует состояния, ScanJobsClient работает по административной cookie. Готовый отчёт показывает прежний ScanResultsViewModel, CSV делает прежний ScanCsvExporter. Модуль локальной проверки 0.5 сохранён отдельно.

Сетевая логика, хранение, анализ, представление и жизненный цикл разделены. Windows-специфичные действия находятся в Agent/WindowsAgentFiles и tools, переносимая логика проверяется на Linux.

Модуль Core/Content разделён: DocumentTextReader выбирает формат, OfficeZipDirectory проверяет центральный каталог до ZipArchive, OfficePackage контролирует части/связи, OfficeBudget/OfficeReadStream/OfficeXmlPart ограничивают ресурсы. WordTextExtractor читает Word-части; SpreadsheetTextExtractor/WorksheetText/SpreadsheetStrings извлекают Excel. OfficeSampleDocuments создаёт отдельные демонстрационные пакеты без замены существующих файлов. Контракты отчёта, БД и формат защищённой очереди не менялись.

## Endpoint-этап 0.8

Седьмой проект Session работает как обычный пользователь, получает изменения CF_UNICODETEXT через AddClipboardFormatListener и показывает трей. Он не имеет токена агента и HTTP-клиента. Символьный буфер анализируется Core/Clipboard и очищается; IPC/очереди содержат только метаданные. Служба связывает компонент с зарегистрированным устройством через локальный named pipe с проверками прав/владельца/пользователя и установленного пути Session; на сервер ходит ClipboardAgentClient с bearer. Пользовательская очередь защищена DPAPI CurrentUser, служебная — LocalMachine + ACL. Отдельные cached/applied подтверждения исключают ложный статус применения по одному получению службой.

Server/Clipboard разделён на неизменяемые политики, назначения, обмен агента, приём с идемпотентностью и запросы журнала. Выдача версий привязана к устройству и credential hash; прежние выданные версии принимают исторические офлайн-события до смены регистрации. Device lock сериализует выдачу/приём/отзыв, policy lock — версии. Пять новых таблиц добавляются миграцией. Desktop/Clipboard разделён на клиент, редактор, строки и workspace. Наблюдение и ограничения — CLIPBOARD.md. Защита от остановки и предотвращение вставки отсутствуют.

## Интерфейс 0.8.1

ClipboardDeviceStatus отдельно вычисляет состояние и следующий шаг без зависимости от WPF. ClipboardRows представляет данные, ClipboardLists хранит загруженные и отфильтрованные строки, ClipboardOverview хранит состояние обновления, Workspace оркестрирует команды. Представления разделены на ClipboardView, ClipboardPoliciesView, ClipboardComputersView, ClipboardEventsView. ConsoleNavigation отвечает только за переходы из обзора. При фильтрации скрытый выбранный компьютер сбрасывается; автоперезагрузка сохраняет черновик и запросы. Схема данных и формат очередей 0.8 сохраняются.
