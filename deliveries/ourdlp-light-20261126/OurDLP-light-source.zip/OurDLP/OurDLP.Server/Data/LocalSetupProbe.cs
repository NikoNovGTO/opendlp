using Microsoft.EntityFrameworkCore;
namespace OurDLP.Server.Data;

public sealed record LocalSetupReport(string DatabaseStatus, bool AdministratorExists);
public static class LocalSetupProbe
{
    // Local CLI only. Does not migrate, create users, reset passwords or expose settings.
    public static async Task<LocalSetupReport> CheckAsync(IServiceProvider services, CancellationToken token)
    {
        await using var scope = services.CreateAsyncScope();
        var status = await scope.ServiceProvider.GetRequiredService<DatabaseReadiness>().CheckAsync(token);
        if (status.Status != "ready") return new(status.Status, false);
        var db = scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        return new("ready", await db.Users.AsNoTracking().AnyAsync(token));
    }
}
