using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;

namespace OurDLP.Session;

[SupportedOSPlatform("windows")]
public sealed class WindowsSessionStore : ISessionStateStore
{
    private readonly string _directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OurDLP", "Session");
    private readonly string _mutex;
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("OurDLP.Session.Clipboard.v1");
    public WindowsSessionStore()
    {
        using var identity = WindowsIdentity.GetCurrent();
        _mutex = @"Global\OurDLP.Session.Store." + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(identity.User!.Value)));
    }
    public Task<SessionState> ReadAsync(CancellationToken token) => Task.Run(() => Locked(null, token), token);
    public Task<SessionState> UpdateAsync(Func<SessionState, SessionState> update, CancellationToken token) => Task.Run(() => Locked(update, token), token);
    private SessionState Locked(Func<SessionState, SessionState>? update, CancellationToken token)
    {
        using var mutex = new Mutex(false, _mutex); var held = false;
        try
        {
            try { held = mutex.WaitOne(TimeSpan.FromSeconds(3)); } catch (AbandonedMutexException) { held = true; }
            if (!held) throw new IOException("Хранилище пользовательского компонента занято.");
            token.ThrowIfCancellationRequested(); Directory.CreateDirectory(_directory);
            if ((File.GetAttributes(_directory) & FileAttributes.ReparsePoint) != 0) throw new UnauthorizedAccessException();
            var path = Path.Combine(_directory, "state.bin"); var state = Read(path);
            if (update is null) return state;
            var next = update(state);
            if (next.SchemaVersion != 1 || next.Pending is null || next.Pending.Count > 128) throw new InvalidDataException();
            if (ReferenceEquals(next, state)) return state;
            var plain = JsonSerializer.SerializeToUtf8Bytes(next); byte[] protectedData;
            try { if (plain.Length > 1024 * 1024) throw new InvalidDataException(); protectedData = ProtectedData.Protect(plain, Entropy, DataProtectionScope.CurrentUser); }
            finally { CryptographicOperations.ZeroMemory(plain); }
            var temporary = Path.Combine(_directory, Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                File.WriteAllBytes(temporary, protectedData); token.ThrowIfCancellationRequested();
                if (state.RegistrationKey is not null && state.RegistrationKey != next.RegistrationKey && File.Exists(path))
                    File.Copy(path, Path.Combine(_directory, "archive-" + Guid.NewGuid().ToString("N") + ".bin"));
                File.Move(temporary, path, true);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
            foreach (var old in new DirectoryInfo(_directory).EnumerateFiles("archive-*.bin").OrderByDescending(x => x.LastWriteTimeUtc).Skip(3)) old.Delete();
            return next;
        }
        finally { if (held) mutex.ReleaseMutex(); }
    }
    private static SessionState Read(string path)
    {
        if (!File.Exists(path)) return new();
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0 || new FileInfo(path).Length > 1100 * 1024) throw new InvalidDataException();
        var plain = ProtectedData.Unprotect(File.ReadAllBytes(path), Entropy, DataProtectionScope.CurrentUser);
        try
        {
            var state = JsonSerializer.Deserialize<SessionState>(plain);
            if (state is null || state.SchemaVersion != 1 || state.Pending is null || state.Pending.Count > 128) throw new InvalidDataException();
            return state;
        }
        finally { CryptographicOperations.ZeroMemory(plain); }
    }
}
