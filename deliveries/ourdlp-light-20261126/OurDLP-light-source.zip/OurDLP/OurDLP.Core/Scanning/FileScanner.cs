using System.Text;
using OurDLP.Core.Content;

namespace OurDLP.Core.Scanning;

public sealed class FileScanner : IFileScanner
{
    public Task<ScanReport> ScanAsync(ScanRequest request, IProgress<ScanProgress>? progress, CancellationToken token) =>
        Task.Run(() => Run(ScanPreparation.Prepare(request), progress, token), CancellationToken.None);

    private static ScanReport Run(PreparedScan prepared, IProgress<ScanProgress>? progress, CancellationToken token)
    {
        using var priority = new ScanThreadPriority();
        var session = new ScanSession(prepared, progress, token);
        var attempted = 0;
        foreach (var path in ScanTraversal.Files(session))
        {
            if (!session.CanContinue()) break;
            if (attempted >= session.Request.Limits.MaxFiles)
            { session.Stop(ScanCompletion.LimitReached, "Достигнут предел поддерживаемых файлов."); break; }
            attempted++;
            try
            {
                var text = DocumentTextReader.Read(path, session.Request.Limits.MaxFileBytes, token);
                session.FilesScanned++;
                RuleMatcher.Apply(text, path, prepared.Rules, session);
            }
            catch (OperationCanceledException) when (token.IsCancellationRequested)
            { session.Stop(ScanCompletion.Cancelled, "Проверка отменена. Частичные результаты сохранены."); }
            catch (ScanContentException error)
            { session.FilesSkipped++; session.Issue(path, error.Code, error.Message); }
            catch (InvalidDataException error)
            {
                session.FilesSkipped++;
                session.Issue(path, error.Message, error.Message switch
                { "size" => "Размер файла превышает выбранный предел.", "link" => "Ссылка пропущена.", _ => "Поддерживаются текст UTF-8 и UTF-16 с BOM; двоичные файлы пропускаются." });
            }
            catch (DecoderFallbackException)
            { session.FilesSkipped++; session.Issue(path, "encoding", "Файл не является корректным текстом UTF-8 или UTF-16 с BOM."); }
            catch (Exception error) when (ScanTraversal.IsFileError(error))
            { session.FilesSkipped++; session.Issue(path, "access", "Файл недоступен, занят или был удалён во время проверки."); }
            session.Notify(path);
        }
        session.CanContinue();
        return session.Finish();
    }
}
