using System.Security;

namespace OurDLP.Core.Scanning;

/// <summary>Only the synchronous file-scan worker is lowered, then restored before thread-pool reuse.</summary>
internal sealed class ScanThreadPriority : IDisposable
{
    private readonly Thread _thread = Thread.CurrentThread;
    private readonly ThreadPriority _previous;
    private readonly bool _changed;
    public ScanThreadPriority()
    {
        if (!OperatingSystem.IsWindows()) return;
        try
        {
            _previous = _thread.Priority;
            if (_previous > ThreadPriority.BelowNormal) { _thread.Priority = ThreadPriority.BelowNormal; _changed = true; }
        }
        catch (Exception error) when (error is ThreadStateException or SecurityException or PlatformNotSupportedException or System.ComponentModel.Win32Exception) { }
    }
    public void Dispose()
    {
        if (!_changed) return;
        try { _thread.Priority = _previous; }
        catch (Exception error) when (error is ThreadStateException or SecurityException or PlatformNotSupportedException or System.ComponentModel.Win32Exception) { }
    }
}
