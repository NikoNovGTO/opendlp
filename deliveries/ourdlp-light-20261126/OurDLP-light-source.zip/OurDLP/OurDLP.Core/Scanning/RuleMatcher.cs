using System.Text.RegularExpressions;

namespace OurDLP.Core.Scanning;

internal static class RuleMatcher
{
    public static void Apply(string text, string path, IReadOnlyList<PreparedRule> rules, ScanSession session)
    {
        foreach (var rule in rules)
        {
            if (!session.CanContinue()) return;
            var count = 0; var limited = false;
            try
            {
                foreach (var match in rule.Expression.EnumerateMatches(text))
                {
                    if (!session.CanContinue()) { limited = true; break; }
                    if (count == session.Request.Limits.MaxMatchesPerFile) { limited = true; break; }
                    count++;
                }
            }
            catch (RegexMatchTimeoutException)
            { limited = true; session.Issue(path, "regex-timeout", "Правило превысило 100 мс при поиске очередного совпадения; результат может быть неполным."); }
            if (count == 0) continue;
            if (session.Findings.Count >= session.Request.Limits.MaxFindings)
            { session.Stop(ScanCompletion.LimitReached, "Достигнут предел строк результатов."); return; }
            session.Findings.Add(new(Guid.NewGuid(), path, Path.GetRelativePath(session.Request.RootPath, path),
                rule.Definition.Id, rule.Definition.Name, count, limited, DateTimeOffset.UtcNow));
        }
    }
}
