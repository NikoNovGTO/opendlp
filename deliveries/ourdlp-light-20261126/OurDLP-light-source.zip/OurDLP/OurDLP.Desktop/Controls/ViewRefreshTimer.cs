using System.Windows;
using System.Windows.Threading;
using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.Controls;

/// <summary>Refreshes a visible workspace; stops as soon as its view leaves the window.</summary>
public sealed class ViewRefreshTimer
{
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(10) };
    public ViewRefreshTimer(FrameworkElement view, Func<AsyncRelayCommand?> command)
    {
        void Refresh() { var action = command(); if (action?.CanExecute(null) == true) action.Execute(null); }
        _timer.Tick += (_, _) => Refresh();
        view.Loaded += (_, _) => { Refresh(); _timer.Start(); };
        view.Unloaded += (_, _) => _timer.Stop();
    }
}
