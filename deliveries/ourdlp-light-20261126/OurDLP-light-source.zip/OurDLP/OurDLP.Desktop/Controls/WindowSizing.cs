using System.Windows;

namespace OurDLP.Desktop.Controls;

public static class WindowSizing
{
    public static void FitWorkArea(Window window)
    {
        var area = SystemParameters.WorkArea;
        var width = Math.Max(320, area.Width - 16);
        var height = Math.Max(320, area.Height - 16);
        window.MinWidth = Math.Min(window.MinWidth, width);
        window.MinHeight = Math.Min(window.MinHeight, height);
        window.Width = Math.Min(window.Width, width);
        window.Height = Math.Min(window.Height, height);
    }
}
