using System.Globalization;
using System.Windows.Data;

namespace OurDLP.Desktop.Controls;

public sealed class MetricColumnsConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value is double width && width >= 840 ? 4 : 2;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}
