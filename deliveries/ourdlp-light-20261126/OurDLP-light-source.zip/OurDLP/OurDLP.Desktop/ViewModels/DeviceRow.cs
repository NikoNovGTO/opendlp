using System.Globalization;
using OurDLP.Contracts;

namespace OurDLP.Desktop.ViewModels;

public sealed class DeviceRow(DeviceResponse device)
{
    public Guid Id => device.Id;
    public string StatusCode => device.Status;
    public string Name => device.Name;
    public string HostName => device.HostName ?? "—";
    public string OperatingSystem => device.OperatingSystem ?? "—";
    public string AgentVersion => device.AgentVersion ?? "—";
    public string IpAddress => device.IpAddress ?? "—";
    public string Status => device.Status switch
    { "pending" => "Ожидает агента", "active" => "Активен", "offline" => "Нет связи", "revoked" => "Доступ отозван", _ => "Неизвестно" };
    public string StatusHint => device.Status switch
    {
        "pending" => "Установите агент на этот компьютер с одноразовым кодом. Если код истёк, выдайте новый. После установки нажмите «Обновить».",
        "active" => "Служба агента на связи. Чтобы проверить буфер, назначьте политику в разделе «Буфер обмена» и дождитесь «Наблюдение включено». Связь службы сама по себе не подтверждает наблюдение.",
        "offline" => "Более 90 секунд нет сообщений. Проверьте питание, сеть, доступность сервера и службу OurDLP.Agent. Агент может продолжать работу по сохранённой политике; показано последнее известное состояние.",
        "revoked" => "Сервер больше не принимает сообщения этой регистрации. Для повторного подключения нужны новый код и явная перерегистрация агента. Не удаляйте локальные данные ради повторной установки.",
        _ => "Обновите список и проверьте регистрацию и состояние службы агента."
    };
    public string LastSeen => device.LastSeenAtUtc is { } time
        ? TimeZoneInfo.ConvertTime(time, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss", CultureInfo.GetCultureInfo("ru-RU")) + " МСК" : "—";
}
