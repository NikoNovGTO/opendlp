using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels;
public sealed class ConsoleNavigation : ObservableObject
{
    private int _section;
    public int Section { get => _section; set { if (SetProperty(ref _section, value)) OnPropertyChanged(nameof(SectionTitle)); } }
    public string SectionTitle => Section switch
    {
        1 => "Компьютеры", 2 => "Буфер обмена", 3 => "Проверки на ПК", 4 => "Проверка папки",
        5 => "Настройки", 6 => "Помощь", _ => "Обзор"
    };
    public RelayCommand Devices { get; }
    public RelayCommand Clipboard { get; }
    public RelayCommand Scans { get; }
    public RelayCommand LocalFiles { get; }
    public RelayCommand Settings { get; }
    public RelayCommand Help { get; }
    public ConsoleNavigation()
    {
        Devices = new(() => Section = 1); Clipboard = new(() => Section = 2);
        Scans = new(() => Section = 3); LocalFiles = new(() => Section = 4);
        Settings = new(() => Section = 5); Help = new(() => Section = 6);
    }
}
