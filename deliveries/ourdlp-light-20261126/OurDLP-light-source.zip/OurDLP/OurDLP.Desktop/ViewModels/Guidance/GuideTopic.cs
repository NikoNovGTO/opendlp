using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.ViewModels.Guidance;

public sealed record GuideStep(string Title, string Instruction, string Expected,
    RelayCommand? OpenCommand = null, string ActionText = "")
{
    public bool HasAction => OpenCommand is not null;
}

public sealed record GuideTopic(string Id, string Title, string Summary, IReadOnlyList<GuideStep> Steps,
    bool HasTestText = false)
{
    public bool Matches(string query) => new[] { Title, Summary }
        .Concat(Steps.SelectMany(step => new[] { step.Title, step.Instruction, step.Expected }))
        .Any(text => text.Contains(query, StringComparison.OrdinalIgnoreCase));
}
