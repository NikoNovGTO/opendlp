using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.ViewModels.Clipboard;

namespace OurDLP.Desktop.ViewModels.Guidance;

public sealed class GuideLinks(ConsoleNavigation navigation, ClipboardWorkspace clipboard)
{
    public RelayCommand Devices => navigation.Devices;
    public RelayCommand LocalFiles => navigation.LocalFiles;
    public RelayCommand RemoteFiles => navigation.Scans;
    public RelayCommand Settings => navigation.Settings;
    public RelayCommand Policies { get; } = new(() => { clipboard.Section = 0; navigation.Section = 2; });
    public RelayCommand Assignments { get; } = new(() => { clipboard.Section = 1; navigation.Section = 2; });
    public RelayCommand Events { get; } = new(() => { clipboard.Section = 2; navigation.Section = 2; });
}
