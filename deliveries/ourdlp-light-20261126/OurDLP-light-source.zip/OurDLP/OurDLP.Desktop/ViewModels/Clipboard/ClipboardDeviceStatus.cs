using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed record ClipboardDeviceStatus(string Code, string Title, string Hint, bool RequiresAttention)
{
    public static ClipboardDeviceStatus Evaluate(ClipboardDeviceState state, ClipboardPolicy? policy, DateTimeOffset now)
    {
        var fresh = state.Helpers.Where(row => row.LastSeenAtUtc >= now.AddSeconds(-45) && row.LastSeenAtUtc <= now.AddMinutes(1)).ToArray();
        if (state.Status == "offline") return new("offline", "Нет связи с компьютером",
            "Проверьте питание, сеть и службу OurDLP.Agent. Показано последнее известное состояние; при отсутствии связи может действовать прежняя политика.", true);
        if (state.Status != "active") return new("unknown", "Состояние требует проверки", "Обновите список устройств и проверьте регистрацию агента.", true);
        if (!state.Capable) return new("unsupported", "Нужно обновить агент",
            "Установите агент версии 0.8 или новее. Обновление одной консоли не добавляет наблюдение на компьютер.", true);
        if (state.AssignedPolicyId is null)
        {
            if (state.CachedPolicyId is not null || fresh.Any(row => row.AppliedPolicyId is not null))
                return new("removing", "Ожидает снятия политики", "Назначение уже снято на сервере. Дождитесь получения изменения службой и пользовательским компонентом; до этого может действовать прежняя политика.", true);
            return new("unassigned", "Политика не назначена", "Выберите политику из списка выше и назначьте её этому компьютеру. Недоступные пользовательские компоненты могут хранить прежнюю политику до следующего подключения.", false);
        }
        if (state.CachedPolicyId != state.AssignedPolicyId || state.CachedVersion != state.DesiredVersion)
            return new("waiting", "Ожидает получения политики", "Служба ещё не подтвердила получение назначенной версии. Обычно обмен занимает до 30 секунд. При задержке проверьте службу и соединение с сервером.", true);
        if (fresh.Length == 0) return new("no-session", "Нет подтверждения пользователя",
            "Служба получила политику. На компьютере откройте «OurDLP — Контроль буфера обмена» из меню Пуск обычным пользователем. Если пользователь вышел из Windows, подтверждения не будет.", true);
        var ready = fresh.Count(row => row.AppliedPolicyId == state.AssignedPolicyId && row.AppliedVersion == state.DesiredVersion);
        if (ready != fresh.Length) return new("partial", ready == 0 ? "Ожидает применения у пользователя" : "Политика применена частично",
            $"Назначенную версию подтвердили {ready} из {fresh.Length} недавно подключавшихся компонентов. Дождитесь обмена или откройте состояние значка OurDLP у пользователя.", true);
        if (policy?.Id == state.AssignedPolicyId && policy.Version == state.DesiredVersion)
            return new(policy.Enabled ? "observing" : "disabled", policy.Enabled ? "Наблюдение включено" : "Наблюдение выключено",
                $"Версию {state.DesiredVersion} подтвердили все {ready} недавно подключавшихся компонентов. Это подтверждение известных компонентов, а не проверка всех сеансов Windows. " +
                (policy.Enabled ? "Совпадения регистрируются; копирование и вставка разрешены." : "По этой версии новые тексты не анализируются. Офлайн-компоненты получат изменение при подключении."), false);
        return new("applied", $"Применена: {ready} из {fresh.Length} сеансов", "Версия подтверждена компонентами. Обновите список политик, чтобы уточнить, включено ли наблюдение.", false);
    }
}
