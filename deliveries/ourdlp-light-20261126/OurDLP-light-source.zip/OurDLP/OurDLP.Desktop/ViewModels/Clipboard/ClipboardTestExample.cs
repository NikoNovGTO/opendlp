using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed class ClipboardTestExample : ObservableObject
{
    private int _number = 1234;
    public string Text => $"OURDLP-TEST-{_number:D4}";
    public RelayCommand NextCommand { get; }
    public ClipboardTestExample() => NextCommand = new(() =>
    {
        _number = (_number + 1) % 10000;
        OnPropertyChanged(nameof(Text));
    });
}
