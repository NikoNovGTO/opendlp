using System.Collections.ObjectModel;
using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services.Clipboard;
namespace OurDLP.Desktop.ViewModels.Clipboard;
public sealed class ClipboardWorkspace : ObservableObject, IDisposable
{
    private readonly IClipboardClient _client; private readonly Func<string, bool> _confirm; private readonly Action _expired;
    private readonly CancellationTokenSource _lifetime = new(); private bool _busy, _disposed, _refreshing;
    private ClipboardPolicy? _policy; private ClipboardDeviceRow? _device; private string _message = "";
    private int _section;
    public int Section { get => _section; set => SetProperty(ref _section, value); }
    public ClipboardTestExample TestExample { get; } = new();
    public ObservableCollection<ClipboardPolicy> Policies { get; } = [];
    public ClipboardLists Lists { get; } = new();
    public ClipboardOverview Overview { get; } = new();
    public ObservableCollection<ClipboardDeviceRow> Devices => Lists.Devices;
    public ObservableCollection<ClipboardEventView> Events => Lists.Events;
    public bool NoPolicies => Policies.Count == 0;
    public bool HasPolicySelection => SelectedPolicy is not null;
    public string AssignmentPreview => SelectedPolicy is null ? "Выберите сохранённую политику. Несохранённый черновик не назначается." :
        $"Выбрана политика «{SelectedPolicy.Name}», версия {SelectedPolicy.Version}. Наблюдение {(SelectedPolicy.Enabled ? "включено" : "выключено")}.";
    public ClipboardPolicyEditor Editor { get; } = new();
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public bool CanEdit => !_busy && !_disposed;
    public ClipboardPolicy? SelectedPolicy { get => _policy; set { if (SetProperty(ref _policy, value)) { if (!_refreshing && value is not null) Editor.Load(value); RefreshCommands(); } } }
    public ClipboardDeviceRow? SelectedDevice { get => _device; set { if (SetProperty(ref _device, value)) RefreshCommands(); } }
    public AsyncRelayCommand RefreshCommand { get; }
    public AsyncRelayCommand NewCommand { get; }
    public AsyncRelayCommand SaveCommand { get; }
    public AsyncRelayCommand AssignCommand { get; }
    public AsyncRelayCommand UnassignCommand { get; }
    public ClipboardWorkspace(IClipboardClient client, Func<string, bool> confirm, Action expired)
    {
        _client = client; _confirm = confirm; _expired = expired;
        Lists.DeviceFilterChanged += () => { if (!_refreshing && SelectedDevice is not null && !Lists.VisibleDevices.Contains(SelectedDevice)) SelectedDevice = null; };
        RefreshCommand = Command(RefreshAsync); NewCommand = Command(() => { SelectedPolicy = null; Editor.Load(null); return Task.CompletedTask; });
        SaveCommand = Command(SaveAsync, () => Editor.SupportsEditing);
        AssignCommand = Command(() => AssignAsync(SelectedPolicy?.Id), () => SelectedDevice?.Capable == true && SelectedPolicy is not null && Lists.VisibleDevices.Contains(SelectedDevice));
        UnassignCommand = Command(() => AssignAsync(null), () => SelectedDevice?.PolicyId is not null);
        Editor.PropertyChanged += (_, e) => { if (e.PropertyName == nameof(ClipboardPolicyEditor.SupportsEditing)) RefreshCommands(); };
    }
    private AsyncRelayCommand Command(Func<Task> operation, Func<bool>? allowed = null) => new(() => RunAsync(operation), Unexpected, () => CanEdit && (allowed?.Invoke() ?? true));
    private async Task RunAsync(Func<Task> operation)
    {
        if (!CanEdit) return; _busy = true; Message = ""; RefreshCommands();
        try { await operation(); }
        catch (OperationCanceledException) when (_disposed) { }
        catch (ArgumentException e) { if (!_disposed) Message = e.Message; }
        finally { _busy = false; if (_disposed) _lifetime.Dispose(); else RefreshCommands(); }
    }
    private async Task RefreshAsync()
    {
        var policies = await _client.PoliciesAsync(_lifetime.Token); if (!Accept(policies)) return;
        var devices = await _client.DevicesAsync(_lifetime.Token); if (!Accept(devices)) return;
        var events = await _client.EventsAsync(_lifetime.Token); if (!Accept(events)) return;
        var policyId = SelectedPolicy?.Id; var deviceId = SelectedDevice?.Id; _refreshing = true;
        try
        {
            Policies.Clear(); foreach (var policy in policies.Value!.Policies) Policies.Add(policy);
            SelectedPolicy = Policies.FirstOrDefault(row => row.Id == policyId);
            Lists.Replace(devices.Value!.Devices.Select(device => new ClipboardDeviceRow(device, Policies.FirstOrDefault(p => p.Id == device.AssignedPolicyId))),
                events.Value!.Events.Select(item => new ClipboardEventView(item)));
            SelectedDevice = Lists.VisibleDevices.FirstOrDefault(row => row.Id == deviceId);
            Overview.Update(Lists); OnPropertyChanged(nameof(NoPolicies));
        }
        finally { _refreshing = false; }
    }
    private async Task SaveAsync()
    {
        var draft = Editor.Draft();
        // This editor deliberately supports a single rule; do not silently erase a multi-rule policy created through the API.
        if (Editor.HasMultipleRules) { Message = "Эта политика содержит несколько правил. В этом редакторе можно изменить одно правило. Создайте новую политику или используйте средства управления несколькими правилами."; return; }
        var result = await _client.SaveAsync(Editor.Id, draft, _lifetime.Token); if (!Accept(result)) return;
        Editor.Load(result.Value); await RefreshAsync(); if (!_disposed) { SelectedPolicy = Policies.FirstOrDefault(row => row.Id == result.Value!.Id); Message = "Версия сохранена. Выберите компьютер на вкладке «Компьютеры» и назначьте политику. Ранее назначенные компьютеры получат новую версию автоматически."; }
    }
    private async Task AssignAsync(Guid? policy)
    {
        if (SelectedDevice is not { } device || !_confirm(policy is null
            ? $"Снять политику с компьютера «{device.Name}»? Наблюдение остановится после получения изменения службой и пользовательским компонентом. При отсутствии связи может действовать прежняя политика."
            : $"Назначить политику «{SelectedPolicy?.Name}» (версия {SelectedPolicy?.Version}, наблюдение {(SelectedPolicy?.Enabled == true ? "включено" : "выключено")}) компьютеру «{device.Name}»? Содержимое буфера не отправляется, вставка не блокируется.")) return;
        if (Accept(await _client.AssignAsync(device.Id, policy, _lifetime.Token))) { await RefreshAsync(); if (!_disposed) Message = "Назначение сохранено. Дождитесь подтверждения в столбце «Состояние наблюдения»."; }
    }
    private bool Accept<T>(DeviceApiResult<T> result)
    {
        if (_disposed) return false;
        if (result.SessionExpired) { Lists.Replace([], []); Overview.Failed(); _expired(); return false; }
        if (result.Value is not null) return true; Message = result.Error ?? "Операция не выполнена."; Overview.Failed(); return false;
    }
    private void RefreshCommands() { OnPropertyChanged(nameof(CanEdit)); OnPropertyChanged(nameof(AssignmentPreview)); OnPropertyChanged(nameof(HasPolicySelection)); foreach (var c in new[] { RefreshCommand, NewCommand, SaveCommand, AssignCommand, UnassignCommand }) c.Refresh(); }
    private void Unexpected(Exception e) { System.Diagnostics.Trace.TraceError(e.GetType().Name); if (!_disposed) { Message = "Операция не завершена. Проверьте соединение с сервером и повторите действие."; Overview.Failed(); } }
    public void Dispose() { if (_disposed) return; _disposed = true; _lifetime.Cancel(); if (!_busy) _lifetime.Dispose(); }
}
