using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed class ClipboardOverview : ObservableObject
{
    private DateTimeOffset? _lastRefresh;
    private bool _unavailable;
    public int Computers { get; private set; }
    public int Observing { get; private set; }
    public int Attention { get; private set; }
    public int RecentEvents { get; private set; }
    public bool HasLoaded => _lastRefresh is not null;
    public bool Unavailable => _unavailable;
    public string ComputersText => Count(Computers);
    public string ObservingText => Count(Observing);
    public string AttentionText => Count(Attention);
    public string RecentEventsText => Count(RecentEvents);
    private string Count(int value) => HasLoaded ? value.ToString("N0", System.Globalization.CultureInfo.GetCultureInfo("ru-RU")) : "—";
    public string DataStatus => _unavailable
        ? "Не удалось обновить данные. " + (HasLoaded ? "Ниже показаны последние полученные сведения. Проверьте сервер и нажмите «Обновить»." : "Проверьте соединение с сервером и нажмите «Обновить».")
        : _lastRefresh is { } time ? "Данные получены: " + ClipboardDeviceRow.MoscowTime(time) + ". Обновление — каждые 10 секунд, пока раздел открыт."
        : "Данные ещё не загружены. Откройте раздел или нажмите «Обновить».";
    public void Update(ClipboardLists lists)
    {
        Computers = lists.Devices.Count; Observing = lists.Devices.Count(row => row.Status.Code == "observing");
        Attention = lists.Devices.Count(row => row.Status.RequiresAttention); RecentEvents = lists.Events.Count;
        _lastRefresh = DateTimeOffset.UtcNow; _unavailable = false; Publish();
    }
    public void Failed() { _unavailable = true; Publish(); }
    private void Publish()
    { foreach (var name in new[] { nameof(Computers), nameof(Observing), nameof(Attention), nameof(RecentEvents), nameof(ComputersText), nameof(ObservingText), nameof(AttentionText), nameof(RecentEventsText), nameof(HasLoaded), nameof(Unavailable), nameof(DataStatus) }) OnPropertyChanged(name); }
}
