using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;
namespace OurDLP.Desktop.ViewModels.Clipboard;
public sealed class ClipboardPolicyEditor : ObservableObject
{
    private string _name = "Контроль тестового маркера", _rule = "Тестовый маркер", _pattern = "OURDLP-TEST-[0-9]{4}";
    private bool _enabled = true; private int _maximum = 16384; private Guid _ruleId = Guid.NewGuid();
    public Guid? Id { get; private set; }
    public int Version { get; private set; }
    public bool HasMultipleRules { get; private set; }
    public bool SupportsEditing => !HasMultipleRules;
    public string VersionText => Id is null ? "Новая политика" : $"Сохранённая версия: {Version}. После изменения будет создана версия {Version + 1}.";
    public string Name { get => _name; set => SetProperty(ref _name, value); }
    public string RuleName { get => _rule; set => SetProperty(ref _rule, value); }
    public string Pattern { get => _pattern; set => SetProperty(ref _pattern, value); }
    public bool Enabled { get => _enabled; set => SetProperty(ref _enabled, value); }
    public int Maximum { get => _maximum; set => SetProperty(ref _maximum, value); }
    public IReadOnlyList<int> Sizes { get; } = [4096, 16384, 65536];
    public ClipboardPolicyDraft Draft()
    {
        var draft = new ClipboardPolicyDraft(Name.Trim(), Enabled, Maximum, [new ScanRule(_ruleId, RuleName.Trim(), Pattern)], Version);
        _ = new CompiledClipboardPolicy(new(Id ?? Guid.NewGuid(), Version + 1, draft.Name, draft.Enabled, draft.MaxTextCharacters, draft.Rules));
        return draft;
    }
    public void Load(ClipboardPolicy? policy)
    {
        HasMultipleRules = policy?.Rules.Count > 1; OnPropertyChanged(nameof(HasMultipleRules)); OnPropertyChanged(nameof(SupportsEditing));
        Id = policy?.Id; Version = policy?.Version ?? 0; Name = policy?.Name ?? "Контроль тестового маркера";
        Enabled = policy?.Enabled ?? true; Maximum = policy?.MaxTextCharacters ?? 16384;
        var rule = policy?.Rules.FirstOrDefault(); _ruleId = rule?.Id ?? Guid.NewGuid(); RuleName = rule?.Name ?? "Тестовый маркер";
        Pattern = rule?.Pattern ?? "OURDLP-TEST-[0-9]{4}"; OnPropertyChanged(nameof(VersionText));
    }
}
