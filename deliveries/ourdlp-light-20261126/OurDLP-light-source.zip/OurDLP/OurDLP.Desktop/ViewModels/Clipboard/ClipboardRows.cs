using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
namespace OurDLP.Desktop.ViewModels.Clipboard;

public sealed class ClipboardDeviceRow
{
    private readonly ClipboardDeviceState _state;
    private readonly DateTimeOffset _now;
    public ClipboardDeviceRow(ClipboardDeviceState state, ClipboardPolicy? policy = null, DateTimeOffset? now = null)
    { _state = state; _now = now ?? DateTimeOffset.UtcNow; Status = ClipboardDeviceStatus.Evaluate(state, policy, _now); }
    public Guid Id => _state.Id;
    public string Name => _state.Name;
    public bool Capable => _state.Capable;
    public Guid? PolicyId => _state.AssignedPolicyId;
    public ClipboardDeviceStatus Status { get; }
    public string Desired => _state.DesiredVersion is { } version ? "Версия " + version : "Не назначена";
    public string Cached => _state.CachedVersion is { } version ? "Версия " + version : "Не получена";
    public string Applied => Status.Title;
    public string Sessions => _state.Helpers.Count == 0 ? "Пользовательские компоненты ещё не подключались. Откройте ярлык OurDLP на компьютере пользователя." :
        string.Join(Environment.NewLine, _state.Helpers.Select(row => $"{row.UserName}, сеанс {row.SessionId}: " +
            (row.LastSeenAtUtc < _now.AddSeconds(-45) ? "нет свежего подтверждения" : row.AppliedVersion is { } version ? "подтверждена версия " + version : "политика ещё не подтверждена") +
            $"; последнее сообщение {MoscowTime(row.LastSeenAtUtc)}; пропущенных изменений: {row.DroppedCaptures}."));
    internal static string MoscowTime(DateTimeOffset value) => TimeZoneInfo.ConvertTime(value, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss") + " МСК";
}
public sealed class ClipboardEventView(ClipboardEventRow data)
{
    public Guid DeviceId => data.DeviceId;
    public string Device => data.DeviceName;
    public string User => data.UserName;
    public string Process => string.IsNullOrWhiteSpace(data.SourceProcess) ? "Не удалось определить" : data.SourceProcess;
    public string Time => ClipboardDeviceRow.MoscowTime(data.OccurredAtUtc);
    public string Policy => data.PolicyName + ", версия " + data.PolicyVersion;
    public string Matches => data.Hits.Count == 0 ? "Совпадений не найдено" : string.Join("; ", data.Hits.Select(hit =>
        (data.Rules.FirstOrDefault(rule => rule.Id == hit.RuleId)?.Name ?? "Правило") + ": " + hit.Count + (hit.CountLimited ? " (достигнут предел подсчёта)" : "")));
    public string Result => data.Truncated || data.TimedOutRules.Count > 0 ? "Проверка ограничена" : "Обнаружено совпадение";
    public string Details => $"Проверено символов: {data.TextCharacters}; сеанс пользователя: {data.SessionId}. " +
        (data.Truncated ? "Проверена только начальная часть текста из-за ограничения размера. " : "") +
        (data.TimedOutRules.Count > 0 ? "Некоторые правила не завершились за отведённое время. " : "") +
        "Имя процесса указывает источник копирования. Место вставки не определяется. Содержимое буфера не хранится.";
}
