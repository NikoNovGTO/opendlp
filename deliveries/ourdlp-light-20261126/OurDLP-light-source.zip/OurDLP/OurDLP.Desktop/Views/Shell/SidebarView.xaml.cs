using System.Windows.Controls;
namespace OurDLP.Desktop.Views.Shell;
public partial class SidebarView : UserControl
{
    public SidebarView() => InitializeComponent();
}
