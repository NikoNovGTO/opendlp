using System.Windows.Controls;
namespace OurDLP.Desktop.Views.Shell;
public partial class TopBarView : UserControl
{
    public TopBarView() => InitializeComponent();
}
