using System.Windows.Controls;
namespace OurDLP.Desktop.Views;
public partial class ClipboardPoliciesView : UserControl
{
    public ClipboardPoliciesView() => InitializeComponent();
}
