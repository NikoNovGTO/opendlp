using System.Windows;
using OurDLP.Contracts;
using OurDLP.Desktop.ViewModels;

namespace OurDLP.Desktop.Views;

public partial class LoginWindow : Window
{
    private readonly LoginViewModel _viewModel;
    public AdministratorResponse? Administrator { get; private set; }

    public LoginWindow(LoginViewModel viewModel)
    {
        InitializeComponent();
        SourceInitialized += (_, _) => Controls.WindowSizing.FitWorkArea(this);
        _viewModel = viewModel;
        DataContext = viewModel;
    }

    private async void SignIn_Click(object sender, RoutedEventArgs e)
    {
        // PasswordBox handling stays in the view; passwords are never bound to a VM property.
        var password = PasswordInput.Password;
        PasswordInput.Clear();
        var administrator = await _viewModel.SignInAsync(password);
        password = string.Empty;
        if (administrator is null) return;
        Administrator = administrator;
        DialogResult = true;
    }

    protected override void OnClosed(EventArgs e)
    {
        PasswordInput.Clear();
        _viewModel.Dispose();
        base.OnClosed(e);
    }
}
