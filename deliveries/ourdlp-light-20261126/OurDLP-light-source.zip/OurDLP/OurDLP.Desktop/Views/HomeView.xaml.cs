using System.Windows.Controls;
using OurDLP.Desktop.Controls;
using OurDLP.Desktop.ViewModels;
namespace OurDLP.Desktop.Views;
public partial class HomeView : UserControl
{
    public HomeView()
    {
        InitializeComponent();
        _ = new ViewRefreshTimer(this, () => (DataContext as MainWindowViewModel)?.Clipboard.RefreshCommand);
    }
}
