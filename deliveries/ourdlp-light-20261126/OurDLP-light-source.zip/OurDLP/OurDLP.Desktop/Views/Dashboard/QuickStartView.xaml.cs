using System.Windows.Controls;
namespace OurDLP.Desktop.Views.Dashboard;
public partial class QuickStartView : UserControl
{
    public QuickStartView() => InitializeComponent();
}
