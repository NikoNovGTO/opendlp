using System.Windows.Controls;
namespace OurDLP.Desktop.Views.Dashboard;
public partial class RecentEventsView : UserControl
{
    public RecentEventsView() => InitializeComponent();
}
