using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace OurDLP.Desktop.Views;

public partial class HelpView : UserControl
{
    public HelpView()
    {
        InitializeComponent();
        // A newly selected topic must start at the first step, even after reading a long instruction.
        AddHandler(Selector.SelectionChangedEvent, new SelectionChangedEventHandler((_, _) => TopicScroll.ScrollToTop()));
    }
}
