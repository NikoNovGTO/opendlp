using System.Windows.Controls;
namespace OurDLP.Desktop.Views;
public partial class ClipboardEventsView : UserControl
{
    public ClipboardEventsView() => InitializeComponent();
}
