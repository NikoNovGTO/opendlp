using System.Windows.Controls;
namespace OurDLP.Desktop.Views;
public partial class ClipboardTestView : UserControl
{
    public ClipboardTestView() => InitializeComponent();
}
