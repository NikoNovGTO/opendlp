using System.Windows.Controls;
namespace OurDLP.Desktop.Views;
public partial class ClipboardComputersView : UserControl
{
    public ClipboardComputersView() => InitializeComponent();
}
