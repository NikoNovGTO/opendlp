using System.Windows.Controls;
using OurDLP.Desktop.Controls;
using OurDLP.Desktop.ViewModels.Clipboard;
namespace OurDLP.Desktop.Views;
public partial class ClipboardView : UserControl
{
    public ClipboardView()
    {
        InitializeComponent();
        _ = new ViewRefreshTimer(this, () => (DataContext as ClipboardWorkspace)?.RefreshCommand);
    }
}
