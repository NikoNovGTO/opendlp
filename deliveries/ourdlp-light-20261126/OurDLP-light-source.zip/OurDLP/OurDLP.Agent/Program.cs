using System.Text.Json;
using OurDLP.Agent.Clipboard;
using OurDLP.Core.Samples;
using OurDLP.Agent.Scanning;
using OurDLP.Core.Scanning;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OurDLP.Agent;

if (!OperatingSystem.IsWindows()) { Console.Error.WriteLine("OurDLP.Agent предназначен для Windows 10/11."); return 1; }
var commands = new[] { "--prepare-demo-documents", "--prepare-service-start", "--status", "--enroll" };
if (args.Length > 1 || (args.Length == 1 && !commands.Contains(args[0], StringComparer.Ordinal)))
{ Console.Error.WriteLine("Неизвестная команда агента."); return 1; }
using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false })
{ Timeout = TimeSpan.FromSeconds(10), MaxResponseContentBufferSize = 256 * 1024 };
var store = new WindowsAgentStateStore();
var protocol = new AgentProtocolClient(http);
var queue = new WindowsAgentScanQueue();
var scanRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OurDLP", "ScanTargets");
if (args.Contains("--prepare-demo-documents", StringComparer.Ordinal))
{
    try { OfficeSampleDocuments.Create(Path.Combine(scanRoot, "Demo")); Console.WriteLine("Демонстрационные документы Word и Excel подготовлены. Существующие файлы сохранены."); return 0; }
    catch { Console.Error.WriteLine("Не удалось подготовить демонстрационные документы. Проверьте область и права администратора."); return 1; }
}
if (args.Contains("--prepare-service-start", StringComparer.Ordinal))
{
    var saved = await store.ReadAsync(default);
    if (saved?.DeviceId is not { } device) return 1;
    await store.SaveAsync(saved.WithDevice(device), default); return 0;
}
if (args.Contains("--status", StringComparer.Ordinal))
{
    try
    {
        var state = await store.ReadAsync(default);
        Console.WriteLine(JsonSerializer.Serialize(new { DeviceId = state?.DeviceId, ServiceContactConfirmedAtUtc = state?.ServiceContactConfirmedAtUtc }));
        return 0;
    }
    catch { Console.Error.WriteLine("Не удалось прочитать защищённое состояние агента."); return 1; }
}
if (args.Contains("--enroll", StringComparer.Ordinal))
{
    try
    {
        var request = await JsonSerializer.DeserializeAsync<LocalEnrollmentRequest>(Console.OpenStandardInput(), new JsonSerializerOptions(JsonSerializerDefaults.Web));
        if (request is null) return 1;
        var result = await new AgentEnrollment(store, protocol).EnrollAsync(request.ServerAddress, request.Code, request.ReplaceExisting, default);
        if (!result.Succeeded) { Console.Error.WriteLine($"Регистрация не завершена (HTTP {result.StatusCode}). Проверьте HTTPS, сеть, срок кода и готовность сервера."); return 1; }
        if (request.ReplaceExisting) { await queue.ArchiveAsync(default); await new WindowsClipboardAgentStore().ArchiveAsync(default); }
        Console.WriteLine($"Агент зарегистрирован: {result.Response!.DeviceId}");
        return 0;
    }
    catch (Exception exception) { Console.Error.WriteLine($"Регистрация не завершена ({exception.GetType().Name}). Проверьте установку и права."); return 1; }
}
var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings { Args = args, ContentRootPath = AppContext.BaseDirectory });
builder.Services.AddWindowsService(options => options.ServiceName = "OurDLP.Agent");
builder.Logging.AddEventLog(options =>
{
    if (OperatingSystem.IsWindows()) { options.SourceName = "OurDLP.Agent"; options.LogName = "Application"; }
});
builder.Services.AddSingleton<IAgentStateStore>(store);
builder.Services.AddSingleton(protocol);
builder.Services.AddHostedService<AgentWorker>();
var scans = new AgentScanClient(http);
var execution = new AgentScanExecutor(new FileScanner(), scanRoot);
builder.Services.AddSingleton(new AgentScanCycle(queue, scans, new AgentScanProcessing(execution, scans), scanRoot));
builder.Services.AddHostedService<AgentScanWorker>();
builder.Services.AddSingleton(new ClipboardAgentCoordinator(store, new WindowsClipboardAgentStore()));
builder.Services.AddSingleton<IClipboardAgentClient>(new ClipboardAgentClient(http));
builder.Services.AddHostedService<ClipboardPolicyWorker>();
builder.Services.AddHostedService<ClipboardPipeWorker>();
await builder.Build().RunAsync();
return 0;

internal sealed class LocalEnrollmentRequest
{
    public string ServerAddress { get; init; } = string.Empty;
    public string Code { get; init; } = string.Empty;
    public bool ReplaceExisting { get; init; }
}
