﻿param([string]$SourceRoot=(Split-Path (Split-Path $PSScriptRoot -Parent) -Parent))
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path $SourceRoot 'tools/AgentInstallation.ps1')
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('ourdlp-install-repair-'+[Guid]::NewGuid().ToString('N'))
$passed=0
function Check([bool]$Condition,[string]$Label){if(-not $Condition){throw ('FAIL '+$Label)};$script:passed++;Write-Host ('PASS '+$Label)}
function MustFail([scriptblock]$Action){try{& $Action}catch{return};throw 'Expected failure'}
try{
    $install=Join-Path $fixture 'ProgramFiles/OurDLP/Agent';$data=Join-Path $fixture 'ProgramData/OurDLP/Agent';$payload=Join-Path $fixture 'payload'
    foreach($p in @($install,$data,$payload)){[IO.Directory]::CreateDirectory($p)|Out-Null}
    [IO.File]::WriteAllText((Join-Path $install 'unknown-user-file.txt'),'keep-original')
    [IO.File]::WriteAllText((Join-Path $data 'state.bin'),'test-only-registration')
    [IO.File]::WriteAllText((Join-Path $data 'pending-scan.bin'),'test-only-report')
    MustFail {Assert-OurDlpAgentPayload $payload}
    Check (Test-Path -LiteralPath (Join-Path $install 'unknown-user-file.txt')) 'Missing payload cannot replace old folder'
    foreach($name in @('OurDLP.Agent.exe','OurDLP.Session.exe','OurDLP.Core.dll')){[IO.File]::WriteAllText((Join-Path $payload $name),'harmless-test-file')}
    Assert-OurDlpAgentPayload $payload
    $backup=Backup-OurDlpAgentFolder $install
    Check ((Test-Path -LiteralPath (Join-Path $backup 'unknown-user-file.txt')) -and -not (Test-Path -LiteralPath $install)) 'Orphaned binary folder is preserved by rename'
    [IO.Directory]::CreateDirectory($install)|Out-Null
    [IO.File]::WriteAllText((Join-Path $install 'partial-new-file'),'partial')
    Restore-OurDlpAgentFolder $install $backup $true
    Check (([IO.File]::ReadAllText((Join-Path $install 'unknown-user-file.txt'))) -eq 'keep-original' -and -not (Test-Path -LiteralPath (Join-Path $install 'partial-new-file'))) 'Rollback restores old files after interrupted copy or service creation'
    Check (([IO.File]::ReadAllText((Join-Path $data 'state.bin'))) -eq 'test-only-registration' -and ([IO.File]::ReadAllText((Join-Path $data 'pending-scan.bin'))) -eq 'test-only-report') 'Registration and queue outside binary folder stay untouched'
    $backup=Backup-OurDlpAgentFolder $install
    Restore-OurDlpAgentFolder $install $backup $false
    Check (Test-Path -LiteralPath (Join-Path $install 'unknown-user-file.txt')) 'Failure before new directory creation restores backup'
    $newInstall=Join-Path $fixture 'new-install';[IO.Directory]::CreateDirectory($newInstall)|Out-Null
    [IO.File]::WriteAllText((Join-Path $newInstall 'partial'),'partial')
    Restore-OurDlpAgentFolder $newInstall '' $true
    Check (-not (Test-Path -LiteralPath $newInstall)) 'Fresh partial folder is removed without a backup'
    $registered=[PSCustomObject]@{DeviceId=[Guid]::NewGuid().ToString()}
    Check ((Get-OurDlpEnrollmentMode $registered $false $false) -eq 'Resume') 'Existing registration is resumed without new code'
    Check ((Get-OurDlpEnrollmentMode ([PSCustomObject]@{DeviceId=$null}) $false $false) -eq 'Enroll') 'New or pending device requests normal enrollment'
    MustFail {Get-OurDlpEnrollmentMode $registered $false $true}
    Check $true 'New code cannot silently replace existing registration'
    Check ((Get-OurDlpEnrollmentMode $registered $true $true) -eq 'Enroll') 'Explicit reenrollment remains available'
    MustFail {Get-OurDlpEnrollmentMode ([PSCustomObject]@{DeviceId='corrupt-id'}) $false $false}
    Check $true 'Malformed registration is not treated as fresh'
    MustFail {Get-OurDlpEnrollmentMode ([PSCustomObject]@{}) $false $false}
    Check $true 'Unrecognized status does not overwrite local state'
    Write-Host ('RESULT '+$passed+' installer recovery checks passed; SCM/DPAPI were not executed')
}finally{if(Test-Path -LiteralPath $fixture){Remove-Item -LiteralPath $fixture -Recurse -Force}}
