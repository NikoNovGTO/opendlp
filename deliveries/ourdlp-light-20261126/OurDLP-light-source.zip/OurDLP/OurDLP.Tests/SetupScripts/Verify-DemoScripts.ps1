﻿[CmdletBinding()]
param([string]$SourceRoot=(Split-Path (Split-Path $PSScriptRoot -Parent) -Parent))
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('ourdlp-demo-script-tests-'+[Guid]::NewGuid().ToString('N'))
$passed=0
function Check([bool]$Condition,[string]$Label){if(-not $Condition){throw ('FAIL '+$Label)};$script:passed++;Write-Host ('PASS '+$Label)}
function MustFail([scriptblock]$Action){try{& $Action}catch{return};throw 'Expected the operation to fail.'}
try {
    $bundle=Join-Path $fixture 'bundle';$tools=Join-Path $bundle 'tools';$launcher=Join-Path $bundle 'launcher';$runtime=Join-Path $bundle 'runtime';$data=Join-Path $fixture 'data'
    foreach($p in @($tools,$launcher,$runtime,$data)){[IO.Directory]::CreateDirectory($p)|Out-Null}
    Copy-Item -LiteralPath (Join-Path $SourceRoot 'tools/DatabaseTools.ps1'),(Join-Path $SourceRoot 'tools/LocalSettings.ps1') -Destination $tools
    Copy-Item -Path (Join-Path $SourceRoot 'demo/launcher/*.ps1') -Destination $launcher
    [IO.Directory]::CreateDirectory((Join-Path $bundle 'payload/content'))|Out-Null
    @{Version='0.8.2';Apps=@{Server=@();Desktop=@();Agent=@()}}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $bundle 'payload/apps.json') -Encoding UTF8
    . (Join-Path $launcher 'DemoCommon.ps1')
    . (Join-Path $launcher 'DemoPayload.ps1')
    . (Join-Path $launcher 'DemoProcesses.ps1')
    $script:DemoData=$data
    $script:SettingsFile=Join-Path $fixture 'settings/secrets.json'
    function Get-OurDlpSecretsFile{return $script:SettingsFile}
    # Windows ACL/identity APIs are intentionally not simulated as a successful native test.
    function Protect-OurDlpSettingsPath([string]$Path){}
    Save-OurDlpSettings @{'ConnectionStrings:OurDlp'='TestOnlyConnection';'Unknown:Keep'='Сохранить'}
    Save-OurDlpSettings @{'Kestrel:Certificates:Default:Path'='TestOnly.pfx'}
    $saved=Get-Content -LiteralPath $script:SettingsFile -Raw -Encoding UTF8|ConvertFrom-Json
    Check ($saved.'ConnectionStrings:OurDlp' -eq 'TestOnlyConnection' -and $saved.'Unknown:Keep' -eq 'Сохранить') 'Atomic merge preserves unrelated settings and Unicode'
    $nested='{"ConnectionStrings":{"OurDlp":"Old"},"Other":{"Array":["a","b"]}}'
    [IO.File]::WriteAllText($script:SettingsFile,$nested)
    Save-OurDlpSettings @{'ConnectionStrings:OurDlp'='New'}
    $saved=Get-Content -LiteralPath $script:SettingsFile -Raw|ConvertFrom-Json
    Check ($saved.'ConnectionStrings:OurDlp' -eq 'New' -and $saved.'Other:Array:1' -eq 'b' -and $null -eq $saved.PSObject.Properties['ConnectionStrings']) 'Nested configuration updates without duplicate colon keys'
    [IO.File]::WriteAllText($script:SettingsFile,'{broken-json')
    MustFail {Save-OurDlpSettings @{'New'='value'}}
    Check ([IO.File]::ReadAllText($script:SettingsFile) -eq '{broken-json') 'Malformed configuration stays untouched'
    [IO.File]::WriteAllText($script:SettingsFile,('x'*(1MB+1)))
    MustFail {Save-OurDlpSettings @{'New'='value'}}
    Check ((Get-Item -LiteralPath $script:SettingsFile).Length -eq 1MB+1) 'Oversized settings are rejected before replacement'
    [IO.File]::WriteAllText($script:SettingsFile,'{"Kestrel:Endpoints:Https:Url":"https://0.0.0.0:7443"}')
    Check ((Get-DemoAddress) -eq 'https://localhost:7443') 'LAN wildcard listener maps to same-PC console address'
    [IO.File]::WriteAllText($script:SettingsFile,'{"Kestrel:Endpoints:Https:Url":"https://example.com:7443"}')
    MustFail {Get-DemoAddress}
    Check $true 'Launcher refuses a remote server configuration'
    # Use harmless fixture files; no executable or service is started by these tests.
    foreach($name in @('OurDLP.Agent.exe','OurDLP.Session.exe','coreclr.dll')){[IO.File]::WriteAllText((Join-Path $runtime $name),('test-'+$name))}
    $content=Join-Path $bundle 'payload/content'
    $files=@(Get-ChildItem -LiteralPath $runtime -File|ForEach-Object{
        $hash=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $content ($hash+'.bin'))
        @{Path=$_.Name;Sha256=$hash}
    })
    @{Version='0.8.2';Apps=@{Server=@();Desktop=@();Agent=$files}}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $bundle 'payload/apps.json') -Encoding UTF8
    $payload=Copy-DemoAgentPayload
    Check ((Get-ChildItem -LiteralPath $payload -File).Count -eq 3) 'Agent payload copies only verified manifest entries'
    $server=@();$desktop=@()
    foreach($pair in @(@('Server','server-version'),@('Desktop','desktop-version'))){
        $group=@();foreach($item in @(@('Shared.dll',$pair[1]),@(('OurDLP.'+$pair[0]+'.exe'),'harmless-fixture'))){
            $bytes=[Text.Encoding]::UTF8.GetBytes($item[1]);$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
            [IO.File]::WriteAllBytes((Join-Path $content ($sha+'.bin')),$bytes);$group+=@{Path=$item[0];Sha256=$sha}
        }
        if($pair[0] -eq 'Server'){$server=$group}else{$desktop=$group}
    }
    @{Apps=@{Server=$server;Desktop=$desktop;Agent=$files}}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $bundle 'payload/apps.json') -Encoding UTF8
    $serverPath=Expand-DemoApplication 'Server';$desktopPath=Expand-DemoApplication 'Desktop'
    Check (([IO.File]::ReadAllText((Join-Path $serverPath 'Shared.dll'))) -eq 'server-version' -and ([IO.File]::ReadAllText((Join-Path $desktopPath 'Shared.dll'))) -eq 'desktop-version') 'Application-specific DLL variants stay separate'
    [IO.File]::WriteAllText((Join-Path $serverPath 'Shared.dll'),'corrupted-cache');$serverPath=Expand-DemoApplication 'Server'
    Check (([IO.File]::ReadAllText((Join-Path $serverPath 'Shared.dll'))) -eq 'server-version') 'Corrupted cached file is repaired from verified content'
    $files[0].Path='../outside'
    @{Apps=@{Agent=$files}}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $bundle 'payload/apps.json') -Encoding UTF8
    MustFail {Copy-DemoAgentPayload}
    Check $true 'Agent manifest rejects traversal'
    $files=@(Get-ChildItem -LiteralPath $runtime -File|ForEach-Object{@{Path=$_.Name;Sha256=('0'*64)}})
    @{Apps=@{Agent=$files}}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $bundle 'payload/apps.json') -Encoding UTF8
    MustFail {Copy-DemoAgentPayload}
    Check $true 'Changed payload hash is rejected'
    @{Id=12345;Ticks=100}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $data 'server-process.json') -Encoding UTF8
    $script:FakeIdentity=@{Id=12345;Ticks=200;Path=$script:ServerExe}
    function Get-DemoProcessIdentity([int]$ProcessId){return $script:FakeIdentity}
    Check ($null -eq (Get-OwnedDemoServer)) 'Reused process ID is not owned'
    $script:FakeIdentity=@{Id=12345;Ticks=100;Path='/unrelated/other.exe'}
    Check ($null -eq (Get-OwnedDemoServer)) 'Other executable is not owned'
    $script:FakeIdentity=@{Id=12345;Ticks=100;Path=$script:ServerExe}
    Check ($null -ne (Get-OwnedDemoServer)) 'Matching executable and creation time identify owned server'
    Write-Host ('RESULT '+$passed+' script checks passed. Native Windows APIs were not executed.')
} finally {if(Test-Path -LiteralPath $fixture){Remove-Item -LiteralPath $fixture -Recurse -Force}}
