﻿#Requires -Version 5.1
[CmdletBinding()]
param([string]$SourceRoot=(Split-Path (Split-Path $PSScriptRoot -Parent) -Parent))
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path $SourceRoot 'tools/ResourceSamples.ps1')
$passed=0
function Check([bool]$Value,[string]$Name){if(-not $Value){throw ('FAIL '+$Name)};$script:passed++;Write-Host ('PASS '+$Name)}
Check ((Get-OurDlpCpuPercent 1 1.08 1 8) -eq 1) 'CPU is normalized to all logical processors'
Check ($null -eq (Get-OurDlpCpuPercent $null 1 1 2)) 'First sample has no invented zero CPU'
Check ($null -eq (Get-OurDlpCpuPercent 2 1 1 2)) 'Reset CPU counter is not a negative usage'
Check ($null -eq (Get-OurDlpCpuPercent 1 2 0 2)) 'Zero elapsed time is rejected'
$rows=@(
 [pscustomobject]@{Sample=0;Process='Agent';WorkingSetMiB=12;PrivateMiB=8;CpuPercent=$null;Status='ok'},
 [pscustomobject]@{Sample=0;Process='Session';WorkingSetMiB=20;PrivateMiB=14;CpuPercent=$null;Status='ok'},
 [pscustomobject]@{Sample=1;Process='Agent';WorkingSetMiB=13;PrivateMiB=9;CpuPercent=0.2;Status='ok'},
 [pscustomobject]@{Sample=1;Process='Session';WorkingSetMiB=21;PrivateMiB=15;CpuPercent=0.3;Status='ok'},
 [pscustomobject]@{Sample=2;Process='Agent';WorkingSetMiB=$null;PrivateMiB=$null;CpuPercent=$null;Status='not-running'},
 [pscustomobject]@{Sample=2;Process='Session';WorkingSetMiB=22;PrivateMiB=16;CpuPercent=0.1;Status='ok'}
)
$summary=Get-OurDlpResourceSummary $rows 2
Check ($summary.CompleteMemorySamples -eq 2 -and $summary.MaxWorkingSetSumMiB -eq 34 -and $summary.AverageCpuPercent -eq 0.5) 'Only complete samples enter endpoint aggregates'
$partial=@($rows[0],($rows[1]|Select-Object *));$partial[1].Status='partial-metrics'
Check ((Get-OurDlpResourceSummary $partial 2).CompleteMemorySamples -eq 1) 'Readable memory remains valid when CPU access is unavailable'
$missing=@(Get-OurDlpResourceRows @('OurDLP.NoSuchFixtureProcess') @{} 0 0)
Check ($missing.Count -eq 1 -and $missing[0].Status -eq 'not-running' -and $null -eq $missing[0].WorkingSetMiB) 'Missing process is unavailable rather than zero memory'
$realName=(Get-Process -Id $PID).ProcessName;$previous=@{}
$one=@(Get-OurDlpResourceRows @($realName) $previous 0 0)
$two=@(Get-OurDlpResourceRows @($realName) $previous 1 1)
Check ($one.Count -gt 0 -and @($two|Where-Object{$_.Pid -eq $PID -and $null -ne $_.WorkingSetMiB}).Count -eq 1) 'Actual portable process counters can be sampled without Windows GUI'
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('ourdlp-resource-check-'+[Guid]::NewGuid().ToString('N'))
try{
 $report=Save-OurDlpResourceReport $missing $fixture 'idle' 1 1 $true
 $json=Get-Content -LiteralPath $report.Json -Raw -Encoding UTF8|ConvertFrom-Json
 Check ($json.Summary.CompleteMemorySamples -eq 0 -and $null -eq $json.Summary.MaxWorkingSetSumMiB) 'Missing counters remain null in serialized report'
 $text=Get-Content -LiteralPath $report.Csv -Raw -Encoding UTF8
 Check ($text -notmatch 'CommandLine|UserName|MachineName|Password|ClipboardText') 'Report contains only process resource fields'
}finally{if(Test-Path -LiteralPath $fixture){Remove-Item -LiteralPath $fixture -Recurse -Force}}
Write-Host ('RESULT '+$passed+' resource sampler checks passed; no native WinForms or service measurement claimed.')
