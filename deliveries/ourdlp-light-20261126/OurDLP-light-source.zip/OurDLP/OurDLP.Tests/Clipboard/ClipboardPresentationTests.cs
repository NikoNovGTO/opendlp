using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services.Clipboard;
using OurDLP.Desktop.ViewModels;
using OurDLP.Desktop.ViewModels.Clipboard;
using Xunit;
namespace OurDLP.Tests.Clipboard;

public sealed class ClipboardPresentationTests
{
    private static readonly DateTimeOffset Now = DateTimeOffset.UtcNow;
    private static ClipboardDeviceState Device(ClipboardPolicy policy, params ClipboardHelperStatus[] helpers) =>
        new(Guid.NewGuid(), "Бухгалтерия", true, "active", policy.Id, policy.Version, policy.Id, policy.Version, helpers);
    private static ClipboardHelperStatus Helper(ClipboardPolicy policy, int session = 3) =>
        new(ClipboardSamples.Peer.UserSid, "ТЕСТ\\Администратор", session, policy.Id, policy.Version, Now, 0);
    [Theory][InlineData(true,"observing")][InlineData(false,"disabled")]
    public void ConfirmedDisabledAndEnabledPoliciesAreDifferentStates(bool enabled, string expected)
    {
        var p=ClipboardSamples.Policy(enabled);var result=ClipboardDeviceStatus.Evaluate(Device(p,Helper(p)),p,Now);
        Assert.Equal(expected,result.Code);Assert.False(result.RequiresAttention);
    }
    [Fact] public void SameVersionOfAnotherPolicyIsNotConfirmation()
    {
        var p=ClipboardSamples.Policy();var other=ClipboardSamples.Policy();var state=Device(p,Helper(other));
        Assert.Equal("partial",ClipboardDeviceStatus.Evaluate(state,p,Now).Code);
        Assert.Equal("waiting",ClipboardDeviceStatus.Evaluate(state with{CachedPolicyId=other.Id},p,Now).Code);
    }
    [Fact] public void StaleOrFutureHelperNeverConfirmsMonitoring()
    {
        var p=ClipboardSamples.Policy();foreach(var time in new[]{Now.AddSeconds(-46),Now.AddMinutes(2)})
            Assert.Equal("no-session",ClipboardDeviceStatus.Evaluate(Device(p,Helper(p) with{LastSeenAtUtc=time}),p,Now).Code);
    }
    [Fact] public void OneUnconfirmedRecentSessionPreventsAllAppliedStatus()
    {
        var p=ClipboardSamples.Policy() with{Version=2};var state=Device(p,Helper(p),Helper(p,4) with{AppliedVersion=1});
        var status=ClipboardDeviceStatus.Evaluate(state,p,Now);Assert.Equal("partial",status.Code);Assert.True(status.RequiresAttention);
    }
    [Fact] public void OfflineOrUnknownAgentIsNotShownAsObserving()
    {
        var p=ClipboardSamples.Policy();var state=Device(p,Helper(p));
        Assert.Equal("offline",ClipboardDeviceStatus.Evaluate(state with{Status="offline"},p,Now).Code);
        Assert.Equal("unknown",ClipboardDeviceStatus.Evaluate(state with{Status="unexpected"},p,Now).Code);
        Assert.Equal("unsupported",ClipboardDeviceStatus.Evaluate(state with{Capable=false},p,Now).Code);
    }
    [Fact] public void UnassignmentWaitsForCachedAndAppliedPoliciesToClear()
    {
        var p=ClipboardSamples.Policy();var state=Device(p,Helper(p)) with{AssignedPolicyId=null,DesiredVersion=null};
        Assert.Equal("removing",ClipboardDeviceStatus.Evaluate(state,p,Now).Code);
        Assert.Equal("removing",ClipboardDeviceStatus.Evaluate(state with{CachedPolicyId=null,CachedVersion=null},p,Now).Code);
        Assert.Equal("unassigned",ClipboardDeviceStatus.Evaluate(state with{CachedPolicyId=null,CachedVersion=null,Helpers=[]},p,Now).Code);
    }
    [Fact] public void FiltersAreScopedToLoadedDataAndPreservedAcrossRefresh()
    {
        var p=ClipboardSamples.Policy();var good=new ClipboardDeviceRow(Device(p,Helper(p)),p,Now);
        var bad=new ClipboardDeviceRow(Device(p) with{Name="Отдел кадров"},p,Now);
        var lists=new ClipboardLists();lists.Replace([good,bad],[]);lists.DeviceQuery="  КАДРОВ ";lists.OnlyAttention=true;
        Assert.Equal(bad.Id,Assert.Single(lists.VisibleDevices).Id);
        lists.Replace([good,bad],[]);Assert.Equal(bad.Id,Assert.Single(lists.VisibleDevices).Id);
        lists.DeviceQuery="Бухгалтерия";Assert.Empty(lists.VisibleDevices);Assert.True(lists.NoDevices);
        lists.OnlyAttention=false;Assert.Equal(good.Id,Assert.Single(lists.VisibleDevices).Id);
    }
    [Fact] public void EventSearchDoesNotNeedOrExposeClipboardContents()
    {
        var lists=new ClipboardLists();var p=ClipboardSamples.Policy();var row=new ClipboardEventRow(Guid.NewGuid(),Guid.NewGuid(),"Бухгалтерия",p.Id,p.Name,1,Now,Now,"ТЕСТ\\Иван",ClipboardSamples.Peer.UserSid,3,"notepad",16,false,[new(p.Rules[0].Id,1,false)],[],p.Rules);
        lists.Replace([], [new(row)]);foreach(var query in new[]{"бухгалтерия","ИВАН","notepad",p.Name,p.Rules[0].Name}){lists.EventQuery=query;Assert.Single(lists.VisibleEvents);}
        lists.EventQuery="неизвестное содержимое";Assert.Empty(lists.VisibleEvents);Assert.True(lists.NoEvents);
        Assert.DoesNotContain("Content",ScanWire.Serialize(row));
    }
    [Fact] public void OverviewRetainsOldCountsButMarksRefreshFailure()
    {
        var p=ClipboardSamples.Policy();var lists=new ClipboardLists();lists.Replace([new(Device(p,Helper(p)),p,Now),new(Device(p),p,Now)],[]);
        var summary=new ClipboardOverview();Assert.False(summary.HasLoaded);summary.Update(lists);Assert.Equal(1,summary.Observing);Assert.Equal(1,summary.Attention);
        summary.Failed();Assert.True(summary.Unavailable);Assert.True(summary.HasLoaded);Assert.Equal(2,summary.Computers);Assert.Contains("последние",summary.DataStatus);
        summary.Update(lists);Assert.False(summary.Unavailable);
    }
    [Fact] public async Task FilteringOutSelectedComputerPreventsAssignmentToInvisibleTarget()
    {
        var client=new Client();using var vm=new ClipboardWorkspace(client,_=>true,()=>{});await vm.RefreshCommand.ExecuteAsync();vm.SelectedPolicy=vm.Policies[0];vm.SelectedDevice=vm.Devices[0];Assert.True(vm.AssignCommand.CanExecute(null));
        vm.Lists.DeviceQuery="Нет такого компьютера";Assert.Null(vm.SelectedDevice);Assert.False(vm.AssignCommand.CanExecute(null));await vm.AssignCommand.ExecuteAsync();Assert.Equal(0,client.Assignments);
    }
    [Fact] public async Task FailedRefreshPreservesDraftAndOldRowsWithVisibleStaleFlag()
    {
        var client=new Client();using var vm=new ClipboardWorkspace(client,_=>true,()=>{});await vm.RefreshCommand.ExecuteAsync();vm.SelectedPolicy=vm.Policies[0];vm.Editor.Name="Черновик администратора";var old=vm.Devices[0].Id;
        client.Unavailable=true;await vm.RefreshCommand.ExecuteAsync();Assert.True(vm.Overview.Unavailable);Assert.Equal(old,Assert.Single(vm.Devices).Id);Assert.Equal("Черновик администратора",vm.Editor.Name);
        client.Unavailable=false;await vm.RefreshCommand.ExecuteAsync();Assert.False(vm.Overview.Unavailable);Assert.Equal("Черновик администратора",vm.Editor.Name);
    }
    [Fact] public async Task MultiRulePolicyCannotBeFlattenedBySingleRuleEditorAfterRefresh()
    {
        var client=new Client{MultipleRules=true};using var vm=new ClipboardWorkspace(client,_=>true,()=>{});await vm.RefreshCommand.ExecuteAsync();vm.SelectedPolicy=vm.Policies[0];Assert.False(vm.SaveCommand.CanExecute(null));
        client.HidePolicies=true;await vm.RefreshCommand.ExecuteAsync();Assert.Null(vm.SelectedPolicy);Assert.False(vm.SaveCommand.CanExecute(null));
        await vm.NewCommand.ExecuteAsync();Assert.True(vm.SaveCommand.CanExecute(null));Assert.Null(vm.Editor.Id);
    }
    private sealed class Client:IClipboardClient
    {
        private readonly ClipboardPolicy _policy=ClipboardSamples.Policy();private readonly Guid _device=Guid.NewGuid();
        public bool MultipleRules{get;set;}public bool HidePolicies{get;set;}public bool Unavailable{get;set;}public int Assignments{get;private set;}
        public Task<DeviceApiResult<ClipboardPolicyList>> PoliciesAsync(CancellationToken t)=>Task.FromResult(Unavailable?new DeviceApiResult<ClipboardPolicyList>(null,"Сервер недоступен"):new(new(HidePolicies?[]:[MultipleRules?_policy with{Rules=[_policy.Rules[0],_policy.Rules[0] with{Id=Guid.NewGuid()}]}:_policy])));
        public Task<DeviceApiResult<ClipboardDeviceList>> DevicesAsync(CancellationToken t)=>Task.FromResult(new DeviceApiResult<ClipboardDeviceList>(new([Device(_policy) with{Id=_device}])));
        public Task<DeviceApiResult<ClipboardEventList>> EventsAsync(CancellationToken t)=>Task.FromResult(new DeviceApiResult<ClipboardEventList>(new([])));
        public Task<DeviceApiResult<ClipboardPolicy>> SaveAsync(Guid? id,ClipboardPolicyDraft draft,CancellationToken t)=>throw new NotImplementedException();
        public Task<DeviceApiResult<DeviceOperationResponse>> AssignAsync(Guid device,Guid? policy,CancellationToken t){Assignments++;return Task.FromResult(new DeviceApiResult<DeviceOperationResponse>(new("Готово")));}
    }
}
