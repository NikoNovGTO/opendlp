using OurDLP.Contracts;
using OurDLP.Core.Clipboard;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services.Clipboard;
using OurDLP.Desktop.ViewModels;
using OurDLP.Desktop.ViewModels.Clipboard;
using OurDLP.Desktop.ViewModels.Guidance;
using Xunit;

namespace OurDLP.Tests.Guidance;

public sealed class HelpWorkspaceTests
{
    [Theory]
    [InlineData(0, "start")]
    [InlineData(1, "enrollment")]
    [InlineData(2, "clipboard")]
    [InlineData(3, "files")]
    [InlineData(4, "files")]
    [InlineData(5, "problems")]
    public void ContextHelpClearsOldSearchAndOpensTheRelevantTopic(int section, string topic)
    {
        using var clipboard = new ClipboardWorkspace(new UnusedClient(), _ => false, () => { });
        var navigation = new ConsoleNavigation();
        var help = new HelpWorkspace(navigation, clipboard) { Query = "нет такой инструкции 98765" };
        Assert.Null(help.SelectedTopic); Assert.True(help.NoTopics);
        navigation.Section = section; help.ContextCommand.Execute(null);
        Assert.Equal("", help.Query); Assert.Equal(topic, help.SelectedTopic?.Id);
        Assert.Contains(help.SelectedTopic, help.Topics); Assert.Equal(6, navigation.Section);
    }

    [Fact]
    public void SearchFindsStepTextAndNeverLeavesAnInvisibleTopicSelected()
    {
        using var clipboard = new ClipboardWorkspace(new UnusedClient(), _ => false, () => { });
        var help = new HelpWorkspace(new(), clipboard);
        help.StatesCommand.Execute(null);
        help.Query = " СЕРТИФИКАТ ";
        Assert.NotEmpty(help.Topics); Assert.Contains(help.SelectedTopic, help.Topics);
        Assert.DoesNotContain(help.Topics, topic => topic.Id == "states");
        help.Query = "несуществующая инструкция 98765";
        Assert.Empty(help.Topics); Assert.Null(help.SelectedTopic);
        help.Query = "";
        Assert.Equal(7, help.Topics.Count); Assert.NotNull(help.SelectedTopic);
        help.OfflineCommand.Execute(null); help.ContextCommand.Execute(null);
        Assert.Equal("offline", help.SelectedTopic?.Id);
    }

    [Fact]
    public void GuideActionsOpenExactClipboardTabsAndPreserveTheDraftWithoutServerCalls()
    {
        using var clipboard = new ClipboardWorkspace(new UnusedClient(), _ => throw new Exception("Unexpected confirmation"), () => { });
        clipboard.Editor.Name = "Несохранённый черновик";
        clipboard.Editor.Pattern = "PRIVATE-DRAFT-[0-9]+";
        var navigation = new ConsoleNavigation(); var help = new HelpWorkspace(navigation, clipboard);
        help.StartCommand.Execute(null);
        var steps = help.SelectedTopic!.Steps;
        steps[1].OpenCommand!.Execute(null); Assert.Equal(1, navigation.Section);
        steps[2].OpenCommand!.Execute(null); Assert.Equal(2, navigation.Section); Assert.Equal(0, clipboard.Section);
        steps[3].OpenCommand!.Execute(null); Assert.Equal(2, navigation.Section); Assert.Equal(1, clipboard.Section);
        steps[4].OpenCommand!.Execute(null); Assert.Equal(2, navigation.Section); Assert.Equal(2, clipboard.Section);
        Assert.Equal("Несохранённый черновик", clipboard.Editor.Name);
        Assert.Equal("PRIVATE-DRAFT-[0-9]+", clipboard.Editor.Pattern);
        Assert.Empty(clipboard.Events); Assert.Empty(clipboard.Policies);
    }

    [Fact]
    public void TestTextIsSharedWithJournalAlwaysMatchesTheExampleAndDoesNotInventEvents()
    {
        using var clipboard = new ClipboardWorkspace(new UnusedClient(), _ => false, () => { });
        var help = new HelpWorkspace(new(), clipboard);
        Assert.Same(clipboard.TestExample, help.TestExample);
        var initial = help.TestExample.Text;
        var seen = new HashSet<string>();
        for (var i = 0; i < 10000; i++)
        {
            Assert.Matches("^OURDLP-TEST-[0-9]{4}$", help.TestExample.Text);
            Assert.True(seen.Add(help.TestExample.Text));
            help.TestExample.NextCommand.Execute(null);
        }
        Assert.Equal(initial, help.TestExample.Text); Assert.Empty(clipboard.Events);
    }

    // Opening instructions and following navigation must not read or mutate the server.
    private sealed class UnusedClient : IClipboardClient
    {
        public Task<DeviceApiResult<ClipboardPolicyList>> PoliciesAsync(CancellationToken token) => throw new InvalidOperationException();
        public Task<DeviceApiResult<ClipboardDeviceList>> DevicesAsync(CancellationToken token) => throw new InvalidOperationException();
        public Task<DeviceApiResult<ClipboardEventList>> EventsAsync(CancellationToken token) => throw new InvalidOperationException();
        public Task<DeviceApiResult<ClipboardPolicy>> SaveAsync(Guid? id, ClipboardPolicyDraft draft, CancellationToken token) => throw new InvalidOperationException();
        public Task<DeviceApiResult<DeviceOperationResponse>> AssignAsync(Guid device, Guid? policy, CancellationToken token) => throw new InvalidOperationException();
    }
}
