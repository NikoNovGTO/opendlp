using System.Net.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Agent;
using OurDLP.Server.Data;
using Xunit;
namespace OurDLP.Tests;

public sealed class AgentServiceRecoveryTests
{
    [PostgresFact][Trait("Category","Postgres")]
    public async Task SavedRegistrationCanBeVerifiedWithoutCodeOrSecondEnrollment()
    {
        await using var context=await AgentTestContext.CreateAsync();var code=await context.AddAsync();
        var handler=new Requests{InnerHandler=context.Server.Server.CreateHandler()};using var http=new HttpClient(handler);
        var store=new MemoryAgentState();var enrollment=new AgentEnrollment(store,new(http));Assert.True((await enrollment.EnrollAsync("https://localhost",code.Code,false,default)).Succeeded);
        var before=store.State!;handler.Paths.Clear();
        Assert.True((await enrollment.EnrollAsync("https://localhost","",false,default)).Succeeded);
        Assert.Equal(before.Token,store.State!.Token);Assert.Equal(before.DeviceId,store.State.DeviceId);Assert.Equal(before.EnrollmentCodeHash,store.State.EnrollmentCodeHash);
        Assert.Equal(new[]{"/api/agent/heartbeat"},handler.Paths);
        await using var scope=context.Server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();Assert.Equal(1,await db.DeviceAudit.CountAsync(row=>row.Action=="agent.registered"));Assert.Equal(1,await db.DeviceCredentials.CountAsync());
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task RestoreDoesNotMoveSavedRegistrationToDifferentServer()
    {
        await using var context=await AgentTestContext.CreateAsync();var code=await context.AddAsync();var handler=new Requests{InnerHandler=context.Server.Server.CreateHandler()};using var http=new HttpClient(handler);
        var store=new MemoryAgentState();var enrollment=new AgentEnrollment(store,new(http));Assert.True((await enrollment.EnrollAsync("https://localhost",code.Code,false,default)).Succeeded);var before=store.State!;handler.Paths.Clear();
        await Assert.ThrowsAsync<InvalidOperationException>(()=>enrollment.EnrollAsync("https://another-server.invalid","",false,default));Assert.Empty(handler.Paths);Assert.Equal(before.Token,store.State!.Token);Assert.Equal(before.ServerAddress,store.State.ServerAddress);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task RevokedRegistrationCannotBeSilentlyReplacedDuringRepair()
    {
        await using var context=await AgentTestContext.CreateAsync();var code=await context.AddAsync();var handler=new Requests{InnerHandler=context.Server.Server.CreateHandler()};using var http=new HttpClient(handler);
        var store=new MemoryAgentState();var enrollment=new AgentEnrollment(store,new(http));Assert.True((await enrollment.EnrollAsync("https://localhost",code.Code,false,default)).Succeeded);var before=store.State!;
        Assert.True((await context.Admin.PostAsync($"/api/devices/{before.DeviceId}/revoke",null)).IsSuccessStatusCode);handler.Paths.Clear();
        await Assert.ThrowsAsync<InvalidOperationException>(()=>enrollment.EnrollAsync("https://localhost","",false,default));Assert.Equal(new[]{"/api/agent/heartbeat"},handler.Paths);Assert.Equal(before.Token,store.State!.Token);Assert.Equal(before.DeviceId,store.State.DeviceId);
    }
    private sealed class Requests:DelegatingHandler
    {
        public List<string> Paths{get;}=[];
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token){Paths.Add(request.RequestUri!.AbsolutePath);return base.SendAsync(request,token);}
    }
}
