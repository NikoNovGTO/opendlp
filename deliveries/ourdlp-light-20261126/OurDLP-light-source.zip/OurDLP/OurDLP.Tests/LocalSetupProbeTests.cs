using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Server.Data;
using Xunit;
namespace OurDLP.Tests;

public sealed class LocalSetupProbeTests
{
    [Fact] public async Task MissingConfigurationDoesNotAttemptToCreateAdministrator()
    {
        await using var server=new DatabaseTestServer("");var report=await LocalSetupProbe.CheckAsync(server.Services,default);
        Assert.Equal("not-configured",report.DatabaseStatus);Assert.False(report.AdministratorExists);
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task ProbeDoesNotApplyPendingMigrations()
    {
        await using var database=await PostgresTestDatabase.CreateAsync();await using var server=new DatabaseTestServer(database.ConnectionString);
        var report=await LocalSetupProbe.CheckAsync(server.Services,default);Assert.Equal("migration-required",report.DatabaseStatus);
        await using var scope=server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();Assert.Empty(await db.Database.GetAppliedMigrationsAsync());
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task ReadyDatabaseWithoutAdministratorIsReportedWithoutCreatingOne()
    {
        await using var database=await PostgresTestDatabase.CreateAsync();await using var server=new DatabaseTestServer(database.ConnectionString);Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        var report=await LocalSetupProbe.CheckAsync(server.Services,default);Assert.Equal("ready",report.DatabaseStatus);Assert.False(report.AdministratorExists);
        await using var scope=server.Services.CreateAsyncScope();Assert.Empty(await scope.ServiceProvider.GetRequiredService<OurDlpDbContext>().Users.ToListAsync());
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task ExistingAdministratorAndPasswordRemainUntouchedByProbe()
    {
        await using var context=await AgentTestContext.CreateAsync();await using var scope=context.Server.Services.CreateAsyncScope();var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();var before=await db.Users.AsNoTracking().SingleAsync();var audits=await db.AuthenticationAudit.CountAsync();
        var report=await LocalSetupProbe.CheckAsync(context.Server.Services,default);Assert.Equal("ready",report.DatabaseStatus);Assert.True(report.AdministratorExists);
        var after=await db.Users.AsNoTracking().SingleAsync();Assert.Equal(before.PasswordHash,after.PasswordHash);Assert.Equal(before.SecurityStamp,after.SecurityStamp);Assert.Equal(audits,await db.AuthenticationAudit.CountAsync());
    }
    [PostgresFact][Trait("Category","Postgres")]
    public async Task UnavailableDatabaseDoesNotLeakConnectionDataOrReportReady()
    {
        await using var database=await PostgresTestDatabase.CreateAsync();await using var server=new DatabaseTestServer(database.WrongPasswordConnectionString);
        var report=await LocalSetupProbe.CheckAsync(server.Services,default);Assert.Equal("unavailable",report.DatabaseStatus);Assert.False(report.AdministratorExists);Assert.DoesNotContain("Password",System.Text.Json.JsonSerializer.Serialize(report));
    }
}
