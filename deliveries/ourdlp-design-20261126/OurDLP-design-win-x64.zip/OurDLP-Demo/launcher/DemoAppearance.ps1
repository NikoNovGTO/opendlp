﻿function New-DemoShell {
    $form=[Windows.Forms.Form]::new();$form.Text='OurDLP — Запуск и демонстрация'
    $form.Size=[Drawing.Size]::new(1050,800);$form.MinimumSize=[Drawing.Size]::new(840,620)
    $form.StartPosition='CenterScreen';$form.Font=[Drawing.Font]::new('Segoe UI',10)
    $form.AutoScaleMode='Dpi';$form.BackColor=[Drawing.ColorTranslator]::FromHtml('#F2F5F5')
    $iconPath=Join-Path $script:BundleRoot 'assets/OurDLP.ico'
    if(Test-Path -LiteralPath $iconPath){$form.Icon=[Drawing.Icon]::new($iconPath)}
    $brand=[Windows.Forms.Panel]::new();$brand.Dock='Left';$brand.Width=200;$brand.BackColor=[Drawing.ColorTranslator]::FromHtml('#0D292D')
    $name=[Windows.Forms.Label]::new();$name.Text='OurDLP';$name.ForeColor=[Drawing.Color]::White;$name.Font=[Drawing.Font]::new('Segoe UI',25,[Drawing.FontStyle]::Bold);$name.SetBounds(22,36,170,52)
    $tagline=[Windows.Forms.Label]::new();$tagline.Text="Сложная защита.`r`nПростое управление.";$tagline.ForeColor=[Drawing.ColorTranslator]::FromHtml('#BDCFD1');$tagline.SetBounds(24,96,155,56)
    $mode=[Windows.Forms.Label]::new();$mode.Text="РЕЖИМ НАБЛЮДЕНИЯ`r`n`r`nКопирование и вставка разрешены.`r`n`r`nOurDLP 0.9.0";$mode.ForeColor=[Drawing.ColorTranslator]::FromHtml('#9AB8BB');$mode.Dock='Bottom';$mode.Height=158;$mode.Padding=[Windows.Forms.Padding]::new(24,12,18,0)
    $brand.Controls.AddRange(@($name,$tagline,$mode))
    $panel=[Windows.Forms.FlowLayoutPanel]::new();$panel.Dock='Fill';$panel.Padding=[Windows.Forms.Padding]::new(28,24,28,24)
    $panel.FlowDirection='TopDown';$panel.WrapContents=$false;$panel.AutoScroll=$true;$panel.ForeColor=[Drawing.ColorTranslator]::FromHtml('#172E32')
    $form.Controls.Add($panel);$form.Controls.Add($brand)
    $panel.Add_SizeChanged({param($sender,$eventArgs) Resize-DemoActions $sender})
    return @{Form=$form;Actions=$panel}
}

function Resize-DemoActions($Panel){
    $width=[Math]::Max(360,$Panel.ClientSize.Width-$Panel.Padding.Horizontal-24)
    foreach($control in $Panel.Controls){if($control -is [Windows.Forms.Label]){$control.MaximumSize=[Drawing.Size]::new($width,0)};$control.Width=$width}
}

function Set-DemoButtonAppearance($Button,[bool]$Primary){
    $Button.FlatStyle='Flat';$Button.FlatAppearance.BorderSize=1
    $Button.FlatAppearance.BorderColor=[Drawing.ColorTranslator]::FromHtml('#DCE5E5')
    $Button.BackColor=[Drawing.Color]::White;$Button.ForeColor=[Drawing.ColorTranslator]::FromHtml('#172E32')
    $Button.FlatAppearance.MouseOverBackColor=[Drawing.ColorTranslator]::FromHtml('#E7F4F1')
    $Button.TextAlign='MiddleLeft';$Button.Padding=[Windows.Forms.Padding]::new(14,0,0,0);$Button.Cursor=[Windows.Forms.Cursors]::Hand
    if($Primary){
        $Button.BackColor=[Drawing.ColorTranslator]::FromHtml('#006D68');$Button.ForeColor=[Drawing.Color]::White
        $Button.FlatAppearance.BorderColor=$Button.BackColor
        $Button.FlatAppearance.MouseOverBackColor=[Drawing.ColorTranslator]::FromHtml('#005651')
    }
}

function Fit-DemoWindow($Form){
    $area=[Windows.Forms.Screen]::FromControl($Form).WorkingArea
    $width=[Math]::Max(320,$area.Width-16);$height=[Math]::Max(320,$area.Height-16)
    $Form.MinimumSize=[Drawing.Size]::new([Math]::Min($Form.MinimumSize.Width,$width),[Math]::Min($Form.MinimumSize.Height,$height))
    $Form.Size=[Drawing.Size]::new([Math]::Min($Form.Width,$width),[Math]::Min($Form.Height,$height))
    $Form.Left=$area.Left+[int](($area.Width-$Form.Width)/2);$Form.Top=$area.Top+[int](($area.Height-$Form.Height)/2)
}
