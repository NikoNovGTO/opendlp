[CmdletBinding()]
param(
    [string]$HostName = '127.0.0.1',
    [ValidateRange(1,65535)][int]$Port = 5432,
    [string]$DatabaseName = 'ourdlp',
    [string]$Username = 'ourdlp_app',
    [Security.SecureString]$Password
)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
Write-Host 'This saves access to an existing database and applies OurDLP migrations. It does not reset database passwords.'
if ($null -eq $Password) { $Password = Read-Host "Password for database user $Username (saved only in your local development configuration)" -AsSecureString }
try {
    $plain = ConvertFrom-OurDlpSecureString $Password
    Save-OurDlpConnection $HostName $Port $DatabaseName $Username $plain
}
finally { $plain = $null; $Password = $null }
Invoke-OurDlpMigration
