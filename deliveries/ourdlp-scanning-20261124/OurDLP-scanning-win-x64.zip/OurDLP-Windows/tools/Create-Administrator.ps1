[CmdletBinding()]
param(
    [string]$UserName = 'admin',
    [Security.SecureString]$Password
)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
Write-Host 'Create the FIRST OurDLP administrator. This password is separate from PostgreSQL and Windows.'
Write-Host 'Use 12-128 characters, including uppercase and lowercase Latin letters and a digit.'
Invoke-OurDlpMigration
if ($null -eq $Password) {
    $Password = Read-Host "New OurDLP password for $UserName" -AsSecureString
    $confirmation = Read-Host 'Repeat the OurDLP password' -AsSecureString
    try {
        $plain = ConvertFrom-OurDlpSecureString $Password
        $repeated = ConvertFrom-OurDlpSecureString $confirmation
        if (-not [string]::Equals($plain,$repeated,[StringComparison]::Ordinal)) { $plain=$null; $Password=$null; throw 'Passwords do not match.' }
    }
    finally { $repeated=$null; $confirmation=$null }
} else {
    $plain=ConvertFrom-OurDlpSecureString $Password
}
$root=Split-Path $PSScriptRoot -Parent
$exe=Join-Path $root 'Server/OurDLP.Server.exe'
$project=Join-Path $root 'OurDLP.Server/OurDLP.Server.csproj'
$previousEnvironment=$env:ASPNETCORE_ENVIRONMENT
$previousEncoding=$OutputEncoding
try {
    $env:ASPNETCORE_ENVIRONMENT='Development'
    $OutputEncoding=[Text.UTF8Encoding]::new($false)
    $payload=@{ userName=$UserName; password=$plain } | ConvertTo-Json -Compress
    if (Test-Path -LiteralPath $exe) {
        $payload | & $exe --create-administrator
    } elseif (Test-Path -LiteralPath $project) {
        $payload | & dotnet run --project $project --configuration Release --no-launch-profile -- --create-administrator
    } else { throw 'OurDLP.Server executable or source project was not found.' }
    if ($LASTEXITCODE -eq 2) { throw 'An administrator already exists. Its password was NOT changed. Sign in with the existing account.' }
    if ($LASTEXITCODE -ne 0) { throw 'Administrator creation failed. See the validation message above.' }
    Write-Host "Done. Start Server + Desktop and sign in as $UserName."
}
finally {
    $plain=$null; $payload=$null; $Password=$null
    $env:ASPNETCORE_ENVIRONMENT=$previousEnvironment
    $OutputEncoding=$previousEncoding
}
