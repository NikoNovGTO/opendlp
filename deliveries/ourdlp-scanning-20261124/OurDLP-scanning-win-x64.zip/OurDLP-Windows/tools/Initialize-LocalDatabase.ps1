[CmdletBinding()]
param(
    [string]$PsqlPath = '',
    [ValidateRange(1,65535)][int]$Port = 5432,
    [string]$AdminUser = 'postgres',
    [Security.SecureString]$AdminPassword
)
. (Join-Path $PSScriptRoot 'DatabaseTools.ps1')
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET SDK 10 is required for local setup.' }

if (Test-OurDlpConfiguration) {
    Write-Host 'Existing OurDLP configuration found. Applying pending migrations only.'
    Invoke-OurDlpMigration
    return
}
$psql = Find-OurDlpPsql $PsqlPath
if ($null -eq $AdminPassword) {
    $AdminPassword = Read-Host "Password of PostgreSQL administrator $AdminUser (not saved)" -AsSecureString
}
$previousPassword = $env:PGPASSWORD
try {
    $env:PGPASSWORD = ConvertFrom-OurDlpSecureString $AdminPassword
    $arguments = @('-X', '-w', '-q', '-t', '-A', '-h', '127.0.0.1', '-p', "$Port", '-U', $AdminUser, '-d', 'postgres', '-v', 'ON_ERROR_STOP=1')
    $query = "SELECT CASE WHEN EXISTS(SELECT FROM pg_roles WHERE rolname='ourdlp_app') OR EXISTS(SELECT FROM pg_database WHERE datname='ourdlp') THEN 1 ELSE 0 END;"
    $existing = $query | & $psql @arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Cannot connect to PostgreSQL. Check service, port, administrator and password.' }
    if (($existing -join '').Trim() -ne '0') {
        throw 'ourdlp database or ourdlp_app role already exists. Nothing was replaced. Use Configure-ExistingDatabase.ps1.'
    }
    $random = [Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 32
    try { $random.GetBytes($bytes) } finally { $random.Dispose() }
    $appPassword = [Convert]::ToBase64String($bytes)
    # Identifiers are fixed; the generated password contains no SQL quotes.
    $sql = "CREATE ROLE ourdlp_app WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD '$appPassword';`nCREATE DATABASE ourdlp OWNER ourdlp_app;"
    $result = $sql | & $psql @arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Database creation failed. No existing database or account was overwritten.' }
    Save-OurDlpConnection '127.0.0.1' $Port 'ourdlp' 'ourdlp_app' $appPassword
    Write-Host 'Created ourdlp database and an application account without PostgreSQL administrator privileges.'
}
finally {
    $env:PGPASSWORD = $previousPassword
    $appPassword = $null
    $sql = $null
    $AdminPassword = $null
}
Invoke-OurDlpMigration
Write-Host 'Database is ready. Start Server and Desktop, then check the connection.'
