Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:OurDlpSecretsId = 'OurDLP.Server.LocalDevelopment'

function Get-OurDlpSecretsFile {
    if (-not [string]::IsNullOrEmpty($env:APPDATA)) {
        return Join-Path $env:APPDATA "Microsoft/UserSecrets/$script:OurDlpSecretsId/secrets.json"
    }
    return Join-Path ([Environment]::GetFolderPath('UserProfile')) ".microsoft/usersecrets/$script:OurDlpSecretsId/secrets.json"
}

function Test-OurDlpConfiguration {
    $file = Get-OurDlpSecretsFile
    if (-not (Test-Path -LiteralPath $file)) { return $false }
    $saved = Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
    $property = $saved.PSObject.Properties['ConnectionStrings:OurDlp']
    return ($null -ne $property -and -not [string]::IsNullOrWhiteSpace([string]$property.Value))
}

function ConvertFrom-OurDlpSecureString([Security.SecureString]$Value) {
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

function Quote-OurDlpConnectionValue([string]$Value) {
    return '"' + $Value.Replace('"', '""') + '"'
}

function Save-OurDlpConnection([string]$HostName, [int]$Port, [string]$DatabaseName,
    [string]$Username, [string]$Password) {
    $connection = 'Host=' + (Quote-OurDlpConnectionValue $HostName) + ';Port=' + $Port +
        ';Database=' + (Quote-OurDlpConnectionValue $DatabaseName) +
        ';Username=' + (Quote-OurDlpConnectionValue $Username) +
        ';Password=' + (Quote-OurDlpConnectionValue $Password) + ';Timeout=5'
    $json = @{ 'ConnectionStrings:OurDlp' = $connection } | ConvertTo-Json -Compress
    $previousEncoding = $OutputEncoding
    try {
        $OutputEncoding = [Text.UTF8Encoding]::new($false)
        # Read JSON from stdin so the password never becomes a command-line argument.
        $json | & dotnet user-secrets set --id $script:OurDlpSecretsId
        if ($LASTEXITCODE -ne 0) { throw 'Could not save local database configuration.' }
    }
    finally {
        $OutputEncoding = $previousEncoding
        $connection = $null
        $json = $null
    }
}

function Invoke-OurDlpMigration {
    $root = Split-Path $PSScriptRoot -Parent
    $exe = Join-Path $root 'Server/OurDLP.Server.exe'
    $project = Join-Path $root 'OurDLP.Server/OurDLP.Server.csproj'
    $previousEnvironment = $env:ASPNETCORE_ENVIRONMENT
    try {
        $env:ASPNETCORE_ENVIRONMENT = 'Development'
        if (Test-Path -LiteralPath $exe) {
            & $exe --migrate-database
        } elseif (Test-Path -LiteralPath $project) {
            & dotnet run --project $project --configuration Release --no-launch-profile -- --migrate-database
        } else {
            throw 'Server executable or source project was not found beside tools.'
        }
        if ($LASTEXITCODE -ne 0) { throw 'Migration failed. Check PostgreSQL and local configuration.' }
    }
    finally { $env:ASPNETCORE_ENVIRONMENT = $previousEnvironment }
}

function Find-OurDlpPsql([string]$ExplicitPath) {
    if ($ExplicitPath) {
        if (-not (Test-Path -LiteralPath $ExplicitPath)) { throw 'Specified psql executable was not found.' }
        return $ExplicitPath
    }
    $command = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($null -ne $command) { return $command.Source }
    if ($env:ProgramFiles) {
        $base = Join-Path $env:ProgramFiles 'PostgreSQL'
        if (Test-Path -LiteralPath $base) {
            $versions = Get-ChildItem -LiteralPath $base -Directory | Sort-Object {
                try { [Version]($_.Name + '.0') } catch { [Version]'0.0' }
            } -Descending
            foreach ($version in $versions) {
                $candidate = Join-Path $version.FullName 'bin/psql.exe'
                if (Test-Path -LiteralPath $candidate) { return $candidate }
            }
        }
    }
    throw 'PostgreSQL client (psql.exe) was not found. Check whether PostgreSQL is installed.'
}
