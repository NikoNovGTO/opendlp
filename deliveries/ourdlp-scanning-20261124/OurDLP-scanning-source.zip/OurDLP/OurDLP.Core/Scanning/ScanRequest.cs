namespace OurDLP.Core.Scanning;

public sealed record ScanRule(Guid Id, string Name, string Pattern);
public sealed record ScanRequest(string RootPath, IReadOnlyList<ScanRule> Rules,
    IReadOnlyList<string> ExcludedDirectories, ScanLimits Limits);

public sealed record ScanLimits
{
    public long MaxFileBytes { get; init; } = 5 * 1024 * 1024;
    public int MaxFiles { get; init; } = 5_000;
    public int MaxEntries { get; init; } = 20_000;
    public int MaxFindings { get; init; } = 1_000;
    public int MaxIssues { get; init; } = 100;
    public int MaxMatchesPerFile { get; init; } = 1_000;
    public TimeSpan MaxDuration { get; init; } = TimeSpan.FromMinutes(2);
}
