namespace OurDLP.Core.Scanning;

public enum ScanCompletion { Completed, Cancelled, LimitReached, Failed }
public sealed record ScanFinding(Guid Id, string FilePath, string RelativePath,
    Guid RuleId, string RuleName, int Matches, bool CountLimited, DateTimeOffset DetectedAtUtc);
public sealed record ScanIssue(string Path, string Code, string Message);
public sealed record ScanProgress(int FilesScanned, int FilesSkipped, int Findings, string CurrentPath);

public sealed record ScanReport
{
    public int SchemaVersion { get; init; } = 1;
    public Guid Id { get; init; } = Guid.NewGuid();
    public DateTimeOffset StartedAtUtc { get; init; }
    public DateTimeOffset CompletedAtUtc { get; init; }
    public string RootPath { get; init; } = string.Empty;
    public IReadOnlyList<ScanRule> Rules { get; init; } = [];
    public IReadOnlyList<string> ExcludedDirectories { get; init; } = [];
    public ScanLimits Limits { get; init; } = new();
    public ScanCompletion Completion { get; init; }
    public string Message { get; init; } = string.Empty;
    public int EntriesVisited { get; init; }
    public int FilesScanned { get; init; }
    public int FilesSkipped { get; init; }
    public int IssueCount { get; init; }
    public IReadOnlyList<ScanFinding> Findings { get; init; } = [];
    public IReadOnlyList<ScanIssue> Issues { get; init; } = [];
}

public interface IFileScanner
{
    Task<ScanReport> ScanAsync(ScanRequest request, IProgress<ScanProgress>? progress, CancellationToken token);
}
