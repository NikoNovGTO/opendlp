namespace OurDLP.Core.Scanning;

internal static class ScanPaths
{
    public static StringComparer Comparison => OperatingSystem.IsWindows() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;
    private static StringComparison TextComparison => OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
    public static bool IsInside(string root, string path)
    {
        var relative = Path.GetRelativePath(root, path);
        return !Path.IsPathRooted(relative) && relative != ".." && !relative.StartsWith(".." + Path.DirectorySeparatorChar, TextComparison);
    }
    public static bool IsExcluded(ScanRequest request, string path)
    {
        var relative = Path.GetRelativePath(request.RootPath, path);
        return request.ExcludedDirectories.Any(excluded => relative.Equals(excluded, TextComparison)
            || relative.StartsWith(excluded + Path.DirectorySeparatorChar, TextComparison));
    }
    public static bool IsTextFile(string path) => Path.GetExtension(path).ToLowerInvariant() is ".txt" or ".csv" or ".log";
}
