using System.Text.RegularExpressions;

namespace OurDLP.Core.Scanning;

internal sealed record PreparedRule(ScanRule Definition, Regex Expression);
internal sealed record PreparedScan(ScanRequest Request, IReadOnlyList<PreparedRule> Rules);

internal static class ScanPreparation
{
    public static PreparedScan Prepare(ScanRequest request)
    {
        var limits = request.Limits;
        if (limits.MaxFileBytes is < 1 or > 20 * 1024 * 1024 || limits.MaxFiles is < 1 or > 5_000
            || limits.MaxEntries is < 1 or > 20_000 || limits.MaxFindings is < 1 or > 1_000
            || limits.MaxIssues is < 1 or > 100 || limits.MaxMatchesPerFile is < 1 or > 1_000
            || limits.MaxDuration < TimeSpan.FromSeconds(1) || limits.MaxDuration > TimeSpan.FromMinutes(2))
            throw new ArgumentException("Пределы проверки превышают допустимые значения.");
        if (string.IsNullOrWhiteSpace(request.RootPath) || !Path.IsPathFullyQualified(request.RootPath))
            throw new ArgumentException("Выберите полный путь к тестовой папке.");
        var root = Path.GetFullPath(request.RootPath);
        if (!Directory.Exists(root)) throw new ArgumentException("Выбранная папка не существует или недоступна.");
        for (var directory = new DirectoryInfo(root); directory is not null; directory = directory.Parent)
            if ((directory.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new ArgumentException("Для проверки выберите обычную папку без ссылок или junction в пути.");
        if (request.Rules.Count is < 1 or > 20 || request.Rules.Select(rule => rule.Id).Distinct().Count() != request.Rules.Count)
            throw new ArgumentException("Нужно от 1 до 20 правил с уникальными идентификаторами.");
        var rules = new List<PreparedRule>();
        foreach (var rule in request.Rules)
        {
            if (rule.Id == Guid.Empty || string.IsNullOrWhiteSpace(rule.Name) || rule.Name.Length > 100
                || string.IsNullOrWhiteSpace(rule.Pattern) || rule.Pattern.Length > 2_000)
                throw new ArgumentException("Укажите название правила до 100 символов и выражение до 2000 символов.");
            try { rules.Add(new(rule, new Regex(rule.Pattern, RegexOptions.CultureInvariant | RegexOptions.Multiline, TimeSpan.FromMilliseconds(100)))); }
            catch (ArgumentException) { throw new ArgumentException("Некорректное регулярное выражение. Исправьте правило до запуска проверки."); }
        }
        if (request.ExcludedDirectories.Count > 100) throw new ArgumentException("Допускается не более 100 исключений.");
        var excluded = request.ExcludedDirectories.Select(NormalizeExclusion).Distinct(ScanPaths.Comparison).ToArray();
        return new(request with { RootPath = root, Rules = rules.Select(row => row.Definition).ToArray(), ExcludedDirectories = excluded }, rules);
    }

    private static string NormalizeExclusion(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || Path.IsPathRooted(path) || path.Contains(':'))
            throw new ArgumentException("Исключения должны быть путями папок относительно выбранного каталога.");
        var parts = path.Replace('\\', '/').Trim('/').Split('/');
        if (parts.Any(part => part is ".." or "." or "")) throw new ArgumentException("В исключениях нельзя использовать переходы .. или пустые части пути.");
        return Path.Combine(parts);
    }
}
