using System.Diagnostics;

namespace OurDLP.Core.Scanning;

internal sealed class ScanSession(PreparedScan prepared, IProgress<ScanProgress>? progress, CancellationToken token)
{
    private readonly Stopwatch _duration = Stopwatch.StartNew();
    private readonly Stopwatch _notification = Stopwatch.StartNew();
    private readonly DateTimeOffset _started = DateTimeOffset.UtcNow;
    public ScanRequest Request => prepared.Request;
    public List<ScanFinding> Findings { get; } = [];
    public List<ScanIssue> Issues { get; } = [];
    public int EntriesVisited { get; set; }
    public int FilesScanned { get; set; }
    public int FilesSkipped { get; set; }
    private int _issues;
    private bool _hasNotified;
    public ScanCompletion Completion { get; private set; } = ScanCompletion.Completed;
    public string Message { get; private set; } = "Проверка завершена.";
    public bool CanContinue()
    {
        if (token.IsCancellationRequested) Stop(ScanCompletion.Cancelled, "Проверка отменена. Частичные результаты сохранены.");
        else if (_duration.Elapsed >= Request.Limits.MaxDuration) Stop(ScanCompletion.LimitReached, "Достигнут предел времени проверки.");
        return Completion == ScanCompletion.Completed;
    }
    public void Stop(ScanCompletion completion, string message) { Completion = completion; Message = message; }
    public void Issue(string path, string code, string message)
    {
        _issues++;
        if (Issues.Count < Request.Limits.MaxIssues) Issues.Add(new(path, code, message));
    }
    public void Notify(string path, bool force = false)
    {
        if (force || !_hasNotified || _notification.ElapsedMilliseconds >= 100)
        { progress?.Report(new(FilesScanned, FilesSkipped, Findings.Count, path)); _hasNotified = true; _notification.Restart(); }
    }
    public ScanReport Finish()
    {
        Notify(string.Empty, true);
        return new()
        {
            StartedAtUtc = _started, CompletedAtUtc = DateTimeOffset.UtcNow, RootPath = Request.RootPath,
            Rules = Request.Rules, ExcludedDirectories = Request.ExcludedDirectories, Limits = Request.Limits,
            Completion = Completion, Message = Message, EntriesVisited = EntriesVisited,
            FilesScanned = FilesScanned, FilesSkipped = FilesSkipped, IssueCount = _issues,
            Findings = Findings.ToArray(), Issues = Issues.ToArray()
        };
    }
}
