using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace OurDLP.Agent;

public sealed class AgentWorker(IAgentStateStore store, AgentProtocolClient client,
    ILogger<AgentWorker> logger, IHostApplicationLifetime lifetime) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            var state = await store.ReadAsync(stoppingToken);
            if (state?.DeviceId is null) { logger.LogError("Агент не зарегистрирован. Выполните локальную установку."); lifetime.StopApplication(); return; }
            bool? online = null;
            while (!stoppingToken.IsCancellationRequested)
            {
                var result = await client.HeartbeatAsync(state, stoppingToken);
                if (result.AccessDenied)
                { logger.LogError("Доступ агента отозван или учётные данные недействительны. Нужна перерегистрация."); lifetime.StopApplication(); return; }
                var available = result.Succeeded && result.Response!.DeviceId == state.DeviceId;
                if (available != online)
                {
                    if (available)
                    {
                        state = state.WithServiceContact();
                        await store.SaveAsync(state, stoppingToken);
                        logger.LogInformation("Связь с сервером установлена.");
                    }
                    else logger.LogWarning("Нет связи с сервером. Настройки сохранены, повтор через 30 секунд.");
                }
                online = available;
                await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
        catch (Exception exception)
        {
            logger.LogError("Агент не запущен ({Type}). Проверьте защищённое состояние и установку.", exception.GetType().Name);
            lifetime.StopApplication();
        }
    }
}
