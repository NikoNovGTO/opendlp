namespace OurDLP.Agent;

public interface IAgentStateStore
{
    Task<AgentState?> ReadAsync(CancellationToken token);
    Task SaveAsync(AgentState state, CancellationToken token);
}
