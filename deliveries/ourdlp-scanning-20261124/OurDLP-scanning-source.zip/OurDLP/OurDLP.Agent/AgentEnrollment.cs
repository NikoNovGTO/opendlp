using System.Security.Cryptography;

namespace OurDLP.Agent;

public sealed class AgentEnrollment(IAgentStateStore store, AgentProtocolClient client)
{
    public async Task<AgentCallResult> EnrollAsync(string address, string code, bool replaceExisting, CancellationToken token)
    {
        address = AgentAddress.Normalize(address);
        var state = await store.ReadAsync(token);
        if (state is not null && !replaceExisting)
        {
            if (state.ServerAddress != address) throw new InvalidOperationException("Агент уже настроен на другой сервер. Нужна явная перерегистрация.");
            var previous = await client.HeartbeatAsync(state, token);
            if (previous.Succeeded)
            {
                await store.SaveAsync(state.WithDevice(previous.Response!.DeviceId), token);
                return previous;
            }
            if (state.DeviceId is not null) throw new InvalidOperationException("Агент уже зарегистрирован. Для нового кода используйте явную перерегистрацию.");
        }
        if (state is null || replaceExisting)
        {
            var secret = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
            state = new AgentState { ServerAddress = address, Token = secret };
            // Persist the new credential before registration so a lost response is recoverable.
            await store.SaveAsync(state, token);
        }
        var result = await client.EnrollAsync(state, code, token);
        if (result.Succeeded) await store.SaveAsync(state.WithDevice(result.Response!.DeviceId), token);
        return result;
    }
}
