namespace OurDLP.Agent;

public static class AgentAddress
{
    public static string Normalize(string address)
    {
        if (!Uri.TryCreate(address.Trim(), UriKind.Absolute, out var uri) || uri.Scheme != "https" || uri.Host.Length == 0
            || uri.AbsolutePath != "/" || uri.UserInfo.Length != 0 || uri.Query.Length != 0 || uri.Fragment.Length != 0)
            throw new InvalidOperationException("Укажите HTTPS-адрес сервера без пути, логина и параметров.");
        return uri.GetLeftPart(UriPartial.Authority);
    }
}
