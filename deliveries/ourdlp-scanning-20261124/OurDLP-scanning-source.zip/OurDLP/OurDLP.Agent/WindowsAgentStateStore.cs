using System.Runtime.Versioning;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;

namespace OurDLP.Agent;

[SupportedOSPlatform("windows")]
public sealed class WindowsAgentStateStore : IAgentStateStore
{
    private readonly string _directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OurDLP", "Agent");
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("OurDLP.Agent.State.v1");
    public async Task<AgentState?> ReadAsync(CancellationToken token)
    {
        CheckPermissions();
        var path = Path.Combine(_directory, "state.bin");
        if (!File.Exists(path)) return null;
        var encrypted = await File.ReadAllBytesAsync(path, token);
        var plain = ProtectedData.Unprotect(encrypted, Entropy, DataProtectionScope.LocalMachine);
        try
        {
            var state = JsonSerializer.Deserialize<AgentState>(plain);
            if (state is null || state.FormatVersion != 1 || state.Token.Length != 43) throw new InvalidDataException("Некорректное состояние агента.");
            _ = AgentAddress.Normalize(state.ServerAddress);
            return state;
        }
        finally { CryptographicOperations.ZeroMemory(plain); }
    }
    public async Task SaveAsync(AgentState state, CancellationToken token)
    {
        CheckPermissions();
        var plain = JsonSerializer.SerializeToUtf8Bytes(state);
        byte[] encrypted;
        try { encrypted = ProtectedData.Protect(plain, Entropy, DataProtectionScope.LocalMachine); }
        finally { CryptographicOperations.ZeroMemory(plain); }
        var temporary = Path.Combine(_directory, Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            await File.WriteAllBytesAsync(temporary, encrypted, token);
            File.Move(temporary, Path.Combine(_directory, "state.bin"), true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    private void CheckPermissions()
    {
        if (!Directory.Exists(_directory)) throw new InvalidOperationException("Сначала выполните Install-Agent.ps1 от имени администратора.");
        var allowed = new HashSet<string>
        {
            new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null).Value,
            new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null).Value,
            ((SecurityIdentifier)new NTAccount("NT SERVICE", "OurDLP.Agent").Translate(typeof(SecurityIdentifier))).Value
        };
        foreach (var directory in new[] { Directory.GetParent(_directory)!.FullName, _directory })
        {
            if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0) throw new UnauthorizedAccessException("Недопустимая ссылка в каталоге агента.");
            var security = new DirectoryInfo(directory).GetAccessControl(AccessControlSections.Access | AccessControlSections.Owner);
            if (!allowed.Contains(security.GetOwner(typeof(SecurityIdentifier))?.Value ?? string.Empty)) throw new UnauthorizedAccessException("Небезопасный владелец каталога агента.");
            foreach (FileSystemAccessRule rule in security.GetAccessRules(true, true, typeof(SecurityIdentifier)))
                if (rule.AccessControlType == AccessControlType.Allow && !allowed.Contains(rule.IdentityReference.Value))
                    throw new UnauthorizedAccessException("Каталог агента доступен посторонним учётным записям.");
        }
    }
}
