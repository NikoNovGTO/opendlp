namespace OurDLP.Contracts;

public sealed record AdministratorResponse(Guid Id, string UserName, DateTimeOffset ExpiresAtUtc);
