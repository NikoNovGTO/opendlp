namespace OurDLP.Contracts;

public sealed class AgentEnrollmentRequest
{
    public string Code { get; init; } = string.Empty;
    public string Token { get; init; } = string.Empty;
    public string HostName { get; init; } = string.Empty;
    public string OperatingSystem { get; init; } = string.Empty;
    public string AgentVersion { get; init; } = string.Empty;
}
public sealed record AgentHeartbeatRequest(string HostName, string OperatingSystem, string AgentVersion);
public sealed record AgentAcknowledgement(Guid DeviceId, DateTimeOffset ServerTimeUtc);
