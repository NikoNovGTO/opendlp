namespace OurDLP.Contracts;

public sealed record AuthMessage(string Message);
