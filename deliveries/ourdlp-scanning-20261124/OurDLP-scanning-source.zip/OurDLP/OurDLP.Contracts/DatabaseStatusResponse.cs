namespace OurDLP.Contracts;

public sealed record DatabaseStatusResponse(string Status, string Message);
