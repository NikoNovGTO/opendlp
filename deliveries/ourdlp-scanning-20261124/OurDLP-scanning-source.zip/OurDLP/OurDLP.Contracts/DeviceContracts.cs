namespace OurDLP.Contracts;

public sealed record DeviceResponse(Guid Id, string Name, string? HostName, string? OperatingSystem,
    string? AgentVersion, string? IpAddress, string Status, DateTimeOffset? LastSeenAtUtc);
public sealed record DeviceListResponse(IReadOnlyList<DeviceResponse> Devices);
public sealed record EnrollmentResponse(Guid DeviceId, string Code, DateTimeOffset ExpiresAtUtc);
public sealed record DeviceOperationResponse(string Message);
public sealed class CreateDeviceRequest { public string Name { get; init; } = string.Empty; }
