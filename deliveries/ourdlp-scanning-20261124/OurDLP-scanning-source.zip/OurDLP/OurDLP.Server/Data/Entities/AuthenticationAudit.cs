namespace OurDLP.Server.Data.Entities;

public sealed class AuthenticationAudit
{
    public Guid Id { get; set; }
    public DateTimeOffset TimeUtc { get; set; }
    public Guid? UserId { get; set; }
    public string Action { get; set; } = string.Empty;
}
