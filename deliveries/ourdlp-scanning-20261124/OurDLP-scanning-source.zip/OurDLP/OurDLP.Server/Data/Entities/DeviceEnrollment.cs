namespace OurDLP.Server.Data.Entities;

public sealed class DeviceEnrollment
{
    public Guid DeviceId { get; set; }
    public string CodeHash { get; set; } = string.Empty;
    public DateTimeOffset ExpiresAtUtc { get; set; }
    public DateTimeOffset? UsedAtUtc { get; set; }
}
