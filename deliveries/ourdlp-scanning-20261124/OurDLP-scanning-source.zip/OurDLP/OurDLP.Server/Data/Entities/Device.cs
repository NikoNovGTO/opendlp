namespace OurDLP.Server.Data.Entities;

public sealed class Device
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsAccessRevoked { get; set; }
    public string? HostName { get; set; }
    public string? IpAddress { get; set; }
    public DateTimeOffset? RegisteredAtUtc { get; set; }
    public string? OperatingSystem { get; set; }
    public string? AgentVersion { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; }
    public DateTimeOffset? LastSeenAtUtc { get; set; }
}
