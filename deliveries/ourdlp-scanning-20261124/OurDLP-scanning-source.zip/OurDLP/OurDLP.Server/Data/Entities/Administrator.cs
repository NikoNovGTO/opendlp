using Microsoft.AspNetCore.Identity;

namespace OurDLP.Server.Data.Entities;

public sealed class Administrator : IdentityUser<Guid>;
