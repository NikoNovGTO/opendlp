namespace OurDLP.Server.Data.Entities;

public sealed class DeviceCredential
{
    public Guid DeviceId { get; set; }
    public string TokenHash { get; set; } = string.Empty;
    public DateTimeOffset? RevokedAtUtc { get; set; }
}
