namespace OurDLP.Server.Data.Entities;

public sealed class DeviceAudit
{
    public Guid Id { get; set; }
    public Guid DeviceId { get; set; }
    public Guid? AdministratorId { get; set; }
    public string Action { get; set; } = string.Empty;
    public DateTimeOffset TimeUtc { get; set; }
}
