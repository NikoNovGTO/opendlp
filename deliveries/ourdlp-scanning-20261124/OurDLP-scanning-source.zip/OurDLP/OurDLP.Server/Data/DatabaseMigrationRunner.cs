using Microsoft.EntityFrameworkCore;

namespace OurDLP.Server.Data;

public static class DatabaseMigrationRunner
{
    public static async Task<int> RunAsync(IServiceProvider services)
    {
        var settings = services.GetRequiredService<DatabaseSettings>();
        if (!settings.IsConfigured)
        {
            Console.Error.WriteLine("PostgreSQL не настроен. Сначала задайте ConnectionStrings:OurDlp локально.");
            return 1;
        }
        try
        {
            await using var scope = services.CreateAsyncScope();
            var factory = scope.ServiceProvider.GetRequiredService<IDbContextFactory<OurDlpDbContext>>();
            await using var db = await factory.CreateDbContextAsync();
            using var budget = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            await db.Database.MigrateAsync(budget.Token);
            Console.WriteLine("Миграции PostgreSQL успешно применены.");
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"Миграции не применены ({exception.GetType().Name}). Проверьте PostgreSQL и параметры подключения.");
            return 1;
        }
    }
}
