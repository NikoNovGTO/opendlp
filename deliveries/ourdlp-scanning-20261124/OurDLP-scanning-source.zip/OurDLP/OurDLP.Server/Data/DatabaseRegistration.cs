using Microsoft.EntityFrameworkCore;

namespace OurDLP.Server.Data;

public static class DatabaseRegistration
{
    public static IServiceCollection AddOurDlpDatabase(this IServiceCollection services, IConfiguration configuration)
    {
        var settings = new DatabaseSettings(configuration.GetConnectionString("OurDlp"));
        services.AddSingleton(settings);
        services.AddDbContextFactory<OurDlpDbContext>(options => options.UseNpgsql(settings.ConnectionString));
        services.AddScoped<DatabaseReadiness>();
        return services;
    }
}
