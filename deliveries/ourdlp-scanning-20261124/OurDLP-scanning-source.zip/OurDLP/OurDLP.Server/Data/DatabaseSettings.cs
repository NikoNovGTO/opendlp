namespace OurDLP.Server.Data;

public sealed class DatabaseSettings(string? connectionString)
{
    public string? ConnectionString { get; } = connectionString;
    public bool IsConfigured => !string.IsNullOrWhiteSpace(ConnectionString);
}
