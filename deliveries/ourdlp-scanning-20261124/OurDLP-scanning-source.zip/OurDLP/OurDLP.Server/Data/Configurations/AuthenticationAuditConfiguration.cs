using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data.Configurations;

public sealed class AuthenticationAuditConfiguration : IEntityTypeConfiguration<AuthenticationAudit>
{
    public void Configure(EntityTypeBuilder<AuthenticationAudit> builder)
    {
        builder.ToTable("authentication_audit");
        builder.HasKey(entry => entry.Id);
        builder.Property(entry => entry.Action).HasMaxLength(64).IsRequired();
        builder.HasIndex(entry => entry.TimeUtc);
    }
}
