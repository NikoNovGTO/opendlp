using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Data.Configurations;

public sealed class AgentConfiguration : IEntityTypeConfiguration<DeviceEnrollment>, IEntityTypeConfiguration<DeviceCredential>, IEntityTypeConfiguration<DeviceAudit>
{
    public void Configure(EntityTypeBuilder<DeviceEnrollment> builder)
    {
        builder.ToTable("device_enrollments"); builder.HasKey(row => row.DeviceId);
        builder.Property(row => row.CodeHash).HasMaxLength(64).IsRequired();
        builder.HasIndex(row => row.CodeHash).IsUnique();
        builder.HasOne<Device>().WithOne().HasForeignKey<DeviceEnrollment>(row => row.DeviceId);
    }
    public void Configure(EntityTypeBuilder<DeviceCredential> builder)
    {
        builder.ToTable("device_credentials"); builder.HasKey(row => row.DeviceId);
        builder.Property(row => row.TokenHash).HasMaxLength(64).IsRequired();
        builder.HasIndex(row => row.TokenHash).IsUnique();
        builder.HasOne<Device>().WithOne().HasForeignKey<DeviceCredential>(row => row.DeviceId);
    }
    public void Configure(EntityTypeBuilder<DeviceAudit> builder)
    {
        builder.ToTable("device_audit"); builder.HasKey(row => row.Id);
        builder.Property(row => row.Action).HasMaxLength(64).IsRequired();
        builder.HasIndex(row => new { row.DeviceId, row.TimeUtc });
    }
}
