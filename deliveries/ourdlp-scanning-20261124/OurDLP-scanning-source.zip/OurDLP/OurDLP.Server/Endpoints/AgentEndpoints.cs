using OurDLP.Contracts;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;

namespace OurDLP.Server.Endpoints;

public static class AgentEndpoints
{
    public static IEndpointRouteBuilder MapAgentEndpoints(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/api/agent/enroll", async (AgentEnrollmentRequest request, AgentRegistration registration,
            DatabaseReadiness database, HttpContext context, CancellationToken token) =>
        {
            if ((await database.CheckAsync(token)).Status != "ready") return Results.StatusCode(503);
            var result = await registration.EnrollAsync(request, Ip(context), token);
            return result is null ? Results.BadRequest(new DeviceOperationResponse("Код истёк, уже использован или данные регистрации некорректны.")) : Results.Ok(result);
        }).AllowAnonymous().RequireRateLimiting("agent-enrollment");
        endpoints.MapPost("/api/agent/heartbeat", async (AgentHeartbeatRequest request, AgentRegistration registration, HttpContext context, CancellationToken token) =>
        {
            var id = Guid.Parse(context.User.FindFirst("device_id")!.Value);
            var result = await registration.HeartbeatAsync(id, request, Ip(context), token);
            return result is null ? Results.BadRequest() : Results.Ok(result);
        }).RequireAuthorization(AgentAuthenticationHandler.PolicyName);
        return endpoints;
    }
    private static string? Ip(HttpContext context)
    {
        var address = context.Connection.RemoteIpAddress;
        return address?.IsIPv4MappedToIPv6 == true ? address.MapToIPv4().ToString() : address?.ToString();
    }
}
