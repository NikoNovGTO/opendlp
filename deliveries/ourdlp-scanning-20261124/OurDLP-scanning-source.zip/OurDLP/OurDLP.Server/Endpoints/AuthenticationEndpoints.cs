using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using OurDLP.Contracts;
using OurDLP.Server.Authentication;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Endpoints;

public static class AuthenticationEndpoints
{
    public static IEndpointRouteBuilder MapAuthenticationEndpoints(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/api/auth/login", LoginAsync).AllowAnonymous().RequireRateLimiting("administrator-login");
        endpoints.MapGet("/api/auth/me", (Func<HttpContext, Task<IResult>>)CurrentUserAsync).RequireAuthorization(AuthDefaults.AdministratorPolicy);
        endpoints.MapPost("/api/auth/logout", LogoutAsync).RequireAuthorization(AuthDefaults.AdministratorPolicy);
        return endpoints;
    }

    private static async Task<IResult> LoginAsync(LoginRequest request, DatabaseReadiness database,
        UserManager<Administrator> users, SignInManager<Administrator> signIn,
        AuthenticationAuditWriter audit, CancellationToken token)
    {
        if (string.IsNullOrWhiteSpace(request.UserName) || request.UserName.Length > 64
            || string.IsNullOrEmpty(request.Password) || request.Password.Length > 128)
            return Results.BadRequest(new AuthMessage("Укажите логин и пароль. Логин — до 64 символов, пароль — до 128."));
        if ((await database.CheckAsync(token)).Status != "ready")
            return Results.Json(new AuthMessage("База не готова. Проверьте PostgreSQL и примените миграции."), statusCode: 503);
        var user = await users.FindByNameAsync(request.UserName.Trim());
        var result = user is null ? SignInResult.Failed : await signIn.CheckPasswordSignInAsync(user, request.Password, true);
        if (!result.Succeeded)
        {
            await audit.RecordAsync("login.failed", user?.Id, token);
            return Results.Json(new AuthMessage("Неверный логин или пароль либо вход временно недоступен. После нескольких ошибок повторите позже."), statusCode: 401);
        }
        if (!await users.IsInRoleAsync(user!, AuthDefaults.AdministratorRole))
        {
            await audit.RecordAsync("login.forbidden", user!.Id, token);
            return Results.Json(new AuthMessage("Учётная запись не имеет прав администратора."), statusCode: 403);
        }
        var expires = DateTimeOffset.UtcNow + AuthDefaults.SessionLifetime;
        await audit.RecordAsync("login.succeeded", user!.Id, token);
        await signIn.SignInAsync(user, new AuthenticationProperties
        { IsPersistent = false, AllowRefresh = false, ExpiresUtc = expires });
        return Results.Ok(new AdministratorResponse(user.Id, user.UserName!, expires));
    }

    private static async Task<IResult> CurrentUserAsync(HttpContext context)
    {
        var ticket = await context.AuthenticateAsync(IdentityConstants.ApplicationScheme);
        return Results.Ok(new AdministratorResponse(Guid.Parse(context.User.FindFirstValue(ClaimTypes.NameIdentifier)!),
            context.User.Identity!.Name!, ticket.Properties!.ExpiresUtc!.Value));
    }

    private static async Task<IResult> LogoutAsync(HttpContext context, UserManager<Administrator> users,
        AuthenticationAuditWriter audit, CancellationToken token)
    {
        var user = await users.GetUserAsync(context.User);
        if (user is null) return Results.Unauthorized();
        // Revoke every cookie issued for this account, including a copied cookie.
        var result = await users.UpdateSecurityStampAsync(user);
        if (!result.Succeeded) return Results.Json(new AuthMessage("Не удалось завершить серверные сеансы."), statusCode: 503);
        await audit.RecordAsync("logout.succeeded", user.Id, token);
        await context.SignOutAsync(IdentityConstants.ApplicationScheme);
        return Results.NoContent();
    }
}
