using System.Security.Claims;
using OurDLP.Contracts;
using OurDLP.Server.Agents;
using OurDLP.Server.Authentication;

namespace OurDLP.Server.Endpoints;

public static class DeviceEndpoints
{
    public static IEndpointRouteBuilder MapDeviceEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/devices").RequireAuthorization(AuthDefaults.AdministratorPolicy);
        group.MapGet("", (DeviceRegistry registry, CancellationToken token) => registry.ListAsync(token));
        group.MapPost("", async (CreateDeviceRequest request, DeviceRegistry registry, HttpContext context, CancellationToken token) =>
        {
            if (string.IsNullOrWhiteSpace(request.Name) || request.Name.Length > 255) return Results.BadRequest(new DeviceOperationResponse("Укажите имя устройства до 255 символов."));
            context.Response.Headers.CacheControl = "no-store";
            return Results.Ok(await registry.CreateAsync(request.Name, AdministratorId(context), token));
        });
        group.MapPost("/{id:guid}/enrollment", async (Guid id, DeviceRegistry registry, HttpContext context, CancellationToken token) =>
        {
            context.Response.Headers.CacheControl = "no-store";
            var result = await registry.ReissueAsync(id, AdministratorId(context), token);
            return result is null ? Results.NotFound() : Results.Ok(result);
        });
        group.MapPost("/{id:guid}/revoke", async (Guid id, DeviceRegistry registry, HttpContext context, CancellationToken token) =>
            await registry.RevokeAsync(id, AdministratorId(context), token)
                ? Results.Ok(new DeviceOperationResponse("Доступ агента отозван.")) : Results.NotFound());
        return endpoints;
    }
    private static Guid AdministratorId(HttpContext context) => Guid.Parse(context.User.FindFirstValue(ClaimTypes.NameIdentifier)!);
}
