using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Authentication;

public sealed class AuthenticationAuditWriter(OurDlpDbContext db)
{
    public async Task RecordAsync(string action, Guid? userId, CancellationToken token = default)
    {
        db.AuthenticationAudit.Add(new AuthenticationAudit
        {
            Id = Guid.NewGuid(), TimeUtc = DateTimeOffset.UtcNow, Action = action, UserId = userId
        });
        await db.SaveChangesAsync(token);
    }
}
