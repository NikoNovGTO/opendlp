using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Authentication;

public static class AdministratorBootstrap
{
    public static async Task<int> RunAsync(IServiceProvider services)
    {
        // Standard input only: no password command-line argument or plaintext file.
        LoginRequest? request;
        try { request = await System.Text.Json.JsonSerializer.DeserializeAsync<LoginRequest>(Console.OpenStandardInput(),
            new System.Text.Json.JsonSerializerOptions(System.Text.Json.JsonSerializerDefaults.Web)); }
        catch (System.Text.Json.JsonException) { Console.Error.WriteLine("Некорректные данные создания администратора."); return 1; }
        if (request is null || string.IsNullOrWhiteSpace(request.UserName) || request.UserName.Length > 64
            || string.IsNullOrEmpty(request.Password) || request.Password.Length > 128)
        { Console.Error.WriteLine("Укажите логин до 64 символов и пароль от 12 до 128 символов."); return 1; }

        await using var scope = services.CreateAsyncScope();
        if ((await scope.ServiceProvider.GetRequiredService<DatabaseReadiness>().CheckAsync(default)).Status != "ready")
        { Console.Error.WriteLine("Сначала примените миграции PostgreSQL."); return 1; }
        var db = scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        await using var transaction = await db.Database.BeginTransactionAsync();
        await db.Database.ExecuteSqlRawAsync("SELECT pg_advisory_xact_lock(51129913)");
        if (await db.Users.AnyAsync())
        { Console.Error.WriteLine("Администратор уже создан. Существующий пароль не изменён."); return 2; }
        var users = scope.ServiceProvider.GetRequiredService<UserManager<Administrator>>();
        var roles = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        if (!await roles.RoleExistsAsync(AuthDefaults.AdministratorRole))
        {
            var roleResult = await roles.CreateAsync(new IdentityRole<Guid>(AuthDefaults.AdministratorRole));
            if (!roleResult.Succeeded) return Failure(roleResult);
        }
        var user = new Administrator { Id = Guid.NewGuid(), UserName = request.UserName.Trim() };
        var created = await users.CreateAsync(user, request.Password);
        if (!created.Succeeded) return Failure(created);
        var assigned = await users.AddToRoleAsync(user, AuthDefaults.AdministratorRole);
        if (!assigned.Succeeded) return Failure(assigned);
        await scope.ServiceProvider.GetRequiredService<AuthenticationAuditWriter>().RecordAsync("administrator.created", user.Id);
        await transaction.CommitAsync();
        Console.WriteLine("Администратор OurDLP создан. Пароль хранится только в виде хеша.");
        return 0;
    }

    private static int Failure(IdentityResult result)
    {
        Console.Error.WriteLine("Учётная запись не создана. Проверьте логин и пароль: минимум 12 символов, заглавная и строчная латинские буквы, цифра.");
        Console.Error.WriteLine("Коды проверки: " + string.Join(", ", result.Errors.Select(error => error.Code)));
        return 1;
    }
}
