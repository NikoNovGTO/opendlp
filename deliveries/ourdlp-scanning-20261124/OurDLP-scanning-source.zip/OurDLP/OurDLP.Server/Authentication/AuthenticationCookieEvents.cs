using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Npgsql;

namespace OurDLP.Server.Authentication;

public static class AuthenticationCookieEvents
{
    public static async Task ValidateAsync(CookieValidatePrincipalContext context)
    {
        try { await SecurityStampValidator.ValidatePrincipalAsync(context); }
        catch (Exception exception) when (exception is NpgsqlException or TimeoutException)
        {
            context.RejectPrincipal();
            context.HttpContext.Items["AuthenticationDatabaseUnavailable"] = true;
        }
    }

    public static Task UnauthorizedAsync(RedirectContext<CookieAuthenticationOptions> context)
    {
        context.Response.StatusCode = context.HttpContext.Items.ContainsKey("AuthenticationDatabaseUnavailable")
            ? StatusCodes.Status503ServiceUnavailable : StatusCodes.Status401Unauthorized;
        return Task.CompletedTask;
    }
}
