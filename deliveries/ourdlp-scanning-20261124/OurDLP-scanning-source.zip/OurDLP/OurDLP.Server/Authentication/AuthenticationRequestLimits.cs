using Microsoft.AspNetCore.Http.Features;

namespace OurDLP.Server.Authentication;

public sealed class AuthenticationRequestLimits(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.StartsWithSegments("/api/auth")
            || context.Request.Path.StartsWithSegments("/api/agent") || context.Request.Path.StartsWithSegments("/api/devices"))
        {
            if (!context.Request.IsHttps)
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsJsonAsync(new OurDLP.Contracts.AuthMessage("Для защищённого обмена требуется HTTPS."));
                return;
            }
            var size = context.Features.Get<IHttpMaxRequestBodySizeFeature>();
            if (size is { IsReadOnly: false }) size.MaxRequestBodySize = 16 * 1024;
        }
        await next(context);
    }
}
