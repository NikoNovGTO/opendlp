using Microsoft.AspNetCore.Authorization;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Authentication;

public static class AuthenticationRegistration
{
    public static IServiceCollection AddOurDlpAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddIdentityCore<Administrator>(options =>
        {
            options.Password.RequiredLength = 12;
            options.Password.RequireNonAlphanumeric = false;
            options.Lockout.MaxFailedAccessAttempts = 5;
            options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
        }).AddRoles<IdentityRole<Guid>>().AddEntityFrameworkStores<OurDlpDbContext>().AddSignInManager();

        services.Configure<SecurityStampValidatorOptions>(options => options.ValidationInterval = TimeSpan.Zero);
        services.AddAuthentication(IdentityConstants.ApplicationScheme).AddIdentityCookies();
        services.Configure<CookieAuthenticationOptions>(IdentityConstants.ApplicationScheme, options =>
            {
                options.Cookie.Name = "OurDLP.Session";
                options.Cookie.HttpOnly = true;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.ExpireTimeSpan = AuthDefaults.SessionLifetime;
                options.SlidingExpiration = false;
                options.Events.OnValidatePrincipal = AuthenticationCookieEvents.ValidateAsync;
                options.Events.OnRedirectToLogin = AuthenticationCookieEvents.UnauthorizedAsync;
                options.Events.OnRedirectToAccessDenied = context =>
                {
                    context.Response.StatusCode = StatusCodes.Status403Forbidden;
                    return Task.CompletedTask;
                };
            });
        services.AddAuthorizationBuilder().AddPolicy(AuthDefaults.AdministratorPolicy,
            policy => policy.RequireAuthenticatedUser().RequireRole(AuthDefaults.AdministratorRole))
            .SetFallbackPolicy(new AuthorizationPolicyBuilder().RequireAuthenticatedUser()
                .RequireRole(AuthDefaults.AdministratorRole).Build());

        var keyPath = configuration["Authentication:KeyDirectory"] ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OurDLP", "Server", "DataProtectionKeys");
        var protection = services.AddDataProtection().SetApplicationName("OurDLP.Server")
            .PersistKeysToFileSystem(new DirectoryInfo(keyPath));
        if (OperatingSystem.IsWindows()) protection.ProtectKeysWithDpapi();
        services.AddRateLimiter(options =>
        {
            options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
            options.AddPolicy("administrator-login", context => RateLimitPartition.GetFixedWindowLimiter(
                context.Connection.RemoteIpAddress?.ToString() ?? "local", _ => new FixedWindowRateLimiterOptions
                { PermitLimit = 10, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
        });
        services.AddScoped<AuthenticationAuditWriter>();
        return services;
    }
}
