namespace OurDLP.Server.Authentication;

public static class AuthDefaults
{
    public const string AdministratorRole = "Administrator";
    public const string AdministratorPolicy = "Administrator";
    public static readonly TimeSpan SessionLifetime = TimeSpan.FromHours(8);
}
