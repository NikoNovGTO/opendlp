using System.Buffers.Binary;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using OurDLP.Server.Data;

namespace OurDLP.Server.Agents;

public static class AgentDatabaseLock
{
    public static Task AcquireAsync(OurDlpDbContext db, Guid deviceId, CancellationToken token)
    {
        var key = BinaryPrimitives.ReadInt64LittleEndian(SHA256.HashData(deviceId.ToByteArray()));
        return db.Database.ExecuteSqlInterpolatedAsync($"SELECT pg_advisory_xact_lock({key})", token);
    }
}
