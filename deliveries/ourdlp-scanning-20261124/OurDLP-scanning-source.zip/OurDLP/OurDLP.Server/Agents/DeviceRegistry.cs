using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Agents;

public sealed class DeviceRegistry(OurDlpDbContext db, TimeProvider time)
{
    public async Task<DeviceListResponse> ListAsync(CancellationToken token)
    {
        var rows = await (from device in db.Devices.AsNoTracking()
            join credential in db.DeviceCredentials.AsNoTracking() on device.Id equals credential.DeviceId into credentials
            from credential in credentials.DefaultIfEmpty()
            orderby device.CreatedAtUtc descending
            select new { device, Revoked = credential != null && credential.RevokedAtUtc != null }).Take(200).ToListAsync(token);
        var threshold = time.GetUtcNow().AddSeconds(-90);
        return new(rows.Select(row => new DeviceResponse(row.device.Id, row.device.Name, row.device.HostName,
            row.device.OperatingSystem, row.device.AgentVersion, row.device.IpAddress,
            row.device.IsAccessRevoked ? "revoked" : row.device.RegisteredAtUtc is null ? "pending" : row.Revoked ? "revoked"
                : row.device.LastSeenAtUtc >= threshold ? "active" : "offline", row.device.LastSeenAtUtc)).ToList());
    }

    public async Task<EnrollmentResponse> CreateAsync(string name, Guid administrator, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        var device = new Device { Id = Guid.NewGuid(), Name = name.Trim(), CreatedAtUtc = time.GetUtcNow() };
        db.Devices.Add(device);
        var result = await IssueAsync(device, administrator, token);
        await transaction.CommitAsync(token);
        return result;
    }

    public async Task<EnrollmentResponse?> ReissueAsync(Guid id, Guid administrator, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, id, token);
        var device = await db.Devices.FindAsync([id], token);
        if (device is null) return null;
        var result = await IssueAsync(device, administrator, token);
        await transaction.CommitAsync(token);
        return result;
    }

    private async Task<EnrollmentResponse> IssueAsync(Device device, Guid administrator, CancellationToken token)
    {
        var code = AgentSecrets.Create();
        var enrollment = await db.DeviceEnrollments.FindAsync([device.Id], token);
        if (enrollment is null) { enrollment = new DeviceEnrollment { DeviceId = device.Id }; db.DeviceEnrollments.Add(enrollment); }
        enrollment.CodeHash = AgentSecrets.Hash(code); enrollment.ExpiresAtUtc = time.GetUtcNow().AddMinutes(15); enrollment.UsedAtUtc = null;
        var credential = await db.DeviceCredentials.FindAsync([device.Id], token);
        if (credential is not null) credential.RevokedAtUtc = time.GetUtcNow();
        device.IsAccessRevoked = false;
        device.RegisteredAtUtc = null; device.LastSeenAtUtc = null;
        AddAudit(device.Id, administrator, "enrollment.issued");
        await db.SaveChangesAsync(token);
        return new(device.Id, code, enrollment.ExpiresAtUtc);
    }

    public async Task<bool> RevokeAsync(Guid id, Guid administrator, CancellationToken token)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        await AgentDatabaseLock.AcquireAsync(db, id, token);
        var device = await db.Devices.FindAsync([id], token);
        if (device is null) return false;
        device.IsAccessRevoked = true;
        var credential = await db.DeviceCredentials.FindAsync([id], token);
        if (credential is not null) credential.RevokedAtUtc = time.GetUtcNow();
        var enrollment = await db.DeviceEnrollments.FindAsync([id], token);
        if (enrollment is not null) enrollment.ExpiresAtUtc = time.GetUtcNow().AddSeconds(-1);
        AddAudit(id, administrator, "access.revoked");
        await db.SaveChangesAsync(token);
        await transaction.CommitAsync(token);
        return true;
    }

    public void AddAudit(Guid id, Guid? administrator, string action) => db.DeviceAudit.Add(new()
    { Id = Guid.NewGuid(), DeviceId = id, AdministratorId = administrator, Action = action, TimeUtc = time.GetUtcNow() });
}
