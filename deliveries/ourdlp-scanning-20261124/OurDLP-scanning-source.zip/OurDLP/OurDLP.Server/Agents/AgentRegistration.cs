using Microsoft.EntityFrameworkCore;
using OurDLP.Contracts;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;

namespace OurDLP.Server.Agents;

public sealed class AgentRegistration(OurDlpDbContext db, DeviceRegistry registry, TimeProvider time)
{
    public async Task<AgentAcknowledgement?> EnrollAsync(AgentEnrollmentRequest request, string? ip, CancellationToken token)
    {
        if (!AgentSecrets.IsValid(request.Code) || !AgentSecrets.IsValid(request.Token) || !ValidMetadata(request.HostName, request.OperatingSystem, request.AgentVersion)) return null;
        var codeHash = AgentSecrets.Hash(request.Code);
        var tokenHash = AgentSecrets.Hash(request.Token);
        await using var transaction = await db.Database.BeginTransactionAsync(token);
        var deviceId = await db.DeviceEnrollments.Where(row => row.CodeHash == codeHash).Select(row => (Guid?)row.DeviceId).SingleOrDefaultAsync(token);
        if (deviceId is null) return null;
        await AgentDatabaseLock.AcquireAsync(db, deviceId.Value, token);
        var enrollment = await db.DeviceEnrollments.FromSqlInterpolated($"SELECT * FROM device_enrollments WHERE \"CodeHash\" = {codeHash} FOR UPDATE").SingleOrDefaultAsync(token);
        if (enrollment is null || enrollment.ExpiresAtUtc <= time.GetUtcNow()) return null;
        var credential = await db.DeviceCredentials.FindAsync([enrollment.DeviceId], token);
        if (enrollment.UsedAtUtc is not null)
            return credential is not null && credential.TokenHash == tokenHash && credential.RevokedAtUtc is null
                ? new(enrollment.DeviceId, time.GetUtcNow()) : null;
        if (await db.DeviceCredentials.AnyAsync(row => row.TokenHash == tokenHash && row.DeviceId != enrollment.DeviceId, token)) return null;
        var device = await db.Devices.SingleAsync(row => row.Id == enrollment.DeviceId, token);
        if (credential is null) { credential = new DeviceCredential { DeviceId = device.Id }; db.DeviceCredentials.Add(credential); }
        credential.TokenHash = tokenHash; credential.RevokedAtUtc = null;
        enrollment.UsedAtUtc = time.GetUtcNow();
        device.IsAccessRevoked = false;
        device.RegisteredAtUtc = time.GetUtcNow();
        ApplyMetadata(device, request.HostName, request.OperatingSystem, request.AgentVersion, ip);
        registry.AddAudit(device.Id, null, "agent.registered");
        await db.SaveChangesAsync(token); await transaction.CommitAsync(token);
        return new(device.Id, time.GetUtcNow());
    }

    public async Task<AgentAcknowledgement?> HeartbeatAsync(Guid id, AgentHeartbeatRequest request, string? ip, CancellationToken token)
    {
        if (!ValidMetadata(request.HostName, request.OperatingSystem, request.AgentVersion)) return null;
        var device = await db.Devices.SingleAsync(row => row.Id == id, token);
        ApplyMetadata(device, request.HostName, request.OperatingSystem, request.AgentVersion, ip);
        await db.SaveChangesAsync(token);
        return new(device.Id, time.GetUtcNow());
    }

    private void ApplyMetadata(Device device, string host, string os, string version, string? ip)
    {
        device.HostName = host; device.OperatingSystem = os; device.AgentVersion = version;
        device.IpAddress = ip; device.LastSeenAtUtc = time.GetUtcNow();
    }
    private static bool ValidMetadata(string? host, string? os, string? version) => !string.IsNullOrWhiteSpace(host) && host.Length <= 255
        && !string.IsNullOrWhiteSpace(os) && os.Length <= 255 && !string.IsNullOrWhiteSpace(version) && version.Length <= 64;
}
