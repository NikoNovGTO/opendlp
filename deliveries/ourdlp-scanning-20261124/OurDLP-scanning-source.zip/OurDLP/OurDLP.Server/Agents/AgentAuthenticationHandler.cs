using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Npgsql;
using OurDLP.Server.Data;

namespace OurDLP.Server.Agents;

public sealed class AgentAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options,
    ILoggerFactory logger, UrlEncoder encoder, OurDlpDbContext db) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder)
{
    public const string SchemeName = "OurDLP.Agent";
    public const string PolicyName = "Agent";
    private bool _unavailable;

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var header = Request.Headers.Authorization.ToString();
        if (!header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return AuthenticateResult.NoResult();
        var secret = header[7..];
        if (!AgentSecrets.IsValid(secret)) return AuthenticateResult.Fail("Invalid agent credential.");
        try
        {
            var hash = AgentSecrets.Hash(secret);
            var credential = await db.DeviceCredentials.AsNoTracking().SingleOrDefaultAsync(row => row.TokenHash == hash && row.RevokedAtUtc == null, Context.RequestAborted);
            if (credential is null) return AuthenticateResult.Fail("Agent credential is not active.");
            var principal = new ClaimsPrincipal(new ClaimsIdentity([new Claim("device_id", credential.DeviceId.ToString())], SchemeName));
            return AuthenticateResult.Success(new AuthenticationTicket(principal, SchemeName));
        }
        catch (Exception exception) when (exception is NpgsqlException or InvalidOperationException or TimeoutException)
        {
            _unavailable = true;
            return AuthenticateResult.Fail("Agent authentication unavailable.");
        }
    }
    protected override Task HandleChallengeAsync(AuthenticationProperties properties)
    {
        Response.StatusCode = _unavailable ? 503 : 401;
        return Task.CompletedTask;
    }
}
