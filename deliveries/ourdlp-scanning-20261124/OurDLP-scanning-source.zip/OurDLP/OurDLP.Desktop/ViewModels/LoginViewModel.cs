using System.IO;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Services;

namespace OurDLP.Desktop.ViewModels;

public sealed class LoginViewModel : ObservableObject, IDisposable
{
    private readonly JsonSettingsStore _store;
    private readonly IAuthenticationClient _client;
    private readonly CancellationTokenSource _lifetime = new();
    private string _serverAddress = JsonSettingsStore.DefaultAddress;
    private string _userName = "admin";
    private string _message = string.Empty;
    private bool _isBusy;
    private bool _disposed;
    public string ServerAddress { get => _serverAddress; set => SetProperty(ref _serverAddress, value); }
    public string UserName { get => _userName; set => SetProperty(ref _userName, value); }
    public string Message
    {
        get => _message;
        private set { if (SetProperty(ref _message, value)) OnPropertyChanged(nameof(HasError)); }
    }
    public bool HasError => !_isBusy && !string.IsNullOrWhiteSpace(Message);
    public bool CanSignIn => !_isBusy && !_disposed;

    public LoginViewModel(JsonSettingsStore store, IAuthenticationClient client)
    {
        _store = store;
        _client = client;
        try { ServerAddress = store.Load(); }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException or InvalidOperationException)
        { Message = "Не удалось прочитать адрес сервера. Укажите его вручную."; }
    }

    public async Task<AdministratorResponse?> SignInAsync(string password)
    {
        if (_isBusy || _disposed) return null;
        if (!ServerAddressValidator.TryNormalize(ServerAddress, out var address) || string.IsNullOrWhiteSpace(UserName)
            || UserName.Length > 64 || string.IsNullOrEmpty(password) || password.Length > 128)
        { Message = "Укажите HTTPS-адрес, логин до 64 символов и пароль до 128 символов."; return null; }
        _isBusy = true;
        OnPropertyChanged(nameof(CanSignIn));
        OnPropertyChanged(nameof(HasError));
        Message = "Выполняем вход…";
        try
        {
            var result = await _client.LoginAsync(address, UserName, password, _lifetime.Token);
            if (_disposed) return null;
            if (!result.Succeeded) { Message = result.Message; return null; }
            try { _store.Save(address); }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
            {
                await _client.LogoutAsync(address, _lifetime.Token);
                Message = "Не удалось сохранить адрес сервера. Проверьте доступ к локальным настройкам.";
                return null;
            }
            ServerAddress = address;
            Message = string.Empty;
            return result.Administrator;
        }
        catch (OperationCanceledException) when (_lifetime.IsCancellationRequested) { return null; }
        catch (Exception exception)
        {
            System.Diagnostics.Trace.TraceError(exception.GetType().Name);
            if (!_disposed) Message = "Не удалось завершить вход. Повторите попытку.";
            return null;
        }
        finally
        {
            _isBusy = false;
            if (!_disposed) { OnPropertyChanged(nameof(CanSignIn)); OnPropertyChanged(nameof(HasError)); }
            else _lifetime.Dispose();
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _lifetime.Cancel();
        if (!_isBusy) _lifetime.Dispose();
    }
}
