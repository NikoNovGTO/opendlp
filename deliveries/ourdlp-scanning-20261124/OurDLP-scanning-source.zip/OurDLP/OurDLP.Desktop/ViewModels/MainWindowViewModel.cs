using OurDLP.Contracts;
using OurDLP.Desktop.ViewModels.Scanning;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Services;

namespace OurDLP.Desktop.ViewModels;

public sealed class MainWindowViewModel(
    MoscowClock clock, SettingsViewModel settings, ServerConnectionViewModel connection, AdministratorResponse administrator, AsyncRelayCommand logout, DevicesViewModel devices, ScanWorkspaceViewModel scanning) : IDisposable
{
    public string ApplicationName => "OurDLP";
    public string Slogan => "Сложная защита. Простое управление.";
    public MoscowClock Clock { get; } = clock;
    public SettingsViewModel Settings { get; } = settings;
    public ServerConnectionViewModel Connection { get; } = connection;

    public AdministratorResponse Administrator { get; } = administrator;
    public AsyncRelayCommand LogoutCommand { get; } = logout;

    public DevicesViewModel Devices { get; } = devices;

    public ScanWorkspaceViewModel Scanning { get; } = scanning;

    public void Dispose()
    {
        Scanning.Dispose();
        Devices.Dispose();
        Connection.Dispose();
        Clock.Dispose();
    }
}
