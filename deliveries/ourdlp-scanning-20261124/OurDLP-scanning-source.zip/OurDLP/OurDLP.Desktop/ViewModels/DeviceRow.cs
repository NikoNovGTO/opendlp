using System.Globalization;
using OurDLP.Contracts;

namespace OurDLP.Desktop.ViewModels;

public sealed class DeviceRow(DeviceResponse device)
{
    public Guid Id => device.Id;
    public string Name => device.Name;
    public string HostName => device.HostName ?? "—";
    public string OperatingSystem => device.OperatingSystem ?? "—";
    public string AgentVersion => device.AgentVersion ?? "—";
    public string IpAddress => device.IpAddress ?? "—";
    public string Status => device.Status switch
    { "pending" => "Ожидает агента", "active" => "Активен", "offline" => "Нет связи", "revoked" => "Доступ отозван", _ => "Неизвестно" };
    public string LastSeen => device.LastSeenAtUtc is { } time
        ? TimeZoneInfo.ConvertTime(time, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss", CultureInfo.GetCultureInfo("ru-RU")) + " МСК" : "—";
}
