using System.IO;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Services.Scanning;

namespace OurDLP.Desktop.ViewModels.Scanning;

public sealed class ScanWorkspaceViewModel : ObservableObject, IDisposable
{
    private readonly IFileScanner _scanner;
    private readonly IScanReportStore _store;
    private readonly Func<string?> _chooseFolder;
    private readonly Func<string?> _chooseExport;
    private readonly Func<string> _createSample;
    private readonly CancellationTokenSource _lifetime = new();
    private CancellationTokenSource? _scan;
    private bool _busy, _disposed;
    private string _message = string.Empty, _progress = string.Empty;
    public ScanOptionsViewModel Options { get; } = new();
    public ScanResultsViewModel Results { get; } = new();
    public ScanHistoryViewModel History { get; } = new();
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public string ProgressText { get => _progress; private set => SetProperty(ref _progress, value); }
    public bool CanEdit => !_busy && !_disposed;
    public AsyncRelayCommand ChooseFolderCommand { get; }
    public AsyncRelayCommand CreateSampleCommand { get; }
    public AsyncRelayCommand StartCommand { get; }
    public AsyncRelayCommand CancelCommand { get; }
    public AsyncRelayCommand RefreshHistoryCommand { get; }
    public AsyncRelayCommand OpenHistoryCommand { get; }
    public AsyncRelayCommand ExportCommand { get; }
    public ScanWorkspaceViewModel(IFileScanner scanner, IScanReportStore store, Func<string?> chooseFolder,
        Func<string?> chooseExport, Func<string> createSample)
    {
        _scanner = scanner; _store = store; _chooseFolder = chooseFolder; _chooseExport = chooseExport; _createSample = createSample;
        ChooseFolderCommand = Command(() => { var path = _chooseFolder(); if (path is not null) Options.Folder = path; return Task.CompletedTask; });
        CreateSampleCommand = Command(() => { Options.UseSample(_createSample()); Message = "Создан отдельный тестовый каталог. Стандартное правило найдёт 3 совпадения в двух файлах."; return Task.CompletedTask; });
        StartCommand = Command(StartAsync);
        CancelCommand = new(() => { _scan?.Cancel(); Message = "Отмена проверки…"; return Task.CompletedTask; }, Unexpected, () => _scan is not null && !_disposed);
        RefreshHistoryCommand = Command(RefreshHistoryAsync);
        OpenHistoryCommand = Command(OpenHistoryAsync);
        ExportCommand = Command(ExportAsync);
    }
    private AsyncRelayCommand Command(Func<Task> operation) => new(() => RunAsync(operation), Unexpected, () => CanEdit);
    private async Task RunAsync(Func<Task> operation)
    {
        if (!CanEdit) return;
        _busy = true; Message = string.Empty; RefreshCommands();
        try { await operation(); }
        catch (OperationCanceledException) when (_disposed) { }
        finally { _busy = false; if (_disposed) _lifetime.Dispose(); else RefreshCommands(); }
    }
    private async Task StartAsync()
    {
        var request = Options.BuildRequest();
        using var scan = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token);
        _scan = scan; ProgressText = "Проверка выбранного каталога…"; RefreshCommands();
        try
        {
            var progress = new Progress<ScanProgress>(value =>
            {
                if (!_disposed && ReferenceEquals(_scan, scan)) ProgressText = $"Проверено: {value.FilesScanned}, обнаружений: {value.Findings} · {value.CurrentPath}";
            });
            var report = await _scanner.ScanAsync(request, progress, scan.Token);
            if (_disposed) return;
            Results.Show(report); ProgressText = string.Empty;
            try
            {
                // Cancellation stops scanning; partial results still need to be persisted.
                await _store.SaveAsync(report, _lifetime.Token);
                if (_disposed) return;
                Message = "Результат сохранён в локальной истории (последние 20 проверок).";
                var list = await _store.ListAsync(_lifetime.Token);
                if (!_disposed) History.Apply(list, report.Id);
            }
            catch (Exception error) when (error is IOException or InvalidDataException or UnauthorizedAccessException or System.Text.Json.JsonException)
            { Message = "Проверка завершена, но историю сохранить не удалось. Результат доступен в окне; используйте экспорт CSV."; }
        }
        catch (ArgumentException error) { if (!_disposed) { Message = error.Message; ProgressText = string.Empty; } }
        finally { _scan = null; if (!_disposed) { ProgressText = string.Empty; RefreshCommands(); } }
    }
    private async Task RefreshHistoryAsync()
    {
        var list = await _store.ListAsync(_lifetime.Token);
        if (_disposed) return;
        History.Apply(list);
        Message = list.UnreadableCount == 0 ? "История обновлена." : $"Не удалось прочитать отчётов: {list.UnreadableCount}. Они не удалены.";
    }
    private async Task OpenHistoryAsync()
    {
        if (History.Selected is not { } selected) { Message = "Выберите проверку в истории."; return; }
        var report = await _store.LoadAsync(selected.Id, _lifetime.Token);
        if (!_disposed) { Results.Show(report); ProgressText = string.Empty; Message = "Открыт сохранённый результат."; }
    }
    private async Task ExportAsync()
    {
        if (Results.Report is not { } report) { Message = "Сначала выполните проверку или откройте историю."; return; }
        var path = _chooseExport(); if (path is null) return;
        await ScanCsvExporter.ExportAsync(report, path, _lifetime.Token);
        if (!_disposed) Message = "CSV сохранён. В нём пути, правила и число совпадений, без найденных строк.";
    }
    private void RefreshCommands()
    {
        OnPropertyChanged(nameof(CanEdit));
        foreach (var command in new[] { ChooseFolderCommand, CreateSampleCommand, StartCommand, CancelCommand, RefreshHistoryCommand, OpenHistoryCommand, ExportCommand }) command.Refresh();
    }
    private void Unexpected(Exception error)
    { System.Diagnostics.Trace.TraceError(error.GetType().Name); if (!_disposed) { Message = "Операция не завершена. Проверьте доступ к папке или файлу отчёта."; ProgressText = string.Empty; } }
    public void Dispose()
    {
        if (_disposed) return; _disposed = true; _lifetime.Cancel();
        if (!_busy) _lifetime.Dispose();
    }
}
