using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.ViewModels.Scanning;

public sealed class ScanOptionsViewModel : ObservableObject
{
    private string _folder = string.Empty;
    private string _ruleName = "Тестовый маркер";
    private string _pattern = "OURDLP-TEST-[0-9]{4}";
    private string _excluded = "excluded\n.git\n.vs\nbin\nobj";
    private int _maximumMegabytes = 5;
    public string Folder { get => _folder; set => SetProperty(ref _folder, value); }
    public string RuleName { get => _ruleName; set => SetProperty(ref _ruleName, value); }
    public string Pattern { get => _pattern; set => SetProperty(ref _pattern, value); }
    public string ExcludedDirectories { get => _excluded; set => SetProperty(ref _excluded, value); }
    public int MaximumMegabytes { get => _maximumMegabytes; set => SetProperty(ref _maximumMegabytes, value); }
    public IReadOnlyList<int> SizeChoices { get; } = [1, 5, 10, 20];
    public void UseSample(string path)
    {
        Folder = path; RuleName = "Тестовый маркер"; Pattern = "OURDLP-TEST-[0-9]{4}";
        ExcludedDirectories = "excluded\n.git\n.vs\nbin\nobj"; MaximumMegabytes = 5;
    }
    public ScanRequest BuildRequest() => new(Folder.Trim(), [new(Guid.NewGuid(), RuleName.Trim(), Pattern)],
        ExcludedDirectories.Split(['\r', '\n'], StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries),
        new() { MaxFileBytes = (long)MaximumMegabytes * 1024 * 1024 });
}
