using System.Collections.ObjectModel;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.ViewModels.Scanning;

public sealed record ScanFindingRow(string RelativePath, string FilePath, string RuleName, string Matches);
public sealed class ScanResultsViewModel : ObservableObject
{
    public ObservableCollection<ScanFindingRow> Findings { get; } = [];
    public ObservableCollection<ScanIssue> Issues { get; } = [];
    public ScanReport? Report { get; private set; }
    public string Summary => Report is not { } report ? "Проверка ещё не запускалась." :
        $"{Completion(report.Completion)}{(report.IssueCount > 0 ? " с замечаниями" : string.Empty)} · проверено файлов: {report.FilesScanned}, пропущено объектов: {report.FilesSkipped}, обнаружений: {report.Findings.Count}, замечаний: {report.IssueCount}";
    public string Details => Report is not { } report ? string.Empty : report.RootPath + Environment.NewLine + report.Message
        + (report.IssueCount > report.Issues.Count ? $" Показаны первые {report.Issues.Count} замечаний." : string.Empty);
    public void Show(ScanReport? report)
    {
        Report = report; Findings.Clear(); Issues.Clear();
        if (report is not null)
        {
            foreach (var row in report.Findings) Findings.Add(new(row.RelativePath, row.FilePath, row.RuleName,
                row.Matches.ToString() + (row.CountLimited ? "+ (неполный подсчёт)" : string.Empty)));
            foreach (var issue in report.Issues) Issues.Add(issue);
        }
        OnPropertyChanged(nameof(Summary)); OnPropertyChanged(nameof(Details));
    }
    private static string Completion(ScanCompletion value) => value switch
    { ScanCompletion.Completed => "Завершено", ScanCompletion.Cancelled => "Отменено", ScanCompletion.LimitReached => "Достигнут предел", _ => "Ошибка" };
}
