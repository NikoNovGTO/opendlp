using System.Collections.ObjectModel;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Services.Scanning;

namespace OurDLP.Desktop.ViewModels.Scanning;

public sealed class ScanHistoryViewModel : ObservableObject
{
    private ScanHistoryEntry? _selected;
    public ObservableCollection<ScanHistoryEntry> Items { get; } = [];
    public ScanHistoryEntry? Selected { get => _selected; set => SetProperty(ref _selected, value); }
    public void Apply(ScanHistoryList result, Guid? select = null)
    {
        var id = select ?? Selected?.Id;
        Items.Clear(); foreach (var entry in result.Entries) Items.Add(entry);
        Selected = Items.FirstOrDefault(entry => entry.Id == id) ?? Items.FirstOrDefault();
    }
}
