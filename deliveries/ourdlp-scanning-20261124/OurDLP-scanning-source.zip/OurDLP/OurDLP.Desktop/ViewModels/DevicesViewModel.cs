using System.Collections.ObjectModel;
using OurDLP.Contracts;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;

namespace OurDLP.Desktop.ViewModels;

public sealed class DevicesViewModel : ObservableObject, IDisposable
{
    private readonly IDevicesClient _client;
    private readonly Func<string, bool> _confirm;
    private readonly Action _sessionExpired;
    private readonly CancellationTokenSource _lifetime = new();
    private DeviceRow? _selected;
    private Guid? _selectAfterRefresh;
    private string _deviceName = string.Empty;
    private string _message = string.Empty;
    private bool _busy;
    private bool _disposed;
    public ObservableCollection<DeviceRow> Devices { get; } = [];
    public EnrollmentDisplay Enrollment { get; } = new();
    public string DeviceName { get => _deviceName; set => SetProperty(ref _deviceName, value); }
    public string Message { get => _message; private set => SetProperty(ref _message, value); }
    public bool CanOperate => !_busy && !_disposed;
    public DeviceRow? Selected { get => _selected; set { if (SetProperty(ref _selected, value)) RefreshCommands(); } }
    public AsyncRelayCommand RefreshCommand { get; }
    public AsyncRelayCommand CreateCommand { get; }
    public AsyncRelayCommand ReissueCommand { get; }
    public AsyncRelayCommand RevokeCommand { get; }

    public DevicesViewModel(IDevicesClient client, Func<string, bool> confirm, Action sessionExpired)
    {
        _client = client; _confirm = confirm; _sessionExpired = sessionExpired;
        RefreshCommand = new(() => RunAsync(_client.ListAsync, ApplyList, false), Unexpected, () => CanOperate);
        CreateCommand = new(CreateAsync, Unexpected, () => CanOperate);
        ReissueCommand = new(ReissueAsync, Unexpected, () => CanOperate && Selected is not null);
        RevokeCommand = new(RevokeAsync, Unexpected, () => CanOperate && Selected is not null);
    }
    private Task CreateAsync()
    {
        if (string.IsNullOrWhiteSpace(DeviceName) || DeviceName.Length > 255) { Message = "Укажите имя или описание устройства до 255 символов."; return Task.CompletedTask; }
        var name = DeviceName.Trim();
        return RunAsync(token => _client.CreateAsync(name, token), result => { Enrollment.Show(result); _selectAfterRefresh = result.DeviceId; DeviceName = string.Empty; });
    }
    private Task ReissueAsync()
    {
        if (Selected is not { } selected || !_confirm("Перевыпустить код? Доступ старого агента этого устройства будет отозван.")) return Task.CompletedTask;
        return RunAsync(token => _client.ReissueAsync(selected.Id, token), Enrollment.Show);
    }
    private Task RevokeAsync()
    {
        if (Selected is not { } selected || !_confirm("Отозвать доступ агента? Он перестанет передавать состояние до новой регистрации.")) return Task.CompletedTask;
        return RunAsync(token => _client.RevokeAsync(selected.Id, token), _ => Enrollment.Show(null));
    }
    private async Task RunAsync<T>(Func<CancellationToken, Task<DeviceApiResult<T>>> operation, Action<T> apply, bool reload = true)
    {
        if (!CanOperate) return;
        _busy = true; Message = string.Empty; RefreshCommands();
        try
        {
            var result = await operation(_lifetime.Token);
            if (!Accept(result)) return;
            apply(result.Value!);
            if (reload)
            {
                var list = await _client.ListAsync(_lifetime.Token);
                if (Accept(list)) ApplyList(list.Value!);
            }
        }
        catch (OperationCanceledException) when (_lifetime.IsCancellationRequested) { }
        finally { _busy = false; if (!_disposed) RefreshCommands(); else _lifetime.Dispose(); }
    }
    private bool Accept<T>(DeviceApiResult<T> result)
    {
        if (_disposed) return false;
        if (result.SessionExpired) { Enrollment.Show(null); _sessionExpired(); return false; }
        if (result.Value is not null) return true;
        Message = result.Error ?? "Операция не выполнена.";
        return false;
    }
    private void ApplyList(DeviceListResponse result)
    {
        var id = _selectAfterRefresh ?? Selected?.Id;
        _selectAfterRefresh = null;
        Devices.Clear(); foreach (var device in result.Devices) Devices.Add(new(device));
        if (Enrollment.Expired || result.Devices.Any(device => device.Id == Enrollment.DeviceId && device.Status != "pending")) Enrollment.Show(null);
        Selected = Devices.FirstOrDefault(device => device.Id == id);
    }
    private void RefreshCommands()
    { OnPropertyChanged(nameof(CanOperate)); foreach (var command in new[] { RefreshCommand, CreateCommand, ReissueCommand, RevokeCommand }) command.Refresh(); }
    private void Unexpected(Exception exception)
    { System.Diagnostics.Trace.TraceError(exception.GetType().Name); if (!_disposed) Message = "Операция не завершена. Обновите список и повторите."; }
    public void Dispose()
    {
        if (_disposed) return; _disposed = true; Enrollment.Show(null); _lifetime.Cancel();
        if (!_busy) _lifetime.Dispose();
    }
}
