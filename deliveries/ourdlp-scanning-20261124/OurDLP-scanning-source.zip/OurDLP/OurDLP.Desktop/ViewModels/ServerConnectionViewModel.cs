using System.Diagnostics;
using System.Globalization;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;

namespace OurDLP.Desktop.ViewModels;

public sealed class ServerConnectionViewModel : ObservableObject, IDisposable
{
    private readonly IServerStatusClient _client;
    private CancellationTokenSource? _request;
    private int _revision;
    private bool _disposed;
    private ConnectionSnapshot _snapshot = new(ConnectionPhase.NotChecked, "", "Проверка ещё не выполнялась.");
    public ConnectionSnapshot Snapshot => _snapshot;
    public bool IsAvailable => Snapshot.Phase == ConnectionPhase.Available;
    public bool HasError => Snapshot.Phase is ConnectionPhase.Unavailable or ConnectionPhase.InvalidAddress;
    public string StatusText => Snapshot.Phase switch
    {
        ConnectionPhase.Checking => "Проверяем…",
        ConnectionPhase.Available => "API доступен",
        ConnectionPhase.Unavailable => "API недоступен",
        ConnectionPhase.InvalidAddress => "Некорректный адрес",
        _ => "Не проверено"
    };
    public bool IsDatabaseReady => IsAvailable && Snapshot.Database?.Status == "ready";
    public bool HasDatabaseError => Snapshot.Database?.Status is "unavailable" or "migration-required";
    public string DatabaseStatusText => Snapshot.Phase == ConnectionPhase.Checking ? "Проверяем…" : Snapshot.Database?.Status switch
    {
        "ready" => "База готова",
        "not-configured" => "Не настроена",
        "migration-required" => "Требуется миграция",
        "unavailable" => "База не готова",
        _ => "Не проверено"
    };
    public string DatabaseDetails => Snapshot.Database?.Message
        ?? "Состояние PostgreSQL проверяется после успешного ответа API.";
    public string LastCheckedText => Snapshot.CheckedAtUtc is { } time
        ? "Последняя проверка: " + TimeZoneInfo.ConvertTime(time, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time"))
            .ToString("dd.MM.yyyy HH:mm:ss", CultureInfo.GetCultureInfo("ru-RU")) + " МСК"
        : "Проверка ещё не выполнялась";
    public AsyncRelayCommand CheckCommand { get; }

    public ServerConnectionViewModel(IServerStatusClient client)
    {
        _client = client;
        CheckCommand = new(CheckAsync, OnUnexpectedError, () => !_disposed);
    }

    public void SetAddress(string address)
    {
        if (_disposed) return;
        var key = ServerAddressValidator.TryNormalize(address, out var normalized) ? normalized : address.Trim();
        if (key == Snapshot.Address) return;
        _revision++;
        _request?.Cancel();
        Publish(new(ConnectionPhase.NotChecked, key, "Адрес изменён. Выполните проверку соединения."));
    }

    private async Task CheckAsync()
    {
        var address = Snapshot.Address;
        if (!ServerAddressValidator.TryNormalize(address, out _))
        {
            Publish(new(ConnectionPhase.InvalidAddress, address, "Введите HTTPS-адрес без пути, логина и параметров."));
            return;
        }
        var revision = _revision;
        using var request = new CancellationTokenSource();
        _request = request;
        Publish(new(ConnectionPhase.Checking, address, "Ожидаем ответ сервера…"));
        try
        {
            var result = await _client.ProbeAsync(address, request.Token);
            if (_disposed || revision != _revision) return;
            Publish(new(result.Available ? ConnectionPhase.Available : ConnectionPhase.Unavailable,
                address, result.Details, DateTimeOffset.UtcNow, result.Version, result.Database));
        }
        catch (OperationCanceledException) when (request.IsCancellationRequested) { }
        catch (Exception exception)
        {
            if (!_disposed && revision == _revision) OnUnexpectedError(exception);
            else Trace.TraceError(exception.ToString());
        }
        finally
        {
            if (ReferenceEquals(_request, request)) _request = null;
        }
    }

    private void Publish(ConnectionSnapshot snapshot)
    {
        _snapshot = snapshot;
        foreach (var name in new[] { nameof(Snapshot), nameof(StatusText), nameof(IsAvailable), nameof(HasError), nameof(LastCheckedText),
            nameof(IsDatabaseReady), nameof(HasDatabaseError), nameof(DatabaseStatusText), nameof(DatabaseDetails) })
            OnPropertyChanged(name);
    }

    private void OnUnexpectedError(Exception exception)
    {
        Trace.TraceError(exception.ToString());
        if (!_disposed) Publish(new(ConnectionPhase.Unavailable, Snapshot.Address,
            "Не удалось завершить проверку. Подробности записаны в диагностический вывод."));
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _revision++;
        _request?.Cancel();
        CheckCommand.Refresh();
    }
}
