using OurDLP.Contracts;
using OurDLP.Desktop.Infrastructure;

namespace OurDLP.Desktop.ViewModels;

public sealed class EnrollmentDisplay : ObservableObject
{
    private EnrollmentResponse? _value;
    public Guid? DeviceId => _value?.DeviceId;
    public bool Expired => _value is not null && _value.ExpiresAtUtc <= DateTimeOffset.UtcNow;
    public string Code => _value?.Code ?? string.Empty;
    public bool HasCode => _value is not null;
    public string ExpiresText => _value is { } value
        ? "Код действует до " + TimeZoneInfo.ConvertTime(value.ExpiresAtUtc, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss") + " МСК"
        : string.Empty;
    public void Show(EnrollmentResponse? value)
    {
        _value = value;
        OnPropertyChanged(nameof(Code)); OnPropertyChanged(nameof(HasCode)); OnPropertyChanged(nameof(ExpiresText));
    }
}
