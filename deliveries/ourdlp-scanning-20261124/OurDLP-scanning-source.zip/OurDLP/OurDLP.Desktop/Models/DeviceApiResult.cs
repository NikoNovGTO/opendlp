namespace OurDLP.Desktop.Models;

public sealed record DeviceApiResult<T>(T? Value, string? Error = null, bool SessionExpired = false);
