using OurDLP.Contracts;

namespace OurDLP.Desktop.Models;

public sealed record LoginAttempt(AdministratorResponse? Administrator, string Message)
{
    public bool Succeeded => Administrator is not null;
}
