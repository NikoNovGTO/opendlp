using System.Windows.Controls;

namespace OurDLP.Desktop.Views;

public partial class DatabaseSummaryView : UserControl
{
    public DatabaseSummaryView() => InitializeComponent();
}
