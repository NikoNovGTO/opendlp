using System.Windows.Controls;
using OurDLP.Desktop.ViewModels.Scanning;

namespace OurDLP.Desktop.Views;

public partial class ScanningView : UserControl
{
    public ScanningView()
    {
        InitializeComponent();
        Loaded += (_, _) =>
        {
            if (DataContext is ScanWorkspaceViewModel model && model.RefreshHistoryCommand.CanExecute(null))
                model.RefreshHistoryCommand.Execute(null);
        };
    }
}
