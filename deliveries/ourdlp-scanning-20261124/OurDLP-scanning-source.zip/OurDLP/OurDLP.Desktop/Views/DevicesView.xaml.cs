using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using OurDLP.Desktop.ViewModels;

namespace OurDLP.Desktop.Views;

public partial class DevicesView : UserControl
{
    private readonly DispatcherTimer _refresh = new() { Interval = TimeSpan.FromSeconds(15) };
    public DevicesView()
    {
        InitializeComponent();
        _refresh.Tick += (_, _) => Refresh();
        Loaded += (_, _) => { Refresh(); _refresh.Start(); };
        Unloaded += (_, _) => _refresh.Stop();
    }
    private void Refresh()
    {
        if (DataContext is DevicesViewModel viewModel && viewModel.RefreshCommand.CanExecute(null)) viewModel.RefreshCommand.Execute(null);
    }
}
