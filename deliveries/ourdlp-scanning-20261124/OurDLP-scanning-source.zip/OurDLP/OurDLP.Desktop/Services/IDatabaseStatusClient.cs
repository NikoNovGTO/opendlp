using OurDLP.Contracts;

namespace OurDLP.Desktop.Services;

public interface IDatabaseStatusClient
{
    Task<DatabaseStatusResponse> ProbeAsync(string address, CancellationToken cancellationToken);
}
