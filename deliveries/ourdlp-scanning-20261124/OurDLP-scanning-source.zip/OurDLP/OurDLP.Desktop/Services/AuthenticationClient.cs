using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public sealed class AuthenticationClient(HttpClient http) : IAuthenticationClient
{
    public async Task<LoginAttempt> LoginAsync(string address, string userName, string password, CancellationToken token)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized))
            return new(null, "Укажите корректный HTTPS-адрес сервера.");
        if (string.IsNullOrWhiteSpace(userName) || userName.Length > 64 || string.IsNullOrEmpty(password) || password.Length > 128)
            return new(null, "Укажите логин и пароль допустимой длины.");
        try
        {
            using var response = await http.PostAsJsonAsync(normalized + "/api/auth/login",
                new LoginRequest { UserName = userName.Trim(), Password = password }, token);
            if (!response.IsSuccessStatusCode) return new(null, FailureMessage(response.StatusCode));
            var administrator = await response.Content.ReadFromJsonAsync<AdministratorResponse>(token);
            if (administrator is null || administrator.Id == Guid.Empty || string.IsNullOrWhiteSpace(administrator.UserName)
                || administrator.ExpiresAtUtc == default)
                return new(null, "Сервер вернул некорректный ответ входа.");
            // Check the real protected endpoint, not just the login response body.
            using var current = await http.GetAsync(normalized + "/api/auth/me", token);
            if (!current.IsSuccessStatusCode) return new(null, "Не удалось подтвердить административный сеанс.");
            var verified = await current.Content.ReadFromJsonAsync<AdministratorResponse>(token);
            return verified?.Id == administrator.Id && verified.UserName == administrator.UserName
                ? new(verified, string.Empty) : new(null, "Не удалось подтвердить учётную запись.");
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        { return new(null, "Сервер не ответил вовремя. Повторите попытку."); }
        catch (Exception exception) when (exception is HttpRequestException or JsonException or NotSupportedException)
        { return new(null, "Не удалось выполнить вход. Проверьте сервер, HTTPS-сертификат и версию API."); }
    }

    public async Task<bool> LogoutAsync(string address, CancellationToken token)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized)) return false;
        try
        {
            using var response = await http.PostAsync(normalized + "/api/auth/logout", null, token);
            return response.IsSuccessStatusCode;
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return false; }
        catch (HttpRequestException) { return false; }
    }

    public async Task<bool?> IsSessionValidAsync(string address, Guid expectedUser, CancellationToken token)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized)) return false;
        try
        {
            using var response = await http.GetAsync(normalized + "/api/auth/me", token);
            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden) return false;
            if (!response.IsSuccessStatusCode) return null;
            var user = await response.Content.ReadFromJsonAsync<AdministratorResponse>(token);
            return user is not null && user.Id == expectedUser;
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return null; }
        catch (Exception exception) when (exception is HttpRequestException or JsonException or NotSupportedException) { return null; }
    }

    private static string FailureMessage(HttpStatusCode status) => (int)status switch
    {
        400 => "Проверьте логин и пароль: логин до 64 символов, пароль до 128.",
        401 => "Неверный логин или пароль либо вход временно заблокирован. После пяти ошибок подождите 15 минут.",
        403 => "Учётная запись не имеет прав администратора.",
        404 => "В этой версии сервера нет входа. Запустите новый OurDLP.Server.",
        429 => "Слишком много попыток входа. Подождите минуту и повторите.",
        503 => "База не готова. Проверьте PostgreSQL и примените миграции.",
        _ => "Сервер не смог выполнить вход. Проверьте его состояние."
    };
}
