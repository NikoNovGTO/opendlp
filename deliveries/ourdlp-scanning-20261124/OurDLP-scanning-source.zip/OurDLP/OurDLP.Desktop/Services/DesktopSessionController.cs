using Microsoft.Win32;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Services.Scanning;
using OurDLP.Desktop.ViewModels.Scanning;
using System.Net;
using System.Net.Http;
using System.Windows;
using OurDLP.Desktop.Infrastructure;
using OurDLP.Desktop.ViewModels;
using OurDLP.Desktop.Views;

namespace OurDLP.Desktop.Services;

public sealed class DesktopSessionController(Application application)
{
    public async Task RunAsync()
    {
        while (true)
        {
            // A fresh memory-only cookie jar for every sign-in cycle.
            using var http = new HttpClient(new HttpClientHandler
            { AllowAutoRedirect = false, UseCookies = true, CookieContainer = new CookieContainer() })
            { Timeout = TimeSpan.FromSeconds(5), MaxResponseContentBufferSize = 64 * 1024 };
            var auth = new AuthenticationClient(http);
            var store = new JsonSettingsStore();
            using var loginModel = new LoginViewModel(store, auth);
            var login = new LoginWindow(loginModel);
            application.MainWindow = login;
            if (login.ShowDialog() != true || login.Administrator is null) { application.Shutdown(); return; }

            var connection = new ServerConnectionViewModel(new ServerReadinessClient(new ServerApiClient(http), new DatabaseApiClient(http)));
            var settings = new SettingsViewModel(store, connection, canEditAddress: false);
            var window = new MainWindow();
            var closed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var reopenLogin = false;
            var isClosed = false;
            using var lifetime = new CancellationTokenSource();
            using var watchdog = new SessionWatchdog(login.Administrator.ExpiresAtUtc,
                token => auth.IsSessionValidAsync(loginModel.ServerAddress, login.Administrator.Id, token), () =>
            {
                if (isClosed) return;
                reopenLogin = true;
                MessageBox.Show(window, "Сеанс завершён или срок его действия истёк. Войдите повторно.", "OurDLP");
                window.Close();
            });
            var logout = new AsyncRelayCommand(async () =>
            {
                watchdog.Stop();
                bool revoked;
                try { revoked = await auth.LogoutAsync(loginModel.ServerAddress, lifetime.Token); }
                catch (OperationCanceledException) when (lifetime.IsCancellationRequested) { return; }
                if (isClosed) return;
                if (!revoked) MessageBox.Show(window,
                    "Сервер не подтвердил завершение сеансов. На этом компьютере вход будет сброшен; серверный сеанс действует до истечения срока.", "Выход OurDLP");
                reopenLogin = true;
                window.Close();
            }, exception =>
            {
                System.Diagnostics.Trace.TraceError(exception.GetType().Name);
                if (!isClosed)
                {
                    watchdog.Start();
                    MessageBox.Show(window, "Не удалось выполнить выход. Повторите попытку или закройте консоль.", "OurDLP");
                }
            });
            var devices = new DevicesViewModel(new DevicesClient(http, loginModel.ServerAddress),
                message => MessageBox.Show(window, message, "OurDLP", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes,
                () => { if (!isClosed) { reopenLogin = true; window.Close(); } });
            var scanning = new ScanWorkspaceViewModel(new FileScanner(), new JsonScanReportStore(),
                () => { var dialog = new OpenFolderDialog { Title = "Выберите тестовую папку для проверки" }; return dialog.ShowDialog(window) == true ? dialog.FolderName : null; },
                () => { var dialog = new SaveFileDialog { Title = "Экспорт обнаружений", Filter = "CSV (*.csv)|*.csv", FileName = "OurDLP-findings.csv", AddExtension = true, OverwritePrompt = true }; return dialog.ShowDialog(window) == true ? dialog.FileName : null; },
                new ScanSampleFactory().Create);
            window.DataContext = new MainWindowViewModel(new MoscowClock(), settings, connection, login.Administrator, logout, devices, scanning);
            window.Closed += (_, _) => { isClosed = true; lifetime.Cancel(); closed.TrySetResult(); };
            application.MainWindow = window;
            window.Show();
            watchdog.Start();
            await closed.Task;
            if (!reopenLogin) { application.Shutdown(); return; }
        }
    }
}
