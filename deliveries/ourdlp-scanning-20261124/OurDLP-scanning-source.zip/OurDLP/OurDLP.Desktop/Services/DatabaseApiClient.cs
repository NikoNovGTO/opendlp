using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Contracts;

namespace OurDLP.Desktop.Services;

public sealed class DatabaseApiClient(HttpClient httpClient) : IDatabaseStatusClient
{
    public async Task<DatabaseStatusResponse> ProbeAsync(string address, CancellationToken cancellationToken)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized))
            return new("unavailable", "Укажите корректный HTTPS-адрес сервера.");
        try
        {
            using var response = await httpClient.GetAsync(new Uri(normalized + "/api/health/database"), cancellationToken);
            if (response.StatusCode == HttpStatusCode.NotFound)
                return new("unavailable", "В этой версии сервера нет проверки PostgreSQL. Обновите OurDLP.Server.");
            if (response.StatusCode is not (HttpStatusCode.OK or HttpStatusCode.ServiceUnavailable))
                return new("unavailable", $"Проверка базы вернула HTTP {(int)response.StatusCode}.");
            var status = await response.Content.ReadFromJsonAsync<DatabaseStatusResponse>(cancellationToken);
            var ready = status?.Status == "ready" && response.StatusCode == HttpStatusCode.OK;
            var notReady = status?.Status is "not-configured" or "migration-required" or "unavailable"
                && response.StatusCode == HttpStatusCode.ServiceUnavailable;
            return status is not null && !string.IsNullOrWhiteSpace(status.Message) && (ready || notReady)
                ? status : new("unavailable", "Получен некорректный ответ проверки PostgreSQL.");
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return new("unavailable", "Истекло время ожидания проверки PostgreSQL.");
        }
        catch (Exception exception) when (exception is HttpRequestException or JsonException or NotSupportedException)
        {
            return new("unavailable", "Не удалось получить состояние PostgreSQL. API ответил, но проверка базы не завершилась.");
        }
    }
}
