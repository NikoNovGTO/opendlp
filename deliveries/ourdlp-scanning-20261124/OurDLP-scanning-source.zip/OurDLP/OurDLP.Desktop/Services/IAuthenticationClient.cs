using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public interface IAuthenticationClient
{
    Task<LoginAttempt> LoginAsync(string address, string userName, string password, CancellationToken token);
    Task<bool> LogoutAsync(string address, CancellationToken token);
    Task<bool?> IsSessionValidAsync(string address, Guid expectedUser, CancellationToken token);
}
