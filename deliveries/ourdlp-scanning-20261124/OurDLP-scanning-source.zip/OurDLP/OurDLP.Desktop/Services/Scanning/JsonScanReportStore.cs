using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using OurDLP.Core.Scanning;

namespace OurDLP.Desktop.Services.Scanning;

public sealed class JsonScanReportStore : IScanReportStore
{
    private const int MaxBytes = 8 * 1024 * 1024;
    private readonly string _directory;
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true, MaxDepth = 32, Converters = { new JsonStringEnumConverter() } };
    public JsonScanReportStore(string? directory = null) => _directory = directory ?? Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OurDLP", "Scans");
    public async Task SaveAsync(ScanReport report, CancellationToken token)
    {
        Validate(report);
        var json = JsonSerializer.SerializeToUtf8Bytes(report, Options);
        if (json.Length > MaxBytes) throw new InvalidDataException("Отчёт превышает предел локального хранения.");
        Directory.CreateDirectory(_directory);
        var temporary = Path.Combine(_directory, Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            await File.WriteAllBytesAsync(temporary, json, token);
            token.ThrowIfCancellationRequested();
            File.Move(temporary, FileName(report.Id), true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
        foreach (var old in ReportFiles().Skip(20))
            try { File.Delete(old.FullName); } catch (Exception error) when (error is IOException or UnauthorizedAccessException) { }
    }
    public async Task<ScanReport> LoadAsync(Guid id, CancellationToken token)
    {
        await using var stream = new FileStream(FileName(id), FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length > MaxBytes) throw new InvalidDataException("Отчёт слишком большой.");
        var data = new byte[checked((int)stream.Length)];
        await stream.ReadExactlyAsync(data, token);
        var report = JsonSerializer.Deserialize<ScanReport>(data, Options) ?? throw new InvalidDataException("Отчёт пуст.");
        Validate(report);
        if (report.Id != id) throw new InvalidDataException("Идентификатор отчёта не совпадает.");
        return report;
    }
    public async Task<ScanHistoryList> ListAsync(CancellationToken token)
    {
        var entries = new List<ScanHistoryEntry>(); var unreadable = 0;
        foreach (var file in ReportFiles().Take(20))
        {
            token.ThrowIfCancellationRequested();
            try
            {
                var report = await LoadAsync(Guid.ParseExact(Path.GetFileNameWithoutExtension(file.Name), "N"), token);
                entries.Add(new(report.Id, report.StartedAtUtc, report.Completion, report.FilesScanned, report.Findings.Count));
            }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException or JsonException or InvalidDataException) { unreadable++; }
        }
        return new(entries.OrderByDescending(row => row.StartedAtUtc).ToArray(), unreadable);
    }
    private IEnumerable<FileInfo> ReportFiles() => !Directory.Exists(_directory) ? [] : new DirectoryInfo(_directory)
        .EnumerateFiles("*.json").Where(file => Guid.TryParseExact(Path.GetFileNameWithoutExtension(file.Name), "N", out _))
        .OrderByDescending(file => file.LastWriteTimeUtc);
    private string FileName(Guid id) => Path.Combine(_directory, id.ToString("N") + ".json");
    private static void Validate(ScanReport report)
    {
        if (report.SchemaVersion != 1 || report.Id == Guid.Empty || !Enum.IsDefined(report.Completion)
            || report.Findings is null || report.Issues is null || report.Rules is null || report.ExcludedDirectories is null
            || report.Findings.Count > 1_000 || report.Issues.Count > 100 || report.Rules.Count > 20
            || report.RootPath is null || report.Message is null || report.Limits is null
            || report.FilesScanned < 0 || report.FilesSkipped < 0 || report.IssueCount < 0
            || report.Findings.Any(row => row is null || row.Id == Guid.Empty || row.FilePath is null
                || row.RelativePath is null || row.RuleName is null || row.Matches is < 1 or > 1_000)
            || report.Rules.Any(row => row is null || row.Name is null || row.Pattern is null)
            || report.Issues.Any(row => row is null || row.Path is null || row.Code is null || row.Message is null))
            throw new InvalidDataException("Неизвестный или повреждённый формат отчёта.");
    }
}
