using System.IO;
using OurDLP.Core.Scanning;

namespace OurDLP.Desktop.Services.Scanning;

public sealed record ScanHistoryEntry(Guid Id, DateTimeOffset StartedAtUtc, ScanCompletion Completion, int FilesScanned, int Findings)
{
    public string Display => TimeZoneInfo.ConvertTime(StartedAtUtc, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")).ToString("dd.MM.yyyy HH:mm:ss")
        + $" МСК · файлов {FilesScanned}, обнаружений {Findings}";
}
public sealed record ScanHistoryList(IReadOnlyList<ScanHistoryEntry> Entries, int UnreadableCount);
public interface IScanReportStore
{
    Task SaveAsync(ScanReport report, CancellationToken token);
    Task<ScanReport> LoadAsync(Guid id, CancellationToken token);
    Task<ScanHistoryList> ListAsync(CancellationToken token);
}
