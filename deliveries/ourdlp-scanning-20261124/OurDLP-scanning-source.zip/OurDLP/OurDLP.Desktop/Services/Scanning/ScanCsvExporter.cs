using System.IO;
using System.Globalization;
using System.Text;
using OurDLP.Core.Scanning;

namespace OurDLP.Desktop.Services.Scanning;

public static class ScanCsvExporter
{
    public static async Task ExportAsync(ScanReport report, string path, CancellationToken token)
    {
        var output = new StringBuilder("ScanId;DetectedAtUtc;Rule;FilePath;Matches;CountLimited\r\n");
        foreach (var finding in report.Findings)
        {
            token.ThrowIfCancellationRequested();
            output.AppendJoin(';', Cell(report.Id.ToString()), Cell(finding.DetectedAtUtc.ToString("O", CultureInfo.InvariantCulture)),
                Cell(finding.RuleName), Cell(finding.FilePath), Cell(finding.Matches.ToString(CultureInfo.InvariantCulture)), Cell(finding.CountLimited ? "yes" : "no"));
            output.Append("\r\n");
        }
        var destination = Path.GetFullPath(path);
        var temporary = Path.Combine(Path.GetDirectoryName(destination)!, Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            await File.WriteAllTextAsync(temporary, output.ToString(), new UTF8Encoding(true), token);
            token.ThrowIfCancellationRequested();
            File.Move(temporary, destination, true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    private static string Cell(string value)
    {
        // Spreadsheet programs must treat file names and rule names as text.
        var trimmed = value.TrimStart();
        if (trimmed.Length > 0 && "=+-@".Contains(trimmed[0])) value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
