using System.Windows.Threading;

namespace OurDLP.Desktop.Services;

public sealed class SessionWatchdog : IDisposable
{
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(15) };
    private readonly CancellationTokenSource _lifetime = new();
    private readonly DateTimeOffset _expiresAtUtc;
    private readonly Func<CancellationToken, Task<bool?>> _validate;
    private readonly Action _expired;
    private DateTimeOffset _lastCheck = DateTimeOffset.UtcNow;
    private bool _checking;
    private bool _disposed;
    private int _generation;

    public SessionWatchdog(DateTimeOffset expiresAtUtc, Func<CancellationToken, Task<bool?>> validate, Action expired)
    {
        _expiresAtUtc = expiresAtUtc;
        _validate = validate;
        _expired = expired;
        _timer.Tick += OnTick;
    }
    public void Start() { if (!_disposed) _timer.Start(); }
    public void Stop() { _generation++; _timer.Stop(); }

    private async void OnTick(object? sender, EventArgs e)
    {
        if (_disposed || _checking) return;
        if (DateTimeOffset.UtcNow >= _expiresAtUtc) { Stop(); _expired(); return; }
        if (DateTimeOffset.UtcNow - _lastCheck < TimeSpan.FromMinutes(1)) return;
        var generation = _generation;
        _checking = true;
        _lastCheck = DateTimeOffset.UtcNow;
        try
        {
            var valid = await _validate(_lifetime.Token);
            if (!_disposed && generation == _generation && valid == false) { Stop(); _expired(); }
        }
        catch (OperationCanceledException) when (_lifetime.IsCancellationRequested) { }
        catch (Exception exception) { System.Diagnostics.Trace.TraceError(exception.GetType().Name); }
        finally { _checking = false; if (_disposed) _lifetime.Dispose(); }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        Stop();
        _timer.Tick -= OnTick;
        _lifetime.Cancel();
        if (!_checking) _lifetime.Dispose();
    }
}
