using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public sealed class DevicesClient(HttpClient http, string address) : IDevicesClient
{
    public Task<DeviceApiResult<DeviceListResponse>> ListAsync(CancellationToken token) => SendAsync<DeviceListResponse>(HttpMethod.Get, "", null, token);
    public Task<DeviceApiResult<EnrollmentResponse>> CreateAsync(string name, CancellationToken token) => SendAsync<EnrollmentResponse>(HttpMethod.Post, "", new CreateDeviceRequest { Name = name }, token);
    public Task<DeviceApiResult<EnrollmentResponse>> ReissueAsync(Guid id, CancellationToken token) => SendAsync<EnrollmentResponse>(HttpMethod.Post, $"/{id}/enrollment", null, token);
    public Task<DeviceApiResult<DeviceOperationResponse>> RevokeAsync(Guid id, CancellationToken token) => SendAsync<DeviceOperationResponse>(HttpMethod.Post, $"/{id}/revoke", null, token);

    private async Task<DeviceApiResult<T>> SendAsync<T>(HttpMethod method, string path, object? body, CancellationToken token)
    {
        if (!ServerAddressValidator.TryNormalize(address, out var normalized)) return new(default, "Некорректный адрес сервера.");
        using var request = new HttpRequestMessage(method, normalized + "/api/devices" + path);
        if (body is not null) request.Content = JsonContent.Create(body);
        try
        {
            using var response = await http.SendAsync(request, token);
            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden) return new(default, "Сеанс завершён. Войдите повторно.", true);
            if (!response.IsSuccessStatusCode) return new(default, $"Операция не выполнена (HTTP {(int)response.StatusCode}). Проверьте состояние сервера и обновите список.");
            var value = await response.Content.ReadFromJsonAsync<T>(token);
            return value is null ? new(default, "Сервер вернул пустой ответ.") : new(value);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested) { return new(default, "Сервер не ответил вовремя. Повторите запрос."); }
        catch (Exception exception) when (exception is HttpRequestException or JsonException or NotSupportedException)
        { return new(default, "Не удалось выполнить запрос. Проверьте соединение и версию сервера."); }
    }
}
