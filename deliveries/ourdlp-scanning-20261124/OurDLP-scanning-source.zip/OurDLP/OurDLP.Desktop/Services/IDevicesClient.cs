using OurDLP.Contracts;
using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public interface IDevicesClient
{
    Task<DeviceApiResult<DeviceListResponse>> ListAsync(CancellationToken token);
    Task<DeviceApiResult<EnrollmentResponse>> CreateAsync(string name, CancellationToken token);
    Task<DeviceApiResult<EnrollmentResponse>> ReissueAsync(Guid id, CancellationToken token);
    Task<DeviceApiResult<DeviceOperationResponse>> RevokeAsync(Guid id, CancellationToken token);
}
