using OurDLP.Desktop.Models;

namespace OurDLP.Desktop.Services;

public sealed class ServerReadinessClient(IServerStatusClient server, IDatabaseStatusClient database) : IServerStatusClient
{
    public async Task<ServerProbeResult> ProbeAsync(string address, CancellationToken cancellationToken)
    {
        var result = await server.ProbeAsync(address, cancellationToken);
        if (!result.Available) return result;
        var databaseStatus = await database.ProbeAsync(address, cancellationToken);
        return result with { Database = databaseStatus };
    }
}
