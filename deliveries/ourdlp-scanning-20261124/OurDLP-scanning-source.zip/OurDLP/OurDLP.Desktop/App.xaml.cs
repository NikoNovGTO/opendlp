using System.Windows;
using OurDLP.Desktop.Services;

namespace OurDLP.Desktop;

public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try { await new DesktopSessionController(this).RunAsync(); }
        catch (Exception exception)
        {
            System.Diagnostics.Trace.TraceError(exception.GetType().Name);
            MessageBox.Show("Не удалось запустить консоль. Проверьте локальные настройки.", "OurDLP");
            Shutdown(1);
        }
    }
}
