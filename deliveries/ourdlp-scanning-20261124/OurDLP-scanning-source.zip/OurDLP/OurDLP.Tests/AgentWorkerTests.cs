using System.Net;
using System.Net.Http.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging.Abstractions;
using OurDLP.Agent;
using OurDLP.Contracts;
using OurDLP.Server.Agents;
using Xunit;

namespace OurDLP.Tests;

public sealed class AgentWorkerTests
{
    [Fact]
    public async Task ServiceConfirmsItsOwnHeartbeatWithoutRegistrationOrAdminCookie()
    {
        var store=new ObservedStore();var id=Guid.NewGuid();
        await store.SaveAsync(new AgentState{ServerAddress="https://localhost",DeviceId=id,Token=AgentSecrets.Create()},default);
        using var http=new HttpClient(new Handler(request=>
        {
            Assert.Equal("/api/agent/heartbeat",request.RequestUri!.AbsolutePath);
            Assert.Equal("Bearer",request.Headers.Authorization!.Scheme);
            Assert.False(request.Headers.Contains("Cookie"));
            return new(HttpStatusCode.OK){Content=JsonContent.Create(new AgentAcknowledgement(id,DateTimeOffset.UtcNow))};
        }));
        var lifetime=new Lifetime();using var worker=new AgentWorker(store,new(http),NullLogger<AgentWorker>.Instance,lifetime);
        await worker.StartAsync(default);
        await store.Contact.Task.WaitAsync(TimeSpan.FromSeconds(5));
        await worker.StopAsync(default);
        Assert.NotNull(store.State!.ServiceContactConfirmedAtUtc);
        Assert.Equal(id,store.State.DeviceId);
        Assert.False(lifetime.Stopped.Task.IsCompleted);
    }
    [Fact]
    public async Task RevokedCredentialStopsWorkerWithoutAutomaticEnrollment()
    {
        var store=new ObservedStore();await store.SaveAsync(new AgentState{DeviceId=Guid.NewGuid(),ServerAddress="https://localhost",Token=AgentSecrets.Create()},default);
        int requests=0;
        using var http=new HttpClient(new Handler(request=>{requests++;Assert.Equal("/api/agent/heartbeat",request.RequestUri!.AbsolutePath);return new(HttpStatusCode.Unauthorized);}));
        var lifetime=new Lifetime();using var worker=new AgentWorker(store,new(http),NullLogger<AgentWorker>.Instance,lifetime);
        await worker.StartAsync(default);await lifetime.Stopped.Task.WaitAsync(TimeSpan.FromSeconds(5));await worker.StopAsync(default);
        Assert.Equal(1,requests);Assert.Null(store.State!.ServiceContactConfirmedAtUtc);
    }
    [Fact]
    public void HttpAndCredentialUrlsAreRejected()
    {
        Assert.Throws<InvalidOperationException>(()=>AgentAddress.Normalize("http://localhost"));
        Assert.Throws<InvalidOperationException>(()=>AgentAddress.Normalize("https://user:password@host"));
        Assert.Throws<InvalidOperationException>(()=>AgentAddress.Normalize("https://host/api"));
    }
    private sealed class ObservedStore:IAgentStateStore
    {
        public AgentState? State{get;private set;}
        public TaskCompletionSource Contact{get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
        public Task<AgentState?> ReadAsync(CancellationToken token)=>Task.FromResult(State);
        public Task SaveAsync(AgentState state,CancellationToken token){State=state;if(state.ServiceContactConfirmedAtUtc is not null)Contact.TrySetResult();return Task.CompletedTask;}
    }
    private sealed class Handler(Func<HttpRequestMessage,HttpResponseMessage> send):HttpMessageHandler
    {protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)=>Task.FromResult(send(request));}
    private sealed class Lifetime:IHostApplicationLifetime
    {
        public TaskCompletionSource Stopped{get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
        public CancellationToken ApplicationStarted=>default;public CancellationToken ApplicationStopping=>default;public CancellationToken ApplicationStopped=>default;
        public void StopApplication()=>Stopped.TrySetResult();
    }
}
