using System.Net.Http.Json;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Contracts;
using OurDLP.Server.Authentication;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;
using Xunit;

namespace OurDLP.Tests;

public sealed class AgentTestContext:IAsyncDisposable
{
    public PostgresTestDatabase Database{get;private set;}=null!;
    public DatabaseTestServer Server{get;private set;}=null!;
    public HttpClient Admin{get;private set;}=null!;
    public static async Task<AgentTestContext> CreateAsync()
    {
        var context=new AgentTestContext();
        context.Database=await PostgresTestDatabase.CreateAsync();
        context.Server=new DatabaseTestServer(context.Database.ConnectionString);
        context.Admin=context.Server.CreateClient(new(){BaseAddress=new Uri("https://localhost"),AllowAutoRedirect=false});
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(context.Server.Services));
        await using var scope=context.Server.Services.CreateAsyncScope();
        var users=scope.ServiceProvider.GetRequiredService<UserManager<Administrator>>();
        var roles=scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        Assert.True((await roles.CreateAsync(new(AuthDefaults.AdministratorRole))).Succeeded);
        var user=new Administrator{Id=Guid.NewGuid(),UserName="test-admin"};
        Assert.True((await users.CreateAsync(user,"ValidTestPassword2026!")).Succeeded);
        Assert.True((await users.AddToRoleAsync(user,AuthDefaults.AdministratorRole)).Succeeded);
        var login=await context.Admin.PostAsJsonAsync("/api/auth/login",new LoginRequest{UserName=user.UserName,Password="ValidTestPassword2026!"});
        Assert.True(login.IsSuccessStatusCode);
        return context;
    }
    public HttpClient Agent()=>Server.CreateClient(new(){BaseAddress=new Uri("https://localhost"),AllowAutoRedirect=false,HandleCookies=false});
    public async Task<EnrollmentResponse> AddAsync(string name="TEST-PC-02")
    {
        using var response=await Admin.PostAsJsonAsync("/api/devices",new CreateDeviceRequest{Name=name});
        Assert.True(response.IsSuccessStatusCode);
        Assert.True(response.Headers.CacheControl!.NoStore);
        return (await response.Content.ReadFromJsonAsync<EnrollmentResponse>())!;
    }
    public async ValueTask DisposeAsync(){Admin.Dispose();await Server.DisposeAsync();await Database.DisposeAsync();}
}
