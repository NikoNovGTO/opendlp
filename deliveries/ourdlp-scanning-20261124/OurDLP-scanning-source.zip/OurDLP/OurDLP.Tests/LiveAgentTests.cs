using System.Net;
using System.Net.Http.Headers;
using System.Text.Json;
using OurDLP.Agent;
using OurDLP.Contracts;
using OurDLP.Desktop.Services;
using Xunit;

namespace OurDLP.Tests;

[Collection("Live server")]
public sealed class LiveAgentTests
{
    [LiveAuthenticationFact][Trait("Category","Integration")]
    public async Task RealHttpsEnrollmentHeartbeatRegistryAndRevocation()
    {
        var address=Environment.GetEnvironmentVariable("OURDLP_LIVE_BASE_URL")!;
        var expected=Environment.GetEnvironmentVariable("OURDLP_EXPECT_LOGIN_SUCCESS")=="1";
        var credential=JsonSerializer.Deserialize<LoginRequest>(await File.ReadAllTextAsync(Environment.GetEnvironmentVariable("OURDLP_LIVE_LOGIN_FILE")!),new JsonSerializerOptions(JsonSerializerDefaults.Web))!;
        using var adminHttp=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false,UseCookies=true,CookieContainer=new()}){Timeout=TimeSpan.FromSeconds(5)};
        var auth=new AuthenticationClient(adminHttp);
        var login=await auth.LoginAsync(address,credential.UserName,credential.Password,default);
        Assert.Equal(expected,login.Succeeded);if(!expected)return;
        var devices=new DevicesClient(adminHttp,address);
        var enrollment=await devices.CreateAsync("LIVE-AGENT-"+Guid.NewGuid().ToString("N")[..8],default);
        Assert.NotNull(enrollment.Value);
        try
        {
            using var agentHttp=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false,UseCookies=false}){Timeout=TimeSpan.FromSeconds(10)};
            var state=new MemoryAgentState();var protocol=new AgentProtocolClient(agentHttp);
            var registered=await new AgentEnrollment(state,protocol).EnrollAsync(address,enrollment.Value.Code,false,default);
            Assert.True(registered.Succeeded);Assert.Equal(enrollment.Value.DeviceId,state.State!.DeviceId);
            Assert.True((await protocol.HeartbeatAsync(state.State,default)).Succeeded);
            var list=await devices.ListAsync(default);
            Assert.Equal("active",list.Value!.Devices.Single(row=>row.Id==enrollment.Value.DeviceId).Status);
            using var forbidden=new HttpRequestMessage(HttpMethod.Get,address+"/api/devices");
            forbidden.Headers.Authorization=new AuthenticationHeaderValue("Bearer",state.State.Token);
            Assert.Equal(HttpStatusCode.Unauthorized,(await agentHttp.SendAsync(forbidden)).StatusCode);
            Assert.NotNull((await devices.RevokeAsync(enrollment.Value.DeviceId,default)).Value);
            Assert.True((await protocol.HeartbeatAsync(state.State,default)).AccessDenied);
        }
        finally {await devices.RevokeAsync(enrollment.Value!.DeviceId,default);await auth.LogoutAsync(address,default);}
    }
}
