using OurDLP.Core.Scanning;

namespace OurDLP.Tests.Scanning;

public sealed class ScanFiles : IDisposable
{
    public string Root { get; } = Path.Combine(Path.GetTempPath(), "ourdlp-scan-" + Guid.NewGuid().ToString("N"));
    public ScanFiles() => Directory.CreateDirectory(Root);
    public string Write(string relative, string text)
    {
        var path = Path.Combine(Root, relative); Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path, text, new System.Text.UTF8Encoding(false)); return path;
    }
    public ScanRequest Request(string pattern = "OURDLP-TEST-[0-9]{4}", ScanLimits? limits = null) =>
        new(Root, [new(Guid.NewGuid(), "Тестовый маркер", pattern)], ["excluded"], limits ?? new());
    public void Dispose() { if (Directory.Exists(Root)) Directory.Delete(Root, true); }
}
internal sealed class ImmediateProgress(Action<ScanProgress> report) : IProgress<ScanProgress>
{ public void Report(ScanProgress value) => report(value); }
