using System.Text;
using System.Text.Json;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Services.Scanning;
using Xunit;

namespace OurDLP.Tests.Scanning;

public sealed class ScanHistoryTests
{
    [Fact]
    public async Task RealScanSurvivesStoreRecreationWithoutKeepingMatchedText()
    {
        using var files=new ScanFiles();files.Write("data.txt","OURDLP-TEST-4321");
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        var directory=Path.Combine(files.Root,"history");await new JsonScanReportStore(directory).SaveAsync(report,default);
        var reopened=new JsonScanReportStore(directory);var loaded=await reopened.LoadAsync(report.Id,default);
        Assert.Equal(report.Findings,loaded.Findings);Assert.Equal(report.Completion,loaded.Completion);
        Assert.Single((await reopened.ListAsync(default)).Entries);
        Assert.DoesNotContain("OURDLP-TEST-4321",await File.ReadAllTextAsync(Directory.GetFiles(directory,"*.json").Single()));
    }
    [Fact]
    public async Task KeepsLatestTwentyReportsAndIgnoresUnrelatedFiles()
    {
        using var files=new ScanFiles();var store=new JsonScanReportStore(files.Root);
        files.Write("notes.json","unrelated");
        for(var i=0;i<23;i++)await store.SaveAsync(new(){StartedAtUtc=DateTimeOffset.UtcNow.AddSeconds(i)},default);
        Assert.Equal(20,(await store.ListAsync(default)).Entries.Count);Assert.True(File.Exists(Path.Combine(files.Root,"notes.json")));
    }
    [Fact]
    public async Task CorruptAndFutureReportsAreReportedWithoutDeletion()
    {
        using var files=new ScanFiles();var bad=Guid.NewGuid();var future=Guid.NewGuid();var missingFinding=Guid.NewGuid();
        files.Write(bad.ToString("N")+".json","{broken");
        files.Write(future.ToString("N")+".json",JsonSerializer.Serialize(new ScanReport{Id=future,SchemaVersion=99}));
        files.Write(missingFinding.ToString("N")+".json",JsonSerializer.Serialize(new ScanReport{Id=missingFinding,Findings=[null!]}));
        var store=new JsonScanReportStore(files.Root);var result=await store.ListAsync(default);
        Assert.Empty(result.Entries);Assert.Equal(3,result.UnreadableCount);Assert.Equal(3,Directory.GetFiles(files.Root).Length);
    }
    [Fact]
    public async Task CancelledWritePreservesExistingReportAndCleansTemporaryFiles()
    {
        using var files=new ScanFiles();var store=new JsonScanReportStore(files.Root);var original=new ScanReport{Message="original"};
        await store.SaveAsync(original,default);
        await Assert.ThrowsAnyAsync<OperationCanceledException>(()=>store.SaveAsync(original with{Message="changed"},new CancellationToken(true)));
        Assert.Equal("original",(await store.LoadAsync(original.Id,default)).Message);Assert.Empty(Directory.GetFiles(files.Root,"*.tmp"));
    }
    [Fact]
    public async Task CsvIsQuotedHasRealLinesUtf8BomAndNeutralizesSpreadsheetFormulas()
    {
        using var files=new ScanFiles();var path=Path.Combine(files.Root,"report.csv");
        var report=new ScanReport{Findings=[new(Guid.NewGuid(),"a;\"b.txt","a",Guid.NewGuid()," \t=HYPERLINK(\"bad\")",3,false,DateTimeOffset.UtcNow)]};
        await ScanCsvExporter.ExportAsync(report,path,default);
        var bytes=await File.ReadAllBytesAsync(path);Assert.Equal(new byte[]{0xef,0xbb,0xbf},bytes[..3]);
        var text=Encoding.UTF8.GetString(bytes);Assert.Equal(2,text.Split("\r\n",StringSplitOptions.RemoveEmptyEntries).Length);
        Assert.Contains("\"' \t=HYPERLINK(\"\"bad\"\")\"",text);Assert.Contains("\"a;\"\"b.txt\"",text);
    }
}
