using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using OurDLP.Core.Scanning;
using OurDLP.Desktop.Services.Scanning;
using Xunit;

namespace OurDLP.Tests.Scanning;

public sealed class FileScannerTests
{
    [Fact]
    public async Task DemoFindsThreeMarkersInTwoFilesWithoutChangingSourceOrRecordingValues()
    {
        using var files = new ScanFiles();
        var sample = new ScanSampleFactory(files.Root).Create();
        var paths = Directory.GetFiles(sample, "*", SearchOption.AllDirectories);
        var before = paths.ToDictionary(path => path, path => SHA256.HashData(File.ReadAllBytes(path)));
        var report = await new FileScanner().ScanAsync(files.Request() with { RootPath = sample }, null, default);
        Assert.Equal(ScanCompletion.Completed, report.Completion); Assert.Equal(3, report.FilesScanned);
        Assert.Equal(2, report.Findings.Count); Assert.Equal(3, report.Findings.Sum(row => row.Matches));
        Assert.Empty(report.Issues); Assert.DoesNotContain(report.Findings, row => row.FilePath.Contains("excluded"));
        var json = JsonSerializer.Serialize(report);
        foreach (var marker in new[] { "OURDLP-TEST-0001", "OURDLP-TEST-0002", "OURDLP-TEST-0003", "OURDLP-TEST-9999" }) Assert.DoesNotContain(marker, json);
        foreach (var path in paths) Assert.Equal(before[path], SHA256.HashData(File.ReadAllBytes(path)));
    }
    [Theory]
    [InlineData("utf8")][InlineData("utf16-le")][InlineData("utf16-be")]
    public async Task ReadsSupportedEncodingsAndCaseInsensitiveExtension(string encoding)
    {
        using var files = new ScanFiles();
        Encoding codec = encoding switch { "utf16-le" => new UnicodeEncoding(false, true, true), "utf16-be" => new UnicodeEncoding(true, true, true), _ => new UTF8Encoding(true, true) };
        File.WriteAllText(Path.Combine(files.Root, "Данные.TXT"), "Секретный маркер OURDLP-TEST-1234", codec);
        var report = await new FileScanner().ScanAsync(files.Request(), null, default);
        Assert.Single(report.Findings); Assert.Empty(report.Issues);
    }
    [Fact]
    public async Task SkipsInvalidEncodingBinaryAndOversizedFilesWithReasons()
    {
        using var files = new ScanFiles();
        File.WriteAllBytes(Path.Combine(files.Root, "bad.txt"), [0xff,0xff,0x41]);
        files.Write("binary.csv", "before\0OURDLP-TEST-1234"); files.Write("large.log", new string('a', 101));
        var report = await new FileScanner().ScanAsync(files.Request(limits:new(){MaxFileBytes=100}), null, default);
        Assert.Empty(report.Findings); Assert.Equal(3, report.FilesSkipped); Assert.Equal(3, report.IssueCount);
        Assert.Contains(report.Issues, issue => issue.Code == "size"); Assert.Equal(2, report.Issues.Count(issue => issue.Code == "encoding"));
    }
    [Fact]
    public async Task RelativeExclusionCoversDescendantsButDoesNotExcludeSimilarNames()
    {
        using var files = new ScanFiles();
        files.Write("excluded/nested/skip.txt", "OURDLP-TEST-0001"); files.Write("excluded-other/keep.log", "OURDLP-TEST-0002");
        var report = await new FileScanner().ScanAsync(files.Request(), null, default);
        Assert.Equal("keep.log", Path.GetFileName(Assert.Single(report.Findings).FilePath));
    }
    [Theory]
    [InlineData("../outside")][InlineData("nested/../../outside")][InlineData("/absolute")]
    public async Task RejectsEscapingOrAbsoluteExclusions(string excluded)
    {
        using var files = new ScanFiles();
        await Assert.ThrowsAsync<ArgumentException>(() => new FileScanner().ScanAsync(files.Request() with { ExcludedDirectories=[excluded] }, null, default));
    }
    [Fact]
    public async Task RejectsInvalidRegexBeforeScanning()
    {
        using var files = new ScanFiles(); files.Write("data.txt", "OURDLP-TEST-0001");
        await Assert.ThrowsAsync<ArgumentException>(() => new FileScanner().ScanAsync(files.Request("("), null, default));
    }
    [Fact]
    public async Task BoundsCatastrophicRegexAndReportsIncompleteFile()
    {
        using var files = new ScanFiles(); files.Write("data.txt", new string('a', 20_000) + "!");
        var report = await new FileScanner().ScanAsync(files.Request("^(a+)+$"), null, default).WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Contains(report.Issues, issue => issue.Code == "regex-timeout"); Assert.Empty(report.Findings);
    }
    [Fact]
    public async Task MatchCapDistinguishesExactCountFromTruncatedCount()
    {
        using var files = new ScanFiles(); files.Write("exact.txt", "xxx"); files.Write("extra.txt", "xxxx");
        var report = await new FileScanner().ScanAsync(files.Request("x",new(){MaxMatchesPerFile=3}), null, default);
        Assert.Equal(2, report.Findings.Count);
        Assert.False(report.Findings.Single(row => row.RelativePath == "exact.txt").CountLimited);
        var extra = report.Findings.Single(row => row.RelativePath == "extra.txt"); Assert.True(extra.CountLimited); Assert.Equal(3, extra.Matches);
    }
    [Fact]
    public async Task FileAndTraversalCapsProduceExplicitPartialReports()
    {
        using var files = new ScanFiles(); for (var i=0;i<4;i++) files.Write(i+".txt", "OURDLP-TEST-0001");
        var limited = await new FileScanner().ScanAsync(files.Request(limits:new(){MaxFiles=1}), null, default);
        Assert.Equal(ScanCompletion.LimitReached, limited.Completion); Assert.Single(limited.Findings); Assert.Equal(1, limited.FilesScanned);
        var traversal = await new FileScanner().ScanAsync(files.Request(limits:new(){MaxEntries=1}), null, default);
        Assert.Equal(ScanCompletion.LimitReached, traversal.Completion); Assert.Equal(1, traversal.EntriesVisited);
    }
    [Fact]
    public async Task BoundsFindingsAndVisibleIssues()
    {
        using var files = new ScanFiles(); files.Write("one.txt", "x"); files.Write("two.txt", "x");
        var report = await new FileScanner().ScanAsync(files.Request("x", new(){MaxFindings=1}), null, default);
        Assert.Equal(ScanCompletion.LimitReached, report.Completion); Assert.Single(report.Findings);
        files.Write("a.txt", new string('a',200));files.Write("b.txt",new string('a',200));
        var issues = await new FileScanner().ScanAsync(files.Request(limits:new(){MaxFileBytes=100,MaxIssues=1}),null,default);
        Assert.Equal(2, issues.IssueCount); Assert.Single(issues.Issues);
    }
    [Fact]
    public async Task CancellationKeepsPartialFindingsAndDoesNotBecomeSuccess()
    {
        using var files = new ScanFiles(); for(var i=0;i<3;i++)files.Write(i+".txt","OURDLP-TEST-0001");
        using var cancel = new CancellationTokenSource();
        var progress = new ImmediateProgress(value => { if(value.FilesScanned == 1)cancel.Cancel(); });
        var report = await new FileScanner().ScanAsync(files.Request(),progress,cancel.Token);
        Assert.Equal(ScanCompletion.Cancelled,report.Completion); Assert.Single(report.Findings); Assert.Equal(1,report.FilesScanned);
    }
    [Fact]
    public async Task AlreadyCancelledScanReturnsAnEmptyCancelledReport()
    {
        using var files=new ScanFiles();files.Write("a.txt","x");
        var report=await new FileScanner().ScanAsync(files.Request(),null,new CancellationToken(true));
        Assert.Equal(ScanCompletion.Cancelled,report.Completion);Assert.Equal(0,report.FilesScanned);
    }
    [Fact]
    public async Task DoesNotFollowFileOrDirectoryLinksOutsideScope()
    {
        using var files=new ScanFiles();using var outside=new ScanFiles();outside.Write("secret.txt","OURDLP-TEST-9999");
        File.CreateSymbolicLink(Path.Combine(files.Root,"file.txt"),Path.Combine(outside.Root,"secret.txt"));
        Directory.CreateSymbolicLink(Path.Combine(files.Root,"linked"),outside.Root);
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Empty(report.Findings);Assert.Equal(2,report.Issues.Count(issue=>issue.Code=="link"));
        await Assert.ThrowsAsync<ArgumentException>(()=>new FileScanner().ScanAsync(files.Request() with{RootPath=Path.Combine(files.Root,"linked")},null,default));
    }
    [Fact]
    public async Task LockedFileProducesAnIssueAndOtherFilesContinue()
    {
        using var files=new ScanFiles();var locked=files.Write("locked.txt","OURDLP-TEST-0001");files.Write("readable.txt","OURDLP-TEST-0002");
        using var stream=new FileStream(locked,FileMode.Open,FileAccess.ReadWrite,FileShare.None);
        var report=await new FileScanner().ScanAsync(files.Request(),null,default);
        Assert.Single(report.Findings);Assert.Contains(report.Issues,issue=>issue.Code=="access");
    }
}
