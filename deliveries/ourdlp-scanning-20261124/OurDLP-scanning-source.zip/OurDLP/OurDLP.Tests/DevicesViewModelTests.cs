using OurDLP.Contracts;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels;
using OurDLP.Server.Agents;
using Xunit;

namespace OurDLP.Tests;

public sealed class DevicesViewModelTests
{
    [Fact]
    public async Task NewCodeSelectsItsDeviceAndIsClearedAfterRegistration()
    {
        var client=new Fake();using var vm=new DevicesViewModel(client,_=>true,()=>{});
        vm.DeviceName="ПК-02";await vm.CreateCommand.ExecuteAsync();
        Assert.True(vm.Enrollment.HasCode);Assert.Equal(client.Id,vm.Selected!.Id);
        client.Status="active";await vm.RefreshCommand.ExecuteAsync();
        Assert.False(vm.Enrollment.HasCode);Assert.Equal("Активен",vm.Selected!.Status);
    }
    [Fact]
    public async Task CancelledConfirmationDoesNotReissueOrRevoke()
    {
        var client=new Fake();using var vm=new DevicesViewModel(client,_=>false,()=>{});
        await vm.RefreshCommand.ExecuteAsync();vm.Selected=Assert.Single(vm.Devices);
        await vm.ReissueCommand.ExecuteAsync();await vm.RevokeCommand.ExecuteAsync();
        Assert.Equal(0,client.Mutations);
    }
    [Fact]
    public async Task ExpiredSessionClearsCodeAndReturnsToLogin()
    {
        int expired=0;var client=new Fake();using var vm=new DevicesViewModel(client,_=>true,()=>expired++);
        vm.DeviceName="ПК";await vm.CreateCommand.ExecuteAsync();Assert.True(vm.Enrollment.HasCode);
        client.Expired=true;await vm.RefreshCommand.ExecuteAsync();
        Assert.Equal(1,expired);Assert.False(vm.Enrollment.HasCode);
    }
    private sealed class Fake:IDevicesClient
    {
        public Guid Id{get;}=Guid.NewGuid();public string Status{get;set;}="pending";public int Mutations{get;private set;}public bool Expired{get;set;}
        public Task<DeviceApiResult<DeviceListResponse>> ListAsync(CancellationToken token)=>Task.FromResult(Expired
            ?new DeviceApiResult<DeviceListResponse>(null,"expired",true)
            :new(new DeviceListResponse([new(Id,"ПК",null,null,null,null,Status,null)])));
        public Task<DeviceApiResult<EnrollmentResponse>> CreateAsync(string name,CancellationToken token)=>Task.FromResult(new DeviceApiResult<EnrollmentResponse>(new(Id,AgentSecrets.Create(),DateTimeOffset.UtcNow.AddMinutes(15))));
        public Task<DeviceApiResult<EnrollmentResponse>> ReissueAsync(Guid id,CancellationToken token){Mutations++;return CreateAsync("",token);}
        public Task<DeviceApiResult<DeviceOperationResponse>> RevokeAsync(Guid id,CancellationToken token){Mutations++;return Task.FromResult(new DeviceApiResult<DeviceOperationResponse>(new("revoked")));}
    }
}
