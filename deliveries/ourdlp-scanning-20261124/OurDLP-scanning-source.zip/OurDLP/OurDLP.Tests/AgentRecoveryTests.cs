using System.Net;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Agent;
using OurDLP.Server.Data;
using Xunit;

namespace OurDLP.Tests;

public sealed class MemoryAgentState:IAgentStateStore
{
    public AgentState? State{get;private set;}
    public Task<AgentState?> ReadAsync(CancellationToken token)=>Task.FromResult(State);
    public Task SaveAsync(AgentState state,CancellationToken token){State=state;return Task.CompletedTask;}
}

public sealed class AgentRecoveryTests
{
    [PostgresFact][Trait("Category","Postgres")]
    public async Task LostEnrollmentResponseCanRecoverAfterCodeExpiresWithoutSecondRegistration()
    {
        await using var context=await AgentTestContext.CreateAsync();var enrollment=await context.AddAsync();
        var handler=new LoseEnrollmentResponse{InnerHandler=context.Server.Server.CreateHandler()};
        using var http=new HttpClient(handler);
        var store=new MemoryAgentState();
        var first=await new AgentEnrollment(store,new AgentProtocolClient(http)).EnrollAsync("https://localhost",enrollment.Code,false,default);
        Assert.False(first.Succeeded);Assert.Null(store.State!.DeviceId);Assert.Equal(43,store.State.Token.Length);
        await using(var scope=context.Server.Services.CreateAsyncScope())
        {var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();(await db.DeviceEnrollments.SingleAsync()).ExpiresAtUtc=DateTimeOffset.UtcNow.AddMinutes(-1);await db.SaveChangesAsync();}
        var savedToken=store.State.Token;
        var recovered=await new AgentEnrollment(store,new AgentProtocolClient(http)).EnrollAsync("https://localhost",enrollment.Code,false,default);
        Assert.True(recovered.Succeeded);Assert.Equal(enrollment.DeviceId,store.State!.DeviceId);Assert.Equal(savedToken,store.State.Token);
        Assert.Equal(1,handler.Enrollments);
    }
    private sealed class LoseEnrollmentResponse:DelegatingHandler
    {
        public int Enrollments{get;private set;}
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)
        {
            var response=await base.SendAsync(request,token);
            if(request.RequestUri!.AbsolutePath=="/api/agent/enroll"){Enrollments++;response.Dispose();throw new HttpRequestException("Simulated lost response");}
            return response;
        }
    }
}
