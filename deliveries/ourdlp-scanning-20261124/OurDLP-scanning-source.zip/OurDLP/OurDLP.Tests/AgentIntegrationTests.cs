using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OurDLP.Contracts;
using OurDLP.Server.Agents;
using OurDLP.Server.Data;
using Xunit;

namespace OurDLP.Tests;

public sealed class AgentIntegrationTests
{
    private static AgentEnrollmentRequest Request(string code,string token)=>new()
    {Code=code,Token=token,HostName="WORKSTATION-02",OperatingSystem="Windows 11",AgentVersion="0.4.0"};
    private static async Task<DeviceResponse> Device(AgentTestContext context,Guid id)=>
        (await context.Admin.GetFromJsonAsync<DeviceListResponse>("/api/devices"))!.Devices.Single(device=>device.Id==id);

    [PostgresFact][Trait("Category","Postgres")]
    public async Task OneTimeEnrollmentHeartbeatIsolationAndHashedStorage()
    {
        await using var context=await AgentTestContext.CreateAsync();
        var enrollment=await context.AddAsync();
        Assert.Equal("pending",(await Device(context,enrollment.DeviceId)).Status);
        var secret=AgentSecrets.Create();
        using var agent=context.Agent();
        Assert.Equal(HttpStatusCode.OK,(await agent.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,secret))).StatusCode);
        Assert.Equal(HttpStatusCode.OK,(await agent.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,secret))).StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest,(await agent.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,AgentSecrets.Create()))).StatusCode);
        agent.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",secret);
        var heartbeat=await agent.PostAsJsonAsync("/api/agent/heartbeat",new AgentHeartbeatRequest("WORKSTATION-02","Windows 11","0.4.0"));
        Assert.Equal(HttpStatusCode.OK,heartbeat.StatusCode);
        Assert.Equal(enrollment.DeviceId,(await heartbeat.Content.ReadFromJsonAsync<AgentAcknowledgement>())!.DeviceId);
        Assert.Equal(HttpStatusCode.Unauthorized,(await agent.GetAsync("/api/devices")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await agent.GetAsync("/api/auth/me")).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await context.Admin.PostAsJsonAsync("/api/agent/heartbeat",new AgentHeartbeatRequest("x","y","z"))).StatusCode);
        var device=await Device(context,enrollment.DeviceId);
        Assert.Equal("active",device.Status);Assert.Equal("WORKSTATION-02",device.HostName);Assert.NotNull(device.LastSeenAtUtc);
        await using var scope=context.Server.Services.CreateAsyncScope();
        var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
        Assert.Equal(AgentSecrets.Hash(enrollment.Code),(await db.DeviceEnrollments.SingleAsync()).CodeHash);
        Assert.Equal(AgentSecrets.Hash(secret),(await db.DeviceCredentials.SingleAsync()).TokenHash);
        Assert.DoesNotContain(enrollment.Code,await context.Admin.GetStringAsync("/api/devices"));
        Assert.DoesNotContain(secret,await context.Admin.GetStringAsync("/api/devices"));
        Assert.Equal(1,await db.DeviceAudit.CountAsync(row=>row.Action=="agent.registered"));
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task ExpiredCodeAndAnonymousAdminRequestsAreRejected()
    {
        await using var context=await AgentTestContext.CreateAsync();
        var enrollment=await context.AddAsync();
        await using(var scope=context.Server.Services.CreateAsyncScope())
        {
            var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();
            var row=await db.DeviceEnrollments.SingleAsync();row.ExpiresAtUtc=DateTimeOffset.UtcNow.AddSeconds(-1);await db.SaveChangesAsync();
        }
        using var agent=context.Agent();
        Assert.Equal(HttpStatusCode.BadRequest,(await agent.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,AgentSecrets.Create()))).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await agent.PostAsJsonAsync("/api/devices",new CreateDeviceRequest{Name="unauthorized"})).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await agent.GetAsync("/api/devices")).StatusCode);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task ConcurrentUseOfCodeCanActivateOnlyOneCredential()
    {
        await using var context=await AgentTestContext.CreateAsync();
        var enrollment=await context.AddAsync();
        using var first=context.Agent();using var second=context.Agent();
        var results=await Task.WhenAll(first.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,AgentSecrets.Create())),
            second.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,AgentSecrets.Create())));
        Assert.Single(results,result=>result.StatusCode==HttpStatusCode.OK);
        Assert.Single(results,result=>result.StatusCode==HttpStatusCode.BadRequest);
        await using var scope=context.Server.Services.CreateAsyncScope();
        Assert.Equal(1,await scope.ServiceProvider.GetRequiredService<OurDlpDbContext>().DeviceCredentials.CountAsync());
        foreach(var result in results)result.Dispose();
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task ReissueAndRevokeInvalidatePreviousAgentAndOfflineIsDistinct()
    {
        await using var context=await AgentTestContext.CreateAsync();var enrollment=await context.AddAsync();
        using var agent=context.Agent();var old=AgentSecrets.Create();
        Assert.Equal(HttpStatusCode.OK,(await agent.PostAsJsonAsync("/api/agent/enroll",Request(enrollment.Code,old))).StatusCode);
        await using(var scope=context.Server.Services.CreateAsyncScope())
        {var db=scope.ServiceProvider.GetRequiredService<OurDlpDbContext>();(await db.Devices.SingleAsync()).LastSeenAtUtc=DateTimeOffset.UtcNow.AddMinutes(-3);await db.SaveChangesAsync();}
        Assert.Equal("offline",(await Device(context,enrollment.DeviceId)).Status);
        var next=(await (await context.Admin.PostAsync($"/api/devices/{enrollment.DeviceId}/enrollment",null)).Content.ReadFromJsonAsync<EnrollmentResponse>())!;
        agent.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",old);
        Assert.Equal(HttpStatusCode.Unauthorized,(await agent.PostAsJsonAsync("/api/agent/heartbeat",new AgentHeartbeatRequest("x","y","z"))).StatusCode);
        Assert.Equal("pending",(await Device(context,enrollment.DeviceId)).Status);
        var fresh=AgentSecrets.Create();
        Assert.Equal(HttpStatusCode.OK,(await agent.PostAsJsonAsync("/api/agent/enroll",Request(next.Code,fresh))).StatusCode);
        Assert.True((await context.Admin.PostAsync($"/api/devices/{enrollment.DeviceId}/revoke",null)).IsSuccessStatusCode);
        agent.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",fresh);
        Assert.Equal(HttpStatusCode.Unauthorized,(await agent.PostAsJsonAsync("/api/agent/heartbeat",new AgentHeartbeatRequest("x","y","z"))).StatusCode);
        Assert.Equal("revoked",(await Device(context,enrollment.DeviceId)).Status);
    }

    [PostgresFact][Trait("Category","Postgres")]
    public async Task AgentCannotSelectAnotherDeviceWithRequestBody()
    {
        await using var context=await AgentTestContext.CreateAsync();var own=await context.AddAsync();var other=await context.AddAsync("OTHER-PC");
        using var agent=context.Agent();var secret=AgentSecrets.Create();
        Assert.True((await agent.PostAsJsonAsync("/api/agent/enroll",Request(own.Code,secret))).IsSuccessStatusCode);
        agent.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",secret);
        var response=await agent.PostAsJsonAsync("/api/agent/heartbeat",new{DeviceId=other.DeviceId,HostName="OWN",OperatingSystem="Windows",AgentVersion="0.4.0"});
        Assert.Equal(own.DeviceId,(await response.Content.ReadFromJsonAsync<AgentAcknowledgement>())!.DeviceId);
        Assert.Null((await Device(context,other.DeviceId)).LastSeenAtUtc);
    }
}
