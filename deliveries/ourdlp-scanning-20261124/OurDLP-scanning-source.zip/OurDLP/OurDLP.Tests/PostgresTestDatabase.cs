using System.Text.Json;
using Npgsql;
using Xunit;

namespace OurDLP.Tests;

public sealed class PostgresFactAttribute:FactAttribute
{
    public PostgresFactAttribute()
    {
        if(string.IsNullOrEmpty(Environment.GetEnvironmentVariable("OURDLP_TEST_POSTGRES_SETTINGS")))
            Skip="Requires a local disposable PostgreSQL instance and private test settings file.";
    }
}

public sealed class PostgresTestDatabase:IAsyncDisposable
{
    private readonly string _admin;
    private readonly string _name="ourdlp_test_"+Guid.NewGuid().ToString("N");
    private readonly string _role="ourdlp_role_"+Guid.NewGuid().ToString("N");
    public string ConnectionString{get;private set;}="";
    public string WrongPasswordConnectionString => new NpgsqlConnectionStringBuilder(ConnectionString){Password="definitely-wrong-test-password"}.ConnectionString;
    private PostgresTestDatabase(string admin)=>_admin=admin;

    public static async Task<PostgresTestDatabase> CreateAsync()
    {
        using var settings=JsonDocument.Parse(await File.ReadAllTextAsync(Environment.GetEnvironmentVariable("OURDLP_TEST_POSTGRES_SETTINGS")!));
        var db=new PostgresTestDatabase(settings.RootElement.GetProperty("Admin").GetString()!);
        var password=settings.RootElement.GetProperty("AppPassword").GetString()!;
        Assert.Matches("^[0-9a-f]+$",password);
        await using var admin=new NpgsqlConnection(db._admin);
        await admin.OpenAsync();
        await new NpgsqlCommand($"CREATE ROLE {db._role} WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD '{password}'",admin).ExecuteNonQueryAsync();
        await new NpgsqlCommand($"CREATE DATABASE {db._name} OWNER {db._role}",admin).ExecuteNonQueryAsync();
        db.ConnectionString=new NpgsqlConnectionStringBuilder(db._admin){Database=db._name,Username=db._role,Password=password,Timeout=3,CommandTimeout=3}.ConnectionString;
        return db;
    }

    public async ValueTask DisposeAsync()
    {
        NpgsqlConnection.ClearAllPools();
        await using var admin=new NpgsqlConnection(_admin);
        await admin.OpenAsync();
        await new NpgsqlCommand($"DROP DATABASE IF EXISTS {_name} WITH (FORCE)",admin).ExecuteNonQueryAsync();
        await new NpgsqlCommand($"DROP ROLE IF EXISTS {_role}",admin).ExecuteNonQueryAsync();
    }
}
