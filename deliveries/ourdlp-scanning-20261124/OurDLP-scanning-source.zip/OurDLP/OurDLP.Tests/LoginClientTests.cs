using System.Net;
using System.Net.Http.Json;
using OurDLP.Contracts;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels;
using Xunit;

namespace OurDLP.Tests;

public sealed class LoginClientTests:IDisposable
{
    private readonly string _directory=Path.Combine(Path.GetTempPath(),"ourdlp-login-"+Guid.NewGuid().ToString("N"));
    private JsonSettingsStore Store=>new(Path.Combine(_directory,"address.json"));
    private static readonly AdministratorResponse User=new(Guid.NewGuid(),"admin",DateTimeOffset.UtcNow.AddHours(8));

    [Theory]
    [InlineData(400)][InlineData(401)][InlineData(403)][InlineData(404)][InlineData(429)][InlineData(503)][InlineData(500)]
    public async Task FailedHttpResponseNeverOpensSession(int status)
    {
        using var http=new HttpClient(new Handler((_,_)=>Task.FromResult(new HttpResponseMessage((HttpStatusCode)status))));
        var result=await new AuthenticationClient(http).LoginAsync("https://localhost","admin","secret-test",default);
        Assert.False(result.Succeeded);
        Assert.DoesNotContain("secret-test",result.Message);
        Assert.NotEmpty(result.Message);
    }

    [Fact]
    public async Task ALoginResponseAloneCannotAuthenticateWithoutProtectedMe()
    {
        int calls=0;
        using var http=new HttpClient(new Handler((request,_)=>
        {
            calls++;
            return Task.FromResult(request.RequestUri!.AbsolutePath.EndsWith("/login")
                ? new HttpResponseMessage(HttpStatusCode.OK){Content=JsonContent.Create(User)}
                : new HttpResponseMessage(HttpStatusCode.Unauthorized));
        }));
        var result=await new AuthenticationClient(http).LoginAsync("https://localhost","admin","password",default);
        Assert.False(result.Succeeded);
        Assert.Equal(2,calls);
    }

    [Fact]
    public async Task LoginOnlySavesAddressAndConcurrentClickDoesNotDuplicateRequest()
    {
        var fake=new ControlledAuth();
        using var vm=new LoginViewModel(Store,fake);
        var task=vm.SignInAsync("PrivateTestPassword1");
        Assert.False(vm.CanSignIn);
        Assert.Null(await vm.SignInAsync("Duplicate1"));
        fake.Pending.SetResult(new(User,""));
        Assert.NotNull(await task);
        Assert.Equal(1,fake.Calls);
        var file=File.ReadAllText(Path.Combine(_directory,"address.json"));
        Assert.Equal("\"https://localhost:7443\"",file);
        Assert.DoesNotContain("PrivateTestPassword1",file);
        Assert.DoesNotContain("admin",file);
    }

    [Fact]
    public async Task ClosingLoginCancelsAndDoesNotPublishALateSuccess()
    {
        var fake=new ControlledAuth();
        var vm=new LoginViewModel(Store,fake);
        var task=vm.SignInAsync("Password1");
        vm.Dispose();
        Assert.True(fake.Token.IsCancellationRequested);
        fake.Pending.SetResult(new(User,""));
        Assert.Null(await task);
        Assert.False(File.Exists(Path.Combine(_directory,"address.json")));
        vm.Dispose();
    }

    [Fact]
    public async Task ReadOnlyConnectionAddressIsBoundToAuthenticatedServer()
    {
        var client=new ControlledStatus();
        using var connection=new ServerConnectionViewModel(client);
        var settings=new SettingsViewModel(Store,connection,canEditAddress:false);
        var original=settings.ServerAddress;
        settings.ServerAddress="https://different-server";
        settings.SaveCommand.Execute(null);
        Assert.Equal(original,settings.ServerAddress);
        Assert.True(settings.IsAddressReadOnly);
        await connection.CheckCommand.ExecuteAsync();
        Assert.Equal(original,client.Address);
    }

    public void Dispose(){if(Directory.Exists(_directory))Directory.Delete(_directory,true);}
    private sealed class Handler(Func<HttpRequestMessage,CancellationToken,Task<HttpResponseMessage>> send):HttpMessageHandler
    {protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)=>send(request,token);}
    private sealed class ControlledAuth:IAuthenticationClient
    {
        public TaskCompletionSource<LoginAttempt> Pending{get;}=new();
        public int Calls{get;private set;}
        public CancellationToken Token{get;private set;}
        public Task<LoginAttempt> LoginAsync(string address,string userName,string password,CancellationToken token){Calls++;Token=token;return Pending.Task;}
        public Task<bool> LogoutAsync(string address,CancellationToken token)=>Task.FromResult(true);
        public Task<bool?> IsSessionValidAsync(string address,Guid expectedUser,CancellationToken token)=>Task.FromResult<bool?>(true);
    }
    private sealed class ControlledStatus:IServerStatusClient
    {
        public string? Address{get;private set;}
        public Task<ServerProbeResult> ProbeAsync(string address,CancellationToken token){Address=address;return Task.FromResult(new ServerProbeResult(true,"ok"));}
    }
}
