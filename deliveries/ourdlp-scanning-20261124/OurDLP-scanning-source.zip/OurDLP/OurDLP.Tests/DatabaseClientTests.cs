using System.Net;
using OurDLP.Contracts;
using OurDLP.Desktop.Models;
using OurDLP.Desktop.Services;
using OurDLP.Desktop.ViewModels;
using Xunit;

namespace OurDLP.Tests;

public sealed class DatabaseClientTests
{
    [Theory]
    [InlineData(200,"ready",true)]
    [InlineData(503,"not-configured",false)]
    [InlineData(503,"migration-required",false)]
    [InlineData(503,"unavailable",false)]
    public async Task ReadsExpectedStatus(int code,string status,bool ready)
    {
        using var http = new HttpClient(new Handler(code, $$"""{"status":"{{status}}","message":"detail"}"""));
        var result = await new DatabaseApiClient(http).ProbeAsync("https://localhost:7443",default);
        Assert.Equal(status,result.Status);
        Assert.Equal(ready,result.Status=="ready");
    }

    [Theory]
    [InlineData(503,"{\"status\":\"ready\",\"message\":\"wrong\"}")]
    [InlineData(200,"not json")]
    [InlineData(200,"{}")]
    [InlineData(404,"")]
    public async Task CannotMistakeInvalidResponseForReady(int code,string json)
    {
        using var http = new HttpClient(new Handler(code,json));
        Assert.Equal("unavailable",(await new DatabaseApiClient(http).ProbeAsync("https://localhost",default)).Status);
    }

    [Fact]
    public async Task ApiSuccessDoesNotImplyDatabaseSuccessAndAddressEditClearsBoth()
    {
        var database = new FakeDatabase();
        using var vm = new ServerConnectionViewModel(new ServerReadinessClient(new FakeApi(true),database));
        vm.SetAddress("https://localhost");
        await vm.CheckCommand.ExecuteAsync();
        Assert.True(vm.IsAvailable);
        Assert.False(vm.IsDatabaseReady);
        Assert.Equal("Не настроена",vm.DatabaseStatusText);
        Assert.Equal(1,database.Calls);
        vm.SetAddress("https://other");
        Assert.Null(vm.Snapshot.Database);
        Assert.Equal("Не проверено",vm.DatabaseStatusText);
    }

    [Fact]
    public async Task DoesNotCallDatabaseIfApiFailed()
    {
        var database = new FakeDatabase();
        var result=await new ServerReadinessClient(new FakeApi(false),database).ProbeAsync("https://localhost",default);
        Assert.False(result.Available);
        Assert.Null(result.Database);
        Assert.Equal(0,database.Calls);
    }

    private sealed class FakeApi(bool ready):IServerStatusClient
    {
        public Task<ServerProbeResult> ProbeAsync(string address,CancellationToken cancellationToken)=>Task.FromResult(new ServerProbeResult(ready,"api"));
    }
    private sealed class FakeDatabase:IDatabaseStatusClient
    {
        public int Calls{get;private set;}
        public Task<DatabaseStatusResponse> ProbeAsync(string address,CancellationToken cancellationToken)
        { Calls++;return Task.FromResult(new DatabaseStatusResponse("not-configured","configure")); }
    }
    private sealed class Handler(int code,string json):HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)
        {
            Assert.Equal("/api/health/database",request.RequestUri!.AbsolutePath);
            return Task.FromResult(new HttpResponseMessage((HttpStatusCode)code){Content=new StringContent(json,System.Text.Encoding.UTF8,"application/json")});
        }
    }
}
