using System.Net;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using OurDLP.Contracts;
using OurDLP.Server.Data;
using OurDLP.Server.Data.Entities;
using Xunit;

namespace OurDLP.Tests;

public sealed class PostgresIntegrationTests
{
    [PostgresFact]
    [Trait("Category","Postgres")]
    public async Task ExplicitMigrationIsRepeatableAndDataSurvivesNewContext()
    {
        await using var database=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(database.ConnectionString);
        using var client=server.CreateClient();
        using(var pending=await client.GetAsync("/api/health/database"))
        {
            Assert.Equal(HttpStatusCode.ServiceUnavailable,pending.StatusCode);
            Assert.Equal("migration-required",(await pending.Content.ReadFromJsonAsync<DatabaseStatusResponse>())!.Status);
        }
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        var factory=server.Services.GetRequiredService<IDbContextFactory<OurDlpDbContext>>();
        var id=Guid.NewGuid();
        await using(var first=await factory.CreateDbContextAsync())
        {
            first.Devices.Add(new Device{Id=id,Name="OURDLP-TEST-PC",CreatedAtUtc=DateTimeOffset.UtcNow});
            await first.SaveChangesAsync();
        }
        await using(var second=await factory.CreateDbContextAsync())
        {
            Assert.Equal("OURDLP-TEST-PC",(await second.Devices.SingleAsync(device=>device.Id==id)).Name);
            Assert.Empty(await second.Database.GetPendingMigrationsAsync());
        }
        using var ready=await client.GetAsync("/api/health/database");
        Assert.Equal(HttpStatusCode.OK,ready.StatusCode);
        Assert.Equal("ready",(await ready.Content.ReadFromJsonAsync<DatabaseStatusResponse>())!.Status);
        await using var connection=new NpgsqlConnection(database.ConnectionString);
        await connection.OpenAsync();
        var privileged=await new NpgsqlCommand("SELECT rolsuper OR rolcreatedb OR rolcreaterole FROM pg_roles WHERE rolname=current_user",connection).ExecuteScalarAsync();
        Assert.Equal(false,privileged);
    }

    [PostgresFact]
    [Trait("Category","Postgres")]
    public async Task WrongCredentialsDoNotLeakAndDoNotTakeApiDown()
    {
        await using var database=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(database.WrongPasswordConnectionString);
        using var client=server.CreateClient();
        using var response=await client.GetAsync("/api/health/database");
        Assert.Equal(HttpStatusCode.ServiceUnavailable,response.StatusCode);
        var text=await response.Content.ReadAsStringAsync();
        Assert.DoesNotContain("definitely-wrong-test-password",text);
        Assert.DoesNotContain("Password=",text);
        Assert.Contains("unavailable",text);
        Assert.Equal(HttpStatusCode.OK,(await client.GetAsync("/api/status")).StatusCode);
    }

    [PostgresFact]
    [Trait("Category","Postgres")]
    public async Task RecordedMigrationWithMissingTableIsNotReportedReady()
    {
        await using var database=await PostgresTestDatabase.CreateAsync();
        await using var server=new DatabaseTestServer(database.ConnectionString);
        using var client=server.CreateClient();
        Assert.Equal(0,await DatabaseMigrationRunner.RunAsync(server.Services));
        await using var connection=new NpgsqlConnection(database.ConnectionString);
        await connection.OpenAsync();
        await new NpgsqlCommand("DROP TABLE devices CASCADE",connection).ExecuteNonQueryAsync();
        using var response=await client.GetAsync("/api/health/database");
        Assert.Equal(HttpStatusCode.ServiceUnavailable,response.StatusCode);
        Assert.Equal("unavailable",(await response.Content.ReadFromJsonAsync<DatabaseStatusResponse>())!.Status);
    }
}
